import copy,json
from jsonschema import Draft202012Validator,FormatChecker
from validator import ROOT,Invalid
from rules import verified_estimate_allowed
checks=[]
def test(name,condition):
 assert condition,name;checks.append({'name':name,'passed':True})
schema=json.loads((ROOT/'contracts/foundation-extension.data.schema.json').read_text());Draft202012Validator.check_schema(schema);test('extension_schema_metaschema',True)
v=Draft202012Validator(schema,format_checker=FormatChecker());xs=json.loads((ROOT/'examples/foundation-extension.json').read_text())
for x in xs:test('valid_extension_'+x['kind'],v.is_valid(x))
old_schema=json.loads((ROOT/'contracts/baseline-foundation.commands.schema.json').read_text());old=Draft202012Validator(old_schema)
policy=xs[1]['data'];base={'contract':'brant.foundation/0.1.0','command':'foundation.save','idempotency_key':'adapter.1','args':{'id':'policy.1','expected_version':0,'kind':'pricing_policy','data':{k:val for k,val in policy.items() if k!='allow_verified_estimates'},'evidence_ids':['source.1']}}
test('baseline_policy_original_shape_accepted',old.is_valid(base))
new=copy.deepcopy(base);new['args']['data']['allow_verified_estimates']=True
test('baseline_rejects_hidden_estimate_field',not old.is_valid(new))
no_flag=copy.deepcopy(xs[1]);no_flag['data'].pop('allow_verified_estimates')
test('new_extension_requires_explicit_estimate_flag',not v.is_valid(no_flag))
invalid=copy.deepcopy(xs[0]);invalid['data']['country']='CN\n';test('location_country_no_newline',not v.is_valid(invalid))
invalid=copy.deepcopy(xs[0]);invalid['data']['place_type']='zone';test('complex_zone_not_silently_supported',not v.is_valid(invalid))
invalid=copy.deepcopy(xs[1]);invalid['contract']='brant.foundation/0.1.0';test('extension_cannot_impersonate_baseline',not v.is_valid(invalid))
invalid=copy.deepcopy(xs[1]);invalid['data']['minimum_margin']='0.123456789';test('new_margin_max8_decimals',not v.is_valid(invalid))
invalid=copy.deepcopy(xs[1]);invalid['data']['minimum_margin']='1.1';test('margin_cannot_exceed_one',not v.is_valid(invalid))
try:verified_estimate_allowed('estimated',{})
except Invalid as e:test('old_policy_missing_flag_defaults_deny',e.code=='COST_INPUT_NOT_READY')
else:raise AssertionError('old missing flag accepted')
# Candidate data only; no claim of migrated foundation runtime.
report={'checks_passed':len(checks),'checks':checks,'baseline_contract_changed':False,'candidate_payload_shape_verified':True,'runtime_adapter_implemented':False}
(ROOT/'evidence/adapter-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'adapter_shape_checks':len(checks),'runtime_adapter':False}))
