import copy
import hashlib
import json
import sqlite3
import sys
from datetime import datetime,timezone
from pathlib import Path
import jsonschema
from validator import V, ROOT, REG, SCHEMA, Invalid, allocate, canonical, canonical_business, digest, evaluate_fixture, minor, validate
checks=[];negative=[]
def record(name,category):checks.append({'name':name,'category':category,'passed':True})
def expect(name,fn,code,category='cross_field'):
 try:fn()
 except Invalid as e:
  assert e.code==code,(name,e.code,code);record(name,category)
 else:raise AssertionError(name+' unexpectedly accepted')
def save(n,x):(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
valid=json.loads((ROOT/'examples/valid.json').read_text())
V.check_schema(SCHEMA);record('command_schema_metaschema','schema')
response=json.loads((ROOT/'contracts/response.schema.json').read_text());jsonschema.Draft202012Validator.check_schema(response);record('response_schema_metaschema','schema')
for i,v in enumerate(valid):validate(v);record('valid_'+v['command'],'schema_and_selected_cross_field')
# Every candidate branch gets a concrete shape example. These examples assert schema only,
# not that IDs/version/state/permissions make it executable against the registry.
def shape(s):
 if '$ref' in s:return shape(SCHEMA['$defs'][s['$ref'].split('/')[-1]])
 if 'const' in s:return s['const']
 if 'enum' in s:return s['enum'][0]
 if 'oneOf' in s:return shape(s['oneOf'][0])
 if s.get('type')=='object':return {k:shape(s['properties'][k]) for k in s.get('required',[])}
 if s.get('type')=='array':return [shape(s['items']) for _ in range(s.get('minItems',0))]
 if s.get('type')=='integer':return s.get('minimum',0)
 if s.get('type')=='boolean':return False
 if s.get('format')=='date-time':return '2026-10-22T09:00:00Z'
 if s.get('format')=='date':return '2026-11-15'
 if '64' in s.get('pattern',''):return '0'*64
 if s.get('maxLength')==40:return '1'
 return 'example.1'
shapes=[shape(s) for s in SCHEMA['oneOf']]
for req in shapes:
 V.validate(req);record('branch_shape_'+req['command'],'schema_only')
save('examples/command_shapes.json',shapes)
rv=jsonschema.Draft202012Validator(response)
for i,v in enumerate(json.loads((ROOT/'examples/responses.json').read_text())):rv.validate(v);record('response_'+str(i),'schema')
def neg(name,index,edit,code):
 v=copy.deepcopy(valid[index]);edit(v);negative.append({'name':name,'request':v,'expected_code':code});expect(name,lambda:validate(v),code)
neg('forged_company',0,lambda v:v.update(company='forged'),'SCHEMA_INVALID')
neg('unknown_data_field',0,lambda v:v['args']['data'].update(surprise=True),'SCHEMA_INVALID')
neg('null_quantity',0,lambda v:v['args']['data']['lines'][0].update(quantity=None),'SCHEMA_INVALID')
neg('float_quantity',0,lambda v:v['args']['data']['lines'][0].update(quantity=120.0),'SCHEMA_INVALID')
neg('quantity_over_scale',0,lambda v:v['args']['data']['lines'][0].update(quantity='120.0000001'),'SCHEMA_INVALID')
neg('fractional_PCS',0,lambda v:v['args']['data']['lines'][0].update(quantity='120.5'),'INVALID_KNOWN_VALUE')
neg('demand_changed',0,lambda v:v['args']['data']['lines'][0].update(quantity='100'),'COMPARISON_BASIS_MISMATCH')
neg('duplicate_context_line',0,lambda v:v['args']['data']['lines'].append(copy.deepcopy(v['args']['data']['lines'][0])),'DUPLICATE_LINE_ID')
neg('stale_RFQ_version',0,lambda v:v['args']['data']['rfq_ref'].update(row_version=1),'REFERENCE_STALE')
neg('group_price_tier_rejected',1,lambda v:v['args']['data']['lines'][0].update(price_tier_scope='explicit_group'),'SCHEMA_INVALID')
neg('offer_expired_at_boundary',1,lambda v:v['args']['data']['interval'].update(valid_until=REG['as_of']),'REFERENCE_STALE')
neg('unsolicited_fabricated_RFQ',1,lambda v:v['args']['data']['origin'].update(supplier_rfq_ref={'id':'invented','row_version':1}),'SCHEMA_INVALID')
neg('response_missing_RFQ',1,lambda v:v['args']['data'].update(origin={'kind':'in_response_to_rfq'}),'SCHEMA_INVALID')
neg('zero_price_without_reason',1,lambda v:v['args']['data']['lines'][0]['tiers'][0].update(unit_price='0'),'COST_INPUT_NOT_READY')
neg('duplicate_fee_obligation',3,lambda v:v['args']['data']['fees'].append({**copy.deepcopy(v['args']['data']['fees'][0]),'id':'F2'}),'CHARGE_DOUBLE_COUNT')
neg('different_destination',3,lambda v:v['args']['data'].update(destination_ref={'kind':'location','id':'origin.test','revision':1}),'REFERENCE_INVALID')
neg('MOQ_not_met',4,lambda v:v['args']['data']['allocations'][0].update(purchase_quantity='99'),'MOQ_NOT_MET')
neg('gross_below_net',5,lambda v:v['args']['data']['packages'][0].update(gross_kg='1'),'INVALID_KNOWN_VALUE')
neg('declared_volume_conflict',5,lambda v:v['args']['data'].update(declared_volume_m3='2'),'MEASUREMENT_CONFLICT')
save('examples/invalid.json',negative)
partial=copy.deepcopy(valid[0]);partial['args']['data']={};validate(partial);record('empty_draft_allowed','schema_and_selected_cross_field')
assert allocate(5,[1,1,1])==[2,2,1];record('equal_weights_integer_remainder','arithmetic')
expect('zero_allocation_base',lambda:allocate(5,[0,0]),'ALLOCATION_INVALID','arithmetic')
def fixed(seq):
 w=[1,1]
 for n in seq:w=[x+y for x,y in zip(w,allocate(n,[1,1]))]
 return w
assert fixed([1,4])==fixed([4,1])==[4,3];record('fixed_base_order_invariant','arithmetic')
assert minor('0.005')*2==2 and minor('0.010')==1;record('line_rounding_vs_fragment_sum','arithmetic')
assert max(10,1)+max(1,10)==20 and max(11,11)==11;record('chargeable_max_scope_difference','arithmetic')
actual=evaluate_fixture(REG);expected=json.loads((ROOT/'examples/expected.json').read_text());assert all(actual[k]==expected[k] for k in actual);record('synthetic_120x5_plus60','fixture_arithmetic_only')
a={'quantity':'1.00','source_text':'1.00','id':'x.1'};b={'quantity':'1','source_text':'1.00','id':'x.1'}
assert digest(a)!=digest(b) and digest(canonical_business(a))==digest(canonical_business(b));record('request_hash_vs_business_hash','hash')
vectors=[{'input':x,'request_canonical':canonical(x),'request_hash':digest(x),'business_payload':canonical_business(x),'business_canonical':canonical(canonical_business(x)),'business_hash':digest(canonical_business(x))} for x in [a,b,valid[1]['args']['data']]]
save('examples/hash_vectors.json',vectors)
# SQLite reference constraints, not full transaction service.
sql=(ROOT/'contracts/reference.sql').read_text();db=sqlite3.connect(':memory:');db.executescript(sql)
db.execute("INSERT INTO scope VALUES('t','a')");db.execute("INSERT INTO scope VALUES('t','b')")
db.execute("INSERT INTO actor VALUES('t','a','human.1','human')")
db.commit();record('reference_DDL_loads','sqlite')
def rejected_sql(name,fn):
 try:
  db.execute('SAVEPOINT test');fn();db.execute('RELEASE test')
 except sqlite3.IntegrityError:
  db.execute('ROLLBACK TO test');db.execute('RELEASE test');record(name,'sqlite')
 else:raise AssertionError(name+' unexpectedly accepted')
# Insert valid root/revision in deferred transaction.
db.execute("INSERT INTO object_root VALUES('t','a','offer','o',1,1,NULL,NULL)")
db.execute("INSERT INTO object_revision VALUES('t','a','offer','o',1,1,'human.1','{}',?)",('a'*64,));db.commit()
rejected_sql('sealed_revision_cannot_update',lambda:db.execute("UPDATE object_revision SET payload_json='{}'"))
rejected_sql('cross_company_dependency_rejected',lambda:db.execute("INSERT INTO dependency VALUES('t','b','offer','o',1,'offer','o',1)"))
rejected_sql('cross_company_actor_rejected',lambda:db.execute("INSERT INTO source_denial VALUES('t','b','deny.1','source.1','human.1','now','reason','[]')"))
db.execute("INSERT INTO scenario VALUES('t','a','s',1,'draft','{}')")
db.execute("INSERT INTO evaluation VALUES('t','a','e','s',1,1,'now',?,?, '{}')",('a'*64,'b'*64))
db.execute("UPDATE scenario SET status='frozen',row_version=2 WHERE id='s'")
db.execute("INSERT INTO cost_snapshot VALUES('t','a','snap','s',1,2,'e',?,'{}')",('b'*64,));db.commit()
record('correct_evaluation_freeze_binding','sqlite')
rejected_sql('second_snapshot_same_scenario_rejected',lambda:db.execute("INSERT INTO cost_snapshot VALUES('t','a','snap2','s',1,2,'e',?,'{}')",('b'*64,)))
db.execute("INSERT INTO scenario VALUES('t','a','s2',2,'frozen','{}')")
db.execute("INSERT INTO evaluation VALUES('t','a','e2','s2',1,1,'now',?,?, '{}')",('a'*64,'b'*64));db.commit()
rejected_sql('snapshot_wrong_result_hash_rejected',lambda:db.execute("INSERT INTO cost_snapshot VALUES('t','a','snap3','s2',1,2,'e2',?,'{}')",('c'*64,)))
rejected_sql('frozen_scenario_cannot_edit',lambda:db.execute("UPDATE scenario SET payload_json='{}' WHERE id='s'"))
rejected_sql('snapshot_cannot_edit',lambda:db.execute("UPDATE cost_snapshot SET payload_json='{}' WHERE id='snap'"))
db.execute("INSERT INTO cost_component VALUES('t','a','snap','C1','freight',60,'USD',0)")
rejected_sql('same_obligation_cannot_count_twice',lambda:db.execute("INSERT INTO cost_component VALUES('t','a','snap','C2','freight',60,'USD',0)"))
rejected_sql('cost_component_cannot_edit',lambda:db.execute("UPDATE cost_component SET amount_minor=99"))
# Expected partial transactional write rolls back without retained scenario.
db.commit();db.execute('BEGIN')
try:
 db.execute("INSERT INTO scenario VALUES('t','a','rollback.test',1,'draft','{}')")
 db.execute("INSERT INTO outbox VALUES('t','a','event.bad','missing','{}')")
except sqlite3.IntegrityError:db.rollback()
assert db.execute("SELECT count(*) FROM scenario WHERE id='rollback.test'").fetchone()[0]==0;record('partial_write_rollback','sqlite')
report={'executed_at':datetime.now(timezone.utc).isoformat(),'python':sys.version.split()[0],'jsonschema':__import__('importlib.metadata',fromlist=['version']).version('jsonschema'),'candidate_contract':'brant.costing/0.1.0','command_branches':len(SCHEMA['oneOf']),'checks_passed':len(checks),'checks':checks,'fixture_result':actual,'model_calls':0,'external_actions':0,'t02_business_service_implemented':False,'production_migration_executed':False,'permission_runtime_tested':False,'concurrent_freeze_runtime_tested':False,'full_contract_readiness':False,'limitations':['35 command branches have schema shape validation, not all lifecycle semantics.','Cross-field validator covers selected fixture paths only; not complete costing engine.','Standalone SQLite DDL is not a migration into existing T01 database.','Authentication, scopes, independent review, FX, all tiers and live effect transitions remain service implementation gates.']}
save('evidence/verification.json',report)
print(json.dumps({k:report[k] for k in ['command_branches','checks_passed','fixture_result','t02_business_service_implemented','full_contract_readiness']},ensure_ascii=False))
