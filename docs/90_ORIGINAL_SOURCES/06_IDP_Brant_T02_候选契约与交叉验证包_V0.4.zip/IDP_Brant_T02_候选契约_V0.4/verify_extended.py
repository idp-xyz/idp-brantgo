import copy,json,hashlib
from pathlib import Path
from fractions import Fraction
from validator import ROOT,REG,Invalid,allocate,minor,canonical,canonical_business,digest
from rules import purchase_groups,tiers_cost,fee_graph,split_tax,fx_cost,chargeable,bill,source_effect,dependency_access,RevisionModel
checks=[];cases=[]
def ok(name,test):
 test();checks.append({'name':name,'passed':True})
def eq(a,b):assert a==b,(a,b)
def reject(name,code,fn):
 try:fn()
 except Invalid as e:assert e.code==code,(name,e.code,code);checks.append({'name':name,'passed':True,'expected_rejection':code})
 else:raise AssertionError(name+' accepted')
base=copy.deepcopy(REG['verified_business'][1]['data']);context=copy.deepcopy(REG['verified_business'][0]['data'])
source={'kind':'offer','id':'offer.1','revision':1,'condition_line_id':'OL1'};unit=base['lines'][0]['purchase_unit_ref']
def scenario(parts,src=source):return {'allocations':[{'rfq_line_id':line,'purchase_quantity':str(q),'purchase_unit_ref':unit,'source':copy.deepcopy(src)} for line,q in parts]}
def resolve(src):
 if src['id'] not in ('offer.1','offer.2'):raise Invalid('REFERENCE_INVALID','/source')
 return copy.deepcopy(base)
ok('split_allocations_60_plus60_satisfy_same_SKU_MOQ100',lambda:eq(purchase_groups(scenario([('L1',60),('L1',60)]),context,resolve)[0]['raw_amount'],600))
reject('other_supplier_quantity_cannot_fill_MOQ','MOQ_NOT_MET',lambda:purchase_groups({'allocations':scenario([('L1',60)])['allocations']+scenario([('L1',60)],{**source,'id':'offer.2'})['allocations']},context,resolve))
reject('unmatched_demand_quantity','COMPARISON_BASIS_MISMATCH',lambda:purchase_groups(scenario([('L1',130)]),context,resolve))
# Aggregate selected same commercial line across two demand rows, pricing once.
ctx=copy.deepcopy(context);ctx['lines']=[{**ctx['lines'][0],'line_id':'A','quantity':'60'},{**ctx['lines'][0],'line_id':'B','quantity':'60'}]
ok('one_offer_line_multiple_demand_rows_prices_once',lambda:eq(len(purchase_groups(scenario([('A',60),('B',60)]),ctx,resolve)),1))
group_offer=copy.deepcopy(base);group_context=copy.deepcopy(ctx)
for i,line in enumerate(group_context['lines']):line['sku_profile_ref']={**line['sku_profile_ref'],'id':'sku.'+str(i+1)}
group_offer['lines']=[]
for i,line in enumerate(group_context['lines']):
 cond=copy.deepcopy(base['lines'][0]);cond['id']='O'+str(i);cond['sku_profile_ref']=line['sku_profile_ref'];cond['moq']={'quantity':'100','unit_ref':unit,'scope':'explicit_group','group_id':'G','member_line_ids':['A','B']};group_offer['lines'].append(cond)
gs=scenario([('A',60),('B',60)])
for i,a in enumerate(gs['allocations']):a['source']['condition_line_id']='O'+str(i)
ok('cross_SKU_explicit_group_MOQ_only',lambda:eq(sum(x['raw_amount'] for x in purchase_groups(gs,group_context,lambda s:group_offer)),600))
bad_group=copy.deepcopy(gs);bad_group['allocations'][1]['source']['id']='offer.2'
reject('group_MOQ_cannot_mix_offer_roots','MOQ_NOT_MET',lambda:purchase_groups(bad_group,group_context,lambda s:group_offer))
cond={**base['lines'][0],'pricing_mode':'all_units','tiers':[{'lower_inclusive':'0','upper_exclusive':'100','unit_price':'5'},{'lower_inclusive':'100','unit_price':'4'}]}
ok('all_units150_is600',lambda:eq(tiers_cost('150',cond),600))
ok('all_units_boundary100_is400',lambda:eq(tiers_cost('100',cond),400))
ok('graduated150_is700',lambda:eq(tiers_cost('150',{**cond,'pricing_mode':'graduated'}),700))
ok('graduated_boundary100_is500',lambda:eq(tiers_cost('100',{**cond,'pricing_mode':'graduated'}),500))
reject('group_tiers_explicitly_unsupported','UNSUPPORTED_PRICING_MODE',lambda:tiers_cost('150',{**cond,'price_tier_scope':'explicit_group'}))
reject('tier_gap_rejected','PRICE_TIER_AMBIGUOUS',lambda:tiers_cost('150',{**cond,'tiers':[cond['tiers'][0],{**cond['tiers'][1],'lower_inclusive':'101'}]}))
reject('tier_overlap_rejected','PRICE_TIER_AMBIGUOUS',lambda:tiers_cost('150',{**cond,'tiers':[cond['tiers'][0],{**cond['tiers'][1],'lower_inclusive':'99'}]}))
fees=[{'id':'purchase','obligation_id':'goods'},{'id':'freight','obligation_id':'freight','included_in_component_ref':'purchase'}]
ok('included_freight_not_added_twice',lambda:eq([x['id'] for x in fee_graph(fees)],['purchase']))
reject('same_obligation_new_id_rejected','CHARGE_DOUBLE_COUNT',lambda:fee_graph([{'id':'a','obligation_id':'x'},{'id':'b','obligation_id':'x'}]))
reject('inclusion_cycle','CHARGE_DOUBLE_COUNT',lambda:fee_graph([{'id':'a','obligation_id':'a','included_in_component_ref':'b'},{'id':'b','obligation_id':'b','included_in_component_ref':'a'}]))
reject('missing_inclusion_parent','REFERENCE_INVALID',lambda:fee_graph([{'id':'a','obligation_id':'a','included_in_component_ref':'no'}]))
tax={'rate':'0.13','price_basis':'inclusive','recovery_treatment':'recoverable'}
ok('inclusive_tax_113_split',lambda:eq(split_tax('113',tax),{'net_minor':10000,'tax_minor':1300,'gross_minor':11300,'cost_minor':10000}))
ok('nonrecoverable_113_cost',lambda:eq(split_tax('113',{**tax,'recovery_treatment':'nonrecoverable'})['cost_minor'],11300))
reject('unknown_tax_recovery','TAX_TREATMENT_UNKNOWN',lambda:split_tax('113',{**tax,'recovery_treatment':'unknown'}))
now='2026-10-22T09:00:00Z';fx={'from_currency':'USD','to_currency':'CNY','purpose':'cost_estimate','rate':'7.123456','observed_at':'2026-10-22T08:00:00Z','valid_from':'2026-10-22T00:00:00Z','valid_until':'2026-10-23T00:00:00Z'}
ok('cross_currency100USD_71235fen',lambda:eq(fx_cost('100','USD','CNY',fx,now,3600),71235))
ok('same_currency_explicit_no_FX',lambda:eq(fx_cost('100','USD','USD',None,now,3600),10000))
reject('wrong_FX_purpose','FX_NOT_APPLICABLE',lambda:fx_cost('100','USD','CNY',{**fx,'purpose':'quotation'},now,3600))
reject('reverse_FX_not_derived','FX_NOT_APPLICABLE',lambda:fx_cost('100','CNY','USD',fx,now,3600))
reject('FX_too_old','FX_NOT_APPLICABLE',lambda:fx_cost('100','USD','CNY',fx,now,3599))
reject('FX_future_observation','FX_NOT_APPLICABLE',lambda:fx_cost('100','USD','CNY',{**fx,'observed_at':'2026-10-22T10:00:00Z'},now,3600))
reject('FX_expiry_right_boundary','REFERENCE_STALE',lambda:fx_cost('100','USD','CNY',{**fx,'valid_until':now},now,3600))
packages=[{'count':1,'gross_kg':'10','length_m':'1','width_m':'1','height_m':'1'},{'count':1,'gross_kg':'1','length_m':'1','width_m':'1','height_m':'10'}]
rule={'kind':'max_actual_volumetric','divisor_m3_per_kg':'1','billing_increment':'1','rounding_mode':'ceil','rounding_scope':'per_package','max_scope':'per_package'}
ok('per_package_chargeable20',lambda:eq(chargeable(packages,rule),20))
ok('shipment_chargeable11',lambda:eq(chargeable(packages,{**rule,'rounding_scope':'shipment','max_scope':'shipment'}),11))
reject('mixed_max_rounding_scopes','UNSUPPORTED_PRICING_MODE',lambda:chargeable(packages,{**rule,'max_scope':'shipment'}))
ok('per_basis_minimum_fee',lambda:eq(bill('2',{'kind':'per_basis','basis_quantity':'1','rate':'3','minimum_amount':'10'}),10))
terms={'validity_mode':'independent_validity','interval':{'valid_from':'2026-10-22T00:00:00Z','valid_until':'2026-10-29T00:00:00Z'}}
origin={'readable':True,'active':False,'interval':{'valid_from':'2026-10-20T00:00:00Z','valid_until':'2026-10-21T00:00:00Z'}}
ok('independent_terms_survive_origin_expiry',lambda:source_effect(terms,origin,now))
reject('dependent_terms_expired_origin','REFERENCE_STALE',lambda:source_effect({**terms,'validity_mode':'dependent_validity'},origin,now))
reject('denied_origin_blocks_independent_terms','REFERENCE_STALE',lambda:source_effect(terms,{**origin,'denied':True},now))
reject('unreadable_origin_not_bypassed','PERMISSION_DENIED',lambda:source_effect(terms,{**origin,'readable':False},now))
nodes={'root':{'readable':True,'dependencies':['source']},'source':{'readable':True}}
ok('transitive_dependencies_readable',lambda:eq(dependency_access('root',nodes.__getitem__),{'root','source'}))
reject('transitive_unreadable_dependency','PERMISSION_DENIED',lambda:dependency_access('root',{'root':nodes['root'],'source':{'readable':False}}.__getitem__))
reject('dependency_cycle','REFERENCE_INVALID',lambda:dependency_access('root',{'root':{'readable':True,'dependencies':['root']}}.__getitem__))
# Sequential lifecycle proofs with explicit human identities.
grants=['save_draft','verify','publish','revise','discard_draft','withdraw','retire']
a={'id':'author','kind':'human','grants':grants};b={'id':'reviewer','kind':'human','grants':grants};model=RevisionModel()
def apply(actor,cmd,key,**args):return model.apply(actor,cmd,key,args)
ok('lifecycle_initial_draft',lambda:eq(apply(a,'save_draft','save',expected_version=0,data={'price':'5'})['working'],1))
reject('independent_self_verify_blocked','PERMISSION_DENIED',lambda:apply(a,'verify','self',expected_version=1,working_revision=1,evidence=['source']))
ok('independent_reviewer_verifies',lambda:eq(apply(b,'verify','verify1',expected_version=1,working_revision=1,evidence=['source'])['active'],1))
ok('revision_new_draft_keeps_old_active',lambda:eq(apply(a,'revise','revise',expected_version=2,base_revision=1)['active'],1))
reject('stale_CAS_no_mutation','VERSION_CONFLICT',lambda:apply(b,'verify','stale',expected_version=2,working_revision=2,supersedes_revision=1,evidence=['source']))
ok('revision_publish_exact_supersedes',lambda:eq(apply(b,'verify','verify2',expected_version=3,working_revision=2,supersedes_revision=1,evidence=['source'])['active'],2))
ok('withdraw_old_does_not_clear_new_active',lambda:eq(apply(b,'withdraw','old',expected_version=4,target_revision=1)['active'],2))
ok('same_key_replay_returns_original_version',lambda:eq(apply(b,'withdraw','old',expected_version=4,target_revision=1)['replayed'],True))
reject('same_key_new_payload_conflict','IDEMPOTENCY_PAYLOAD_CONFLICT',lambda:apply(b,'withdraw','old',expected_version=5,target_revision=2))
reject('revoked_read_blocks_old_replay','PERMISSION_DENIED',lambda:apply({**b,'readable':False},'withdraw','old',expected_version=4,target_revision=1))
reject('AI_cannot_self_verify','PERMISSION_DENIED',lambda:apply({**b,'kind':'ai'},'verify','ai',expected_version=5,working_revision=2,evidence=['source']))
ok('withdraw_current_clears_active',lambda:eq(apply(b,'withdraw','current',expected_version=5,target_revision=2)['active'],None))
# Representative data accompany tests; expressions and state sequences live in this script.
from rules import verified_estimate_allowed,check_output
from jsonschema import Draft202012Validator,FormatChecker
responses=json.loads((ROOT/'examples/responses.json').read_text());q_schema=json.loads((ROOT/'contracts/query.schema.json').read_text())
Draft202012Validator.check_schema(q_schema)
for query in json.loads((ROOT/'examples/query-responses.json').read_text()):
 ok('typed_query_'+query['kind'],lambda query=query:Draft202012Validator(q_schema,format_checker=FormatChecker()).validate(query))
for response in responses:
 if response.get('ok') and 'result' in response:ok('output_conservation_'+response['status'],lambda response=response:check_output(response['result']))
bad=copy.deepcopy(responses[0]['result']);bad['total_minor']='1'
reject('output_total_mismatch','ALLOCATION_INVALID',lambda:check_output(bad))
bad2=copy.deepcopy(responses[0]['result']);bad2['components'][0]['allocations'][0]['amount_minor']='1'
reject('output_allocation_mismatch','ALLOCATION_INVALID',lambda:check_output(bad2))
reject('estimate_missing_policy_defaults_false','COST_INPUT_NOT_READY',lambda:verified_estimate_allowed('estimated',{}))
ok('explicit_estimate_policy_true',lambda:verified_estimate_allowed('estimated',{'allow_verified_estimates':True}))
# Schema must reject identifier and decimal final-newline tricks.
from validator import V
for label,request in [('ID',{'contract':'brant.costing/0.1.0','command':'cost_scenario.evaluate','idempotency_key':'x','args':{'id':'s\n','expected_version':1}})]:
 ok('strict_'+label+'_lexical',lambda request=request:eq(V.is_valid(request),False))
no_permission={'ok':False,'code':'PERMISSION_DENIED','field_errors':[{'path':'/hidden','reason':'hidden'}]}
r_schema=json.loads((ROOT/'contracts/response.schema.json').read_text())
ok('permission_error_cannot_leak_field_errors',lambda:eq(Draft202012Validator(r_schema).is_valid(no_permission),False))
# These fixture hashes are computed from real canonical payload, not placeholder constants.
r=responses[0]['result']
ok('evaluation_response_result_hash',lambda:eq(r['result_hash'],digest({k:v for k,v in r.items() if k!='result_hash'})))
output={'package_version':'0.3.0','checks_passed':len(checks),'checks':checks,'scope':'pure executable rules and sequential reference state model only','production_authentication':False,'database_concurrency':False,'t02_business_service':False,'all_commands_full_semantic_coverage':False}
(ROOT/'evidence/extended-verification.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
(ROOT/'examples/extended-fixtures.json').write_text(json.dumps({'group_offer':group_offer,'group_context':group_context,'group_scenario':gs,'fx':fx,'clock':now,'chargeable_rule':rule,'packages':packages,'inclusion_components':fees},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'extended_checks':len(checks),'business_service':False}))
