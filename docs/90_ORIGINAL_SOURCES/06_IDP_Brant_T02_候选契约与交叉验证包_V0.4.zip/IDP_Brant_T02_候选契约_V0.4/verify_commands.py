from copy import deepcopy
import json
from validator import ROOT,REG,SCHEMA,V,Invalid,digest,canonical
from command_model import CommandModel
from normalization import normalize,path_rules
checks=[];trace=[]
commands={s['properties']['command']['const'] for s in SCHEMA['oneOf']}
a={'tenant':'tenant.test','company':'company.test','id':'author','kind':'human','readable':True,'grants':sorted(commands)}
b={**a,'id':'reviewer'}
m=CommandModel();seq=0

def call(name,args,actor=b,key=None):
 global seq
 seq+=1;r={'contract':'brant.costing/0.1.0','command':name,'idempotency_key':key or 'command.'+str(seq),'args':deepcopy(args)}
 value=m.execute(actor,r);trace.append({'request':r,'actor_id':actor['id'],'response':value});checks.append({'name':'execute_'+name,'passed':True});return value

def plain(v):
 if isinstance(v,dict):return {k:plain(x) for k,x in v.items()}
 if isinstance(v,list):return [plain(x) for x in v]
 if isinstance(v,tuple):return tuple(plain(x) for x in v)
 if hasattr(v,'__dict__'):return plain(vars(v))
 return deepcopy(v)
def rejects(label,code,name,args,actor=b,key=None):
 global seq
 seq+=1;r={'contract':'brant.costing/0.1.0','command':name,'idempotency_key':key or 'command.'+str(seq),'args':deepcopy(args)}
 before=plain(m.__dict__)
 try:m.execute(actor,r)
 except Invalid as e:
  assert e.code==code,(label,e.code,code);assert plain(m.__dict__)==before,label+' mutated state';checks.append({'name':label,'passed':True,'expected_rejection':code})
 else:raise AssertionError(label+' accepted')
valid=json.loads((ROOT/'examples/valid.json').read_text());data={r['command'].split('.')[0]:r['args']['data'] for r in valid if 'data' in r['args']}
terms={'supplier_ref':deepcopy(data['supplier_offer']['supplier_ref']),'source_offer_ref':{'kind':'supplier_offer','id':'supplier_offer.1','revision':1},'validity_mode':'independent_validity','interval':deepcopy(data['supplier_offer']['interval']),'lines':deepcopy(data['supplier_offer']['lines']),'evidence':deepcopy(data['supplier_offer']['evidence'])};data['purchase_terms']=terms
e=[{'source_id':'source.1','locator':'line 1'}]
for kind in ('costing_context','supplier_offer','logistics_offer','service_party_role','purchase_terms'):
 id_=kind+'.1';action='publish' if kind=='purchase_terms' else 'verify';retire='retire' if kind=='purchase_terms' else 'withdraw'
 call(kind+'.save_draft',{'id':id_,'expected_version':0,'data':data[kind]},a)
 rejects(kind+'_self_review','PERMISSION_DENIED',kind+'.'+action,{'id':id_,'expected_version':1,'working_revision':1,'evidence':e},a)
 call(kind+'.'+action,{'id':id_,'expected_version':1,'working_revision':1,'evidence':e})
 call(kind+'.revise',{'id':id_,'expected_version':2,'base_revision':1,'reason':'test revision'},a)
 call(kind+'.discard_draft',{'id':id_,'expected_version':3,'working_revision':2,'reason':'discard unapproved change'},a)
 call(kind+'.revise',{'id':id_,'expected_version':4,'base_revision':1,'reason':'new revision'},a)
 rejects(kind+'_wrong_supersedes','REFERENCE_STALE',kind+'.'+action,{'id':id_,'expected_version':5,'working_revision':3,'supersedes_revision':2,'evidence':e})
 call(kind+'.'+action,{'id':id_,'expected_version':5,'working_revision':3,'supersedes_revision':1,'evidence':e})
 call(kind+'.'+retire,{'id':id_,'expected_version':6,'target_revision':1,'reason':'old withdrawn','evidence':e})
 assert m.roots[kind,id_].active==3
 checks.append({'name':kind+'_old_withdraw_preserves_new','passed':True})
# Full supplier enquiry record lifecycle, no messages sent.
rfq={'supplier_ref':data['supplier_offer']['supplier_ref'],'rfq_ref':data['costing_context']['rfq_ref'],'rfq_line_ids':['L1'],'evidence':e}
call('supplier_rfq.save_draft',{'id':'request.1','expected_version':0,'data':rfq},a)
call('supplier_rfq.record_issued',{'id':'request.1','expected_version':1,'evidence':e,'reason':'recorded manual send'})
rejects('issued_RFQ_cannot_edit','INVALID_STATE','supplier_rfq.save_draft',{'id':'request.1','expected_version':2,'data':rfq},a)
call('supplier_rfq.close',{'id':'request.1','expected_version':2,'evidence':e,'reason':'closed'})
measurement=data['measurement']
call('measurement.record_verified',{'id':'measurement.1','expected_version':0,'data':measurement})
call('measurement.supersede',{'id':'measurement.1','expected_version':1,'active_revision':1,'data':{**measurement,'declared_volume_m3':'1'},'reason':'reverified'})
call('measurement.withdraw',{'id':'measurement.1','expected_version':2,'target_revision':1,'reason':'old error','evidence':e})
assert m.measurements['measurement.1']['active']==2
checks.append({'name':'measurement_old_withdraw_preserves_new','passed':True})
# Bind input scenario version, result identity and current context; calculate binding only.
sc=deepcopy(data['cost_scenario']);sc['context_ref']={'kind':'costing_context','id':'costing_context.1','revision':3}
call('cost_scenario.save_draft',{'id':'scenario.1','expected_version':0,'data':sc},a)
eval1=call('cost_scenario.evaluate',{'id':'scenario.1','expected_version':1},key='evaluate.original')
eval2=call('cost_scenario.evaluate',{'id':'scenario.1','expected_version':1})
assert eval1['result_id']!=eval2['result_id'] and m.scenarios['scenario.1']['version']==1
checks.append({'name':'new_evaluation_same_input_version','passed':True})
replay=call('cost_scenario.evaluate',{'id':'scenario.1','expected_version':1},key='evaluate.original')
assert replay['replayed'] and replay['result_id']==eval1['result_id']
rejects('revoked_access_blocks_replay','PERMISSION_DENIED','cost_scenario.evaluate',{'id':'scenario.1','expected_version':1},{**b,'readable':False},key='evaluate.original')
rejects('foreign_company_rejected','NOT_FOUND','cost_scenario.evaluate',{'id':'scenario.1','expected_version':1},{**b,'company':'other'})
call('cost_scenario.save_draft',{'id':'scenario.1','expected_version':1,'data':{**sc,'selection_reason':'new reviewed selection'}},a)
rejects('old_evaluation_cannot_freeze_new_version','REFERENCE_STALE','cost_snapshot.freeze',{'scenario_id':'scenario.1','expected_version':2,'result_id':eval1['result_id'],'result_hash':eval1['result_hash'],'selection_reason':'selected'})
eval3=call('cost_scenario.evaluate',{'id':'scenario.1','expected_version':2})
snap=call('cost_snapshot.freeze',{'scenario_id':'scenario.1','expected_version':2,'result_id':eval3['result_id'],'result_hash':eval3['result_hash'],'selection_reason':'selected'})
assert snap['input_version']==2 and snap['frozen_version']==3
checks.append({'name':'freeze_input_and_committed_versions','passed':True})
rejects('second_freeze_different_action_key','INVALID_STATE','cost_snapshot.freeze',{'scenario_id':'scenario.1','expected_version':3,'result_id':eval3['result_id'],'result_hash':eval3['result_hash'],'selection_reason':'selected again'})
call('source_denial.record',{'id':'denial.1','source_id':'source.1','reason':'source denied','evidence':e})
call('cost_scenario.save_draft',{'id':'scenario.2','expected_version':0,'data':sc},a)
r=call('cost_scenario.evaluate',{'id':'scenario.2','expected_version':1})
rejects('source_denial_blocks_new_freeze','REFERENCE_STALE','cost_snapshot.freeze',{'scenario_id':'scenario.2','expected_version':1,'result_id':r['result_id'],'result_hash':r['result_hash'],'selection_reason':'must not pass'})
missing=commands-m.seen
assert not missing,missing
checks.append({'name':'all35_commands_executed_in_reference_dispatcher','passed':True})
# Normalization specification covers every schema branch. Different raw requests stay different.
index=path_rules();assert set(index)==commands
checks.append({'name':'all35_commands_have_generated_path_rules','passed':True})
x=deepcopy(valid[1]);y=deepcopy(x);y['idempotency_key']='another.key';y['args']['data']['lines'][0]['tiers'][0]['unit_price']='5.00000000';y['args']['data']['rfq_line_ids']=list(reversed(y['args']['data']['rfq_line_ids']))
assert digest(x)!=digest(y) and digest(normalize(x))==digest(normalize(y))
checks.append({'name':'schema_driven_decimal_normalization','passed':True})
vectors=[]
for request in json.loads((ROOT/'examples/command_shapes.json').read_text()):
 n=normalize(request);vectors.append({'command':request['command'],'request':request,'request_hash':digest(request),'normalized_business':n,'business_hash':digest(n)})
 assert n==normalize(request)
checks.append({'name':'all35_commands_normalization_golden_vectors','passed':True})
report={'checks_passed':len(checks),'checks':checks,'command_count':len(commands),'commands_executed':sorted(m.seen),'command_dispatch_model_coverage':True,'all_commands_complete_business_semantics':False,'reference_model_only':True,'no_cost_engine_in_dispatcher':True,'production_identity':False,'database_transactions_or_concurrency':False}
for name,value in [('evidence/command-verification.json',report),('examples/command-traces.json',trace),('contracts/normalization-paths.json',index),('examples/command-hash-vectors.json',vectors)]:
 (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'command_model_checks':len(checks),'commands_executed':len(m.seen),'reference_model_only':True}))
