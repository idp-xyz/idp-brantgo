"""Sequential candidate command dispatcher. A model, never production runtime."""
from copy import deepcopy
from fractions import Fraction
from jsonschema import Draft202012Validator,FormatChecker
from validator import SCHEMA,REG,Invalid,fail,canonical,digest,V
from rules import RevisionModel,check_output,active_interval,verified_estimate_allowed

ROOT_TYPES={'costing_context':'context','supplier_offer':'offer','purchase_terms':'purchase_terms','logistics_offer':'logistics','service_party_role':'service_role'}
class CommandModel:
 def __init__(self):
  self.roots={};self.rfqs={};self.measurements={};self.denials={};self.scenarios={};self.results={};self.snapshots={};self.replays={};self.seen=set();self.clock=REG['as_of']
 def execute(self,actor,req):
  # Schema errors are about caller's own request. Never read private body before auth.
  if not V.is_valid(req):fail('SCHEMA_INVALID','/')
  cmd=req['command'];a=req['args'];key=(actor['tenant'],actor['company'],cmd,req['idempotency_key']);h=digest(req)
  if cmd not in actor['grants'] or not actor.get('readable',False):fail('PERMISSION_DENIED','/')
  if actor['company']!='company.test' or actor['tenant']!='tenant.test':fail('NOT_FOUND','/')
  if key in self.replays:
   old,value=self.replays[key]
   if old!=h:fail('IDEMPOTENCY_PAYLOAD_CONFLICT','/')
   return {**deepcopy(value),'replayed':True}
  before=deepcopy(self.__dict__)
  try:
   result=self._apply(actor,cmd,a)
   self.seen.add(cmd);self.replays[key]=(h,deepcopy(result));return {**result,'replayed':False}
  except Exception:
   self.__dict__=before;raise
 def _ready(self,kind,data):
  schema={'$defs':SCHEMA['$defs'],'$ref':'#/$defs/'+ROOT_TYPES[kind]}
  if not Draft202012Validator(schema,format_checker=FormatChecker()).is_valid(data):fail('COST_INPUT_NOT_READY','/working_revision/data')
  if 'interval' in data:active_interval(data['interval'],self.clock)
 def _apply(self,actor,cmd,a):
  kind,action=cmd.split('.',1);id_=a.get('id',a.get('scenario_id'))
  if kind in ROOT_TYPES:
   root=self.roots.get((kind,id_))
   if root is None:
    if action!='save_draft' or a['expected_version']!=0:fail('NOT_FOUND','/')
    root=RevisionModel(kind=kind,independent=True);self.roots[kind,id_]=root
   if action in ('verify','publish'):
    if root.working is None:fail('INVALID_STATE','/working_revision')
    self._ready(kind,root.revisions[root.working]['data'])
   mapped={**actor,'grants':[action]}
   return root.apply(mapped,action,cmd+':'+str(len(root.events))+':'+str(root.version),a)
  human=actor['kind']=='human'
  if kind=='supplier_rfq':
   r=self.rfqs.get(id_)
   if action=='save_draft':
    if r is None:
     if a['expected_version']!=0:fail('VERSION_CONFLICT','/expected_version')
     r={'version':0,'status':'draft'};self.rfqs[id_]=r
    if r['version']!=a['expected_version']:fail('VERSION_CONFLICT','/expected_version')
    if r['status']!='draft':fail('INVALID_STATE','/status')
    r.update(data=deepcopy(a['data']),version=r['version']+1)
   else:
    if r is None:fail('NOT_FOUND','/')
    if r['version']!=a['expected_version']:fail('VERSION_CONFLICT','/expected_version')
    if not human:fail('PERMISSION_DENIED','/')
    if action=='record_issued':
     if r['status']!='draft':fail('INVALID_STATE','/status')
     schema={'$defs':SCHEMA['$defs'],'$ref':'#/$defs/supplier_rfq'}
     if not Draft202012Validator(schema).is_valid(r['data']):fail('COST_INPUT_NOT_READY','/data')
     r['status']='issued'
    elif action=='close':
     if r['status']!='issued':fail('INVALID_STATE','/status')
     r['status']='closed'
    r['version']+=1
   return {'version':r['version'],'status':r['status']}
  if kind=='measurement':
   if not human:fail('PERMISSION_DENIED','/')
   r=self.measurements.get(id_)
   if action=='record_verified':
    if r is not None:fail('VERSION_CONFLICT','/expected_version')
    r={'version':1,'active':1,'last':1,'revisions':{1:deepcopy(a['data'])}};self.measurements[id_]=r
   else:
    if r is None:fail('NOT_FOUND','/')
    if r['version']!=a['expected_version']:fail('VERSION_CONFLICT','/expected_version')
    if action=='supersede':
     if r['active']!=a['active_revision']:fail('REFERENCE_STALE','/active_revision')
     r['last']+=1;r['active']=r['last'];r['revisions'][r['last']]=deepcopy(a['data'])
    elif action=='withdraw':
     if a['target_revision'] not in r['revisions']:fail('REFERENCE_INVALID','/target_revision')
     if r['active']==a['target_revision']:r['active']=None
    r['version']+=1
   return {'version':r['version'],'active':r['active']}
  if kind=='source_denial':
   if not human:fail('PERMISSION_DENIED','/')
   if id_ in self.denials:fail('VERSION_CONFLICT','/id')
   self.denials[id_]=deepcopy(a);return {'version':1,'status':'denied'}
  if kind=='cost_scenario':
   r=self.scenarios.get(id_)
   if action=='save_draft':
    if r is None:
     if a['expected_version']!=0:fail('VERSION_CONFLICT','/expected_version')
     r={'version':0,'status':'draft'};self.scenarios[id_]=r
    if r['version']!=a['expected_version']:fail('VERSION_CONFLICT','/expected_version')
    if r['status']!='draft':fail('INVALID_STATE','/status')
    r['data']=deepcopy(a['data']);r['version']+=1
    return {'version':r['version'],'status':'draft'}
   if r is None:fail('NOT_FOUND','/')
   if r['version']!=a['expected_version']:fail('VERSION_CONFLICT','/expected_version')
   if r['status']!='draft':fail('INVALID_STATE','/status')
   schema={'$defs':SCHEMA['$defs'],'$ref':'#/$defs/scenario'}
   if not Draft202012Validator(schema).is_valid(r['data']):fail('COST_INPUT_NOT_READY','/data')
   ctx=r['data']['context_ref'];root=self.roots.get(('costing_context',ctx['id']))
   if root is None or root.active!=ctx['revision']:fail('REFERENCE_STALE','/context_ref')
   # Model binds inputs, not a second independently implemented costing engine.
   result_id='result.'+str(len(self.results)+1)
   result={'id':result_id,'scenario_id':id_,'input_version':r['version'],'input_hash':digest(r['data']),'context_ref':deepcopy(ctx),'calculation_time':self.clock}
   result['result_hash']=digest(result);self.results[result_id]=result
   return {'version':r['version'],'result_id':result_id,'result_hash':result['result_hash']}
  if kind=='cost_snapshot':
   r=self.scenarios.get(id_);result=self.results.get(a['result_id'])
   if r is None or result is None:fail('NOT_FOUND','/')
   if r['version']!=a['expected_version']:fail('VERSION_CONFLICT','/expected_version')
   if r['status']!='draft' or id_ in self.snapshots:fail('INVALID_STATE','/status')
   if result['scenario_id']!=id_ or result['input_version']!=r['version'] or result['input_hash']!=digest(r['data']) or result['result_hash']!=a['result_hash']:fail('REFERENCE_STALE','/result_id')
   ctx=result['context_ref'];root=self.roots.get(('costing_context',ctx['id']))
   if root is None or root.active!=ctx['revision']:fail('REFERENCE_STALE','/context_ref')
   if root.revisions[root.active]['data']['context_kind']!='actual':fail('COST_INPUT_NOT_READY','/context_kind')
   # All registered denial facts conservatively block this fixture's only source.
   if any(d['source_id']=='source.1' for d in self.denials.values()):fail('REFERENCE_STALE','/source_denial')
   r['status']='frozen';r['version']+=1
   snap={'input_version':result['input_version'],'frozen_version':r['version'],'result_id':a['result_id'],'result_hash':a['result_hash']};self.snapshots[id_]=snap
   return {'version':r['version'],'status':'frozen',**snap}
  fail('UNSUPPORTED_CONTRACT','/command')
