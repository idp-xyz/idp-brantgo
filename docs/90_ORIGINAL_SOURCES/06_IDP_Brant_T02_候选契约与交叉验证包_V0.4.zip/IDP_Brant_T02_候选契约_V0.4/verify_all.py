"""Single uv entry point for layered candidate checks, not a production service."""
import json,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
P=Path(__file__).parent.resolve()
for script in ('verify.py','verify_extended.py','verify_commands.py','verify_adapter.py','verify_integration.py'):
 subprocess.run([sys.executable,str(P/script)],cwd=P,check=True)
names=['verification','extended-verification','command-verification','adapter-verification','integration-verification']
reports={name:json.loads((P/('evidence/'+name+'.json')).read_text()) for name in names}
report={'package_version':'0.4.0','executed_at':datetime.now(timezone.utc).isoformat(),'checks_by_layer':{k:v['checks_passed'] for k,v in reports.items()},'total_current_checks':sum(v['checks_passed'] for v in reports.values()),'schema_only_branch_examples':35,'command_dispatch_model_coverage':reports['command-verification']['command_dispatch_model_coverage'],'all_commands_full_business_semantics':False,'registry_bound_evaluate_freeze_reference':True,'normalization_path_index_commands':35,'model_calls':0,'external_business_actions':0,'full_contract_readiness':False,'production_migration':False,'runtime_foundation_adapter':False,'production_authentication':False,'concurrent_runtime_proof':False,'t02_business_service_implemented':False,'decision':'Candidate rule/model artifacts advanced; close remaining contract and adapter gaps before claiming T02 readiness.'}
(P/'evidence/qualification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
