"""Output evidence rules: snapshot hash includes selection; original result hash is retained."""
from copy import deepcopy
import json
from validator import ROOT,digest,fail

def check_hashes(result):
 if result['kind']=='evaluation':
  if result['result_hash']!=digest({k:v for k,v in result.items() if k!='result_hash'}):fail('EVIDENCE_HASH_MISMATCH','/result_hash')
 else:
  if result['evidence_hash']!=digest({k:v for k,v in result.items() if k!='evidence_hash'}):fail('EVIDENCE_HASH_MISMATCH','/evidence_hash')
  evaluation={k:v for k,v in result.items() if k not in {'evidence_hash','evaluation_id','frozen_scenario_version','selection_reason'}}
  evaluation['kind']='evaluation';evaluation['id']=result['evaluation_id']
  if evaluation['result_hash']!=digest({k:v for k,v in evaluation.items() if k!='result_hash'}):fail('EVIDENCE_HASH_MISMATCH','/result_hash')

def paths():
 records={}
 def walk(s,path,rows):
  if 'oneOf' in s:
   for x in s['oneOf']:walk(x,path,rows)
  elif s.get('type')=='object':
   for key,value in s['properties'].items():walk(value,path+'/'+key,rows)
  elif s.get('type')=='array':
   key=path.split('/')[-1];rule={'input_manifest':'kind,id,version','components':'id','allocations':'line_id','differences':'path,reason'}.get(key,'preserve response order')
   rows.add((path,'array order: '+rule));walk(s['items'],path+'/*',rows)
  elif s.get('type')=='string':rows.add((path,'preserve canonical nonnegative integer string' if 'amount_minor' in path or path.endswith(('total_minor','base_integer')) else 'preserve exact Unicode string'))
  else:rows.add((path,'preserve typed scalar'))
 for filename in ['response.schema.json','query.schema.json']:
  schema=json.loads((ROOT/'contracts'/filename).read_text());rows=set();walk(schema,'',rows);records[filename]=[{'path':p,'rule':r} for p,r in sorted(rows)]
 return {'path_index':records,'evaluation_hash':'SHA256(canonical evaluation minus result_hash); server fixes array order before hashing','snapshot_evidence_hash':'SHA256(canonical snapshot minus evidence_hash); includes original result_hash and selection_reason','query_current_fields':'currently_eligible_for_quote and eligibility_checked_at are query facts; excluded from immutable evidence payload','raw_request_hash':'unchanged; never replace by result hash'}
