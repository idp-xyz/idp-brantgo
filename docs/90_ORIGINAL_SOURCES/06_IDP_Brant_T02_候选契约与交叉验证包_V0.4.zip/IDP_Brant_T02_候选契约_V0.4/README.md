# IDP Brant T02候选契约与交叉验证包 V0.4

范围V1.0，规格V0.3.1，候选契约brant.costing/0.1.0。先阅读验证说明和契约关闭矩阵；完整契约准入仍为false。

```bash
uv sync --frozen
uv run --frozen python verify_all.py
```

本轮274项当前检查通过：基础86、纯规则61、35命令顺序模型79、基础扩展数据12、注册表绑定联调36。35项仅是Schema结构例；不与旧包历史数重复相加。运行不执行企业外部动作、不调用模型，不是生产服务。

V0.4新增：

- integrated_model.py从合成注册表或当前修订根读取选定报价／配置／来源，计算成本，生成完整评估及冻结响应；不是静态填660。不同路径按明确支持范围执行，未集成路径拒绝。
- verify_integration.py验证注册表版本、源读权及否认、报价替代／到期、RFQ版本、币种精度、原输入hash、FX年龄、失败回滚及完整响应。
- output_evidence.py区分原评估result_hash和快照evidence_hash；新增快照哈希绑定选定依据，历史重放仍须当前依赖读权。
- examples/generated-integration-responses.json为本轮实际参考路径生成的响应；contracts/output-evidence-paths.json为输出证据规则。

保留35命令Schema、逐字段输入规范化与哈希样例、扩展数据契约、顺序分发轨迹和SQLite约束参照。完整文件说明见验证说明。pyproject.toml与uv.lock锁定依赖；首次同步需网络或预置发行包缓存，Python3.12—3.13。

scripts/build_contracts.py重建Schema与fixture并调用响应及扩展数据生成器；之后运行verify_all.py更新证据。参考规则、分发、联调与DDL独立维护。历史证据在evidence/history；不能与本轮计数相加。
