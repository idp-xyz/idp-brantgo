"""Registry-bound sequential costing reference. Not a persistent enterprise service."""
from copy import deepcopy
from fractions import Fraction
from jsonschema import Draft202012Validator,FormatChecker
from validator import REG,ROOT,fail,digest,canonical,minor,allocate,V
from rules import purchase_groups,fee_graph,split_tax,fx_cost,check_output,active_interval
from command_model import CommandModel
from normalization import normalize

class IntegratedModel(CommandModel):
 def __init__(self,registry=None):
  super().__init__();self.registry=deepcopy(REG if registry is None else registry);self.complete_results={};self.complete_snapshots={};self.bindings={}
 def _history_access(self,actor,result):
  if not actor.get('readable',False):fail('PERMISSION_DENIED','/')
  if actor.get('tenant')!='tenant.test' or actor.get('company')!='company.test':fail('NOT_FOUND','/')
  for entry in result['input_manifest']:
   kind=entry['kind']
   if kind=='source':
    row=next((x for x in self.registry['sources'] if x['id']==entry['id']),None)
    if row is None or not row['readable']:fail('PERMISSION_DENIED','/')
   else:
    for row in self.registry['configs']+self.registry['verified_business']:
     ref=row['ref']
     if (ref['kind'],ref['id'],ref['revision'])==(kind,entry['id'],entry['version']) and not row.get('readable',True):fail('PERMISSION_DENIED','/')
 def execute(self,actor,req):
  if not V.is_valid(req):fail('SCHEMA_INVALID','/')
  cmd=req['command']
  if cmd not in actor['grants'] or not actor.get('readable',False):fail('PERMISSION_DENIED','/')
  if actor['company']!='company.test' or actor['tenant']!='tenant.test':fail('NOT_FOUND','/')
  key=(actor['tenant'],actor['company'],cmd,req['idempotency_key'])
  if key in self.replays:
   saved=self.replays[key][1]
   if 'result' in saved:self._history_access(actor,saved['result'])
  return super().execute(actor,req)
 def _source(self,id_):
  row=next((x for x in self.registry['sources'] if x['id']==id_),None)
  if row is None:fail('REFERENCE_INVALID','/source')
  if not row['readable']:fail('PERMISSION_DENIED','/')
  if row.get('denied') or any(x['source_id']==id_ for x in self.denials.values()):fail('REFERENCE_STALE','/source_denial')
  if row['status']!='verified':fail('COST_INPUT_NOT_READY','/source')
  return row
 def _remember(self,manifest,kind,id_,version,data):
  key=(kind,id_,version);manifest[key]={'kind':kind,'id':id_,'version':version,'content_hash':digest(data)}
 def _cfg(self,ref,manifest,expected=None):
  if expected is not None and ref['kind']!=expected:fail('REFERENCE_INVALID','/config_kind')
  rows=[x for x in self.registry['configs'] if x['ref']['kind']==ref['kind'] and x['ref']['id']==ref['id']]
  exact=next((x for x in rows if x['ref']['revision']==ref['revision']),None)
  if exact is None:fail('REFERENCE_INVALID','/config')
  if not exact.get('readable',True):fail('PERMISSION_DENIED','/')
  active=max((x['ref']['revision'] for x in rows if x.get('active',True)),default=None)
  if not exact.get('active',True) or active!=ref['revision']:fail('REFERENCE_STALE','/config')
  d=exact['data']
  if 'valid_from' in d:active_interval(d,self.clock)
  self._remember(manifest,ref['kind'],ref['id'],ref['revision'],d);return d
 def _business(self,ref,manifest,expected):
  if ref['kind']!=expected:fail('REFERENCE_INVALID','/business_kind')
  root=self.roots.get((expected,ref['id']))
  if root is not None:
   if root.active!=ref['revision']:fail('REFERENCE_STALE','/business_revision')
   d=root.revisions[root.active]['data']
  else:
   rows=[x for x in self.registry['verified_business'] if x['ref']['kind']==expected and x['ref']['id']==ref['id']]
   row=next((x for x in rows if x['ref']['revision']==ref['revision']),None)
   if row is None:fail('REFERENCE_INVALID','/business')
   if not row.get('readable',True):fail('PERMISSION_DENIED','/')
   if not row.get('active',True) or max(x['ref']['revision'] for x in rows if x.get('active',True))!=ref['revision']:fail('REFERENCE_STALE','/business_revision')
   d=row['data']
  if 'interval' in d:active_interval(d['interval'],self.clock)
  self._remember(manifest,expected,ref['id'],ref['revision'],d)
  for e in d.get('evidence',[]):self._remember(manifest,'source',e['source_id'],1,self._source(e['source_id']))
  return d
 def _master(self,ref,manifest,expected):
  if ref['kind']!=expected or ref not in self.registry['masters']:fail('REFERENCE_INVALID','/master')
  self._remember(manifest,'master.'+expected,ref['id'],ref['row_version'],ref)
 def _cost(self,scenario_id,result_id):
  scenario=self.scenarios[scenario_id];data=scenario['data'];manifest={}
  context=self._business(data['context_ref'],manifest,'costing_context')
  if context.get('context_kind')!='actual' or context.get('assumptions'):fail('DEPENDENCY_NOT_SUPPORTED','/context_assumptions')
  rfq=next((x for x in self.registry['rfqs'] if x['id']==context['rfq_ref']['id'] and x['row_version']==context['rfq_ref']['row_version']),None)
  if rfq is None or rfq['status']!='ready':fail('REFERENCE_STALE','/rfq')
  a=sorted(context['lines'],key=lambda x:x['line_id']);b=sorted(rfq['lines'],key=lambda x:x['line_id'])
  if canonical(a)!=canonical(b):fail('COMPARISON_BASIS_MISMATCH','/context_lines')
  self._remember(manifest,'rfq',rfq['id'],rfq['row_version'],rfq)
  currency=self._cfg(context['calculation_currency_ref'],manifest,'currency');precision=currency['minor_units'];target=currency['code']
  policy=self._cfg(context['pricing_policy_ref'],manifest,'pricing_policy')
  pc=policy['calculation_currency']
  if (pc['id'] if isinstance(pc,dict) else pc)!=context['calculation_currency_ref']['id']:fail('REFERENCE_INVALID','/policy_currency')
  self._cfg(context['comparison_basis']['named_place_ref'],manifest,'location')
  for l in context['lines']:
   sku=self._cfg(l['sku_profile_ref'],manifest,'sku_profile');u=self._cfg(l['unit_ref'],manifest,'unit')
   if Fraction(l['quantity'])<=0 or len(l['quantity'].split('.')[1] if '.' in l['quantity'] else '')>min(6,u['precision']):fail('INVALID_KNOWN_VALUE','/quantity')
   self._master({'kind':'sku','id':sku['sku_id'],'row_version':sku.get('sku_row_version',1)},manifest,'sku')
  resolved={}
  def supplier(src):
   kind='supplier_offer' if src['kind']=='offer' else 'purchase_terms'
   if kind=='purchase_terms':fail('DEPENDENCY_NOT_SUPPORTED','/purchase_terms_integration')
   ref={'kind':kind,'id':src['id'],'revision':src['revision']};o=self._business(ref,manifest,kind)
   self._master(o['supplier_ref'],manifest,'supplier')
   if o['rfq_ref']!=context['rfq_ref']:fail('REFERENCE_INVALID','/offer/rfq_ref')
   if o['origin']['kind']!='unsolicited':fail('DEPENDENCY_NOT_SUPPORTED','/offer/origin_integration')
   resolved[(src['kind'],src['id'],src['revision'])]=o;return o
  groups=sorted(purchase_groups(data,context,supplier),key=lambda g:g['source_identity']);components=[];graphs=[]
  fx=[]
  for ref in data.get('fx_refs',[]):fx.append(self._cfg(ref,manifest,'fx'))
  def convert(value,cur):
   if cur['code']==target:return minor(value,precision)
   options=[x for x in fx if x['from_currency']==cur['code'] and x['to_currency']==target and x['purpose']=='cost_estimate']
   if len(options)!=1:fail('FX_NOT_APPLICABLE','/fx_refs')
   if 'max_fx_age_seconds' not in policy:fail('COST_INPUT_NOT_READY','/policy/max_fx_age_seconds')
   return fx_cost(value,cur['code'],target,options[0],self.clock,policy['max_fx_age_seconds'],precision)
  def amount(value,curref,taxref):
   cur=self._cfg(curref,manifest,'currency');tax=self._cfg(taxref,manifest,'tax_profile')
   parts=split_tax(value,tax,cur['minor_units']);return convert(Fraction(parts['cost_minor'],10**cur['minor_units']),cur)
  def distribute(total,members,basis,weights):
   ids=sorted(members);values=allocate(total,[weights[x] for x in ids])
   return [{'line_id':i,'amount_minor':str(v),'basis':basis,'base_integer':str(weights[i])} for i,v in zip(ids,values)]
  purchase_base={l['line_id']:0 for l in context['lines']};included=set()
  for i,g in enumerate(groups):
   c=g['condition'];self._cfg(c['trade_terms_ref'],manifest,'trade_terms');self._cfg(c['payment_terms_ref'],manifest,'payment_terms')
   value=amount(g['raw_amount'],c['currency_ref'],c['tax_profile_ref']);members=g['members']
   # Exact common denominator maps rational quantities to integer relative weights.
   from math import lcm
   den=lcm(*(x.denominator for x in members.values()));weights={k:int(v*den) for k,v in members.items()}
   component={'id':'purchase.'+str(i+1),'obligation_id':'goods.'+str(i+1),'amount_minor':str(value),'allocations':distribute(value,members,'quantity',weights)}
   components.append(component);graphs.append({'id':component['id'],'obligation_id':component['obligation_id']})
   for alloc in component['allocations']:purchase_base[alloc['line_id']]+=int(alloc['amount_minor'])
   included.update(c['included_obligation_ids'])
  seen_fee_obligations=set();fee_type_ids=set()
  for ref in sorted(data.get('logistics_offer_refs',[]),key=lambda r:(r['kind'],r['id'],r['revision'])):
   log=self._business(ref,manifest,'logistics_offer');role=self._business(log['service_role_ref'],manifest,'service_party_role');self._master(role['party_ref'],manifest,'supplier')
   if any(log[k]!=role[k] for k in ['service_code','origin_ref','destination_ref']):fail('REFERENCE_INVALID','/service_role')
   if log['destination_ref']!=context['comparison_basis']['named_place_ref']:fail('COMPARISON_BASIS_MISMATCH','/destination')
   self._cfg(log['origin_ref'],manifest,'location');self._cfg(log['destination_ref'],manifest,'location')
   for f in sorted(log['fees'],key=lambda f:f['id']):
    if f['obligation_id'] in seen_fee_obligations:fail('CHARGE_DOUBLE_COUNT','/fee_obligation')
    seen_fee_obligations.add(f['obligation_id']);fee_type_ids.add(canonical(f['fee_type_ref']));self._cfg(f['fee_type_ref'],manifest,'fee_type')
    if f['responsible_party']!='seller':fail('COMPARISON_BASIS_MISMATCH','/fee_responsibility')
    if f['obligation_id'] in included or 'included_in_component_ref' in f:fail('DEPENDENCY_NOT_SUPPORTED','/included_fee_integration')
    if f['billing']['kind']!='fixed' or f['chargeable']['kind']!='fixed':fail('DEPENDENCY_NOT_SUPPORTED','/billing_integration')
    if Fraction(f['billing']['amount'])==0 and not f.get('zero_price_reason'):fail('COST_INPUT_NOT_READY','/fee_zero_price_reason')
    value=amount(Fraction(f['billing']['amount']),f['currency_ref'],f['tax_profile_ref']);allocation=f['allocation'];basis=allocation['basis']
    if basis=='explicit':
     weights={x['line_id']:int(x['weight']) for x in allocation['weights']}
     if len(weights)!=len(allocation['weights']):fail('DUPLICATE_LINE_ID','/weights')
    else:
     ids=allocation['target_line_ids']
     if len(ids)!=len(set(ids)):fail('DUPLICATE_LINE_ID','/target_line_ids')
     if basis=='amount':weights={x:purchase_base.get(x,0) for x in ids}
     elif basis=='quantity':
      quantities={l['line_id']:Fraction(l['quantity']) for l in context['lines']};den=lcm(*(quantities[x].denominator for x in ids if x in quantities));weights={x:int(quantities.get(x,0)*den) for x in ids}
     else:fail('DEPENDENCY_NOT_SUPPORTED','/allocation_basis_integration')
    if any(x not in purchase_base for x in weights):fail('REFERENCE_INVALID','/allocation_target')
    components.append({'id':'fee.'+str(len(components)+1),'obligation_id':f['obligation_id'],'amount_minor':str(value),'allocations':distribute(value,weights,basis,weights)})
    graphs.append({'id':components[-1]['id'],'obligation_id':f['obligation_id']})
  fee_graph(graphs)
  if any(canonical(x) not in fee_type_ids for x in context['comparison_basis']['required_fee_type_refs']):fail('COST_INPUT_NOT_READY','/required_fees')
  total=sum(int(c['amount_minor']) for c in components)
  if total>10**12*10**precision:fail('CALCULATION_LIMIT_EXCEEDED','/total_cost')
  input_manifest=sorted(manifest.values(),key=lambda x:(x['kind'],x['id'],x['version']))
  binding={'scenario':normalize({'contract':'brant.costing/0.1.0','command':'cost_scenario.save_draft','idempotency_key':'binding','args':{'id':scenario_id,'expected_version':scenario['version'],'data':data}}),'input_manifest':input_manifest}
  components.sort(key=lambda c:c['id'])
  result={'kind':'evaluation','id':result_id,'scenario_id':scenario_id,'input_scenario_version':scenario['version'],'context_ref':deepcopy(data['context_ref']),'rfq_ref':deepcopy(context['rfq_ref']),'engine_version':'reference.integrated.0.4','calculation_time':self.clock,'input_manifest':input_manifest,'input_hash':digest(binding),'comparison_status':'comparable','verification_status':'verified','currency':target,'minor_units':precision,'components':components,'total_minor':str(total),'differences':[]}
  result['result_hash']=digest(result);check_output(result)
  return result,binding
 def _apply(self,actor,cmd,a):
  if cmd=='cost_scenario.evaluate':
   value=super()._apply(actor,cmd,a);result,binding=self._cost(a['id'],value['result_id'])
   self.complete_results[result['id']]=result;self.bindings[result['id']]=binding
   self.results[result['id']]['result_hash']=result['result_hash']
   self.results[result['id']]['complete_input_hash']=result['input_hash']
   return {**value,'result_hash':result['result_hash'],'result':deepcopy(result)}
  if cmd=='cost_snapshot.freeze':
   scenario=self.scenarios.get(a['scenario_id'])
   if scenario is None:fail('NOT_FOUND','/')
   if scenario['version']!=a['expected_version']:fail('VERSION_CONFLICT','/expected_version')
   if scenario['status']!='draft':fail('INVALID_STATE','/status')
   previous=self.complete_results.get(a['result_id'])
   if previous is None:fail('REFERENCE_INVALID','/result_id')
   current,binding=self._cost(a['scenario_id'],a['result_id'])
   if current['input_hash']!=previous['input_hash'] or current['components']!=previous['components'] or a['result_hash']!=previous['result_hash']:fail('REFERENCE_STALE','/result_input')
   # New current-time checks are from _cost; freeze keeps original calculation_time/hash.
   value=super()._apply(actor,cmd,a)
   snap={**deepcopy(previous),'kind':'snapshot','id':'snapshot.'+str(len(self.complete_snapshots)+1),'evaluation_id':previous['id'],'frozen_scenario_version':value['version'],'selection_reason':a['selection_reason']}
   snap['evidence_hash']=digest(snap)
   self.complete_snapshots[snap['id']]=snap;check_output(snap);return {**value,'result':deepcopy(snap)}
  return super()._apply(actor,cmd,a)
 def response(self,command,model_result,action_id='reference.action'):
  if command=='cost_scenario.evaluate':status='evaluated';result=model_result['result']
  elif command=='cost_snapshot.freeze':status='frozen';result=model_result['result']
  else:fail('DEPENDENCY_NOT_SUPPORTED','/response_mapping')
  payload={'ok':True,'action_id':action_id,'object_id':result['id'],'status':status,'replayed':model_result['replayed'],'row_version':model_result['version'],'result_hash':result['result_hash'],'result':result}
  schema=__import__('json').loads((ROOT/'contracts/response.schema.json').read_text());Draft202012Validator(schema,format_checker=FormatChecker()).validate(payload)
  return payload
 def history(self,actor,id_):
  if 'costing.read' not in actor.get('grants',[]):fail('PERMISSION_DENIED','/')
  if not actor.get('readable',False):fail('PERMISSION_DENIED','/')
  if actor.get('tenant')!='tenant.test' or actor.get('company')!='company.test':fail('NOT_FOUND','/')
  result=self.complete_results.get(id_,self.complete_snapshots.get(id_))
  if result is None:fail('NOT_FOUND','/')
  self._history_access(actor,result)
  return deepcopy(result)
