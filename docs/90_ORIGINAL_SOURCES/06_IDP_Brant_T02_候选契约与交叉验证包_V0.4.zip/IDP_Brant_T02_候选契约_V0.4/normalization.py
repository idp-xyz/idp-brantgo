"""Schema-driven candidate business normalization; raw request hashing is separate."""
from copy import deepcopy
from fractions import Fraction
from validator import SCHEMA,V,fail,canonical,digest

def deref(s):
 while '$ref' in s:s=SCHEMA['$defs'][s['$ref'].split('/')[-1]]
 return s
def branch(s,value):
 s=deref(s)
 if 'oneOf' in s:
  from jsonschema import Draft202012Validator
  good=[x for x in s['oneOf'] if Draft202012Validator({'$defs':SCHEMA['$defs'],**x}).is_valid(value)]
  if len(good)!=1:fail('SCHEMA_INVALID','/normalization')
  return branch(good[0],value)
 return s

def normalize(req):
 if not V.is_valid(req):fail('SCHEMA_INVALID','/')
 command_schema=next(x for x in SCHEMA['oneOf'] if x['properties']['command']['const']==req['command'])
 def visit(value,s,key=''):
  s=branch(s,value)
  if isinstance(value,dict):return {k:visit(v,s['properties'][k],k) for k,v in value.items()}
  if isinstance(value,list):
   values=[visit(v,s['items']) for v in value]
   if key=='tiers':return sorted(values,key=lambda x:Fraction(x['lower_inclusive']))
   return sorted(values,key=canonical)
  if isinstance(value,str) and s.get('maxLength')==40 and 'pattern' in s:
   if '.' not in value:return value
   return value.rstrip('0').rstrip('.')
  return value
 out=visit(req,command_schema);out.pop('idempotency_key',None)
 return out

def path_rules():
 out={}
 def walk(s,path,rows):
  s=deref(s)
  if 'oneOf' in s:
   for x in s['oneOf']:walk(x,path,rows)
  elif s.get('type')=='object':
   for k,v in s['properties'].items():walk(v,path+'/'+k,rows)
  elif s.get('type')=='array':
   rows.add((path,'numeric lower_inclusive order' if path.endswith('/tiers') else 'canonical normalized element order'))
   walk(s['items'],path+'/*',rows)
  elif s.get('type')=='string':rows.add((path,'decimal trim fractional zeros' if s.get('maxLength')==40 else 'preserve Unicode code points'))
  else:rows.add((path,'preserve typed scalar'))
 for s in SCHEMA['oneOf']:
  name=s['properties']['command']['const'];rows=set();walk(s,'',rows)
  out[name]=[{'path':p,'rule':r} for p,r in sorted(rows)]
 return out
