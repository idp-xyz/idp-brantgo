"""Candidate cross-field checker. No identity provider or business service."""
import copy
import hashlib
import json
from datetime import datetime
from decimal import Decimal
from fractions import Fraction
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
ROOT=Path(__file__).parent
SCHEMA=json.loads((ROOT/'contracts/commands.schema.json').read_text())
REG=json.loads((ROOT/'examples/registry.json').read_text())
V=Draft202012Validator(SCHEMA,format_checker=FormatChecker())
class Invalid(Exception):
 def __init__(self,code,path):self.code=code;self.path=path;super().__init__(f'{code}: {path}')
def fail(code,path):raise Invalid(code,path)
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def canonical_business(x):
 """Explicit numeric field paths; source strings and IDs never numeric-normalized."""
 numeric={'quantity','purchase_quantity','price_basis_quantity','lower_inclusive','upper_exclusive','unit_price','rate','basis_quantity','minimum_amount','amount','length_m','width_m','height_m','net_kg','gross_kg','declared_volume_m3','billing_increment','divisor_kg_per_m3','weight'}
 sortable={'lines':'id','packages':'id','fees':'id','weights':'line_id'}
 def walk(v,key=''):
  if isinstance(v,dict):return {k:walk(z,k) for k,z in v.items()}
  if isinstance(v,list):
   a=[walk(z) for z in v]
   if key in sortable and all(isinstance(z,dict) and sortable[key] in z for z in a):a.sort(key=lambda z:z[sortable[key]])
   if key=='tiers':a.sort(key=lambda z:Fraction(z['lower_inclusive']))
   return a
  if key in numeric and isinstance(v,str):
   d=Decimal(v);return '0' if not d else format(d,'f').rstrip('0').rstrip('.') if '.' in format(d,'f') else format(d,'f')
  return v
 return walk(x)
def digest(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def minor(x,precision=2):
 f=Fraction(x)*10**precision;q,r=divmod(f.numerator,f.denominator)
 return q+(2*r>=f.denominator)
def allocate(n,weights):
 if not weights or any(w<0 for w in weights) or sum(weights)==0:fail('ALLOCATION_INVALID','/weights')
 pairs=[divmod(n*w,sum(weights)) for w in weights];out=[p[0] for p in pairs]
 for i in sorted(range(len(weights)),key=lambda i:(-pairs[i][1],i))[:n-sum(out)]:out[i]+=1
 return out
CONFIGS={canonical(x['ref']):x['data'] for x in REG['configs']}
BUSINESS={canonical(x['ref']):x['data'] for x in REG['verified_business']}
def cfg(r,path,kind=None):
 if kind and r['kind']!=kind:fail('REFERENCE_INVALID',path)
 d=CONFIGS.get(canonical(r))
 if d is None:fail('REFERENCE_INVALID',path)
 return d
def unique(xs,path,key=None):
 v=[x[key] if key else canonical(x) for x in xs]
 if len(v)!=len(set(v)):fail('DUPLICATE_LINE_ID',path)
def q_unit(q,r,path):
 d=cfg(r,path,'unit');scale=len(q.split('.')[1]) if '.' in q else 0
 if scale>min(6,d['precision']) or not 0<Fraction(q)<=1000000:fail('INVALID_KNOWN_VALUE',path)
def interval(d,path):
 a=datetime.fromisoformat(d['valid_from'].replace('Z','+00:00'));b=datetime.fromisoformat(d['valid_until'].replace('Z','+00:00'));now=datetime.fromisoformat(REG['as_of'].replace('Z','+00:00'))
 if not a<=now<b:fail('REFERENCE_STALE',path)
def tiers(d,path):
 ts=d['tiers']
 if d['pricing_mode']=='flat' and len(ts)!=1:fail('PRICE_TIER_AMBIGUOUS',path)
 for i,t in enumerate(ts):
  if i==0 and Fraction(t['lower_inclusive'])!=0:fail('PRICE_TIER_AMBIGUOUS',path)
  if 'upper_exclusive' in t and Fraction(t['upper_exclusive'])<=Fraction(t['lower_inclusive']):fail('PRICE_TIER_AMBIGUOUS',path)
  if i and ('upper_exclusive' not in ts[i-1] or Fraction(ts[i-1]['upper_exclusive'])!=Fraction(t['lower_inclusive'])):fail('PRICE_TIER_AMBIGUOUS',path)
  if i<len(ts)-1 and 'upper_exclusive' not in t:fail('PRICE_TIER_AMBIGUOUS',path)
def validate(request):
 if len(canonical(request).encode())>1048576:fail('CALCULATION_LIMIT_EXCEEDED','/')
 if list(V.iter_errors(request)):fail('SCHEMA_INVALID','/')
 name=request['command'];d=request['args'].get('data')
 if d is None:return
 # A draft may omit unknown top-level fields; references already supplied are checked.
 def walk(v,path=''):
  if isinstance(v,dict):
   if set(v)=={'kind','id','revision'} and v['kind'] in {'unit','currency','sku_profile','tax_profile','pricing_policy','trade_terms','payment_terms','location','fee_type'}:cfg(v,path)
   if set(v)=={'kind','id','row_version'} and v not in REG['masters']:fail('REFERENCE_INVALID',path)
   for k,x in v.items():walk(x,path+'/'+k)
  elif isinstance(v,list):
   for i,x in enumerate(v):walk(x,path+'/'+str(i))
 walk(d,'/args/data')
 for x in d.get('evidence',[]):
  src=next((z for z in REG['sources'] if z['id']==x['source_id']),None)
  if src is None:fail('REFERENCE_INVALID','/args/data/evidence')
  if not src['readable']:fail('PERMISSION_DENIED','/')
  if src['denied']:fail('REFERENCE_STALE','/args/data/evidence')
 if 'interval' in d:interval(d['interval'],'/args/data/interval')
 if name=='costing_context.save_draft' and 'lines' in d:
  unique(d['lines'],'/args/data/lines','line_id')
  for l in d['lines']:q_unit(l['quantity'],l['unit_ref'],'/args/data/lines/quantity')
  if d.get('context_kind')=='actual' and 'rfq_ref' in d:
   rfq=next((z for z in REG['rfqs'] if z['id']==d['rfq_ref']['id'] and z['row_version']==d['rfq_ref']['row_version']),None)
   if rfq is None:fail('REFERENCE_STALE','/args/data/rfq_ref')
   # First supported path is explicit same-unit PCS, never approximate conversion.
   if canonical(d['lines'])!=canonical(rfq['lines']):fail('COMPARISON_BASIS_MISMATCH','/args/data/lines')
 if name in {'supplier_offer.save_draft','purchase_terms.save_draft'} and 'lines' in d:
  unique(d['lines'],'/args/data/lines','id')
  for l in d['lines']:
   tiers(l,'/args/data/lines/tiers')
   if Fraction(l['price_basis_quantity'])>1000000:fail('CALCULATION_LIMIT_EXCEEDED','/args/data/lines/price_basis_quantity')
   for t in l['tiers']:
    if Fraction(t['unit_price'])>10**12:fail('CALCULATION_LIMIT_EXCEEDED','/args/data/lines/tiers')
    if Fraction(t['unit_price'])==0 and not t.get('zero_price_reason'):fail('COST_INPUT_NOT_READY','/args/data/lines/tiers/zero_price_reason')
 if name.startswith('measurement.') and 'packages' in d:
  unique(d['packages'],'/args/data/packages','id');volume=Fraction(0)
  for p in d['packages']:
   if Fraction(p['gross_kg'])<Fraction(p['net_kg']):fail('INVALID_KNOWN_VALUE','/args/data/packages/gross_kg')
   if any(Fraction(p[k])>1000 for k in ['length_m','width_m','height_m']):fail('CALCULATION_LIMIT_EXCEEDED','/args/data/packages')
   volume+=p['count']*Fraction(p['length_m'])*Fraction(p['width_m'])*Fraction(p['height_m'])
  if 'declared_volume_m3' in d and minor(volume,6)!=minor(d['declared_volume_m3'],6):fail('MEASUREMENT_CONFLICT','/args/data/declared_volume_m3')
 if name=='logistics_offer.save_draft' and 'fees' in d:
  unique(d['fees'],'/args/data/fees','id')
  if len({f['obligation_id'] for f in d['fees']})!=len(d['fees']):fail('CHARGE_DOUBLE_COUNT','/args/data/fees')
  role=BUSINESS.get(canonical(d.get('service_role_ref',{})))
  if role and any(d.get(k)!=role.get(k) for k in ['service_code','origin_ref','destination_ref']):fail('REFERENCE_INVALID','/args/data/service_role_ref')
  for f in d['fees']:
   a=f['allocation'];ch=f['chargeable']
   if a['basis']=='explicit':
    unique(a['weights'],'/args/data/fees/weights','line_id')
    if not any(int(w['weight']) for w in a['weights']) or any(int(w['weight'])>10**9 for w in a['weights']):fail('ALLOCATION_INVALID','/args/data/fees/weights')
   if ch['kind']=='max_actual_volumetric' and ch['max_scope']!=ch['rounding_scope']:fail('UNSUPPORTED_PRICING_MODE','/args/data/fees/chargeable')
 if name=='cost_scenario.save_draft' and 'allocations' in d:
  ctx=BUSINESS.get(canonical(d.get('context_ref',{})))
  if ctx is None:fail('REFERENCE_INVALID','/args/data/context_ref')
  from rules import purchase_groups
  def resolve(src):
   kind='supplier_offer' if src['kind']=='offer' else 'purchase_terms'
   value=BUSINESS.get(canonical({'kind':kind,'id':src['id'],'revision':src['revision']}))
   if value is None:fail('REFERENCE_INVALID','/args/data/allocations/source')
   return value
  for a in d['allocations']:q_unit(a['purchase_quantity'],a['purchase_unit_ref'],'/args/data/allocations/purchase_quantity')
  purchase_groups(d,ctx,resolve)

def evaluate_fixture(registry):
 """Exact arithmetic for the supplied one-line flat, same-currency fixture only."""
 ctx=registry['verified_business'][0]['data'];offer=registry['verified_business'][1]['data'];log=registry['verified_business'][3]['data']
 l=offer['lines'][0]
 if l['pricing_mode']!='flat' or l['price_unit_ref']!=ctx['lines'][0]['unit_ref']:raise ValueError('Fixture path only')
 purchase=minor(Fraction(ctx['lines'][0]['quantity'])/Fraction(l['price_basis_quantity'])*Fraction(l['tiers'][0]['unit_price']))
 fee=sum(minor(f['billing']['amount']) for f in log['fees'])
 return {'purchase_original':f'{purchase//100}.{purchase%100:02d}','direct_fees':f'{fee//100}.{fee%100:02d}','total_cost':f'{(purchase+fee)//100}.{(purchase+fee)%100:02d}','currency':'USD'}
