"""Build a candidate extension data schema from an included immutable baseline schema."""
import copy,json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent.parent
old=json.loads((P/'contracts/baseline-foundation.commands.schema.json').read_text())
policy=next(x for x in old['oneOf'] if x.get('properties',{}).get('args',{}).get('properties',{}).get('kind',{}).get('const')=='pricing_policy')
policy_data=copy.deepcopy(policy['properties']['args']['properties']['data'])
policy_data['properties']['allow_verified_estimates']={'type':'boolean'};policy_data['required'].append('allow_verified_estimates')
# Apply the new costing ratio precision only to the new candidate payload, not baseline.
policy_data['properties']['minimum_margin']={'type':'string','maxLength':40,'pattern':'^(?:0(?:\\.[0-9]{1,8})?|1(?:\\.0{1,8})?)$','not':{'pattern':'[^0-9.]'}}
ID=copy.deepcopy(policy['properties']['args']['properties']['id']);REF=policy_data['properties']['calculation_currency']
def obj(p,required=None):return {'type':'object','properties':p,'required':list(p) if required is None else required,'additionalProperties':False}
location=obj({'code':ID,'name':{'type':'string','minLength':1,'maxLength':500},'country':{'type':'string','pattern':'^[A-Z]{2}$','not':{'pattern':'[^A-Z]'}},'place_type':{'enum':['port','airport','city','address']},'address':{'type':'string','minLength':1,'maxLength':1000}},['code','name','country','place_type'])
branches=[]
for kind,data in [('location',location),('pricing_policy',policy_data)]:branches.append(obj({'contract':{'const':'brant.foundation-extension-data/0.1.0'},'kind':{'const':kind},'data':data}))
(P/'contracts/foundation-extension.data.schema.json').write_text(json.dumps({'$schema':'https://json-schema.org/draft/2020-12/schema','oneOf':branches},ensure_ascii=False,indent=2)+'\n')
fixtures=[{'contract':'brant.foundation-extension-data/0.1.0','kind':'location','data':{'code':'port.test','name':'Synthetic test destination','country':'CN','place_type':'port'}},{'contract':'brant.foundation-extension-data/0.1.0','kind':'pricing_policy','data':{'name':'Synthetic independent review policy','calculation_currency':{'kind':'currency','id':'USD','revision':1},'minimum_margin':'0.25','quote_valid_days':7,'max_fx_age_seconds':3600,'independent_review':True,'tax_profile':{'kind':'tax_profile','id':'tax.zero','revision':1},'allow_verified_estimates':False}}]
(P/'examples/foundation-extension.json').write_text(json.dumps(fixtures,ensure_ascii=False,indent=2)+'\n')
(P/'contracts/foundation-adapter-plan.json').write_text(json.dumps({'candidate_data_contract':'brant.foundation-extension-data/0.1.0','baseline_contract_unchanged':'brant.foundation/0.1.0','baseline_schema_sha256':hashlib.sha256((P/'contracts/baseline-foundation.commands.schema.json').read_bytes()).hexdigest(),'runtime_registered':False,'transport_commands_defined':False,'missing_estimate_flag_read_semantics':False,'write_rule':'Do not inject extension properties into baseline foundation.save; require explicitly implemented versioned adapter with independent publication and source checks.','location_lookup':'exact stable location reference only; no implicit text or zone match','service_party_role':'T02 versioned object; do not silently add new role to baseline master.kind'},ensure_ascii=False,indent=2)+'\n')
