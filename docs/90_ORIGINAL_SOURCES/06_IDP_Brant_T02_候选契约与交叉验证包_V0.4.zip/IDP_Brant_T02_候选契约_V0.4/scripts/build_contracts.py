import json
from pathlib import Path
P=Path(__file__).resolve().parent.parent
def write(n,x):
 p=P/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n' if not isinstance(x,str) else x)
def obj(p,required=None,**kw):return {'type':'object','properties':p,'required':list(p) if required is None else required,'additionalProperties':False,**kw}
def arr(x,n=200,minimum=1):return {'type':'array','items':x,'minItems':minimum,'maxItems':n}
def enum(*v):return {'enum':list(v)}
def ref(n):return {'$ref':'#/$defs/'+n}
ID={'type':'string','minLength':1,'maxLength':64,'pattern':'^[A-Za-z0-9][A-Za-z0-9._:-]*$','not':{'pattern':'[^A-Za-z0-9._:-]'}}
TXT={'type':'string','minLength':1,'maxLength':1000}
POS={'type':'integer','minimum':1,'maximum':2147483647}
VER={'type':'integer','minimum':0,'maximum':2147483647}
DATE={'type':'string','format':'date-time','pattern':r'.*(Z|[+-][0-9]{2}:[0-9]{2})$'}
def dec(scale,zero=True):return {'type':'string','maxLength':40,'allOf':[{'not':{'pattern':'[^0-9.]'}}],'pattern':r'^(0|[1-9][0-9]*)(\.[0-9]{1,'+str(scale)+r'})?$' if scale else r'^(0|[1-9][0-9]*)$',**({} if zero else {'not':{'pattern':r'^0(\.0+)?$'}})}
D={'id':ID,'quantity':dec(6,False),'price':dec(8),'ratio':dec(8),'amount':dec(4),'rate':dec(12,False),
 'config_ref':obj({'kind':ID,'id':ID,'revision':POS}),
 'master_ref':obj({'kind':enum('customer','supplier','contact','sku'),'id':ID,'row_version':POS}),
 'business_ref':obj({'kind':ID,'id':ID,'revision':POS}),
 'rfq_ref':obj({'id':ID,'row_version':POS}),
 'evidence':obj({'source_id':ID,'locator':TXT}),
 'interval':obj({'valid_from':DATE,'valid_until':DATE}),
 'delivery':{'oneOf':[obj({'kind':enum('fixed'),'date':{'type':'string','format':'date'}}),obj({'kind':enum('lead_time'),'anchor':ID,'days':{'type':'integer','minimum':0,'maximum':3650},'day_basis':enum('calendar','working'),'calendar_ref':ref('config_ref')})]},
 'tier':obj({'lower_inclusive':dec(6),'upper_exclusive':dec(6,False),'unit_price':ref('price')},['lower_inclusive','unit_price']),
 'line':obj({'line_id':ID,'sku_profile_ref':ref('config_ref'),'quantity':ref('quantity'),'unit_ref':ref('config_ref'),'conversion_refs':arr(ref('config_ref'),8,0)},['line_id','sku_profile_ref','quantity','unit_ref']),
 'assumption':obj({'id':ID,'path':TXT,'value_text':TXT,'reason':TXT,'evidence':arr(ref('evidence'),20)}),
}
D['context']=obj({'rfq_ref':ref('rfq_ref'),'context_kind':enum('actual','what_if'),'lines':arr(ref('line')),'calculation_currency_ref':ref('config_ref'),'pricing_policy_ref':ref('config_ref'),'comparison_basis':obj({'specification_basis':TXT,'named_place_ref':ref('config_ref'),'required_fee_type_refs':arr(ref('config_ref'),50,0),'tax_basis':TXT,'delivery':ref('delivery')}),'requested_currency_ref':ref('config_ref'),'requested_trade_terms_ref':ref('config_ref'),'requested_payment_terms_ref':ref('config_ref'),'assumptions':arr(ref('assumption'),100,0)},['rfq_ref','context_kind','lines','calculation_currency_ref','pricing_policy_ref','comparison_basis'])
D['moq']=obj({'quantity':ref('quantity'),'unit_ref':ref('config_ref'),'scope':enum('sku','explicit_group'),'group_id':ID,'member_line_ids':arr(ID)},['quantity','unit_ref','scope'],allOf=[{'if':{'properties':{'scope':{'const':'explicit_group'}}},'then':{'required':['group_id','member_line_ids']},'else':{'not':{'anyOf':[{'required':['group_id']},{'required':['member_line_ids']}]}}}])
D['condition_line']=obj({'id':ID,'sku_profile_ref':ref('config_ref'),'supplier_item_code':TXT,'purchase_unit_ref':ref('config_ref'),'price_unit_ref':ref('config_ref'),'price_basis_quantity':ref('quantity'),'conversion_refs':arr(ref('config_ref'),8,0),'tier_unit_ref':ref('config_ref'),'price_tier_scope':enum('sku'),'pricing_mode':enum('flat','all_units','graduated'),'tiers':arr(ref('tier'),50),'moq':ref('moq'),'order_multiple':ref('quantity'),'currency_ref':ref('config_ref'),'tax_profile_ref':ref('config_ref'),'trade_terms_ref':ref('config_ref'),'payment_terms_ref':ref('config_ref'),'delivery':ref('delivery'),'included_obligation_ids':arr(ID,100,0)},['id','sku_profile_ref','purchase_unit_ref','price_unit_ref','price_basis_quantity','tier_unit_ref','price_tier_scope','pricing_mode','tiers','moq','currency_ref','tax_profile_ref','trade_terms_ref','payment_terms_ref','delivery','included_obligation_ids'])
D['offer']=obj({'supplier_ref':ref('master_ref'),'origin':{'oneOf':[obj({'kind':enum('in_response_to_rfq'),'supplier_rfq_ref':obj({'id':ID,'row_version':POS})}),obj({'kind':enum('unsolicited','imported_price_list')})]},'rfq_ref':ref('rfq_ref'),'rfq_line_ids':arr(ID),'interval':ref('interval'),'lines':arr(ref('condition_line')),'evidence':arr(ref('evidence'),100)})
D['purchase_terms']=obj({'supplier_ref':ref('master_ref'),'source_offer_ref':ref('business_ref'),'validity_mode':enum('independent_validity','dependent_validity'),'interval':ref('interval'),'lines':arr(ref('condition_line')),'evidence':arr(ref('evidence'),100)})
D['service_role']=obj({'party_ref':ref('master_ref'),'role':enum('forwarder','carrier','broker','inspection','insurer'),'service_code':ID,'origin_ref':ref('config_ref'),'destination_ref':ref('config_ref'),'interval':ref('interval'),'evidence':arr(ref('evidence'),100)})
D['supplier_rfq']=obj({'supplier_ref':ref('master_ref'),'rfq_ref':ref('rfq_ref'),'rfq_line_ids':arr(ID),'evidence':arr(ref('evidence'),100,0)})
D['package']=obj({'id':ID,'count':{'type':'integer','minimum':1,'maximum':1000000},'length_m':dec(6,False),'width_m':dec(6,False),'height_m':dec(6,False),'net_kg':dec(6,False),'gross_kg':dec(6,False),'line_ids':arr(ID)})
D['measurement']=obj({'kind':enum('measured','estimated'),'observed_at':DATE,'packages':arr(ref('package'),1000),'declared_volume_m3':dec(6,False),'estimate_reason':TXT,'evidence':arr(ref('evidence'),100)},['kind','observed_at','packages','evidence'],allOf=[{'if':{'properties':{'kind':{'const':'estimated'}}},'then':{'required':['estimate_reason']},'else':{'not':{'required':['estimate_reason']}}}])
D['allocation']={'oneOf':[obj({'basis':enum('quantity','weight','volume','amount'),'target_line_ids':arr(ID)}),obj({'basis':enum('explicit'),'weights':arr(obj({'line_id':ID,'weight':dec(0)}))})]}
D['billing']={'oneOf':[obj({'kind':enum('fixed'),'amount':ref('price')}),obj({'kind':enum('per_basis'),'rate':ref('price'),'basis_quantity':ref('quantity'),'unit_ref':ref('config_ref'),'minimum_amount':ref('price')}),obj({'kind':enum('tiered'),'pricing_mode':enum('all_units','graduated'),'tiers':arr(ref('tier'),50),'basis_quantity':ref('quantity'),'unit_ref':ref('config_ref'),'minimum_amount':ref('price')})]}
D['chargeable']={'oneOf':[obj({'kind':enum('fixed')}),obj({'kind':enum('actual_weight','volume'),'measurement_ref':ref('business_ref'),'billing_increment':ref('quantity'),'rounding_mode':enum('ceil','half_up'),'rounding_scope':enum('per_package','shipment')}),obj({'kind':enum('max_actual_volumetric'),'measurement_ref':ref('business_ref'),'divisor_m3_per_kg':dec(6,False),'billing_increment':ref('quantity'),'rounding_mode':enum('ceil','half_up'),'rounding_scope':enum('per_package','shipment'),'max_scope':enum('per_package','shipment')})]}
D['fee']=obj({'id':ID,'obligation_id':ID,'fee_type_ref':ref('config_ref'),'responsible_party':enum('seller','buyer'),'currency_ref':ref('config_ref'),'tax_profile_ref':ref('config_ref'),'billing':ref('billing'),'chargeable':ref('chargeable'),'included_in_component_ref':ID,'allocation':ref('allocation')},['id','obligation_id','fee_type_ref','responsible_party','currency_ref','tax_profile_ref','billing','chargeable','allocation'])
D['logistics']=obj({'service_role_ref':ref('business_ref'),'service_code':ID,'mode':enum('sea','air','road','rail','courier'),'origin_ref':ref('config_ref'),'destination_ref':ref('config_ref'),'interval':ref('interval'),'fees':arr(ref('fee'),500),'evidence':arr(ref('evidence'),100)})
D['allocation_source']=obj({'rfq_line_id':ID,'purchase_quantity':ref('quantity'),'purchase_unit_ref':ref('config_ref'),'source':obj({'kind':enum('offer','purchase_terms'),'id':ID,'revision':POS,'condition_line_id':ID})})
D['scenario']=obj({'context_ref':ref('business_ref'),'allocations':arr(ref('allocation_source')),'logistics_offer_refs':arr(ref('business_ref'),200,0),'fx_refs':arr(ref('config_ref'),200,0),'selection_reason':TXT})
cmds={}
def command(name,args):cmds[name]=obj({'contract':{'const':'brant.costing/0.1.0'},'command':{'const':name},'idempotency_key':ID,'args':args})
for kind,data in [('costing_context','context'),('supplier_offer','offer'),('purchase_terms','purchase_terms'),('logistics_offer','logistics'),('service_party_role','service_role')]:
 command(kind+'.save_draft',obj({'id':ID,'expected_version':VER,'data':ref(data)}))
 command(kind+'.revise',obj({'id':ID,'expected_version':POS,'base_revision':POS,'reason':TXT}))
 command(kind+'.discard_draft',obj({'id':ID,'expected_version':POS,'working_revision':POS,'reason':TXT}))
 action='publish' if kind=='purchase_terms' else 'verify'
 command(kind+'.'+action,obj({'id':ID,'expected_version':POS,'working_revision':POS,'supersedes_revision':POS,'evidence':arr(ref('evidence'),100)},['id','expected_version','working_revision','evidence']))
 command(kind+('.retire' if kind=='purchase_terms' else '.withdraw'),obj({'id':ID,'expected_version':POS,'target_revision':POS,'reason':TXT,'evidence':arr(ref('evidence'),100)}))
command('supplier_rfq.save_draft',obj({'id':ID,'expected_version':VER,'data':ref('supplier_rfq')}))
for act in ['record_issued','close']:command('supplier_rfq.'+act,obj({'id':ID,'expected_version':POS,'evidence':arr(ref('evidence'),100),'reason':TXT}))
command('measurement.record_verified',obj({'id':ID,'expected_version':{'const':0},'data':ref('measurement')}))
command('measurement.supersede',obj({'id':ID,'expected_version':POS,'active_revision':POS,'data':ref('measurement'),'reason':TXT}))
command('measurement.withdraw',obj({'id':ID,'expected_version':POS,'target_revision':POS,'reason':TXT,'evidence':arr(ref('evidence'),100)}))
command('source_denial.record',obj({'id':ID,'source_id':ID,'reason':TXT,'evidence':arr(ref('evidence'),100)}))
command('cost_scenario.save_draft',obj({'id':ID,'expected_version':VER,'data':ref('scenario')}))
command('cost_scenario.evaluate',obj({'id':ID,'expected_version':POS}))
command('cost_snapshot.freeze',obj({'scenario_id':ID,'expected_version':POS,'result_id':ID,'result_hash':{'type':'string','pattern':'^[a-f0-9]{64}$'},'selection_reason':TXT}))
# Unknown top-level draft values may be omitted; readiness is a service/verification gate.
for kind,data in [('costing_context','context'),('supplier_offer','offer'),('purchase_terms','purchase_terms'),('logistics_offer','logistics'),('service_party_role','service_role'),('supplier_rfq','supplier_rfq'),('cost_scenario','scenario')]:
 import copy
 D[data+'_draft']=copy.deepcopy(D[data]);D[data+'_draft']['required']=[]
 # Contextual origin/estimated clauses must only fire when discriminator is present.
 cmds[kind+'.save_draft']['properties']['args']['properties']['data']=ref(data+'_draft')
D['tier']['properties']['zero_price_reason']=TXT
D['fee']['properties']['zero_price_reason']=TXT
write('contracts/commands.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:brant:costing:0.1.0:candidate-1','$defs':D,'oneOf':list(cmds.values())})
write('contracts/response.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','oneOf':[obj({'ok':{'const':True},'action_id':ID,'object_id':ID,'status':ID,'replayed':{'type':'boolean'},'row_version':POS,'revision':POS,'result_hash':{'type':'string','pattern':'^[a-f0-9]{64}$'}},['ok','action_id','object_id','status','replayed']),obj({'ok':{'const':False},'code':ID,'field_errors':arr(obj({'path':TXT,'reason':TXT}),100)},['ok','code'])]})
write('contracts/permissions.json',{'candidate':True,'server_identity_only':True,'commands':{n:{'permission':n,'actor':'human' if n.endswith(('.verify','.publish','.record_verified','.supersede','.withdraw','.retire','.record_issued')) or n=='source_denial.record' else 'delegated_human_or_ai','independent':'required' if n=='purchase_terms.publish' else 'pricing_policy_for_verification','data_scope':['own','team','company'],'dependencies':'current_access_to_all_sources_and_dependencies','sensitive':'foundation.sensitive.read additionally when applicable'} for n in cmds},'read':{'permission':'costing.read','history':'current transitive dependency access, not current expiry','source_denial_read':'authorized source access; denial must block new use independently of background retirement'}})
# Deterministic fixtures use explicit candidate-only reference registry, not inferred production objects.
def c(kind,id):return {'kind':kind,'id':id,'revision':1}
def m(kind,id):return {'kind':kind,'id':id,'row_version':1}
e=[{'source_id':'source.1','locator':'line 1'}];iv={'valid_from':'2026-10-22T00:00:00Z','valid_until':'2026-10-29T00:00:00Z'}
pcs=c('unit','PCS');usd=c('currency','USD');sku=c('sku_profile','sku.1.profile');rfq={'id':'rfq.1','row_version':2};delivery={'kind':'fixed','date':'2026-11-15'}
line={'id':'OL1','sku_profile_ref':sku,'purchase_unit_ref':pcs,'price_unit_ref':pcs,'price_basis_quantity':'1','tier_unit_ref':pcs,'price_tier_scope':'sku','pricing_mode':'flat','tiers':[{'lower_inclusive':'0','unit_price':'5'}],'moq':{'quantity':'100','unit_ref':pcs,'scope':'sku'},'currency_ref':usd,'tax_profile_ref':c('tax_profile','tax.zero'),'trade_terms_ref':c('trade_terms','terms.test'),'payment_terms_ref':c('payment_terms','payment.test'),'delivery':delivery,'included_obligation_ids':[]}
context={'rfq_ref':rfq,'context_kind':'actual','lines':[{'line_id':'L1','sku_profile_ref':sku,'quantity':'120','unit_ref':pcs}],'calculation_currency_ref':usd,'pricing_policy_ref':c('pricing_policy','policy.1'),'comparison_basis':{'specification_basis':'SPEC-1','named_place_ref':c('location','port.test'),'required_fee_type_refs':[c('fee_type','freight')],'tax_basis':'synthetic_zero_nonrecoverable','delivery':delivery}}
offer={'supplier_ref':m('supplier','supplier.1'),'origin':{'kind':'unsolicited'},'rfq_ref':rfq,'rfq_line_ids':['L1'],'interval':iv,'lines':[line],'evidence':e}
role={'party_ref':m('supplier','provider.1'),'role':'forwarder','service_code':'service.test','origin_ref':c('location','origin.test'),'destination_ref':c('location','port.test'),'interval':iv,'evidence':e}
fee={'id':'F1','obligation_id':'freight.1','fee_type_ref':c('fee_type','freight'),'responsible_party':'seller','currency_ref':usd,'tax_profile_ref':c('tax_profile','tax.zero'),'billing':{'kind':'fixed','amount':'60'},'chargeable':{'kind':'fixed'},'allocation':{'basis':'quantity','target_line_ids':['L1']}}
log={'service_role_ref':c('service_party_role','provider.role'),'service_code':'service.test','mode':'sea','origin_ref':role['origin_ref'],'destination_ref':role['destination_ref'],'interval':iv,'fees':[fee],'evidence':e}
measurement={'kind':'measured','observed_at':'2026-10-22T08:00:00Z','packages':[{'id':'P1','count':1,'length_m':'1','width_m':'1','height_m':'1','net_kg':'9','gross_kg':'10','line_ids':['L1']}],'declared_volume_m3':'1','evidence':e}
scenario={'context_ref':c('costing_context','context.1'),'allocations':[{'rfq_line_id':'L1','purchase_quantity':'120','purchase_unit_ref':pcs,'source':{'kind':'offer','id':'offer.1','revision':1,'condition_line_id':'OL1'}}],'logistics_offer_refs':[c('logistics_offer','log.1')],'fx_refs':[],'selection_reason':'Same specification and terms; verified synthetic fixture'}
valid=[]
for i,(name,id,data) in enumerate([('costing_context','context.1',context),('supplier_offer','offer.1',offer),('service_party_role','provider.role',role),('logistics_offer','log.1',log),('cost_scenario','scenario.1',scenario)]):valid.append({'contract':'brant.costing/0.1.0','command':name+'.save_draft','idempotency_key':'req.'+str(i),'args':{'id':id,'expected_version':0,'data':data}})
valid.append({'contract':'brant.costing/0.1.0','command':'measurement.record_verified','idempotency_key':'req.measure','args':{'id':'measurement.1','expected_version':0,'data':measurement}})
write('examples/valid.json',valid)
registry={'as_of':'2026-10-22T09:00:00Z','server_scope':{'tenant':'tenant.test','company':'company.test'},'sources':[{'id':'source.1','status':'verified','readable':True,'denied':False}],'rfqs':[{'id':'rfq.1','row_version':2,'status':'ready','lines':context['lines']}],'configs':[{'ref':pcs,'data':{'code':'PCS','precision':0,'dimension':'count'}},{'ref':usd,'data':{'code':'USD','minor_units':2,'rounding':'HALF_UP'}},{'ref':sku,'data':{'sku_id':'sku.1','specification_version':'SPEC-1','base_unit':'PCS'}},{'ref':c('tax_profile','tax.zero'),'data':{'rate':'0','price_basis':'exclusive','recovery_treatment':'nonrecoverable'}},{'ref':c('pricing_policy','policy.1'),'data':{'calculation_currency':'USD','independent_review':True,'allow_verified_estimates':False}}]+[{'ref':x,'data':{'synthetic':True}} for x in [c('trade_terms','terms.test'),c('payment_terms','payment.test'),c('location','port.test'),c('location','origin.test'),c('fee_type','freight')]],'masters':[m('supplier','supplier.1'),m('supplier','provider.1'),m('sku','sku.1')],'verified_business':[{'ref':c('costing_context','context.1'),'data':context},{'ref':c('supplier_offer','offer.1'),'data':offer},{'ref':c('service_party_role','provider.role'),'data':role},{'ref':c('logistics_offer','log.1'),'data':log}],'notice':'Synthetic validator fixture; candidate location/service role/policy extension have not been implemented in foundation runtime.'}
write('examples/registry.json',registry)
write('examples/expected.json',{'purchase_original':'600.00','direct_fees':'60.00','total_cost':'660.00','currency':'USD','model_calls':0,'external_actions':0,'business_service_implemented':False})
write('examples/responses.json',[{'ok':True,'action_id':'action.1','object_id':'scenario.1','status':'evaluated','replayed':False},{'ok':False,'code':'PERMISSION_DENIED'},{'ok':False,'code':'MOQ_NOT_MET','field_errors':[{'path':'/args/data/allocations/0','reason':'Selected quantity below MOQ'}]}])
print(len(cmds),'candidate command branches generated')

# Return and query payloads are generated by a companion using the same package root.
import subprocess,sys
subprocess.run([sys.executable,str(P/"scripts/build_returns.py")],check=True)

subprocess.run([sys.executable,str(P/"scripts/build_extension.py")],check=True)
