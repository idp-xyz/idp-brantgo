import copy,json
from pathlib import Path
P=Path(__file__).resolve().parent.parent
def obj(p,required=None):return {'type':'object','properties':p,'required':list(p) if required is None else required,'additionalProperties':False}
def arr(p):return {'type':'array','items':p,'maxItems':1000}
ID={'type':'string','minLength':1,'maxLength':64,'pattern':'^[A-Za-z0-9][A-Za-z0-9._:-]*$','not':{'pattern':'[^A-Za-z0-9._:-]'}}
HASH={'type':'string','pattern':'^[a-f0-9]{64}$'}
POS={'type':'integer','minimum':1,'maximum':2147483647}
MINOR={'type':'string','pattern':'^(0|[1-9][0-9]{0,16})$'}
REF=obj({'kind':ID,'id':ID,'revision':POS})
manifest=obj({'kind':ID,'id':ID,'version':POS,'content_hash':HASH})
allocation=obj({'line_id':ID,'amount_minor':MINOR,'basis':{'enum':['quantity','weight','volume','amount','explicit']},'base_integer':MINOR})
component=obj({'id':ID,'obligation_id':ID,'amount_minor':MINOR,'allocations':arr(allocation)})
common={'scenario_id':ID,'input_scenario_version':POS,'context_ref':REF,'rfq_ref':obj({'id':ID,'row_version':POS}),'engine_version':ID,'calculation_time':{'type':'string','format':'date-time'},'input_manifest':arr(manifest),'input_hash':HASH,'result_hash':HASH,'comparison_status':{'enum':['comparable','not_comparable']},'verification_status':{'enum':['verified','provisional']},'currency':{'type':'string','pattern':'^[A-Z]{3}$'},'minor_units':{'type':'integer','minimum':0,'maximum':4},'components':arr(component),'total_minor':MINOR,'differences':arr(obj({'path':{'type':'string','minLength':1,'maxLength':1000},'reason':{'type':'string','minLength':1,'maxLength':1000}}))}
evalresult=obj({'kind':{'const':'evaluation'},'id':ID,**common})
snapshot=obj({'kind':{'const':'snapshot'},'id':ID,'evaluation_id':ID,'frozen_scenario_version':POS,'selection_reason':{'type':'string','minLength':1,'maxLength':1000},'evidence_hash':HASH,**common})
ack=obj({'kind':{'const':'ack'},'root_version':POS,'active_revision':POS,'working_revision':POS},['kind','root_version'])
success=obj({'ok':{'const':True},'action_id':ID,'object_id':ID,'status':{'enum':['draft','verified','active','withdrawn','retired','issued','closed','evaluated','frozen']},'replayed':{'type':'boolean'},'row_version':POS,'revision':POS,'result_hash':HASH,'result':{'oneOf':[ack,evalresult,snapshot]}},['ok','action_id','object_id','status','replayed'])
success['allOf']=[{'if':{'properties':{'status':{'const':status}}},'then':{'required':['result'],'properties':{'result':schema}}} for status,schema in [('evaluated',evalresult),('frozen',snapshot)]]
error=obj({'ok':{'const':False},'code':ID,'field_errors':arr(obj({'path':{'type':'string','minLength':1,'maxLength':1000},'reason':{'type':'string','minLength':1,'maxLength':1000}}))},['ok','code'])
error['allOf']=[{'if':{'properties':{'code':{'enum':['PERMISSION_DENIED','NOT_FOUND']}}},'then':{'not':{'required':['field_errors']}}}]
def write(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
write('contracts/response.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','oneOf':[success,error]})
write('contracts/query.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','oneOf':[obj({'kind':{'const':'evaluation_query'},'evaluation':evalresult}),obj({'kind':{'const':'snapshot_query'},'snapshot':snapshot,'currently_eligible_for_quote':{'type':'boolean'},'eligibility_checked_at':{'type':'string','format':'date-time'}})]})
sample={'kind':'evaluation','id':'result.1','scenario_id':'scenario.1','input_scenario_version':1,'context_ref':{'kind':'costing_context','id':'context.1','revision':1},'rfq_ref':{'id':'rfq.1','row_version':2},'engine_version':'candidate.rules.0.2','calculation_time':'2026-10-22T09:00:00Z','input_manifest':[{'kind':'supplier_offer','id':'offer.1','version':1,'content_hash':'a'*64}],'input_hash':'b'*64,'result_hash':'c'*64,'comparison_status':'comparable','verification_status':'verified','currency':'USD','minor_units':2,'components':[{'id':'goods','obligation_id':'goods.1','amount_minor':'60000','allocations':[{'line_id':'L1','amount_minor':'60000','basis':'quantity','base_integer':'120'}]},{'id':'freight','obligation_id':'freight.1','amount_minor':'6000','allocations':[{'line_id':'L1','amount_minor':'6000','basis':'quantity','base_integer':'120'}]}],'total_minor':'66000','differences':[]}
# Generate canonical input/result hashes from complete candidate fixture payloads.
import hashlib
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def sha(x):return hashlib.sha256(canon(x).encode()).hexdigest()
registry=json.loads((P/'examples/registry.json').read_text())
sample['input_manifest'][0]['content_hash']=sha(registry['verified_business'][1]['data'])
sample['input_hash']=sha(registry)
sample['components'].sort(key=lambda c:c['id'])
sample['result_hash']=sha({k:v for k,v in sample.items() if k!='result_hash'})

snap={**copy.deepcopy(sample),'kind':'snapshot','id':'snapshot.1','evaluation_id':'result.1','frozen_scenario_version':2,'selection_reason':'Verified synthetic selection'}
snap['evidence_hash']=sha(snap)
write('examples/responses.json',[{'ok':True,'action_id':'action.1','object_id':'scenario.1','status':'evaluated','replayed':False,'result':sample},{'ok':False,'code':'PERMISSION_DENIED'},{'ok':False,'code':'MOQ_NOT_MET','field_errors':[{'path':'/args/data/allocations/0','reason':'Selected quantity below MOQ'}]},{'ok':True,'action_id':'action.2','object_id':'snapshot.1','status':'frozen','replayed':False,'result':snap}])
write('examples/query-responses.json',[{'kind':'evaluation_query','evaluation':sample},{'kind':'snapshot_query','snapshot':snap,'currently_eligible_for_quote':True,'eligibility_checked_at':'2026-10-22T09:00:00Z'}])
