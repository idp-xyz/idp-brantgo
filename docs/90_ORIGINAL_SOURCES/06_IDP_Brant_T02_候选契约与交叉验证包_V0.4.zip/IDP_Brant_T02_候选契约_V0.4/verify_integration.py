from copy import deepcopy
import json
from validator import ROOT,REG,SCHEMA,Invalid,digest
from integrated_model import IntegratedModel
checks=[];traces=[];commands=[x['properties']['command']['const'] for x in SCHEMA['oneOf']]
a={'tenant':'tenant.test','company':'company.test','id':'author','kind':'human','readable':True,'grants':commands+['costing.read']};b={**a,'id':'reviewer'}
valid=json.loads((ROOT/'examples/valid.json').read_text());ctx=deepcopy(valid[0]['args']['data']);sc=deepcopy(valid[4]['args']['data'])
def run(m,name,args,key,actor=b):
 req={'contract':'brant.costing/0.1.0','command':name,'idempotency_key':key,'args':deepcopy(args)}
 return m.execute(actor,req)
def prepared(registry=None):
 m=IntegratedModel(registry);run(m,'costing_context.save_draft',{'id':'context.1','expected_version':0,'data':ctx},'ctx.save',a);run(m,'costing_context.verify',{'id':'context.1','expected_version':1,'working_revision':1,'evidence':[{'source_id':'source.1','locator':'line 1'}]},'ctx.verify');run(m,'cost_scenario.save_draft',{'id':'scenario.1','expected_version':0,'data':sc},'sc.save',a);return m
def ok(name,test):test();checks.append({'name':name,'passed':True})
def eq(a,b):assert a==b,(a,b)
def reject(name,code,fn):
 try:fn()
 except Invalid as e:assert e.code==code,(name,e.code,code);checks.append({'name':name,'passed':True,'expected_rejection':code})
 else:raise AssertionError(name+' accepted')
def evaluate(m,key='evaluate'):return run(m,'cost_scenario.evaluate',{'id':'scenario.1','expected_version':1},key)
def freeze(m,r,key='freeze'):return run(m,'cost_snapshot.freeze',{'scenario_id':'scenario.1','expected_version':1,'result_id':r['result_id'],'result_hash':r['result_hash'],'selection_reason':'Verified same specification'},key)
m=prepared();r=evaluate(m);ok('bound_cost66000minor',lambda:eq(r['result']['total_minor'],'66000'))
response=m.response('cost_scenario.evaluate',r);traces.append(response);ok('generated_evaluation_passes_response_schema',lambda:eq(response['status'],'evaluated'))
ok('result_hash_matches_exact_evaluation_payload',lambda:eq(r['result_hash'],digest({k:v for k,v in r['result'].items() if k!='result_hash'})))
s=freeze(m,r);traces.append(m.response('cost_snapshot.freeze',s));ok('generated_snapshot_passes_response_schema',lambda:eq(s['result']['total_minor'],'66000'))
ok('snapshot_preserves_original_evaluation_hash',lambda:eq(s['result']['result_hash'],r['result_hash']))
ok('frozen_after_input_version_plus1',lambda:eq(s['result']['frozen_scenario_version'],2))
replay=freeze(m,r);ok('freeze_replay_is_original_snapshot',lambda:eq(replay['result']['id'],s['result']['id']))
reject('second_freeze_CAS_rejected','VERSION_CONFLICT',lambda:freeze(m,r,'freeze.again'))
# Dependency invalidation after evaluation must be checked on new freeze, not silently reused.
def changed(change,code,label):
 x=prepared();out=evaluate(x);change(x);reject(label,code,lambda:freeze(x,out));assert x.scenarios['scenario.1']['status']=='draft' and not x.complete_snapshots
changed(lambda x:x.registry['sources'][0].update(readable=False),'PERMISSION_DENIED','source_read_revocation_blocks_freeze')
changed(lambda x:x.registry['sources'][0].update(denied=True),'REFERENCE_STALE','source_denial_blocks_freeze')
changed(lambda x:x.registry['verified_business'][1].update(active=False),'REFERENCE_STALE','withdrawn_offer_blocks_freeze')
changed(lambda x:x.registry['verified_business'].append({**deepcopy(x.registry['verified_business'][1]),'ref':{'kind':'supplier_offer','id':'offer.1','revision':2}}),'REFERENCE_STALE','superseded_offer_blocks_freeze')
changed(lambda x:x.registry['verified_business'][1]['data']['lines'][0]['tiers'][0].update(unit_price='6'),'REFERENCE_STALE','same_ref_content_hash_change_blocks_freeze')
changed(lambda x:x.registry['rfqs'][0].update(row_version=3),'REFERENCE_STALE','RFQ_parent_version_change_blocks_freeze')
changed(lambda x:x.registry['configs'][1]['data'].update(minor_units=3),'REFERENCE_STALE','currency_precision_change_blocks_freeze')
# Misbound result hash doesn't commit state.
x=prepared();out=evaluate(x)
reject('client_result_hash_cannot_override_server','REFERENCE_STALE',lambda:run(x,'cost_snapshot.freeze',{'scenario_id':'scenario.1','expected_version':1,'result_id':out['result_id'],'result_hash':'0'*64,'selection_reason':'bad'},'bad.hash'))
# Failed evaluate must roll back the internal binding result created by the base dispatcher.
x=prepared();x.registry['verified_business'][1]['data']['lines'][0]['moq']['quantity']='200'
reject('failed_integrated_evaluation_rolls_back','MOQ_NOT_MET',lambda:evaluate(x));ok('no_half_result_after_failure',lambda:eq(len(x.results),0))
# Historical source denial/expiry doesn't erase payload, but current read access does.
x=prepared();out=evaluate(x);x.clock='2026-11-30T09:00:00Z';x.registry['sources'][0]['denied']=True
ok('historical_result_read_after_expiry_denial',lambda:eq(x.history(b,out['result_id'])['total_minor'],'66000'))
x.registry['sources'][0]['readable']=False
reject('historical_result_requires_current_source_access','PERMISSION_DENIED',lambda:x.history(b,out['result_id']))
# Cross-currency integrated path, explicit rate direction & source age.
reg=deepcopy(REG);usd=reg['configs'][1];reg['configs'].append({'ref':{'kind':'currency','id':'CNY','revision':1},'data':{'code':'CNY','minor_units':2,'rounding':'HALF_UP'}})
policy=next(q for q in reg['configs'] if q['ref']['kind']=='pricing_policy');policy['data']['calculation_currency']='CNY';policy['data']['max_fx_age_seconds']=3600
reg['configs'].append({'ref':{'kind':'fx','id':'fx.test','revision':1},'data':{'from_currency':'USD','to_currency':'CNY','purpose':'cost_estimate','rate':'7.123456','observed_at':'2026-10-22T08:00:00Z','valid_from':'2026-10-22T00:00:00Z','valid_until':'2026-10-29T00:00:00Z'}})
x=IntegratedModel(reg);ctx2={**deepcopy(ctx),'calculation_currency_ref':{'kind':'currency','id':'CNY','revision':1}}
run(x,'costing_context.save_draft',{'id':'context.1','expected_version':0,'data':ctx2},'ctx.cny',a);run(x,'costing_context.verify',{'id':'context.1','expected_version':1,'working_revision':1,'evidence':[{'source_id':'source.1','locator':'line 1'}]},'ctx.cny.verify')
sc2={**deepcopy(sc),'fx_refs':[{'kind':'fx','id':'fx.test','revision':1}]};run(x,'cost_scenario.save_draft',{'id':'scenario.1','expected_version':0,'data':sc2},'sc.cny',a)
out=evaluate(x);ok('cross_currency_components_round_independently',lambda:eq(out['result']['total_minor'],'470148'))
x.clock='2026-10-22T09:00:01Z';reject('FX_source_age_rechecked_at_freeze','FX_NOT_APPLICABLE',lambda:freeze(x,out))
# Explicit unsupported integrated modes cannot silently pass using the simple path.
x=prepared();x.registry['verified_business'][3]['data']['fees'][0]['included_in_component_ref']='purchase.1'
reject('included_fee_integration_explicitly_closed','DEPENDENCY_NOT_SUPPORTED',lambda:evaluate(x))
# Replays recheck current dependency access, while expiry/denial alone does not recalculate.
x=prepared();out=evaluate(x);x.registry['sources'][0]['readable']=False
reject('evaluation_replay_checks_source_read_access','PERMISSION_DENIED',lambda:evaluate(x))
x=prepared();out=evaluate(x);x.registry['sources'][0]['denied']=True
ok('evaluation_replay_retains_original_after_denial',lambda:eq(evaluate(x)['result']['result_hash'],out['result_hash']))
x=prepared();out=evaluate(x);x.registry['configs'][1]['readable']=False
reject('evaluation_replay_checks_config_access','PERMISSION_DENIED',lambda:evaluate(x))
reject('foreign_company_history_rejected','NOT_FOUND',lambda:x.history({**b,'company':'other'},out['result_id']))
x=prepared();out=evaluate(x)
returned=deepcopy(out);returned['result']['total_minor']='0'
ok('caller_payload_mutation_cannot_change_server_result',lambda:eq(x.complete_results[out['result_id']]['total_minor'],'66000'))
# Reordered same-source allocations must not change content totals.
x=prepared();root=x.scenarios['scenario.1'];one=deepcopy(root['data']['allocations'][0]);root['data']['allocations']=[{**deepcopy(one),'purchase_quantity':'50'},{**deepcopy(one),'purchase_quantity':'70'}]
o1=evaluate(x);root['data']['allocations'].reverse();o2=evaluate(x,'evaluate.reorder')
ok('allocation_order_preserves_input_hash',lambda:eq(o1['result']['input_hash'],o2['result']['input_hash']))
ok('allocation_order_preserves_components',lambda:eq(o1['result']['components'],o2['result']['components']))
from output_evidence import check_hashes,paths
for response in traces:
 ok('generated_'+response['status']+'_evidence_hash',lambda response=response:check_hashes(response['result']))
modified=deepcopy(traces[-1]['result']);modified['selection_reason']='changed after freezing'
reject('snapshot_selection_is_bound_by_evidence_hash','EVIDENCE_HASH_MISMATCH',lambda:check_hashes(modified))
(ROOT/'contracts/output-evidence-paths.json').write_text(json.dumps(paths(),ensure_ascii=False,indent=2)+'\n')
x=prepared();out=evaluate(x);x.clock='2026-10-22T10:00:00Z';later=freeze(x,out)
ok('later_freeze_keeps_original_calculation_time',lambda:eq(later['result']['calculation_time'],out['result']['calculation_time']))
reject('history_requires_explicit_costing_read','PERMISSION_DENIED',lambda:x.history({**b,'grants':commands},out['result_id']))
x=prepared();out=evaluate(x);x.clock='2026-10-29T00:00:00Z'
reject('offer_expiry_rechecked_at_freeze','REFERENCE_STALE',lambda:freeze(x,out))
report={'checks_passed':len(checks),'checks':checks,'integrated_reference_path':'same-unit selected offers, explicit currency/tax, fixed seller charges, quantity/amount/explicit allocation','full_business_service':False,'database_transactions':False,'production_authentication':False,'unsupported_paths_explicitly_rejected':True}
(ROOT/'evidence/integration-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(ROOT/'examples/generated-integration-responses.json').write_text(json.dumps(traces,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'registry_bound_checks':len(checks),'reference_model_only':True}))
