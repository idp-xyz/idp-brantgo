"""Observe the declared in-memory configuration API, never its private state."""

from copy import deepcopy
from dataclasses import replace

from .build_contracts import CONFIG_CONTRACT, CONFIG_KINDS
from .calculation import calculate
from .configuration import CandidateActor, ConfigurationModel
from .dependencies import References
from .protocol import digest, validate


def checks(registry, quote, passed, reject):
    scope = registry["server_scope"]
    grants = frozenset(
        {
            "quotation_foundation.read",
            *(
                "quotation_foundation." + action
                for action in ("save_draft", "revise", "publish", "discard_draft", "retire")
            ),
        }
    )
    author = CandidateActor(
        **scope, id="config.author", grants=grants, team="trade", data_scope="team"
    )
    reviewer = replace(author, id="config.reviewer", data_scope="company")
    evidence = [{"source_id": "source.1", "locator": "Synthetic independent configuration check"}]
    policy_ref = quote["pricing_policy_ref"]

    def fixture():
        host = deepcopy(registry)
        return ConfigurationModel(host, policy_ref=policy_ref, clock=lambda: host["as_of"]), host

    def request(kind, action, version, *, key=None, id_="config.lifecycle", **args):
        body = {"kind": kind, "id": id_, "expected_version": version, **deepcopy(args)}
        if action in ("publish", "discard_draft", "retire"):
            body.update(reason="Synthetic reviewed action", evidence=deepcopy(evidence))
        return {
            "contract": CONFIG_CONTRACT,
            "command": "quotation_foundation." + action,
            "idempotency_key": key or kind + "." + action + "." + str(version),
            "args": body,
        }

    def sample(kind):
        return deepcopy(next(r["data"] for r in registry["records"] if r["ref"]["kind"] == kind))

    def check(name, condition=True):
        passed("configuration-lifecycle", name, condition)

    def denied(name, code, operation):
        reject("configuration-lifecycle", name, code, operation)

    def unchanged(model, kind, operation, code, name, revision=1):
        before = model.get(reviewer, kind, "config.lifecycle", revision)
        events = model.events(reviewer, kind, "config.lifecycle")
        denied(name, code, operation)
        check(
            name + ":no mutation",
            model.get(reviewer, kind, "config.lifecycle", revision) == before
            and model.events(reviewer, kind, "config.lifecycle") == events,
        )

    for kind in CONFIG_KINDS:
        model, host = fixture()
        save = request(kind, "save_draft", 0, data=sample(kind))
        ack = model.execute(author, save)
        check(
            kind + ":save revision 1",
            ack["root_version"] == 1
            and ack["working_revision"] == 1
            and "active_revision" not in ack,
        )
        observed = model.get(author, kind, "config.lifecycle", 1)
        query = {"contract": CONFIG_CONTRACT, "kind": kind, "id": "config.lifecycle", "revision": 1}
        validate(query, "configuration.queries.schema.json")
        validate(observed, "configuration.query-responses.schema.json")
        check(
            kind + ":closed read data",
            not observed["sealed"] and observed["data_hash"] == digest(sample(kind)),
        )
        observed["data"]["name"] = "Untrusted changed returned copy"
        check(
            kind + ":read copy isolation",
            model.get(author, kind, "config.lifecycle", 1)["data"] == sample(kind),
        )
        publish = request(kind, "publish", 1, working_revision=1)
        unchanged(
            model,
            kind,
            lambda: model.execute(author, publish),
            "INDEPENDENT_REVIEW_REQUIRED",
            kind + ":self publish",
        )
        unchanged(
            model,
            kind,
            lambda: model.execute(replace(reviewer, kind="ai"), publish),
            "PERMISSION_DENIED",
            kind + ":AI publish",
        )
        unchanged(
            model,
            kind,
            lambda: model.execute(replace(reviewer, grants=frozenset()), publish),
            "PERMISSION_DENIED",
            kind + ":grant required",
        )
        stale = deepcopy(publish)
        stale["args"]["expected_version"] = 0
        unchanged(
            model,
            kind,
            lambda: model.execute(reviewer, stale),
            "VERSION_CONFLICT",
            kind + ":CAS required",
        )
        ack = model.execute(reviewer, publish)
        sealed = model.get(reviewer, kind, "config.lifecycle", 1)
        check(
            kind + ":independent publication",
            sealed["sealed"]
            and sealed["effectivity"] == "active"
            and sealed["publication"]["published_by"] == reviewer.id
            and ack["active_revision"] == 1,
        )
        events = model.events(reviewer, kind, "config.lifecycle")
        replay = model.execute(reviewer, publish)
        check(
            kind + ":success replay",
            replay["action_id"] == ack["action_id"]
            and replay["replayed"]
            and model.events(reviewer, kind, "config.lifecycle") == events,
        )
        conflicting = deepcopy(publish)
        conflicting["args"]["expected_version"] = 2
        unchanged(
            model,
            kind,
            lambda: model.execute(reviewer, conflicting),
            "IDEMPOTENCY_PAYLOAD_CONFLICT",
            kind + ":replay binds CAS",
        )
        hidden = replace(author, id="other.owner", data_scope="own")
        denied(
            kind + ":own scope read",
            "PERMISSION_DENIED",
            lambda: model.get(hidden, kind, "config.lifecycle", 1),
        )
        denied(
            kind + ":own scope replay", "PERMISSION_DENIED", lambda: model.execute(hidden, publish)
        )
        denied(
            kind + ":other company",
            "NOT_FOUND",
            lambda: model.get(
                replace(reviewer, company="other.company"), kind, "config.lifecycle", 1
            ),
        )
        check(
            kind + ":same team read",
            model.get(replace(author, id="team.reader"), kind, "config.lifecycle", 1) == sealed,
        )
        denied(
            kind + ":other team",
            "PERMISSION_DENIED",
            lambda: model.get(
                replace(author, id="team.reader", team="other"), kind, "config.lifecycle", 1
            ),
        )
        model.execute(author, request(kind, "revise", 2, base_revision=1))
        check(
            kind + ":revision leaves active",
            model.get(reviewer, kind, "config.lifecycle", 1)["effectivity"] == "active"
            and model.get(author, kind, "config.lifecycle")["revision"] == 2,
        )
        unchanged(
            model,
            kind,
            lambda: model.execute(author, request(kind, "revise", 3, base_revision=1)),
            "INVALID_STATE",
            kind + ":one working draft",
        )
        model.execute(reviewer, request(kind, "discard_draft", 3, working_revision=2))
        check(
            kind + ":discard preserves active",
            model.get(reviewer, kind, "config.lifecycle", 2)["effectivity"] == "discarded"
            and model.get(reviewer, kind, "config.lifecycle")["revision"] == 1,
        )
        model.execute(author, request(kind, "revise", 4, base_revision=1))
        changed = sample(kind)
        changed["name"] += " revised"
        model.execute(author, request(kind, "save_draft", 5, data=changed))
        check(
            kind + ":discarded number not reused",
            model.get(author, kind, "config.lifecycle")["revision"] == 3,
        )
        model.execute(reviewer, request(kind, "publish", 6, working_revision=3))
        third = model.get(reviewer, kind, "config.lifecycle", 3)
        check(
            kind + ":replace single active",
            third["effectivity"] == "active"
            and model.get(reviewer, kind, "config.lifecycle", 1)["effectivity"] == "superseded",
        )
        ack = model.execute(reviewer, request(kind, "retire", 7, target_revision=1))
        check(
            kind + ":retire old keeps new",
            ack["active_revision"] == 3
            and model.get(reviewer, kind, "config.lifecycle", 3)["effectivity"] == "active",
        )
        old = model.get(reviewer, kind, "config.lifecycle", 1)
        check(
            kind + ":immutable old record",
            old["record_hash"] == sealed["record_hash"] and old["data"] == sealed["data"],
        )
        model.execute(reviewer, request(kind, "retire", 8, target_revision=3))
        retired = model.get(reviewer, kind, "config.lifecycle", 3)
        check(
            kind + ":retirement preserves bytes",
            retired["effectivity"] == "retired" and retired["record_hash"] == third["record_hash"],
        )
        denied(
            kind + ":no automatic fallback",
            "NOT_FOUND",
            lambda: model.get(reviewer, kind, "config.lifecycle"),
        )
        ref = {"kind": kind, "id": "config.lifecycle", "revision": 3}
        denied(
            kind + ":retired adoption",
            "REFERENCE_STALE",
            lambda: References(model.adoption_registry(reviewer), host["as_of"]).get(ref),
        )
        check(
            kind + ":retired historical read",
            References(model.adoption_registry(reviewer), host["as_of"]).history(ref) == changed,
        )
        unchanged(
            model,
            kind,
            lambda: model.execute(reviewer, request(kind, "retire", 9, target_revision=3)),
            "INVALID_STATE",
            kind + ":repeat retirement rejected",
            revision=3,
        )
        # A successful old action is historical; denial blocks forward use but
        # does not rewrite the old action or discard its now-readable result.
        host["sources"]["source.1"]["denied"] = True
        check(
            kind + ":denial permits historical replay", model.execute(reviewer, publish)["replayed"]
        )
        host["sources"]["source.1"]["readable"] = False
        denied(
            kind + ":revoked source blocks read",
            "PERMISSION_DENIED",
            lambda: model.get(reviewer, kind, "config.lifecycle", 3),
        )
        denied(
            kind + ":revoked source blocks replay",
            "PERMISSION_DENIED",
            lambda: model.execute(reviewer, publish),
        )

        # Discard of a never-published root can start a new numbered draft.
        fresh, _ = fixture()
        fresh.execute(author, save)
        fresh.execute(author, request(kind, "discard_draft", 1, working_revision=1))
        next_ack = fresh.execute(author, request(kind, "save_draft", 2, data=sample(kind)))
        check(kind + ":restart unpublished discarded root", next_ack["working_revision"] == 2)

    kind = "quote_document_template"
    model, host = fixture()
    model.execute(author, request(kind, "save_draft", 0, data=sample(kind)))
    publish = request(kind, "publish", 1, working_revision=1)
    policy = next(r for r in host["records"] if r["ref"] == policy_ref)
    policy["active"] = False
    unchanged(
        model,
        kind,
        lambda: model.execute(reviewer, publish),
        "REFERENCE_STALE",
        "inactive publication policy",
    )
    policy["active"] = True
    ack = model.execute(reviewer, publish)
    check("rejected key remains retryable", ack["root_version"] == 2 and not ack["replayed"])
    bad = deepcopy(publish)
    bad["args"]["reason"] += " changed"
    denied(
        "success key binds reason",
        "IDEMPOTENCY_PAYLOAD_CONFLICT",
        lambda: model.execute(reviewer, bad),
    )
    model.execute(author, request(kind, "revise", 2, base_revision=1))
    host["sources"]["clean.source"] = {**host["sources"]["source.1"], "content_hash": "a" * 64}
    host["sources"]["source.1"]["denied"] = True
    second = request(kind, "publish", 3, working_revision=2)
    second["args"]["evidence"] = [{"source_id": "clean.source", "locator": "New evidence"}]
    unchanged(
        model,
        kind,
        lambda: model.execute(reviewer, second),
        "REFERENCE_STALE",
        "old denied provenance blocks new publication",
    )
    retire = request(kind, "retire", 3, target_revision=1)
    retire["args"]["evidence"] = deepcopy(second["args"]["evidence"])
    model.execute(reviewer, retire)
    check(
        "new evidence can retire disputed historical content",
        model.get(reviewer, kind, "config.lifecycle", 1)["effectivity"] == "retired",
    )
    host["sources"]["clean.source"]["readable"] = False
    check(
        "record history does not expose later action evidence",
        model.get(reviewer, kind, "config.lifecycle", 1)["effectivity"] == "retired",
    )
    denied(
        "event read rechecks its own later evidence",
        "PERMISSION_DENIED",
        lambda: model.events(reviewer, kind, "config.lifecycle"),
    )
    denied(
        "retire replay rechecks later evidence",
        "PERMISSION_DENIED",
        lambda: model.execute(reviewer, retire),
    )

    model, host = fixture()
    unsupported = sample(kind)
    unsupported["language"] = "zh-CN"
    model.execute(author, request(kind, "save_draft", 0, data=unsupported))
    unchanged(
        model,
        kind,
        lambda: model.execute(reviewer, publish),
        "DEPENDENCY_NOT_SUPPORTED",
        "unsupported renderer fails closed",
    )

    # Publish both real reference objects, then consume them via the quote API.
    model, host = fixture()
    live_quote = deepcopy(quote)
    for kind in CONFIG_KINDS:
        model.execute(author, request(kind, "save_draft", 0, data=sample(kind)))
        model.execute(reviewer, request(kind, "publish", 1, working_revision=1))
        ref = {"kind": kind, "id": "config.lifecycle", "revision": 1}
        if kind == "quote_document_template":
            live_quote["document_template_ref"] = ref
        else:
            live_quote["lines"][0]["tax_application_ref"] = ref
    result, refs, _ = calculate(live_quote, model.adoption_registry(reviewer), host["as_of"])
    check(
        "published configurations feed quote calculation",
        result["payable_minor"] == "96000"
        and any(k[0] == "quotation_publication.sales_tax_application" for k in refs.used),
    )
    model.execute(reviewer, request("sales_tax_application", "retire", 2, target_revision=1))
    denied(
        "retired tax application blocks new quotation",
        "REFERENCE_STALE",
        lambda: calculate(live_quote, model.adoption_registry(reviewer), host["as_of"]),
    )

    kind = "sales_tax_application"
    for name, mutation, code in (
        (
            "expired applicability",
            lambda x: x.update(valid_until="2026-10-22T09:00:00Z"),
            "REFERENCE_STALE",
        ),
        (
            "wrong customer kind",
            lambda x: x["customer_ref"].update(kind="supplier", id="supplier.1"),
            "REFERENCE_INVALID",
        ),
    ):
        model, _ = fixture()
        bad_data = sample(kind)
        mutation(bad_data)
        if name == "wrong customer kind":
            denied(
                name,
                code,
                lambda: model.execute(author, request(kind, "save_draft", 0, data=bad_data)),
            )
        else:
            model.execute(author, request(kind, "save_draft", 0, data=bad_data))
            unchanged(
                model,
                kind,
                lambda: model.execute(reviewer, request(kind, "publish", 1, working_revision=1)),
                code,
                name,
            )

    model, host = fixture()
    model.execute(author, request(kind, "save_draft", 0, data=sample(kind)))
    contact = next(r for r in host["records"] if r["ref"]["kind"] == "sku")
    contact["data"]["status"] = "draft"
    contact["content_hash"] = digest(contact["data"])
    unchanged(
        model,
        kind,
        lambda: model.execute(reviewer, request(kind, "publish", 1, working_revision=1)),
        "REFERENCE_STALE",
        "unconfirmed SKU cannot publish applicability",
    )

    # Grant revocation also applies to old successes and historical queries.
    model, _ = fixture()
    save = request(kind, "save_draft", 0, data=sample(kind))
    model.execute(author, save)
    denied(
        "revoked command grant blocks replay",
        "PERMISSION_DENIED",
        lambda: model.execute(
            replace(author, grants=frozenset({"quotation_foundation.read"})), save
        ),
    )
    denied(
        "read grant not inferred from write grant",
        "PERMISSION_DENIED",
        lambda: model.get(
            replace(author, grants=frozenset({"quotation_foundation.save_draft"})),
            kind,
            "config.lifecycle",
            1,
        ),
    )

    model, host = fixture()
    original = sample(kind)
    model.execute(author, request(kind, "save_draft", 0, data=original))
    old_tax = next(r for r in host["records"] if r["ref"] == original["tax_profile_ref"])
    new_tax = deepcopy(old_tax)
    new_tax["ref"]["id"] = "tax.replacement"
    host["records"].append(new_tax)
    changed = deepcopy(original)
    changed["tax_profile_ref"] = new_tax["ref"]
    model.execute(author, request(kind, "save_draft", 1, data=changed))
    old_tax["readable"] = False
    check(
        "current draft can read its replacement dependency",
        model.get(author, kind, "config.lifecycle", 1)["data"] == changed,
    )
    denied(
        "event history checks overwritten draft dependency",
        "PERMISSION_DENIED",
        lambda: model.events(reviewer, kind, "config.lifecycle"),
    )
    denied(
        "save replay checks its overwritten original dependency",
        "PERMISSION_DENIED",
        lambda: model.execute(author, request(kind, "save_draft", 0, data=original)),
    )
