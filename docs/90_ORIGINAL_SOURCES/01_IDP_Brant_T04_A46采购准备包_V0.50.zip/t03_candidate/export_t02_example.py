"""Rebuild a synthetic export through the existing public core, never T03."""

import importlib.util
import json
import sqlite3
import tempfile
from datetime import datetime
from pathlib import Path

from brant_core import Core

from .build_contracts import ROOT


def export():
    source = ROOT.parent / "tests/costing_fixture.py"
    spec = importlib.util.spec_from_file_location("costing_export_fixture", source)
    if spec is None or spec.loader is None:
        raise RuntimeError("fixture unavailable")
    fixture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fixture)
    with tempfile.TemporaryDirectory() as temp:
        core = Core(
            Path(temp) / "export.sqlite",
            clock=lambda: datetime.fromisoformat("2026-10-22T09:00:00+00:00"),
        )
        trade = fixture.TradeFixture(core)
        for who in (trade.author, trade.reviewer):
            core.provision(who, ["*"], data_scope="company")
        trade.prepare()
        evaluation = trade.evaluate()
        frozen = core.execute(trade.reviewer, trade.freeze_request(evaluation))
        query = core.costing_get(trade.reviewer, "snapshot_query", frozen["result"]["id"])
        reference = query["snapshot"]["context_ref"]
        context = core.costing_get(
            trade.reviewer, "costing_context", reference["id"], reference["revision"]
        )
        # Configuration bytes are exported at the declared SQLite file-format
        # boundary. Business creation and snapshot eligibility used public APIs.
        with sqlite3.connect(core.path) as db:
            db.row_factory = sqlite3.Row
            configs = [
                {
                    "ref": {"kind": r["kind"], "id": r["id"], "revision": r["revision"]},
                    "data": json.loads(r["data_json"]),
                }
                for r in db.execute("SELECT * FROM foundation_revision WHERE status='active'")
            ]
            configs += [
                {
                    "ref": {"kind": r["kind"], "id": r["id"], "revision": r["revision"]},
                    "data": json.loads(r["data_json"]),
                }
                for r in db.execute(
                    "SELECT * FROM t02_revision WHERE namespace='extension' AND sealed=1"
                )
            ]
        value = {
            "snapshot_query": query,
            "context": context,
            "configs": configs,
            "customer": core.get(trade.reviewer, "master", "customer.1"),
            "contact": core.get(trade.reviewer, "master", "contact.1"),
            "rfq": core.get(trade.reviewer, "rfq", "rfq.1"),
            "masters": [
                core.get(trade.reviewer, "master", id_)
                for id_ in ("sku.1", "supplier.1", "provider.1")
            ],
        }
        (ROOT / "examples/t02-export.json").write_text(
            json.dumps(value, ensure_ascii=False, indent=2) + "\n"
        )
    return value


if __name__ == "__main__":
    export()
