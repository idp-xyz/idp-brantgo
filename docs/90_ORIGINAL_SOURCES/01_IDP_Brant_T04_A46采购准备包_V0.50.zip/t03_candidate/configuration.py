"""Sequential configuration lifecycle; no database or Core registration."""

import uuid
from copy import deepcopy
from dataclasses import dataclass, field

from .build_contracts import SECTIONS
from .dependencies import References
from .protocol import Invalid, digest, instant, require, validate


@dataclass(frozen=True)
class CandidateActor:
    tenant: str
    company: str
    id: str
    grants: frozenset[str]
    kind: str = "human"
    team: str | None = None
    data_scope: str = "own"


@dataclass
class Revision:
    data: dict
    contributors: set[str]
    sealed: bool = False
    effectivity: str = "draft"
    publication: dict | None = None
    base_ref: dict | None = None


@dataclass
class Root:
    owner: str
    team: str | None
    version: int = 0
    last: int = 0
    working: int | None = None
    active: int | None = None
    revisions: dict[int, Revision] = field(default_factory=dict)


class ConfigurationModel:
    """Trusted host actor/registry/clock boundary for candidate reference checks."""

    def __init__(self, registry, *, policy_ref, clock):
        self.registry = registry
        self.policy_ref = deepcopy(policy_ref)
        self.clock = clock
        self._roots: dict[tuple[str, str], Root] = {}
        self._actions: dict[tuple, dict] = {}
        self._events: list[dict] = []

    def _authorize(self, actor, permission):
        scope = self.registry["server_scope"]
        require((actor.tenant, actor.company) == (scope["tenant"], scope["company"]), "NOT_FOUND")
        require(
            actor.kind in ("human", "ai") and actor.data_scope in ("own", "team", "company"),
            "PERMISSION_DENIED",
        )
        require(permission in actor.grants or "*" in actor.grants, "PERMISSION_DENIED")

    @staticmethod
    def _readable(actor, root):
        return (
            actor.data_scope == "company"
            or actor.id == root.owner
            or (actor.data_scope == "team" and actor.team is not None and actor.team == root.team)
        )

    def _root(self, actor, kind, id_):
        root = self._roots.get((kind, id_))
        if root is None:
            raise Invalid("NOT_FOUND")
        require(self._readable(actor, root), "PERMISSION_DENIED")
        return root

    @staticmethod
    def _immutable(kind, id_, number, revision):
        value = {
            "kind": kind,
            "id": id_,
            "revision": number,
            "data": revision.data,
            "contributors": sorted(revision.contributors),
        }
        if revision.publication is not None:
            value["publication"] = revision.publication
        if revision.base_ref is not None:
            value["base_ref"] = revision.base_ref
        return value

    def _registry(self, actor):
        result = deepcopy(self.registry)
        for (kind, id_), root in self._roots.items():
            for number, revision in root.revisions.items():
                readable = self._readable(actor, root)
                dependencies = []
                if revision.base_ref is not None:
                    dependencies.append(revision.base_ref)
                if revision.publication is not None:
                    proof_ref = {
                        "kind": "quotation_publication." + kind,
                        "id": id_,
                        "revision": number,
                    }
                    proof = {
                        "origin_kind": kind,
                        "origin_id": id_,
                        "origin_revision": number,
                        **revision.publication,
                    }
                    result["records"].append(
                        {
                            "ref": proof_ref,
                            "data": proof if readable else {},
                            "content_hash": digest(proof if readable else {}),
                            "readable": readable,
                            "active": True,
                            "evidence": revision.publication["evidence"] if readable else [],
                        }
                    )
                    dependencies.append(proof_ref)
                data = revision.data if readable else {}
                result["records"].append(
                    {
                        "ref": {"kind": kind, "id": id_, "revision": number},
                        "data": deepcopy(data),
                        "content_hash": digest(data),
                        "readable": readable,
                        "active": root.active == number,
                        "evidence": [],
                        "history_dependencies": dependencies if readable else [],
                    }
                )
        return result

    def adoption_registry(self, actor):
        """Host fixture adapter; no endpoint may expose registry access flags."""
        self._authorize(actor, "quotation_foundation.read")
        return self._registry(actor)

    def _check_data(self, kind, data, refs, *, historical):
        refs.document(data, historical=historical)
        if kind == "quote_document_template":
            require(
                len(data["sections"]) == len(SECTIONS) and set(data["sections"]) == set(SECTIONS),
                "REFERENCE_INVALID",
            )
            if not historical:
                require(
                    data["language"] == "en" and data["renderer_version"] == "quote-text/0.1.0",
                    "DEPENDENCY_NOT_SUPPORTED",
                )
        else:
            require(data["customer_ref"]["kind"] == "customer", "REFERENCE_INVALID")
            require(
                data["issuer_ref"]["id"] == self.registry["server_scope"]["company"],
                "REFERENCE_INVALID",
            )
            require(
                instant(data["valid_from"]) < instant(data["valid_until"]), "INVALID_KNOWN_VALUE"
            )
            if not historical:
                require(
                    instant(data["valid_from"]) <= refs.as_of < instant(data["valid_until"]),
                    "REFERENCE_STALE",
                )
            tax = (refs.history if historical else refs.get)(data["tax_profile_ref"])
            from .calculation import number

            require(
                0 <= number(tax["rate"]) <= 1
                and (tax["price_basis"] != "not_applicable" or number(tax["rate"]) == 0),
                "REFERENCE_INVALID",
            )
            if not historical:
                customer = refs.get(data["customer_ref"])
                require(customer["status"] == "confirmed", "REFERENCE_STALE")
                if data["subject_kind"] == "sku_profile":
                    subject = refs.get(data["subject_ref"])
                    sku = refs.get(
                        {
                            "kind": "sku",
                            "id": subject["sku_id"],
                            "row_version": subject["sku_row_version"],
                        }
                    )
                    require(sku["status"] == "confirmed", "REFERENCE_STALE")
            if data["subject_kind"] == "fee_type":
                fee = (refs.history if historical else refs.get)(data["subject_ref"])
                require(fee["side"] == "sales_charge", "CHARGE_SCOPE_UNRESOLVED")

    def execute(self, actor, request):
        validate(request, "configuration.commands.schema.json")
        command = request["command"]
        args = request["args"]
        action = command.rsplit(".", 1)[1]
        self._authorize(actor, command)
        self._authorize(actor, "quotation_foundation.read")
        if action in ("publish", "retire", "discard_draft"):
            require(actor.kind == "human", "PERMISSION_DENIED")
        kind, id_ = args["kind"], args["id"]
        original = self._roots.get((kind, id_))
        if original is not None:
            require(self._readable(actor, original), "PERMISSION_DENIED")
        replay_key = (actor.tenant, actor.company, command, request["idempotency_key"])
        if replay_key in self._actions:
            stored = self._actions[replay_key]
            require(stored["request_hash"] == digest(request), "IDEMPOTENCY_PAYLOAD_CONFLICT")
            self.get(actor, kind, id_, stored["revision"])
            refs = References(self._registry(actor), self.clock())
            refs.document(stored["args"], historical=True)
            response = deepcopy(stored["response"])
            response["replayed"] = True
            return response
        root = deepcopy(original) if original is not None else Root(actor.id, actor.team)
        require(args["expected_version"] == root.version, "VERSION_CONFLICT")
        require(original is not None or action == "save_draft", "INVALID_STATE")
        if original is None:
            require(
                not any(
                    r["ref"]["kind"] == kind and r["ref"]["id"] == id_
                    for r in self.registry["records"]
                ),
                "VERSION_CONFLICT",
            )
        as_of = self.clock()
        refs = References(self._registry(actor), as_of)
        refs.evidence(args.get("evidence", []))
        number = root.last
        if action == "save_draft":
            require(
                root.working is not None or not any(r.sealed for r in root.revisions.values()),
                "INVALID_STATE",
            )
            if root.working is not None:
                refs.history({"kind": kind, "id": id_, "revision": root.working})
            self._check_data(kind, args["data"], refs, historical=True)
            if root.working is None:
                root.last += 1
                root.working = root.last
                root.revisions[root.last] = Revision(deepcopy(args["data"]), {actor.id})
            else:
                revision = root.revisions[root.working]
                revision.data = deepcopy(args["data"])
                revision.contributors.add(actor.id)
            number = root.working
        elif action == "revise":
            base = root.revisions.get(args["base_revision"])
            if base is None:
                raise Invalid("INVALID_STATE")
            require(root.working is None and base.sealed, "INVALID_STATE")
            self.get(actor, kind, id_, args["base_revision"])
            root.last += 1
            root.working = root.last
            number = root.last
            root.revisions[number] = Revision(
                deepcopy(base.data),
                base.contributors | {actor.id},
                base_ref={"kind": kind, "id": id_, "revision": args["base_revision"]},
            )
        elif action in ("publish", "discard_draft"):
            require(root.working == args["working_revision"], "INVALID_STATE")
            number = args["working_revision"]
            revision = root.revisions[number]
            if action == "publish":
                require(actor.id not in revision.contributors, "INDEPENDENT_REVIEW_REQUIRED")
                policy = refs.get(self.policy_ref)
                require(policy["independent_review"] is True, "REFERENCE_INVALID")
                self._check_data(kind, revision.data, refs, historical=False)
                if revision.base_ref is not None:
                    refs.provenance(revision.base_ref)
                if root.active is not None:
                    root.revisions[root.active].effectivity = "superseded"
                revision.sealed = True
                revision.effectivity = "active"
                revision.publication = {
                    "published_by": actor.id,
                    "published_at": as_of,
                    "policy_ref": deepcopy(self.policy_ref),
                    "evidence": deepcopy(args["evidence"]),
                }
                root.active = number
            else:
                refs.history({"kind": kind, "id": id_, "revision": number})
                revision.effectivity = "discarded"
            root.working = None
        else:
            number = args["target_revision"]
            target = root.revisions.get(number)
            if target is None:
                raise Invalid("INVALID_STATE")
            revision = target
            require(
                revision.sealed and revision.effectivity != "retired",
                "INVALID_STATE",
            )
            refs.history({"kind": kind, "id": id_, "revision": number})
            revision.effectivity = "retired"
            if root.active == number:
                root.active = None
        root.version += 1
        response = {
            "ok": True,
            "command": command,
            "action_id": "cfg." + uuid.uuid4().hex,
            "replayed": False,
            "kind": kind,
            "id": id_,
            "root_version": root.version,
            "last_revision": root.last,
        }
        if root.active is not None:
            response["active_revision"] = root.active
        if root.working is not None:
            response["working_revision"] = root.working
        validate(response, "configuration.responses.schema.json")
        event = {
            "action_id": response["action_id"],
            "command": command,
            "args": deepcopy(args),
            "actor": actor.id,
            "recorded_at": as_of,
            "root_version": root.version,
            "target_revision": number,
        }
        self._roots[kind, id_] = root
        self._events.append(event)
        self._actions[replay_key] = {
            "request_hash": digest(request),
            "response": deepcopy(response),
            "revision": number,
            "args": deepcopy(args),
        }
        return response

    def get(self, actor, kind, id_, revision=None):
        self._authorize(actor, "quotation_foundation.read")
        query = {"contract": "brant.quotation-foundation/0.1.0", "kind": kind, "id": id_}
        if revision is not None:
            query["revision"] = revision
        validate(query, "configuration.queries.schema.json")
        root = self._root(actor, kind, id_)
        number = revision if revision is not None else (root.working or root.active)
        require(number in root.revisions, "NOT_FOUND")
        record = root.revisions[number]
        refs = References(self._registry(actor), self.clock())
        refs.history({"kind": kind, "id": id_, "revision": number})
        value = {
            "ok": True,
            "kind": kind,
            "id": id_,
            "root_version": root.version,
            "revision": number,
            "sealed": record.sealed,
            "effectivity": record.effectivity,
            "data": deepcopy(record.data),
            "data_hash": digest(record.data),
            "record_hash": digest(self._immutable(kind, id_, number, record)),
            "contributors": sorted(record.contributors),
        }
        if record.publication is not None:
            value["publication"] = deepcopy(record.publication)
        validate(value, "configuration.query-responses.schema.json")
        return value

    def events(self, actor, kind, id_):
        self._authorize(actor, "quotation_foundation.read")
        root = self._root(actor, kind, id_)
        for number in root.revisions:
            self.get(actor, kind, id_, number)
        events = [e for e in self._events if e["args"]["kind"] == kind and e["args"]["id"] == id_]
        refs = References(self._registry(actor), self.clock())
        for event in events:
            refs.document(event["args"], historical=True)
        return deepcopy(events)
