"""Pure quotation arithmetic over explicitly supplied synthetic reference facts."""

from fractions import Fraction

from .dependencies import References
from .protocol import digest, instant, require, validate


def number(value):
    result = Fraction(value)
    require(
        len(str(abs(result.numerator))) <= 256 and len(str(result.denominator)) <= 256,
        "CALCULATION_LIMIT_EXCEEDED",
    )
    return result


def rounded(value):
    require(value >= 0, "INVALID_KNOWN_VALUE")
    return (value.numerator * 2 + value.denominator) // (value.denominator * 2)


def amount(value):
    require(abs(value) < 10**24, "CALCULATION_LIMIT_EXCEEDED")
    return str(value)


def calculate(data, registry, as_of):
    """Validate complete quote input and calculate deterministically; no writes."""
    validate(data, "quote-data.schema.json")
    refs = References(registry, as_of)
    issuer = refs.get(data["issuer_ref"])
    customer = refs.get(data["customer_ref"])
    contact = refs.get(data["contact_ref"])
    require(
        customer["status"] == "confirmed" and contact["status"] == "confirmed", "REFERENCE_STALE"
    )
    require(
        data["customer_ref"]["kind"] == "customer" and data["contact_ref"]["kind"] == "contact",
        "REFERENCE_INVALID",
    )
    require(contact["parent_customer_id"] == data["customer_ref"]["id"], "REFERENCE_INVALID")
    profile = refs.get(data["customer_profile_ref"])
    require(
        profile["party_id"] == data["customer_ref"]["id"]
        and profile["party_row_version"] == data["customer_ref"]["row_version"],
        "REFERENCE_INVALID",
    )
    addresses = [
        a
        for a in profile["addresses"]
        if a["address_id"] == data["customer_address_id"] and a["role"] in ("buyer", "billing")
    ]
    require(len(addresses) == 1, "REFERENCE_INVALID")
    refs.get(issuer["base_currency"])
    rfq = refs.get({"kind": "rfq", **data["rfq_ref"]})
    require(
        rfq["customer_id"] == data["customer_ref"]["id"]
        and rfq["contact_id"] == data["contact_ref"]["id"],
        "REFERENCE_INVALID",
    )
    require(rfq["status"] == "ready", "REFERENCE_STALE")
    policy = refs.get(data["pricing_policy_ref"])
    require(policy["independent_review"] is True, "REFERENCE_INVALID")
    currency = refs.get(data["currency_ref"])
    comparison = refs.get(policy["calculation_currency"])
    snapshot = refs.get({"kind": "cost_snapshot", "id": data["snapshot_ref"]["id"], "revision": 1})
    require(
        snapshot["snapshot"]["kind"] == "snapshot"
        and snapshot["snapshot"]["verification_status"] == "verified"
        and snapshot["snapshot"]["comparison_status"] == "comparable",
        "COST_SNAPSHOT_NOT_ELIGIBLE",
    )
    require(
        snapshot["snapshot"]["result_hash"] == data["snapshot_ref"]["result_hash"],
        "REFERENCE_INVALID",
    )
    # This is an explicit captured assertion at the candidate's fixture boundary.
    # Production must call T02 with its own live transaction/clock, never trust it.
    eligibility = registry["snapshot_eligibility"][data["snapshot_ref"]["id"]]
    require(
        eligibility["eligibility_checked_at"] == as_of
        and eligibility["currently_eligible_for_quote"],
        "COST_SNAPSHOT_NOT_ELIGIBLE",
    )
    captured = snapshot["context"]
    context_ref = snapshot["snapshot"]["context_ref"]
    require(
        captured["sealed"]
        and captured["id"] == context_ref["id"]
        and captured["revision"] == context_ref["revision"],
        "REFERENCE_INVALID",
    )
    context = captured["data"]
    manifest = snapshot["snapshot"]["input_manifest"]
    context_proofs = [
        m
        for m in manifest
        if m["kind"] == "costing_context"
        and m["id"] == captured["id"]
        and m["version"] == captured["revision"]
    ]
    require(
        len(context_proofs) == 1 and context_proofs[0]["content_hash"] == digest(context),
        "REFERENCE_INVALID",
    )
    require(context["context_kind"] == "actual", "COST_SNAPSHOT_NOT_ELIGIBLE")
    basis = context["comparison_basis"]
    sales_scope = refs.get(basis["sales_trade_scope_ref"])
    binding = {
        "rfq_ref": context["rfq_ref"],
        "pricing_policy_ref": context["pricing_policy_ref"],
        "calculation_currency_ref": context["calculation_currency_ref"],
        "trade_terms_ref": sales_scope["trade_terms_ref"],
        "trade_scope_ref": basis["sales_trade_scope_ref"],
        "named_place_ref": basis["named_place_ref"],
        "payment_terms_ref": basis["sales_payment_terms_ref"],
        "delivery": basis["delivery"],
    }
    require(
        binding["rfq_ref"] == data["rfq_ref"]
        and binding["pricing_policy_ref"] == data["pricing_policy_ref"],
        "COMPARISON_BASIS_MISMATCH",
    )
    require(
        snapshot["snapshot"]["cost_basis"] == "nominal_direct_cost"
        and binding["calculation_currency_ref"] == policy["calculation_currency"],
        "COMPARISON_BASIS_MISMATCH",
    )
    for field in (
        "trade_terms_ref",
        "trade_scope_ref",
        "named_place_ref",
        "payment_terms_ref",
        "delivery",
    ):
        require(binding[field] == data[field], "COMPARISON_BASIS_MISMATCH")
    for field in (
        "trade_terms_ref",
        "trade_scope_ref",
        "named_place_ref",
        "document_template_ref",
        "sequence_ref",
    ):
        refs.get(data[field])
    unit_factor = 10 ** currency["minor_units"]
    refs.evidence(data["evidence"])
    seen = set()
    result_lines = []

    def taxed(identifier, base, application_ref, subject):
        application = refs.get(application_ref)
        require(
            application["use"] == "quotation_sale" and application["business_model"] == "CN-M01",
            "REFERENCE_INVALID",
        )
        require(
            application["customer_ref"] == data["customer_ref"]
            and application["issuer_ref"] == data["issuer_ref"]
            and application["subject_ref"] == subject
            and application["subject_kind"] == subject["kind"],
            "REFERENCE_INVALID",
        )
        tax = refs.get(application["tax_profile_ref"])
        rate = number(tax["rate"])
        require(0 <= rate <= 1, "INVALID_KNOWN_VALUE")
        basis = tax["price_basis"]
        require(basis in ("inclusive", "exclusive", "not_applicable"), "REFERENCE_INVALID")
        require(basis != "not_applicable" or rate == 0, "REFERENCE_INVALID")
        if basis == "inclusive":
            gross = rounded(base * unit_factor)
            net = rounded(Fraction(gross) / (1 + rate))
            tax_amount = gross - net
        else:
            net = rounded(base * unit_factor)
            tax_amount = rounded(net * rate)
            gross = net + tax_amount
        return {
            "id": identifier,
            "net_minor": amount(net),
            "tax_minor": amount(tax_amount),
            "payable_minor": amount(gross),
        }

    for line in data["lines"]:
        require(line["line_id"] not in seen, "REFERENCE_INVALID")
        seen.add(line["line_id"])
        matches = [row for row in rfq["lines"] if row["line_id"] == line["rfq_line_id"]]
        require(len(matches) == 1, "REFERENCE_INVALID")
        demand = matches[0]
        covered = [row for row in context["lines"] if row["line_id"] == line["rfq_line_id"]]
        require(
            len(covered) == 1 and covered[0]["sku_profile_ref"] == line["sku_profile_ref"],
            "COMPARISON_BASIS_MISMATCH",
        )
        covered_line = covered[0]
        sku = refs.get(line["sku_profile_ref"])
        proofs = [
            m
            for m in manifest
            if m["kind"] == "sku_profile"
            and m["id"] == line["sku_profile_ref"]["id"]
            and m["version"] == line["sku_profile_ref"]["revision"]
        ]
        require(len(proofs) == 1 and proofs[0]["content_hash"] == digest(sku), "REFERENCE_INVALID")
        unit = refs.get(line["unit_ref"])
        quantity = number(line["quantity"])
        require(
            quantity > 0 and (quantity * 10 ** unit["precision"]).denominator == 1,
            "INVALID_KNOWN_VALUE",
        )
        require(sku["sku_id"] == demand["sku_id"], "REFERENCE_INVALID")
        normalized_quantity = quantity
        standard_unit = refs.get(covered_line["unit_ref"])
        require(standard_unit["code"] == demand["uom"], "DEPENDENCY_NOT_SUPPORTED")
        if line["unit_ref"] != covered_line["unit_ref"]:
            require("conversion_ref" in line, "DEPENDENCY_NOT_SUPPORTED")
            conversion = refs.get(line["conversion_ref"])
            require(
                conversion["sku_profile"] == line["sku_profile_ref"]
                and conversion["from_unit"] == line["unit_ref"]
                and conversion["to_unit"] == covered_line["unit_ref"],
                "REFERENCE_INVALID",
            )
            normalized_quantity *= number(conversion["factor"])
        else:
            require("conversion_ref" not in line, "REFERENCE_INVALID")
        require(
            normalized_quantity == number(demand["quantity"]) == number(covered_line["quantity"]),
            "COMPARISON_BASIS_MISMATCH",
        )
        discount = number(line["discount_ratio"])
        require(
            0 <= discount < 1
            and number(line["unit_price"]) > 0
            and number(line["price_basis_quantity"]) > 0,
            "INVALID_KNOWN_VALUE",
        )
        refs.evidence(line["evidence"])
        result_lines.append(
            taxed(
                line["line_id"],
                quantity
                * number(line["unit_price"])
                / number(line["price_basis_quantity"])
                * (1 - discount),
                line["tax_application_ref"],
                line["sku_profile_ref"],
            )
        )
    require(
        sorted(line["rfq_line_id"] for line in data["lines"])
        == sorted(row["line_id"] for row in rfq["lines"]),
        "COMPARISON_BASIS_MISMATCH",
    )
    charges = []
    charge_ids = set()
    obligations = set()
    for charge in data["charges"]:
        require(
            charge["charge_id"] not in charge_ids and charge["obligation_key"] not in obligations,
            "CHARGE_SCOPE_UNRESOLVED",
        )
        charge_ids.add(charge["charge_id"])
        obligations.add(charge["obligation_key"])
        fee = refs.get(charge["fee_type_ref"])
        require(fee["side"] == "sales_charge", "CHARGE_SCOPE_UNRESOLVED")
        refs.evidence(charge["evidence"])
        if charge["inclusion"] == "included_in_line":
            require(charge.get("included_line_id") in seen, "CHARGE_SCOPE_UNRESOLVED")
            # Still resolve its explicit tax scope; it is not an extra amount.
            taxed(
                charge["charge_id"],
                number(charge["amount"]),
                charge["tax_application_ref"],
                charge["fee_type_ref"],
            )
            charges.append(
                {
                    "id": charge["charge_id"],
                    "net_minor": "0",
                    "tax_minor": "0",
                    "payable_minor": "0",
                }
            )
        else:
            require("included_line_id" not in charge, "CHARGE_SCOPE_UNRESOLVED")
            charges.append(
                taxed(
                    charge["charge_id"],
                    number(charge["amount"]),
                    charge["tax_application_ref"],
                    charge["fee_type_ref"],
                )
            )
    net = sum(int(x["net_minor"]) for x in result_lines + charges)
    tax = sum(int(x["tax_minor"]) for x in result_lines + charges)
    require(net > 0, "INVALID_KNOWN_VALUE")
    revenue = Fraction(net, unit_factor)
    if data["currency_ref"] != policy["calculation_currency"]:
        require("sales_fx_ref" in data, "REFERENCE_INVALID")
        fx = refs.get(data["sales_fx_ref"])
        require(
            fx["from_currency"] == data["currency_ref"]
            and fx["to_currency"] == policy["calculation_currency"]
            and fx["purpose"] == "quotation",
            "REFERENCE_INVALID",
        )
        require(
            0
            <= (instant(as_of) - instant(fx["observed_at"])).total_seconds()
            <= policy["max_fx_age_seconds"],
            "REFERENCE_STALE",
        )
        require(number(fx["rate"]) > 0, "INVALID_KNOWN_VALUE")
        revenue *= number(fx["rate"])
    else:
        require("sales_fx_ref" not in data, "REFERENCE_INVALID")
    revenue_minor = rounded(revenue * 10 ** comparison["minor_units"])
    require(revenue_minor > 0, "INVALID_KNOWN_VALUE")
    cost = int(snapshot["snapshot"]["total_minor"])
    payment_terms = refs.get(data["payment_terms_ref"])
    stages = payment_terms["stages"]
    require(
        0 < len(stages) <= 20 and len({s["stage_id"] for s in stages}) == len(stages),
        "PAYMENT_TOTAL_MISMATCH",
    )
    require(
        all(number(s["percent"]) > 0 for s in stages)
        and sum(number(s["percent"]) for s in stages) == 100,
        "PAYMENT_TOTAL_MISMATCH",
    )
    shares = {s["stage_id"]: Fraction(net + tax) * number(s["percent"]) / 100 for s in stages}
    allocated = {key: value.numerator // value.denominator for key, value in shares.items()}
    order = sorted(shares, key=lambda key: (-(shares[key] - allocated[key]), key))
    for key in order[: net + tax - sum(allocated.values())]:
        allocated[key] += 1
    require(all(value > 0 for value in allocated.values()), "PAYMENT_TOTAL_MISMATCH")
    payments = []
    for stage in stages:
        refs.get(stage["calendar"])
        payments.append({**stage, "amount_minor": amount(allocated[stage["stage_id"]])})
    minimum = number(policy["minimum_margin"])
    require(0 <= minimum <= 1, "INVALID_KNOWN_VALUE")
    output = {
        "lines": result_lines,
        "charges": charges,
        "net_minor": amount(net),
        "tax_minor": amount(tax),
        "payable_minor": amount(net + tax),
        "comparison_currency_ref": policy["calculation_currency"],
        "comparison_revenue_minor": amount(revenue_minor),
        "cost_minor": amount(cost),
        "profit_minor": amount(revenue_minor - cost),
        "margin_numerator": amount(revenue_minor - cost),
        "margin_denominator": amount(revenue_minor),
        "margin_rule": "pass"
        if revenue_minor - cost >= revenue_minor * minimum
        else "requires_approval",
        "cost_basis": "nominal_direct_cost",
        "excluded_cost_categories": snapshot["snapshot"]["excluded_cost_categories"],
        "payments": payments,
    }
    return (
        output,
        refs,
        {
            "issuer": {
                "id": data["issuer_ref"]["id"],
                "name": issuer["legal_name"],
                "address": issuer["address"],
            },
            "customer": {
                "id": data["customer_ref"]["id"],
                "name": profile["legal_name"],
                "address": addresses[0]["address"],
            },
            "contact_name": contact["name"],
        },
    )
