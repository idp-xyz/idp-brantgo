"""Public candidate file/JSON validation and deterministic content identity."""

import hashlib
import json
from copy import deepcopy
from datetime import datetime
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).parent
NORMALIZATION = "brant.quote-normalization/0.1.0"
DECIMAL_PATHS = (
    "/data/lines/*/quantity",
    "/data/lines/*/unit_price",
    "/data/lines/*/price_basis_quantity",
    "/data/lines/*/discount_ratio",
    "/data/charges/*/amount",
    "/calculation/payments/*/percent",
)
SORT_PATHS = {
    "/data/lines": ("line_id",),
    "/data/charges": ("charge_id",),
    "/calculation/lines": ("id",),
    "/calculation/charges": ("id",),
    "/calculation/payments": ("stage_id",),
    "/dependency_manifest": ("kind", "id", "version"),
    "/data/evidence": ("source_id", "locator"),
    "/data/lines/*/evidence": ("source_id", "locator"),
    "/data/charges/*/evidence": ("source_id", "locator"),
    "/calculation/excluded_cost_categories": (),
}


class Invalid(ValueError):
    def __init__(self, code, path="/"):
        super().__init__(code + ": " + path)
        self.code = code
        self.path = path


def require(condition, code, path="/"):
    if not condition:
        raise Invalid(code, path)


def instant(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def canonical(value):
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def validate(value, schema_name):
    body = json.loads((ROOT / "contracts" / schema_name).read_text())
    error = next(
        Draft202012Validator(body, format_checker=FormatChecker()).iter_errors(value), None
    )
    if error:
        raise Invalid("SCHEMA_INVALID", "/" + "/".join(str(x) for x in error.absolute_path))
    try:
        canonical(value).encode("utf-8")
    except (UnicodeError, ValueError) as exc:
        raise Invalid("SCHEMA_INVALID") from exc
    return value


def parse_request(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "SCHEMA_INVALID")
            result[key] = value
        return result

    def reject_number(_):
        raise Invalid("SCHEMA_INVALID")

    require(isinstance(raw, bytes), "SCHEMA_INVALID")
    require(len(raw) <= 1048576, "CALCULATION_LIMIT_EXCEEDED")
    try:
        value = json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=pairs,
            parse_float=reject_number,
            parse_constant=reject_number,
        )
    except (UnicodeError, ValueError, RecursionError) as exc:
        if isinstance(exc, Invalid):
            raise
        raise Invalid("SCHEMA_INVALID") from exc
    count = 0

    def walk(item, depth):
        nonlocal count
        count += 1
        require(depth <= 64 and count <= 100000, "CALCULATION_LIMIT_EXCEEDED")
        if isinstance(item, dict):
            for child in item.values():
                walk(child, depth + 1)
        elif isinstance(item, list):
            for child in item:
                walk(child, depth + 1)

    walk(value, 0)
    return validate(value, "commands.schema.json")


def normalize(commercial):
    validate(commercial, "commercial.schema.json")

    def walk(value, path):
        if path in DECIMAL_PATHS:
            text = value.rstrip("0").rstrip(".") if "." in value else value
            return "0" if not text else text
        if isinstance(value, dict):
            return {key: walk(child, path + "/" + key) for key, child in value.items()}
        if isinstance(value, list):
            result = [walk(child, path + "/*") for child in value]
            if path in SORT_PATHS:
                keys = SORT_PATHS[path]
                result.sort(key=(lambda item: tuple(item[k] for k in keys)) if keys else None)
            return result
        return deepcopy(value)

    return walk(commercial, "")


def business_hash(commercial):
    return digest(normalize(commercial))
