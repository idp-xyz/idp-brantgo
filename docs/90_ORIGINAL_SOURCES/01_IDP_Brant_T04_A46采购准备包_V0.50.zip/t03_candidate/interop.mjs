// Independent Node implementation of the published normalization path table.
// It does not import generated Python output or implement quotation arithmetic.
import fs from 'node:fs';
import crypto from 'node:crypto';

const decimalPaths = new Set([
  '/data/lines/*/quantity', '/data/lines/*/unit_price', '/data/lines/*/price_basis_quantity',
  '/data/lines/*/discount_ratio', '/data/charges/*/amount', '/calculation/payments/*/percent',
]);
const arrayKeys = {
  '/data/lines': ['line_id'], '/data/charges': ['charge_id'], '/calculation/lines': ['id'],
  '/calculation/charges': ['id'], '/calculation/payments': ['stage_id'],
  '/dependency_manifest': ['kind', 'id', 'version'], '/data/evidence': ['source_id', 'locator'],
  '/data/lines/*/evidence': ['source_id', 'locator'], '/data/charges/*/evidence': ['source_id', 'locator'],
  '/calculation/excluded_cost_categories': [],
};
function compare(a, b) {
  if (typeof a === 'string' && typeof b === 'string') {
    const left = Array.from(a, x => x.codePointAt(0));
    const right = Array.from(b, x => x.codePointAt(0));
    for (let i = 0; i < Math.min(left.length, right.length); i++) {
      if (left[i] !== right[i]) return left[i] < right[i] ? -1 : 1;
    }
    return left.length < right.length ? -1 : left.length > right.length ? 1 : 0;
  }
  return a < b ? -1 : a > b ? 1 : 0;
}
function normalized(value, path = '') {
  if (decimalPaths.has(path)) {
    return value.includes('.') ? (value.replace(/0+$/, '').replace(/\.$/, '') || '0') : value;
  }
  if (Array.isArray(value)) {
    const output = value.map(v => normalized(v, `${path}/*`));
    if (Object.hasOwn(arrayKeys, path)) {
      const keys = arrayKeys[path];
      output.sort((a, b) => {
        if (!keys.length) return compare(a, b);
        for (const key of keys) { const order = compare(a[key], b[key]); if (order) return order; }
        return 0;
      });
    }
    return output;
  }
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.keys(value).sort().map(key => [key, normalized(value[key], `${path}/${key}`)]));
  }
  return value;
}
const vectors = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const results = vectors.map(vector => {
  const canonical = JSON.stringify(normalized(vector.input));
  const sha256 = crypto.createHash('sha256').update(canonical, 'utf8').digest('hex');
  if (canonical !== vector.normalized_canonical || sha256 !== vector.sha256) throw Error(vector.name);
  return {name: vector.name, passed: true};
});
process.stdout.write(JSON.stringify({language: 'Node.js', checks: results}));
