"""Real Core/SQLite checks of the caller-owned T02 qualification boundary."""

import importlib.util
import json
import sqlite3
import tempfile
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

from brant_core import Core, Principal
from brant_core.common import Rejected

from .build_contracts import ROOT


def run():
    receipts = []

    def passed(name, condition=True):
        if not condition:
            raise AssertionError(name)
        receipts.append({"name": name, "passed": True})

    def rejected(name, code, operation):
        try:
            operation()
        except Rejected as exc:
            passed(name, exc.code == code)
        else:
            raise AssertionError(name + " unexpectedly admitted")

    with tempfile.TemporaryDirectory() as directory:
        base = Path(directory)
        clock = {"now": datetime(2026, 10, 22, 9, tzinfo=UTC)}
        core = Core(base / "base.sqlite", clock=lambda: clock["now"])
        spec = importlib.util.spec_from_file_location(
            "transaction_fixture", ROOT.parent / "tests/costing_fixture.py"
        )
        if spec is None or spec.loader is None:
            raise RuntimeError("fixture unavailable")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        trade = module.TradeFixture(core)
        for who in (trade.author, trade.reviewer):
            core.provision(who, ["*"], team_id="trade", data_scope="company")
        trade.prepare()
        evaluated = trade.evaluate()
        frozen = core.execute(trade.reviewer, trade.freeze_request(evaluated))
        assert frozen["ok"], frozen
        snapshot = frozen["result"]
        with sqlite3.connect(core.path) as db:
            db.execute("CREATE TABLE transaction_probe(id TEXT PRIMARY KEY,value TEXT NOT NULL)")

        @contextmanager
        def connection(owner=core):
            db = sqlite3.connect(owner.path, isolation_level=None, timeout=0)
            db.row_factory = sqlite3.Row
            db.execute("PRAGMA foreign_keys=ON")
            try:
                yield db
            finally:
                db.close()

        def probe_rows(owner=core):
            with connection(owner) as db:
                return [tuple(r) for r in db.execute("SELECT * FROM transaction_probe ORDER BY id")]

        with connection() as db:
            db.execute("BEGIN IMMEDIATE")
            changes = db.total_changes
            trace: list[str] = []
            db.set_trace_callback(trace.append)
            query = core.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            passed(
                "real persisted snapshot is currently eligible",
                query["currently_eligible_for_quote"] is True and query["snapshot"] == snapshot,
            )
            passed(
                "eligibility uses trusted server clock",
                query["eligibility_checked_at"] == "2026-10-22T09:00:00Z",
            )
            passed("qualification keeps caller transaction open", db.in_transaction)
            passed("adapter performs no row writes", db.total_changes == changes)
            passed(
                "adapter owns no nested transaction",
                not any(
                    s.strip().split()[0].upper()
                    in ("BEGIN", "COMMIT", "END", "ROLLBACK", "SAVEPOINT", "RELEASE")
                    for s in trace
                ),
            )
            db.set_trace_callback(None)
            db.rollback()

        public = core.costing_get(trade.reviewer, "snapshot_query", snapshot["id"])
        passed("public independent query keeps identical result", public == query)
        with connection() as db:
            audited = db.execute(
                "SELECT count(*) FROM audit_event WHERE command='costing.get' AND outcome='read'"
            ).fetchone()[0]
        passed("independent public read retains audit", audited >= 1)

        with connection() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT INTO transaction_probe VALUES('rollback','before qualification')")
            core.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            passed("pending caller write is not independently visible", probe_rows() == [])
            db.rollback()
        passed("caller rollback removes companion write", probe_rows() == [])
        with connection() as db:
            db.execute("BEGIN IMMEDIATE")
            core.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            db.execute("INSERT INTO transaction_probe VALUES('commit','caller-owned result')")
            db.commit()
        passed(
            "caller commit persists its companion write",
            probe_rows() == [("commit", "caller-owned result")],
        )
        reopened = Core(core.path, clock=lambda: clock["now"])
        passed(
            "reopened core preserves immutable snapshot",
            reopened.costing_get(trade.reviewer, "snapshot", snapshot["id"]) == snapshot,
        )

        def invalid_context(name, db, owner=core):
            before = db.in_transaction if isinstance(db, sqlite3.Connection) else None
            try:
                owner.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            except RuntimeError as exc:
                passed(
                    name,
                    str(exc) == "Invalid caller transaction context"
                    and (db.in_transaction if isinstance(db, sqlite3.Connection) else None)
                    == before,
                )
            else:
                raise AssertionError(name + " unexpectedly admitted")

        invalid_context("non-SQLite connection object rejected", None)

        with connection() as db:
            invalid_context("autocommit connection rejected", db)
            db.row_factory = None
            db.execute("BEGIN IMMEDIATE")
            invalid_context("tuple row factory rejected", db)
            db.rollback()
        with connection() as db:
            db.execute("PRAGMA foreign_keys=OFF")
            db.execute("BEGIN IMMEDIATE")
            invalid_context("disabled foreign keys rejected", db)
            db.rollback()
        with connection() as db:
            db.isolation_level = "DEFERRED"
            db.execute("BEGIN IMMEDIATE")
            invalid_context("implicit transaction manager rejected", db)
            db.rollback()
        foreign = Core(base / "foreign.sqlite", clock=lambda: clock["now"])
        with connection(foreign) as db:
            db.execute("BEGIN IMMEDIATE")
            invalid_context("foreign database rejected", db)
            db.rollback()
        with connection() as db:
            db.execute("CREATE TEMP TABLE scope(marker TEXT)")
            db.execute("BEGIN DEFERRED")
            invalid_context("TEMP objects cannot shadow protected core tables", db)
            db.rollback()
        with connection() as db:
            db.execute("ATTACH DATABASE ? AS extra", (str(foreign.path),))
            db.execute("BEGIN DEFERRED")
            invalid_context("attached database rejected", db)
            db.rollback()

        # An explicit DEFERRED BEGIN alone has no writer reservation. The
        # adapter must acquire it before computing a current decision.
        with connection() as db:
            db.execute("BEGIN DEFERRED")
            result = core.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            passed(
                "deferred caller obtains current decision", result["currently_eligible_for_quote"]
            )
            with connection() as competitor:
                try:
                    competitor.execute("BEGIN IMMEDIATE")
                except sqlite3.OperationalError as exc:
                    passed(
                        "qualification holds real SQLite writer reservation",
                        exc.sqlite_errorcode == sqlite3.SQLITE_BUSY,
                    )
                else:
                    raise AssertionError("writer reservation missing")
            db.rollback()
        with connection() as blocker, connection() as borrower:
            blocker.execute("BEGIN IMMEDIATE")
            borrower.execute("BEGIN DEFERRED")
            try:
                core.costing_snapshot_in_transaction(borrower, trade.reviewer, snapshot["id"])
            except sqlite3.OperationalError as exc:
                passed(
                    "busy lock remains storage error",
                    exc.sqlite_errorcode == sqlite3.SQLITE_BUSY and borrower.in_transaction,
                )
            else:
                raise AssertionError("busy writer admitted")
            borrower.rollback()
            blocker.rollback()

        with connection() as db:
            db.execute("PRAGMA query_only=ON")
            db.execute("BEGIN DEFERRED")
            try:
                core.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            except sqlite3.OperationalError as exc:
                passed(
                    "read-only connection remains storage error",
                    exc.sqlite_errorcode == sqlite3.SQLITE_READONLY and db.in_transaction,
                )
            else:
                raise AssertionError("read-only write reservation admitted")
            db.rollback()

        # The fixture is copied through SQLite backup, preserving a real
        # database while keeping each current-fact mutation independent.
        def clone(name):
            target = base / (name + ".sqlite")
            with sqlite3.connect(core.path) as source, sqlite3.connect(target) as dest:
                source.backup(dest)
            return Core(target, clock=lambda: clock["now"])

        revoked = clone("revoked")
        revoked.provision(trade.reviewer, ["read", "foundation.read"], data_scope="company")
        with connection(revoked) as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT INTO transaction_probe VALUES('reject','must roll back')")
            rejected(
                "current command grant is reloaded",
                "PERMISSION_DENIED",
                lambda: revoked.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"]),
            )
            passed("business rejection does not end caller transaction", db.in_transaction)
            db.rollback()
        passed(
            "rejected transaction leaves no companion write",
            probe_rows(revoked) == [("commit", "caller-owned result")],
        )
        private = clone("private")
        private.provision(trade.reviewer, ["*"], data_scope="own")
        with connection(private) as db:
            db.execute("BEGIN IMMEDIATE")
            rejected(
                "current data scope is reloaded",
                "PERMISSION_DENIED",
                lambda: private.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"]),
            )
            db.rollback()
        with connection() as db:
            db.execute("BEGIN IMMEDIATE")
            hidden = Principal("tenant.other", "company.other", trade.reviewer.actor)
            rejected(
                "cross-company principal receives no snapshot",
                "PERMISSION_DENIED",
                lambda: core.costing_snapshot_in_transaction(db, hidden, snapshot["id"]),
            )
            rejected(
                "evaluation is not a frozen snapshot",
                "NOT_FOUND",
                lambda: core.costing_snapshot_in_transaction(
                    db, trade.reviewer, snapshot["evaluation_id"]
                ),
            )
            db.rollback()

        denied = clone("denial")
        old_query = denied.costing_get(trade.reviewer, "snapshot_query", snapshot["id"])
        deny_request = {
            "contract": "brant.costing/0.1.0",
            "command": "source_denial.record",
            "idempotency_key": "transaction.denial",
            "args": {
                "id": "denial.transaction",
                "source_id": "source.1",
                "reason": "Synthetic later disconfirmation",
                "evidence": [
                    {"source_id": "source.2", "locator": "Synthetic contradictory evidence"}
                ],
            },
        }
        result = denied.execute(trade.reviewer, deny_request)
        assert result["ok"], result
        with connection(denied) as db:
            db.execute("BEGIN IMMEDIATE")
            current = denied.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            passed(
                "earlier display query cannot authorize after committed denial",
                old_query["currently_eligible_for_quote"]
                and not current["currently_eligible_for_quote"],
            )
            passed("denial preserves original immutable snapshot", current["snapshot"] == snapshot)
            db.rollback()

        with connection(denied) as db:
            persisted_denial = tuple(
                db.execute("SELECT * FROM t02_denial WHERE id='denial.transaction'").fetchone()
            )
        with connection() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT INTO t02_denial VALUES(?,?,?,?,?)", persisted_denial)
            current = core.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            passed(
                "same caller connection sees its uncommitted denial",
                not current["currently_eligible_for_quote"],
            )
            db.rollback()
        passed(
            "rolling back uncommitted denial restores current qualification",
            core.costing_get(trade.reviewer, "snapshot_query", snapshot["id"])[
                "currently_eligible_for_quote"
            ],
        )
        with connection() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute(
                "UPDATE authorization SET grants_json='[]' WHERE tenant=? AND company=? AND actor=?",
                (*trade.reviewer.scope, trade.reviewer.actor),
            )
            rejected(
                "same caller connection sees its uncommitted grant revocation",
                "PERMISSION_DENIED",
                lambda: core.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"]),
            )
            db.rollback()
        passed(
            "rolling back uncommitted revocation restores original authority",
            core.costing_get(trade.reviewer, "snapshot_query", snapshot["id"])[
                "currently_eligible_for_quote"
            ],
        )

        clock["now"] = datetime(2026, 10, 29, tzinfo=UTC)
        with connection() as db:
            db.execute("BEGIN IMMEDIATE")
            current = core.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            passed(
                "exclusive expiration is checked at current server clock",
                not current["currently_eligible_for_quote"]
                and current["eligibility_checked_at"] == "2026-10-29T00:00:00Z",
            )
            db.rollback()
        clock["now"] = datetime(2026, 10, 22, 9, tzinfo=UTC)

        with connection() as db:
            db.execute("BEGIN IMMEDIATE")
            changed = db.total_changes
            core.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            first = core.costing_snapshot_in_transaction(db, trade.reviewer, snapshot["id"])
            passed(
                "same transaction may recheck without creating facts",
                first == query and db.total_changes == changed,
            )
            db.rollback()
        with connection() as db:
            passed(
                "migration history stays at versions 1 through 3",
                [r[0] for r in db.execute("SELECT version FROM schema_migration ORDER BY version")]
                == [1, 2, 3],
            )
            passed(
                "final SQLite foreign key and structural integrity",
                not db.execute("PRAGMA foreign_key_check").fetchall()
                and db.execute("PRAGMA integrity_check").fetchone()[0] == "ok",
            )

    result = {
        "date": "2026-10-23",
        "classification": "real SQLite caller-transaction T02 adapter; quotation write runtime is separately verified in A17",
        "checks": len(receipts),
        "all_passed": True,
        "receipts": receipts,
        "t03_full_runtime_service_implemented": False,
        "t03_quote_write_runtime_evidence": "../evidence/a17-verification.json",
        "product_v1_launch_ready": False,
    }
    (ROOT / "evidence/transaction-verification.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    )
    print(json.dumps({"transaction_adapter_checks": len(receipts), "all_passed": True}))


if __name__ == "__main__":
    run()
