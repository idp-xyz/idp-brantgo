# T03 候选机器契约与交叉验证 V0.2

日期：2026-10-23。业务来源：`../docs/T03_CONTRACT_SPEC.md` V0.1；首批逻辑见 `../docs/T03_MACHINE_CONTRACT_V0.1.md`，当前增量以 `../docs/T03_CONFIGURATION_REFERENCE_V0.2.md` 为准。
本目录最初作为候选材料而非 Core 注册。自 A17 V0.23 起，Core 已将其中 `commands.schema.json`／`responses.schema.json` 对应的13个报价写命令接入 `Core.execute`；报价基础配置命令仍为候选参考，不注册 Core。A17 新增迁移 8 回填报价 owner/team 记录范围，不接入真实身份、生产数据库或外部渠道。

## 文件与执行

- contracts：13个报价写命令、10个配置动作／类型分支、5种报价查询、配置修订查询及封闭响应；商业载荷、参考DDL，共10份Schema文件。
- examples：完整合成资料、T02实际公共接口产生的快照导出、声明前置状态的命令／响应、文档及冻结哈希向量。
- protocol／calculation／admission／document：候选校验、纯计算、声明状态准入和受限纯文本渲染参考。
- configuration／dependencies：两类配置的顺序内存生命周期、精确引用递归及原T02 manifest访问适配参考。
- interop.mjs：独立 Node 规范化、规范 JSON 及 SHA-256 验证；不是第二套核价引擎。
- evidence/verification.json：本轮实测分类和逐项收据；不与既有162项核心测试相加。

在完整交付包根目录执行：

```bash
uv sync --frozen
uv run --frozen python -m t03_candidate.verify
uv run --frozen python -m t03_candidate.verify_transaction_adapter
uv run --frozen mypy --check-untyped-defs t03_candidate
uv run --frozen ruff check t03_candidate
```

另需 Node.js 24；包不含软件包缓存，首次安装需要取得锁定依赖。不承诺离线安装。
Schema构建器为 `python -m t03_candidate.build_contracts`；样例构建器为 `python -m t03_candidate.build_examples`。
正常验证只读取冻结样例及黄金向量，不重算并覆盖预期哈希；修改样例后须重新生成并审查向量，不能靠更新期望值消除回归。

## 公共观察边界与证据口径

候选公共边界为 `parse_request`／`validate`、`calculate`／`commercial`、`admit`、`render`，
`ConfigurationModel.execute/get/events/adoption_registry`、`References.get/history/provenance/document/source/evidence` 及独立 Node 进程。
候选验收脚本只观察这些边界；不访问参考模型的私有状态。adoption_registry仅是受信任本地夹具适配口，不是HTTP接口。
参考DDL另在新建临时SQLite文件验证，使用已有非空v2 fixture升级到v3后施加候选表；不覆盖用户数据库。
这是机器材料与候选参考规则的验证，不以候选检查数宣称公共Core持久化命令已执行。

冻结T02样例在导出时核心0.5.0上通过 `TradeFixture` 的公共 `Core.execute` 建立来源、配置、询价、核价并冻结，
再经 `Core.costing_get(snapshot_query)` 读取。基础配置导出使用明示SQLite文件格式边界，不伪称T03服务生成。
`python -m t03_candidate.export_t02_example` 可重新生成来源导出（快照ID可能变化，须另行更新并审查绑定样例）。
快照关联的封存costing_context也经公共接口导出；候选直接核对context_ref、原manifest内容哈希和逐行规格／数量，不从报价反造成本覆盖范围。
所有公司、地址、日期、税率、阈值、价格及汇率都是合成数据；文档明确标记仅为契约样例。

## 当前能力边界

13个报价命令已经由 A17 通过 `Core.execute` 调用持久化 T03 状态机；本目录的 `admission.py` 仍是独立声明前态参考，不能冒充 Core 运行态证据。两类配置已有内存保存、修订、丢弃、独立发布、停用、历史读取和成功重放参考；
报价可消费该模型已发布的配置。注册引用路径递归检查当前访问权、前向效力及来源；T02底层仍依赖显式manifest访问适配事实。
报价服务复用 Core 已有持久化迁移与事务适配，并将成功动作幂等记录写入 action_result；真实企业权限或生产事务仍未开放。Core 配置写服务、完整报价 revision／approval／document 查询、企业认证和原始HTTP JSON解析仍未实现。
来源与记录的readable／active、本地授权和根控制是受信任合成夹具，不能由真实API调用方提交。
T02资格使用捕获时点的显式断言，时间变化或断言失效即拒绝；正式运行态须在同一写事务调用T02实时校验。

当前完整例采用固定交期、英文纯文本、同币种报价／成本和明确0税销售适用依据。
参考算术含明确税价、异币报价、付款尾差等规则，但对应完整路径并未全部形成运行态证据。
相对交期、中文渲染及更多商业组合仍按规格推进；未支持情况不得静默放行。资源证据仅覆盖收据所列边界，
64MiB约束为本解析器获权后装载的正文预算；宿主适配器自身装载、真实数据规模和生产容量仍须另验。
参考DDL只验证已声明存储守卫；金额守恒、hash重算、精确依赖和各动作效力仍须应用服务执行。

本包允许继续完善候选契约与适配，不登记完整T03编码准入或业务完成；产品V1.0上线标记保持false。

## 调用方事务适配增量

核心0.5.1新增 `Core.costing_snapshot_in_transaction`，验证边界扩展为该受信任后端接口和调用方SQLite连接。
transaction-verification.json另记39条真实Core／SQLite适配收据；不与350条候选收据或162项核心回归合并。
探针表仅观察同事务伴随写入、回滚和锁，不代替报价正式化表。原黄金样例和哈希向量保持冻结。
新增接口实现的是实时T02资格重查；报价侧配置／权限映射、授权epoch、对象控制及正式化提交仍待实现。
当前事务规则和准入状态以 `docs/T03_TRANSACTION_ADAPTER_V0.1.md`、`docs/T03_PERSISTENCE_ADMISSION_V0.1.md` 为准。
