"""Bounded reference closure over an explicit, trusted candidate registry."""

from copy import deepcopy

from .protocol import Invalid, canonical, digest, instant, require

KINDS = {
    "company",
    "currency",
    "unit",
    "conversion",
    "sku_profile",
    "party_profile",
    "contact_profile",
    "pricing_policy",
    "trade_terms",
    "trade_scope",
    "location",
    "payment_terms",
    "calendar",
    "delivery_calendar",
    "tax_profile",
    "tax_application",
    "fee_type",
    "fx",
    "sequence",
    "bank_account",
    "code_mapping",
    "customer",
    "contact",
    "supplier",
    "sku",
    "rfq",
    "cost_snapshot",
    "costing_context",
    "supplier_offer",
    "purchase_terms",
    "service_party_role",
    "logistics_offer",
    "measurement",
    "quote_document_template",
    "sales_tax_application",
    "quotation_publication.quote_document_template",
    "quotation_publication.sales_tax_application",
}


def key_of(reference):
    return (
        reference["kind"],
        reference["id"],
        reference.get("revision", reference.get("row_version")),
    )


class References:
    """Reference admission only; flags are host fixtures, never remote credentials."""

    def __init__(self, registry, as_of):
        self.registry = registry
        self.as_of = instant(as_of)
        self.used = {}
        self._rows: dict[tuple, dict] = {}
        self._operations = 0
        self._direct_refs = 0
        self._loaded: set[tuple] = set()
        self._loaded_bytes = 0
        require(len(registry["records"]) <= 5000, "CALCULATION_LIMIT_EXCEEDED")
        require(len(registry["sources"]) <= 5000, "CALCULATION_LIMIT_EXCEEDED")
        for row in registry["records"]:
            key = key_of(row["ref"])
            require(key not in self._rows, "REFERENCE_INVALID")
            self._rows[key] = row
        manifest_access = registry.get("manifest_access", [])
        require(len(manifest_access) <= 5000, "CALCULATION_LIMIT_EXCEEDED")
        self._manifest_access: dict[tuple, dict] = {}
        for proof in manifest_access:
            key = (proof["kind"], proof["id"], proof["version"])
            require(key not in self._manifest_access, "REFERENCE_INVALID")
            self._manifest_access[key] = proof

    def _load(self, key, value):
        # Only serialize a body after its read guard. The host adapter must
        # separately cap its own source loading; private bodies are not read here.
        if key not in self._loaded:
            self._loaded_bytes += len(canonical(value).encode("utf-8"))
            require(self._loaded_bytes <= 64 * 1024 * 1024, "CALCULATION_LIMIT_EXCEEDED")
            self._loaded.add(key)

    def _remember(self, key, content_hash):
        previous = self.used.get(key)
        require(previous is None or previous["content_hash"] == content_hash, "REFERENCE_INVALID")
        self.used[key] = {
            "kind": key[0],
            "id": key[1],
            "version": key[2],
            "content_hash": content_hash,
        }
        require(len(self.used) <= 5000, "CALCULATION_LIMIT_EXCEEDED")

    def get(self, reference):
        return self._edge(reference, True, True, ())

    def history(self, reference):
        return self._edge(reference, False, False, ())

    def provenance(self, reference):
        """Forward use of an ancestor: old effectivity, current access and sources."""
        return self._edge(reference, False, True, ())

    def _resolve(self, reference, current, sources_current, trail):
        key = key_of(reference)
        self._operations += 1
        require(self._operations <= 10000 and len(trail) <= 8, "CALCULATION_LIMIT_EXCEEDED")
        require(key[0] in KINDS, "DEPENDENCY_NOT_SUPPORTED")
        require(key not in trail, "REFERENCE_INVALID")
        row = self._rows.get(key)
        if row is None:
            raise Invalid("REFERENCE_INVALID")
        require(row["readable"] is True, "PERMISSION_DENIED")
        self._load(("record", *key), row)
        data = row["data"]
        require(row["content_hash"] == digest(data), "REFERENCE_INVALID")
        if current:
            require(row["active"] is True, "REFERENCE_STALE")
            if "valid_from" in data:
                require(
                    instant(data["valid_from"]) <= self.as_of < instant(data["valid_until"]),
                    "REFERENCE_STALE",
                )
        self._remember(key, row["content_hash"])
        for evidence in row["evidence"]:
            self.source(evidence, current=sources_current)
        nested = (*trail, key)
        if key[0] == "cost_snapshot":
            # Original T02 facts are historical business dependencies. Its live
            # adoption decision remains the separate T02 transaction boundary.
            for entry in data["snapshot"]["input_manifest"]:
                self._manifest(entry, sources_current)
        else:
            self._document(data, current, sources_current, nested, root=True)
        for dependency in row.get("history_dependencies", []):
            self._edge(dependency, False, sources_current, nested)
        return deepcopy(data)

    def _manifest(self, entry, sources_current):
        key = (entry["kind"], entry["id"], entry["version"])
        proof = self._manifest_access.get(key)
        if proof is None:
            raise Invalid("DEPENDENCY_NOT_SUPPORTED")
        require(proof["readable"] is True, "PERMISSION_DENIED")
        self._load(("manifest", *key), proof)
        require(proof["content_hash"] == entry["content_hash"], "REFERENCE_INVALID")
        self._operations += 1
        require(self._operations <= 10000, "CALCULATION_LIMIT_EXCEEDED")
        # Proof identities use their own namespace: T02's normalized projection
        # hash must not be confused with a raw master/config export hash.
        self._remember(("t02_access." + key[0], key[1], key[2]), entry["content_hash"])
        if entry["kind"] == "source":
            self.source({"source_id": entry["id"]}, current=sources_current)

    def _edge(self, reference, current, sources_current, trail):
        self._direct_refs += 1
        require(self._direct_refs <= 1000, "CALCULATION_LIMIT_EXCEEDED")
        return self._resolve(reference, current, sources_current, trail)

    def _party_reference(self, id_, version, role=None):
        matches = [
            r["ref"]
            for r in self.registry["records"]
            if r["ref"]["kind"] in ("customer", "supplier")
            and (role is None or r["ref"]["kind"] == role)
            and r["ref"]["id"] == id_
            and r["ref"].get("row_version") == version
        ]
        require(len(matches) == 1, "REFERENCE_INVALID")
        return matches[0]

    def _document(self, value, current, sources_current, trail, *, root=False, field=""):
        if isinstance(value, dict):
            if (
                not root
                and "kind" in value
                and "id" in value
                and ("revision" in value or "row_version" in value)
            ):
                self._edge(value, current, sources_current, trail)
                return
            if not root and "source_id" in value:
                self.source(value, current=sources_current)
                return
            if not root and field == "rfq_ref" and "id" in value and "row_version" in value:
                self._edge({"kind": "rfq", **value}, current, sources_current, trail)
                return
            if (
                not root
                and field in ("contact_refs", "legacy_contact_ref")
                and "id" in value
                and "row_version" in value
            ):
                self._edge({"kind": "contact", **value}, current, sources_current, trail)
                return
            if "sku_id" in value and "sku_row_version" in value:
                self._edge(
                    {"kind": "sku", "id": value["sku_id"], "row_version": value["sku_row_version"]},
                    current,
                    sources_current,
                    trail,
                )
            if "party_id" in value and "party_row_version" in value:
                self._edge(
                    self._party_reference(
                        value["party_id"], value["party_row_version"], value.get("party_role")
                    ),
                    current,
                    sources_current,
                    trail,
                )
            if value.get("owner_kind") == "party":
                self._edge(
                    self._party_reference(value["owner_id"], value["owner_row_version"]),
                    current,
                    sources_current,
                    trail,
                )
            for key, child in value.items():
                if key == "source_ids":
                    for source_id in child:
                        self.source({"source_id": source_id}, current=sources_current)
                else:
                    self._document(child, current, sources_current, trail, field=key)
        elif isinstance(value, list):
            for child in value:
                self._document(child, current, sources_current, trail, field=field)

    def document(self, value, *, historical=False):
        self._document(value, not historical, not historical, (), root=True)

    def source(self, evidence, *, current=True):
        self._operations += 1
        require(self._operations <= 10000, "CALCULATION_LIMIT_EXCEEDED")
        source = self.registry["sources"].get(evidence["source_id"])
        require(source is not None, "REFERENCE_INVALID")
        require(source["readable"] is True, "PERMISSION_DENIED")
        self._load(("source", evidence["source_id"]), source)
        if current:
            require(source["verified"] is True and source["denied"] is False, "REFERENCE_STALE")
        self._remember(("source", evidence["source_id"], 1), source["content_hash"])

    def evidence(self, values, *, historical=False):
        for value in values:
            self.source(value, current=not historical)
