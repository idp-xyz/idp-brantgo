"""Reproducible artifact, reference-rule, SQLite-DDL and interop checks."""

import hashlib
import json
import sqlite3
import subprocess
import tempfile
from copy import deepcopy
from pathlib import Path

from jsonschema import Draft202012Validator

from brant_core import Core

from .admission import admit, commercial
from .build_contracts import COMMANDS, CONFIG_ACTIONS, CONFIG_KINDS, ROOT
from .calculation import calculate
from .document import render
from .protocol import Invalid, business_hash, canonical, digest, normalize, parse_request, validate
from .verify_configuration import checks as configuration_checks
from .verify_dependencies import checks as dependency_checks


def run():
    receipts = []

    def passed(layer, name, condition=True):
        if not condition:
            raise AssertionError(name)
        receipts.append({"layer": layer, "name": name, "passed": True})

    def reject(layer, name, code, operation):
        try:
            operation()
        except Invalid as exc:
            passed(layer, name, exc.code == code)
        else:
            raise AssertionError(name + " unexpectedly admitted")

    def load(name):
        return json.loads((ROOT / "examples" / name).read_text())

    registry, data, content = load("registry.json"), load("quote.json"), load("commercial.json")
    as_of = registry["as_of"]
    foundation_schema = json.loads(
        (ROOT.parent / "brant_core/contracts/foundation.commands.schema.json").read_text()
    )
    foundation_validator = Draft202012Validator(foundation_schema)
    inherited_kinds = {
        "company",
        "currency",
        "unit",
        "sku_profile",
        "pricing_policy",
        "trade_terms",
        "payment_terms",
        "fee_type",
        "calendar",
        "tax_profile",
        "sequence",
        "party_profile",
    }
    for record in registry["records"]:
        reference = record["ref"]
        if reference["kind"] in inherited_kinds:
            request = {
                "contract": "brant.foundation/0.1.0",
                "command": "foundation.save",
                "idempotency_key": "candidate.check",
                "args": {
                    "kind": reference["kind"],
                    "id": reference["id"],
                    "expected_version": 0,
                    "data": record["data"],
                    "evidence_ids": ["source.1"],
                },
            }
            passed(
                "foundation-compatibility",
                reference["kind"] + ":" + reference["id"],
                foundation_validator.is_valid(request),
            )
    for path in sorted((ROOT / "contracts").glob("*.schema.json")):
        body = json.loads(path.read_text())
        Draft202012Validator.check_schema(body)
        passed("schema", path.name + ":valid-schema")

        def closed(item):
            if isinstance(item, dict):
                if item.get("type") == "object":
                    assert item.get("additionalProperties") is False
                for value in item.values():
                    closed(value)
            elif isinstance(item, list):
                for value in item:
                    closed(value)

        closed(body)
        passed("schema", path.name + ":all-objects-closed")
    cases = load("commands.json")
    passed("schema", "13 distinct commands", {c["name"] for c in cases} == set(COMMANDS))
    for case in cases:
        request = case["request"]
        name = case["name"]
        parse_request(canonical(request).encode())
        validate(case["response"], "responses.schema.json")
        admit(request, case["before"], registry, as_of)
        passed("action-reference", name)
        extra = deepcopy(request)
        extra["args"]["unregistered_override"] = True
        reject(
            "schema-negative",
            name + ":extra-field",
            "SCHEMA_INVALID",
            lambda: validate(extra, "commands.schema.json"),
        )
        invalid_response = deepcopy(case["response"])
        invalid_response["result"]["status"] = "unregistered_state"
        reject(
            "schema-negative",
            name + ":unregistered-response-state",
            "SCHEMA_INVALID",
            lambda: validate(invalid_response, "responses.schema.json"),
        )
        denied = deepcopy(case["before"])
        denied["actor"]["grants"] = []
        reject(
            "action-reference",
            name + ":no-grant",
            "PERMISSION_DENIED",
            lambda: admit(request, denied, registry, as_of),
        )
        stale = deepcopy(case["before"])
        stale["root_version"] += 1
        reject(
            "action-reference",
            name + ":stale-version",
            "VERSION_CONFLICT",
            lambda: admit(request, stale, registry, as_of),
        )
        if name != "quote.save_draft":
            ai = deepcopy(case["before"])
            ai["actor"]["kind"] = "ai"
            reject(
                "action-reference",
                name + ":ai",
                "PERMISSION_DENIED",
                lambda: admit(request, ai, registry, as_of),
            )
    config_cases = load("configuration.json")
    passed(
        "schema",
        "10 configuration branches",
        len(config_cases) == len(CONFIG_KINDS) * len(CONFIG_ACTIONS),
    )
    for case in config_cases:
        name = case["request"]["command"] + ":" + case["request"]["args"]["kind"]
        validate(case["request"], "configuration.commands.schema.json")
        validate(case["response"], "configuration.responses.schema.json")
        passed("configuration-structure", name)
        tampered = deepcopy(case["request"])
        tampered["args"]["publish_without_review"] = True
        reject(
            "schema-negative",
            name,
            "SCHEMA_INVALID",
            lambda: validate(tampered, "configuration.commands.schema.json"),
        )
    for case in load("queries.json"):
        validate(case["request"], "queries.schema.json")
        validate(case["response"], "query-responses.schema.json")
        passed("query-structure", case["request"]["kind"])
    configuration_checks(registry, data, passed, reject)
    dependency_checks(registry, data, cases, passed, reject)
    calculated, _, _ = calculate(data, registry, as_of)
    passed(
        "arithmetic",
        "960/660: net, payable, profit, ratio",
        calculated["net_minor"] == "96000"
        and calculated["payable_minor"] == "96000"
        and calculated["cost_minor"] == "66000"
        and calculated["profit_minor"] == "30000",
    )
    passed(
        "arithmetic",
        "one explicit 100-percent payment",
        calculated["payments"][0]["amount_minor"] == "96000",
    )
    passed(
        "binding",
        "full commercial reconstructs",
        commercial(data, registry, "quote.1", 1, as_of) == content,
    )
    for name, mutate, code in (
        ("zero quantity", lambda x: x["lines"][0].update(quantity="0"), "INVALID_KNOWN_VALUE"),
        (
            "invalid discount",
            lambda x: x["lines"][0].update(discount_ratio="1"),
            "INVALID_KNOWN_VALUE",
        ),
        (
            "zero price basis",
            lambda x: x["lines"][0].update(price_basis_quantity="0"),
            "INVALID_KNOWN_VALUE",
        ),
        (
            "wrong snapshot hash",
            lambda x: x["snapshot_ref"].update(result_hash="0" * 64),
            "REFERENCE_INVALID",
        ),
        (
            "wrong quantity",
            lambda x: x["lines"][0].update(quantity="119"),
            "COMPARISON_BASIS_MISMATCH",
        ),
        (
            "unexpected same-currency FX",
            lambda x: x.update(sales_fx_ref={"kind": "fx", "id": "unused", "revision": 1}),
            "REFERENCE_INVALID",
        ),
    ):
        changed = deepcopy(data)
        mutate(changed)
        reject("business-negative", name, code, lambda: calculate(changed, registry, as_of))
    for name, mutate, code in (
        (
            "source denied",
            lambda x: x["sources"]["source.1"].update(denied=True),
            "REFERENCE_STALE",
        ),
        (
            "source read revoked",
            lambda x: x["sources"]["source.1"].update(readable=False),
            "PERMISSION_DENIED",
        ),
        (
            "captured eligibility false",
            lambda x: x["snapshot_eligibility"][data["snapshot_ref"]["id"]].update(
                currently_eligible_for_quote=False
            ),
            "COST_SNAPSHOT_NOT_ELIGIBLE",
        ),
        (
            "captured eligibility old clock",
            lambda x: x["snapshot_eligibility"][data["snapshot_ref"]["id"]].update(
                eligibility_checked_at="2026-10-22T08:59:59Z"
            ),
            "COST_SNAPSHOT_NOT_ELIGIBLE",
        ),
    ):
        changed_registry = deepcopy(registry)
        mutate(changed_registry)
        reject("business-negative", name, code, lambda: calculate(data, changed_registry, as_of))
    # An independent synthetic policy variant. The captured cost binding remains
    # a declared fixture assertion; this does not re-run T02 eligibility.
    threshold = deepcopy(registry)
    policy = next(row for row in threshold["records"] if row["ref"]["kind"] == "pricing_policy")
    policy["data"]["minimum_margin"] = "0.25"
    policy["content_hash"] = digest(policy["data"])
    for price, expected in (
        ("7", "requires_approval"),
        ("7.33333333", "pass"),
        ("7.33325", "requires_approval"),
    ):
        changed = deepcopy(data)
        changed["lines"][0]["unit_price"] = price
        result, _, _ = calculate(changed, threshold, as_of)
        passed(
            "arithmetic", "margin threshold at price " + price, result["margin_rule"] == expected
        )
    active_case = next(case for case in cases if case["name"] == "quote.activate")
    spec_registry = deepcopy(registry)
    spec_data = deepcopy(data)
    replacement = deepcopy(
        next(row for row in spec_registry["records"] if row["ref"]["kind"] == "sku_profile")
    )
    replacement["ref"]["revision"] = 2
    replacement["data"]["specification_version"] = "SPEC-2"
    replacement["content_hash"] = digest(replacement["data"])
    spec_registry["records"].append(replacement)
    tax_application = deepcopy(
        next(
            row for row in spec_registry["records"] if row["ref"]["kind"] == "sales_tax_application"
        )
    )
    tax_application["ref"]["id"] = "tax.sale.spec2"
    tax_application["data"]["subject_ref"] = replacement["ref"]
    tax_application["content_hash"] = digest(tax_application["data"])
    spec_registry["records"].append(tax_application)
    spec_data["lines"][0].update(
        sku_profile_ref=replacement["ref"], tax_application_ref=tax_application["ref"]
    )
    reject(
        "business-negative",
        "same SKU new specification cannot reuse frozen cost",
        "COMPARISON_BASIS_MISMATCH",
        lambda: calculate(spec_data, spec_registry, as_of),
    )
    changed_context = deepcopy(registry)
    snapshot_record = next(
        row for row in changed_context["records"] if row["ref"]["kind"] == "cost_snapshot"
    )
    snapshot_record["data"]["context"]["data"]["lines"][0]["quantity"] = "121"
    snapshot_record["content_hash"] = digest(snapshot_record["data"])
    reject(
        "business-negative",
        "context content must match original snapshot manifest hash",
        "REFERENCE_INVALID",
        lambda: calculate(data, changed_context, as_of),
    )
    changed_spec = deepcopy(registry)
    sku_record = next(row for row in changed_spec["records"] if row["ref"]["kind"] == "sku_profile")
    sku_record["data"]["specification_version"] = "SPEC-2"
    sku_record["content_hash"] = digest(sku_record["data"])
    reject(
        "business-negative",
        "same revision altered specification hash rejected",
        "REFERENCE_INVALID",
        lambda: calculate(data, changed_spec, as_of),
    )
    for name, decided_at in (
        ("approval before commercial exists", "2026-10-22T08:59:59Z"),
        ("future approval", "2026-10-22T09:00:01Z"),
    ):
        before = deepcopy(active_case["before"])
        before["approval"]["decided_at"] = decided_at
        reject(
            "action-reference",
            name,
            "APPROVAL_REQUIRED",
            lambda: admit(active_case["request"], before, registry, as_of),
        )
    for name, changes, code in (
        (
            "independent reviewer",
            {"reviewer_currently_authorized": False},
            "INDEPENDENT_REVIEW_REQUIRED",
        ),
        ("conversion slot", {"conversion_slot": True}, "ROOT_CONVERSION_LOCKED"),
        (
            "object bound, task absent",
            {"server_control": "bound_unknown"},
            "OBJECT_CONTROL_CONFLICT",
        ),
        ("active holds", {"hold": True}, "INVALID_STATE"),
    ):
        before = deepcopy(active_case["before"])
        before.update(changes)
        reject(
            "action-reference",
            name,
            code,
            lambda: admit(active_case["request"], before, registry, as_of),
        )
    for name, raw in (
        ("duplicate keys", b'{"contract":1,"contract":2}'),
        ("float", b'{"n":1.0}'),
        ("exponent", b'{"n":1e1}'),
        ("NaN", b'{"n":NaN}'),
        ("UTF8", b"\xff"),
    ):
        reject("wire", name, "SCHEMA_INVALID", lambda: parse_request(raw))
    reject("wire", "bytes", "CALCULATION_LIMIT_EXCEEDED", lambda: parse_request(b" " * 1048577))
    document = render(content, registry, "SYN-Q-2026-00001")
    passed("document-reference", "exact immutable sample bytes", document == load("document.json"))
    passed(
        "document-reference",
        "hash and content bytes",
        document["content_sha256"] == hashlib.sha256(document["content_text"].encode()).hexdigest(),
    )
    passed(
        "document-reference",
        "no internal cost fields",
        "66000" not in document["content_text"] and "cost_minor" not in document["content_text"],
    )
    vectors = load("hash-vectors.json")
    for vector in vectors:
        passed(
            "python-golden",
            vector["name"],
            canonical(normalize(vector["input"])) == vector["normalized_canonical"]
            and business_hash(vector["input"]) == vector["sha256"],
        )
    independent = subprocess.run(
        ["node", str(ROOT / "interop.mjs"), str(ROOT / "examples/hash-vectors.json")],
        capture_output=True,
        text=True,
        check=True,
    )
    interop = json.loads(independent.stdout)
    for check in interop["checks"]:
        passed("node-interop", check["name"], check["passed"])
    ddl_checks(passed)
    result = {
        "candidate_version": "0.2.0",
        "date": "2026-10-23",
        "classification": "candidate artifacts and synthetic reference assertions; Core write runtime is verified separately",
        "checks": len(receipts),
        "all_passed": True,
        "receipts": receipts,
        "node_interop": "normalization/canonical JSON/SHA-256 only; not second pricing engine",
        "configuration_lifecycle_reference_verified": True,
        "registered_dependency_closure_reference_verified": True,
        "configuration_lifecycle_in_core": False,
        "live_full_dependency_admission_implemented": False,
        "t03_full_runtime_service_implemented": False,
        "t03_quote_write_runtime_evidence": "../evidence/a17-verification.json",
        "t03_full_coding_admission_passed": False,
        "product_v1_launch_ready": False,
        "t02_162_tests_included": False,
        "model_calls": 0,
        "external_business_actions": 0,
    }
    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=True)
    (evidence / "verification.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    )
    print(
        json.dumps(
            {"checks": len(receipts), "all_passed": True, "core_runtime_included": False}
        )
    )


def ddl_checks(passed):
    """Explicit disposable SQLite file-format boundary, not command execution."""

    def statements(db, source):
        buffer = ""
        for line in source.splitlines(keepends=True):
            buffer += line
            if sqlite3.complete_statement(buffer):
                db.execute(buffer)
                buffer = ""
        if buffer.strip():
            db.execute(buffer)

    with tempfile.TemporaryDirectory() as temp:
        path = Path(temp) / "candidate.sqlite"
        old = sqlite3.connect(path)
        old.executescript((ROOT.parent / "tests/fixtures/foundation_v2_full.sql").read_text())
        old.close()
        Core(path)
        db = sqlite3.connect(path, isolation_level=None)
        db.execute("PRAGMA foreign_keys=ON")
        tables = [
            row[0]
            for row in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            )
        ]
        prior = {table: list(db.execute('SELECT * FROM "' + table + '"')) for table in tables}
        ddl = (ROOT / "contracts/T03_reference.sql").read_text()
        db.execute("BEGIN IMMEDIATE")
        statements(db, ddl)
        db.commit()
        passed("reference-ddl", "applies on nonempty existing v3 database")
        passed(
            "reference-ddl",
            "all previous table bytes preserved",
            all(
                list(db.execute('SELECT * FROM "' + table + '"')) == rows
                for table, rows in prior.items()
            ),
        )
        passed(
            "reference-ddl",
            "foreign key integrity",
            not list(db.execute("PRAGMA foreign_key_check")),
        )
        passed(
            "reference-ddl", "integrity", db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        )
        tenant, company = db.execute("SELECT tenant,company FROM scope LIMIT 1").fetchone()
        scope = (tenant, company)
        exported = json.loads((ROOT / "examples/t02-export.json").read_text())
        snapshot = exported["snapshot_query"]["snapshot"]
        db.execute(
            "INSERT INTO t02_result VALUES(?,?,?,?,?,?,?,?,?,?)",
            (
                *scope,
                snapshot["id"],
                "snapshot",
                snapshot["scenario_id"],
                snapshot["input_scenario_version"],
                snapshot["result_hash"],
                canonical(snapshot),
                "{}",
                1,
            ),
        )
        db.execute(
            "INSERT INTO t03_quote_root VALUES(?,?,?,?,?,?,?,?,?,?)",
            (*scope, "quote.ddl", 1, 1, None, None, None, "author", None),
        )
        content = json.loads((ROOT / "examples/commercial.json").read_text())
        db.execute(
            "INSERT INTO t03_quote_revision VALUES(?,?,?,?,?,?,?,?,?,?)",
            (
                *scope,
                "quote.ddl",
                1,
                0,
                business_hash(content),
                canonical(content),
                snapshot["id"],
                content["issued_at"],
                content["data"]["expires_at"],
            ),
        )
        try:
            db.execute("UPDATE t03_quote_revision SET sealed=1")
        except sqlite3.IntegrityError:
            passed("reference-ddl", "incomplete sealing rejected")
        else:
            raise AssertionError("incomplete seal")
        line = content["calculation"]["lines"][0]
        db.execute(
            "INSERT INTO t03_quote_line VALUES(?,?,?,?,?,?,?,?)",
            (
                *scope,
                "quote.ddl",
                1,
                line["id"],
                line["net_minor"],
                line["tax_minor"],
                line["payable_minor"],
            ),
        )
        for payment in content["calculation"]["payments"]:
            db.execute(
                "INSERT INTO t03_quote_payment VALUES(?,?,?,?,?,?)",
                (*scope, "quote.ddl", 1, payment["stage_id"], canonical(payment)),
            )
        db.execute("UPDATE t03_quote_revision SET sealed=1")
        passed("reference-ddl", "complete child counts seal")
        for name, sql in (
            ("sealed revision update", "UPDATE t03_quote_revision SET business_hash='x'"),
            ("sealed revision delete", "DELETE FROM t03_quote_revision"),
            ("sealed child update", "UPDATE t03_quote_line SET net_minor='0'"),
            ("sealed child delete", "DELETE FROM t03_quote_payment"),
        ):
            try:
                db.execute(sql)
            except sqlite3.IntegrityError:
                passed("reference-ddl", name)
            else:
                raise AssertionError(name)
        db.execute(
            "INSERT INTO t03_revision_effectivity VALUES(?,?,?,?,?,?)",
            (*scope, "quote.ddl", 1, 1, "active"),
        )
        db.execute(
            "UPDATE t03_quote_root SET current_active_revision=1,slot_order_id='order.reserved'"
        )
        try:
            db.execute("UPDATE t03_quote_root SET current_active_revision=NULL")
        except sqlite3.IntegrityError:
            passed("reference-ddl", "occupied conversion blocks pointer change")
        else:
            raise AssertionError("conversion pointer")
        config_ddl_checks(db, scope, passed)
        passed(
            "reference-ddl",
            "final foreign key integrity",
            not list(db.execute("PRAGMA foreign_key_check")),
        )
        db.close()


def config_ddl_checks(db, scope, passed):
    """Config content/effectivity/event guards at the declared SQLite seam."""
    kind = "quote_document_template"
    db.execute(
        "INSERT INTO t03_config_root VALUES(?,?,?,?,?,?,?,?)",
        (*scope, kind, "config.ddl", 1, 2, None, None),
    )
    for revision in (1, 2):
        db.execute(
            "INSERT INTO t03_config_revision VALUES(?,?,?,?,?,?,?,?)",
            (*scope, kind, "config.ddl", revision, 1, '{"name":"Synthetic"}', "{}"),
        )
        db.execute(
            "INSERT INTO t03_config_effectivity VALUES(?,?,?,?,?,?,?)",
            (*scope, kind, "config.ddl", revision, 1, "active" if revision == 1 else "superseded"),
        )
    db.execute(
        "INSERT INTO t03_config_event VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (
            *scope,
            "cfg.event",
            kind,
            "config.ddl",
            1,
            1,
            "reviewer",
            "2026-10-22T09:00:00Z",
            "publish",
            "{}",
        ),
    )
    passed("reference-ddl", "configuration content, effectivity and event inserted")
    for name, sql in (
        ("config sealed content immutable", "UPDATE t03_config_revision SET data_json='{}'"),
        ("config revision delete rejected", "DELETE FROM t03_config_revision WHERE revision=2"),
        (
            "config single active",
            "UPDATE t03_config_effectivity SET effectivity='active',effectivity_version=2 WHERE revision=2",
        ),
        (
            "config effectivity CAS",
            "UPDATE t03_config_effectivity SET effectivity='retired' WHERE revision=1",
        ),
        ("config effectivity delete rejected", "DELETE FROM t03_config_effectivity"),
        ("config event update rejected", "UPDATE t03_config_event SET actor='changed'"),
        ("config event delete rejected", "DELETE FROM t03_config_event"),
        (
            "config cross-kind FK",
            "INSERT INTO t03_config_event SELECT tenant,company,'cfg.wrong','sales_tax_application',config_id,revision,root_version,actor,occurred_at,event_type,data_json FROM t03_config_event",
        ),
    ):
        try:
            db.execute(sql)
        except sqlite3.IntegrityError:
            passed("reference-ddl", name)
        else:
            raise AssertionError(name)
    db.execute(
        "UPDATE t03_config_effectivity SET effectivity='retired',effectivity_version=2 WHERE revision=1"
    )
    db.execute(
        "UPDATE t03_config_effectivity SET effectivity='active',effectivity_version=2 WHERE revision=2"
    )
    passed(
        "reference-ddl",
        "config replacement keeps old content",
        db.execute("SELECT count(*) FROM t03_config_revision").fetchone()[0] == 2
        and db.execute(
            "SELECT revision FROM t03_config_effectivity WHERE effectivity='active'"
        ).fetchone()[0]
        == 2,
    )


if __name__ == "__main__":
    run()
