"""Make synthetic contract examples from a pinned public-API T02 export."""

import json
from copy import deepcopy

from .admission import commercial
from .build_contracts import (
    COMMANDS,
    CONFIG_ACTIONS,
    CONFIG_CONTRACT,
    CONFIG_KINDS,
    CONTRACT,
    ROOT,
    SECTIONS,
)
from .document import render
from .protocol import business_hash, digest

AS_OF = "2026-10-22T09:00:00Z"


def config_ref(kind, id_):
    return {"kind": kind, "id": id_, "revision": 1}


def write(name, value):
    (ROOT / "examples" / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def build():
    exported = json.loads((ROOT / "examples/t02-export.json").read_text())
    query = exported["snapshot_query"]
    usd = config_ref("currency", "USD")
    issuer = config_ref("company", "company.live")
    customer = {"kind": "customer", "id": "customer.1", "row_version": 2}
    contact = {"kind": "contact", "id": "contact.1", "row_version": 2}
    records = []
    evidence = [{"source_id": "source.1", "locator": "合成核实依据"}]

    def add(reference, data):
        records.append(
            {
                "ref": reference,
                "data": data,
                "content_hash": digest(data),
                "active": True,
                "readable": True,
                "evidence": evidence,
            }
        )

    for row in exported["configs"]:
        add(row["ref"], row["data"])
    add(customer, exported["customer"])
    add(contact, exported["contact"])
    for master in exported["masters"]:
        add(
            {"kind": master["kind"], "id": master["id"], "row_version": master["row_version"]},
            master,
        )
    add({"kind": "rfq", "id": "rfq.1", "row_version": 2}, exported["rfq"])
    add(
        config_ref("currency", "CNY"),
        {"code": "CNY", "name": "人民币", "minor_units": 2, "rounding": "HALF_UP"},
    )
    add(
        issuer,
        {
            "legal_name": "SYNTHETIC Exporter — no actual trade",
            "registration_no": "SYNTHETIC-NOT-REAL",
            "country": "CN",
            "address": "Synthetic Shanghai address",
            "base_currency": config_ref("currency", "CNY"),
            "timezone": "Asia/Shanghai",
            "policy_scope": "Synthetic CN-M01 / S01",
        },
    )
    add(
        config_ref("party_profile", "customer.profile"),
        {
            "party_id": "customer.1",
            "party_row_version": 2,
            "contact_refs": [{"id": "contact.1", "row_version": 2}],
            "legal_name": "Synthetic Buyer Ltd",
            "country": "GB",
            "addresses": [
                {
                    "address_id": "buyer.address",
                    "role": "buyer",
                    "address": "Synthetic buyer address",
                }
            ],
            "trade_terms": config_ref("trade_terms", "terms.test"),
            "payment_terms": config_ref("payment_terms", "payment.test"),
        },
    )
    add(
        config_ref("sequence", "quote.sequence"),
        {
            "document_type": "quote",
            "company": issuer,
            "prefix": "SYN-Q-",
            "width": 5,
            "reset": "annual",
        },
    )
    template = {
        "name": "Synthetic quote template",
        "language": "en",
        "renderer_version": "quote-text/0.1.0",
        "title": "SYNTHETIC QUOTATION — CONTRACT EXAMPLE ONLY",
        "sections": list(SECTIONS),
        "footer_note": "Synthetic data. Not an actual offer or customer acceptance.",
    }
    application = {
        "name": "Synthetic sales tax applicability",
        "business_model": "CN-M01",
        "use": "quotation_sale",
        "subject_kind": "sku_profile",
        "subject_ref": config_ref("sku_profile", "sku.1.profile"),
        "issuer_ref": issuer,
        "customer_ref": customer,
        "tax_profile_ref": config_ref("tax_profile", "tax.zero"),
        "jurisdiction": "SYNTHETIC-CN",
        "basis_note": "Reviewed synthetic sale scope; no tax-law claim",
        "valid_from": "2026-10-22T00:00:00Z",
        "valid_until": "2026-10-29T00:00:00Z",
    }
    add(config_ref("quote_document_template", "quote.template"), template)
    add(config_ref("sales_tax_application", "tax.sale"), application)
    data = {
        "issuer_ref": issuer,
        "customer_ref": customer,
        "contact_ref": contact,
        "customer_profile_ref": config_ref("party_profile", "customer.profile"),
        "customer_address_id": "buyer.address",
        "rfq_ref": {"id": "rfq.1", "row_version": 2},
        "snapshot_ref": {
            "id": query["snapshot"]["id"],
            "result_hash": query["snapshot"]["result_hash"],
        },
        "lines": [
            {
                "line_id": "L1",
                "rfq_line_id": "L1",
                "sku_profile_ref": config_ref("sku_profile", "sku.1.profile"),
                "quantity": "120.000000",
                "unit_ref": config_ref("unit", "PCS"),
                "unit_price": "8.0000",
                "price_basis_quantity": "1.0",
                "discount_ratio": "0.00",
                "tax_application_ref": config_ref("sales_tax_application", "tax.sale"),
                "evidence": evidence,
            }
        ],
        "charges": [],
        "currency_ref": usd,
        "pricing_policy_ref": config_ref("pricing_policy", "policy.1"),
        "trade_terms_ref": config_ref("trade_terms", "terms.test"),
        "trade_scope_ref": config_ref("trade_scope", "scope.sale"),
        "named_place_ref": config_ref("location", "port.test"),
        "payment_terms_ref": config_ref("payment_terms", "payment.test"),
        "delivery": {
            "kind": "fixed",
            "date": "2026-11-15",
            "milestone": "handover",
            "place_ref": config_ref("location", "port.test"),
            "time_zone": "Asia/Shanghai",
        },
        "expires_at": "2026-10-28T08:00:00Z",
        "document_template_ref": config_ref("quote_document_template", "quote.template"),
        "sequence_ref": config_ref("sequence", "quote.sequence"),
        "customer_notes": "客户可见说明：合成样例\nKeep this line break.",
        "evidence": evidence,
    }
    add(
        {"kind": "cost_snapshot", "id": query["snapshot"]["id"], "revision": 1},
        {"snapshot": query["snapshot"], "context": exported["context"]},
    )
    source = next(row for row in query["snapshot"]["input_manifest"] if row["kind"] == "source")
    registry = {
        "as_of": AS_OF,
        "server_scope": {
            "tenant": exported["customer"]["tenant"],
            "company": exported["customer"]["company"],
        },
        "manifest_access": [
            {**entry, "readable": True} for entry in query["snapshot"]["input_manifest"]
        ],
        "classification": "synthetic captured reference facts",
        "records": records,
        "sources": {
            "source.1": {
                "content_hash": source["content_hash"],
                "verified": True,
                "denied": False,
                "readable": True,
            }
        },
        "snapshot_eligibility": {
            query["snapshot"]["id"]: {
                "currently_eligible_for_quote": query["currently_eligible_for_quote"],
                "eligibility_checked_at": query["eligibility_checked_at"],
            }
        },
    }
    content = commercial(data, registry, "quote.1", 1, AS_OF)
    approval = {
        "id": "approval.1",
        "quote_id": "quote.1",
        "business_revision": 1,
        "business_hash": business_hash(content),
        "command": "quote.activate",
        "policy_ref": data["pricing_policy_ref"],
        "reviewer": "reviewer",
        "decision": "approved",
        "decided_at": AS_OF,
        "expires_at": "2026-10-28T08:00:00Z",
        "effectivity_version": 1,
        "effectivity": "valid",
    }
    # Each case supplies a separate explicitly declared pre-state. These are not
    # a claim that a persistent workflow created or committed any approval.
    facts = {
        "quote_id": "quote.1",
        "root_version": 5,
        "working": False,
        "draft_generation": 1,
        "sealed_revisions": [1],
        "business_revision": 1,
        "status": "pending_approval",
        "review_open": False,
        "review_request_id": "review.1",
        "approval_current": True,
        "contributors": ["author"],
        "business_hash": business_hash(content),
        "approval": approval,
        "reviewer_currently_authorized": True,
        "server_control": "unbound_verified",
        "conversion_slot": False,
        "hold": False,
        "actor": {"id": "author", "kind": "human", "grants": list(COMMANDS), "readable": True},
        "data": data,
        "commercial": content,
        "expires_at": data["expires_at"],
    }
    cases = []
    common = {"quote_id": "quote.1", "expected_root_version": 5}
    rev = {**common, "business_revision": 1}
    reason = {"reason": "Synthetic reviewed action", "evidence": evidence}
    arguments = [
        {**common, "data": data},
        {**common, "base_revision": 1},
        {**common, "draft_generation": 1, **reason},
        {**common, "draft_generation": 1},
        {**rev, "target": {"command": "quote.activate"}},
        {
            **rev,
            "review_request_id": "review.1",
            "business_hash": facts["business_hash"],
            "expires_at": data["expires_at"],
            **reason,
        },
        {**rev, "review_request_id": "review.1", **reason},
        {**rev, "review_request_id": "review.1", **reason},
        {**rev, "approval_id": "approval.1", "expected_effectivity_version": 1, **reason},
        {**rev, "approval_id": "approval.1", "expected_approval_effectivity_version": 1},
        {
            **rev,
            "expected_old_active_revision": 2,
            "approval_id": "approval.1",
            "expected_approval_effectivity_version": 1,
        },
        {**rev, **reason},
        {**rev, **reason},
    ]
    statuses = [
        "draft",
        "draft",
        "discarded",
        "frozen",
        "pending_approval",
        "pending_approval",
        "frozen",
        "frozen",
        "pending_approval",
        "active",
        "active",
        "withdrawn",
        "cancelled",
    ]
    for i, command in enumerate(COMMANDS):
        before = deepcopy(facts)
        if command in ("quote.save_draft", "quote.discard_draft", "quote.freeze"):
            before["working"] = True
        if command == "quote.submit_review":
            before.update(status="frozen", approval_current=False)
        if command.startswith("quote.review."):
            before["review_open"] = True
            before["actor"]["id"] = "reviewer"
        if command == "quote.replace":
            before["active_revision"] = 2
            before["approval"].update(command="quote.replace", expected_old_active_revision=2)
        if command == "quote.cancel":
            before.update(status="active", active_revision=1)
        request = {
            "contract": CONTRACT,
            "command": command,
            "idempotency_key": f"candidate.{i}",
            "args": arguments[i],
        }
        result = {"object_id": "quote.1", "root_version": 6, "status": statuses[i]}
        if i >= 3:
            result.update(business_revision=1, business_hash=facts["business_hash"])
        if command == "quote.submit_review" or command.startswith("quote.review."):
            result["review_request_id"] = "review.1"
        if command in (
            "quote.activate",
            "quote.replace",
            "quote.review.approve",
            "quote.approval.revoke",
        ):
            result["approval_id"] = "approval.1"
        if command in ("quote.activate", "quote.replace"):
            result["document_id"] = "document.sample"
        cases.append(
            {
                "name": command,
                "request": request,
                "before": before,
                "response": {
                    "ok": True,
                    "command": command,
                    "action_id": f"sample.action.{i}",
                    "replayed": False,
                    "result": result,
                },
            }
        )
    config_cases = []
    for kind, value in zip(CONFIG_KINDS, (template, application), strict=True):
        for action in CONFIG_ACTIONS:
            args = {"kind": kind, "id": "config.sample", "expected_version": 1}
            if action == "save_draft":
                args.update(expected_version=0, data=value)
            elif action == "revise":
                args["base_revision"] = 1
            elif action in ("discard_draft", "publish"):
                args["working_revision"] = 1
            else:
                args["target_revision"] = 1
            if action in ("publish", "retire", "discard_draft"):
                args.update(reason)
            command = "quotation_foundation." + action
            config_cases.append(
                {
                    "request": {
                        "contract": CONFIG_CONTRACT,
                        "command": command,
                        "idempotency_key": kind + "." + action,
                        "args": args,
                    },
                    "response": {
                        "ok": True,
                        "command": command,
                        "action_id": "config.action",
                        "replayed": False,
                        "kind": kind,
                        "id": "config.sample",
                        "root_version": 2,
                        "last_revision": 1,
                    },
                }
            )
    document = render(content, registry, "SYN-Q-2026-00001")
    query_cases = []
    views: dict[str, tuple[dict, dict]] = {
        "quote_root": (
            {"quote_id": "quote.1"},
            {"quote_id": "quote.1", "root_version": 6, "current_active_revision": 1},
        ),
        "quote_revision": (
            {"quote_id": "quote.1", "business_revision": 1},
            {"commercial": content, "business_hash": facts["business_hash"], "status": "active"},
        ),
        "quote_ready": (
            {"quote_id": "quote.1"},
            {
                "quote_id": "quote.1",
                "currently_ready": True,
                "checked_at": AS_OF,
                "reason_codes": [],
                "business_revision": 1,
            },
        ),
        "approval": ({"approval_id": "approval.1"}, approval),
        "document": ({"document_id": "document.sample"}, document),
    }
    for kind, (query_args, query_value) in views.items():
        query_cases.append(
            {
                "request": {"contract": CONTRACT, "kind": kind, "args": query_args},
                "response": {"ok": True, "kind": kind, "value": query_value},
            }
        )
    for name, payload in (
        ("registry.json", registry),
        ("quote.json", data),
        ("commercial.json", content),
        ("commands.json", cases),
        ("configuration.json", config_cases),
        ("queries.json", query_cases),
        ("document.json", document),
    ):
        write(name, payload)
    (ROOT / "examples/candidate-document.txt").write_text(document["content_text"])
    return registry, data, content, cases


if __name__ == "__main__":
    build()
