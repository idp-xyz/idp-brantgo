"""Executable A1 quotation-combination and mapping checks.

The checks use the frozen candidate fixture and copy it before each variant.  They
are intentionally separate from ``verify.py``: passing them does not register a
Core quotation command or claim T03 persistence is implemented.
"""

from __future__ import annotations

import json
from copy import deepcopy
from fractions import Fraction

from .admission import calculate
from .calculation import rounded
from .protocol import ROOT, Invalid, digest


def load(name: str):
    return json.loads((ROOT / "examples" / name).read_text(encoding="utf-8"))


def record(registry: dict, reference: dict, data: dict) -> None:
    registry["records"].append(
        {
            "ref": reference,
            "data": data,
            "content_hash": digest(data),
            "active": True,
            "readable": True,
            "evidence": [{"source_id": "source.1", "locator": "A1 synthetic evidence"}],
        }
    )


def replace_data(registry: dict, kind: str, id_: str, data: dict) -> None:
    row = next(
        row for row in registry["records"] if row["ref"]["kind"] == kind and row["ref"]["id"] == id_
    )
    row["data"] = data
    row["content_hash"] = digest(data)


def variant() -> tuple[dict, dict]:
    return deepcopy(load("registry.json")), deepcopy(load("quote.json"))


def expect(receipts: list[dict], name: str, operation, expected=None) -> None:
    try:
        value = operation()
    except Invalid as exc:
        if expected is None or exc.code != expected:
            raise AssertionError(f"{name}: expected {expected}, got {exc.code}") from exc
        receipts.append({"name": name, "result": exc.code, "passed": True})
        return
    if expected is not None:
        raise AssertionError(f"{name}: expected rejection {expected}")
    if callable(expected):
        expected(value)
    receipts.append({"name": name, "result": "accepted", "passed": True})


def run() -> dict:
    receipts: list[dict] = []
    base_registry, base_data = variant()
    as_of = base_registry["as_of"]

    result, _, _ = calculate(base_data, base_registry, as_of)
    assert result["net_minor"] == "96000" and result["payable_minor"] == "96000"
    receipts.append({"name": "C01 same currency untaxed", "result": "96000", "passed": True})

    registry, data = variant()
    tax = deepcopy(next(row for row in registry["records"] if row["ref"]["kind"] == "tax_profile"))
    tax["data"].update(rate="0.13", price_basis="exclusive")
    replace_data(registry, "tax_profile", tax["ref"]["id"], tax["data"])
    result, _, _ = calculate(data, registry, as_of)
    assert (result["net_minor"], result["tax_minor"], result["payable_minor"]) == (
        "96000",
        "12480",
        "108480",
    )
    receipts.append({"name": "C02 exclusive tax", "result": "96000+12480=108480", "passed": True})

    tax["data"].update(rate="0.13", price_basis="inclusive")
    replace_data(registry, "tax_profile", tax["ref"]["id"], tax["data"])
    result, _, _ = calculate(data, registry, as_of)
    assert (result["net_minor"], result["tax_minor"], result["payable_minor"]) == (
        "84956",
        "11044",
        "96000",
    )
    receipts.append({"name": "C03 inclusive tax", "result": "84956+11044=96000", "passed": True})

    registry, data = variant()
    eur = {"kind": "currency", "id": "EUR", "revision": 1}
    record(
        registry,
        eur,
        {"code": "EUR", "name": "Synthetic euro", "minor_units": 2, "rounding": "HALF_UP"},
    )
    fx = {"kind": "fx", "id": "sales.eur.usd", "revision": 1}
    record(
        registry,
        fx,
        {
            "from_currency": eur,
            "to_currency": {"kind": "currency", "id": "USD", "revision": 1},
            "purpose": "quotation",
            "rate": "1.1",
            "observed_at": "2026-10-22T08:30:00Z",
            "valid_from": "2026-10-22T00:00:00Z",
            "valid_until": "2026-10-23T00:00:00Z",
        },
    )
    data["currency_ref"] = eur
    data["sales_fx_ref"] = fx
    result, _, _ = calculate(data, registry, as_of)
    assert result["comparison_revenue_minor"] == "105600" and result["payable_minor"] == "96000"
    receipts.append(
        {"name": "C04 quotation FX", "result": "960 EUR -> 105600 USD minor", "passed": True}
    )

    registry, data = variant()
    payment_ref = next(row for row in registry["records"] if row["ref"]["kind"] == "payment_terms")
    payment = deepcopy(payment_ref["data"])
    calendar = payment["stages"][0]["calendar"]
    payment["stages"] = [
        {
            "stage_id": "P30",
            "percent": "30",
            "trigger": "before_shipment",
            "days": 0,
            "day_basis": "calendar",
            "calendar": calendar,
        },
        {
            "stage_id": "P70",
            "percent": "70",
            "trigger": "before_shipment",
            "days": 0,
            "day_basis": "calendar",
            "calendar": calendar,
        },
    ]
    replace_data(registry, "payment_terms", payment_ref["ref"]["id"], payment)
    result, _, _ = calculate(data, registry, as_of)
    assert [item["amount_minor"] for item in result["payments"]] == ["28800", "67200"]
    receipts.append({"name": "C05 payment split", "result": "28800+67200=96000", "passed": True})

    assert rounded(Fraction(5, 100) * 100) == 5
    assert rounded(Fraction(5, 1000) * 100) == 1
    receipts.append({"name": "C06 per-line half-up", "result": "1+1=2 minor units", "passed": True})

    registry, data = variant()
    fee_ref = {"kind": "fee_type", "id": "sales.freight", "revision": 1}
    record(
        registry,
        fee_ref,
        {
            "category": "freight",
            "name": "Synthetic sales freight",
            "policy_basis": "A1",
            "side": "sales_charge",
            "inclusion": "separate",
            "allocation_basis": "quantity",
        },
    )
    charge_tax_ref = {"kind": "sales_tax_application", "id": "tax.sale.freight", "revision": 1}
    record(
        registry,
        charge_tax_ref,
        {
            "name": "Synthetic charge tax applicability",
            "business_model": "CN-M01",
            "use": "quotation_sale",
            "subject_kind": "fee_type",
            "subject_ref": fee_ref,
            "issuer_ref": data["issuer_ref"],
            "customer_ref": data["customer_ref"],
            "tax_profile_ref": {"kind": "tax_profile", "id": "tax.zero", "revision": 1},
            "jurisdiction": "SYNTHETIC-CN",
            "basis_note": "A1 synthetic",
            "valid_from": "2026-10-22T00:00:00Z",
            "valid_until": "2026-10-29T00:00:00Z",
        },
    )
    data["charges"] = [
        {
            "charge_id": "F1",
            "fee_type_ref": fee_ref,
            "obligation_key": "freight-1",
            "amount": "10",
            "inclusion": "separate",
            "tax_application_ref": charge_tax_ref,
            "evidence": data["evidence"],
        }
    ]
    result, _, _ = calculate(data, registry, as_of)
    assert result["net_minor"] == "97000" and result["payable_minor"] == "97000"
    receipts.append(
        {"name": "C07 separate sales charge", "result": "96000+1000=97000", "passed": True}
    )
    data["charges"].append(
        {
            "charge_id": "F2",
            "fee_type_ref": fee_ref,
            "obligation_key": "freight-1",
            "amount": "5",
            "inclusion": "separate",
            "tax_application_ref": charge_tax_ref,
            "evidence": data["evidence"],
        }
    )
    expect(
        receipts,
        "C08 duplicate charge obligation",
        lambda: calculate(data, registry, as_of),
        "CHARGE_SCOPE_UNRESOLVED",
    )

    registry, data = variant()
    data["sales_fx_ref"] = {"kind": "fx", "id": "unused", "revision": 1}
    expect(
        receipts,
        "C09 same-currency FX",
        lambda: calculate(data, registry, as_of),
        "REFERENCE_INVALID",
    )
    registry, data = variant()
    eur = {"kind": "currency", "id": "EUR", "revision": 1}
    record(
        registry,
        eur,
        {"code": "EUR", "name": "Synthetic euro", "minor_units": 2, "rounding": "HALF_UP"},
    )
    data["currency_ref"] = eur
    expect(
        receipts,
        "C10 missing quotation FX",
        lambda: calculate(data, registry, as_of),
        "REFERENCE_INVALID",
    )

    registry, data = variant()
    policy = next(row for row in registry["records"] if row["ref"]["kind"] == "pricing_policy")
    policy_data = deepcopy(policy["data"])
    policy_data["minimum_margin"] = "0.25"
    replace_data(registry, "pricing_policy", policy["ref"]["id"], policy_data)
    data["lines"][0]["unit_price"] = "7.33333333"
    result, _, _ = calculate(data, registry, as_of)
    assert result["margin_rule"] == "pass"
    receipts.append({"name": "C11 exact margin threshold", "result": "pass", "passed": True})
    data["lines"][0]["unit_price"] = "7"
    result, _, _ = calculate(data, registry, as_of)
    assert result["margin_rule"] == "requires_approval"
    receipts.append(
        {"name": "C12 below margin threshold", "result": "requires_approval", "passed": True}
    )

    mapping = json.loads(
        (ROOT / "contracts" / "authority-control-mapping.json").read_text(encoding="utf-8")
    )
    command_names = {item["name"] for item in mapping["commands"]}
    expected_commands = {
        "quote.save_draft",
        "quote.revise",
        "quote.discard_draft",
        "quote.freeze",
        "quote.submit_review",
        "quote.review.approve",
        "quote.review.return",
        "quote.review.reject",
        "quote.approval.revoke",
        "quote.activate",
        "quote.replace",
        "quote.withdraw",
        "quote.cancel",
    }
    assert mapping["status"] == "design_only" and command_names == expected_commands
    assert len(command_names) == len(mapping["commands"])
    assert all(item["permission"] in mapping["permissions"] for item in mapping["commands"])
    assert all(item["control"] == "root" for item in mapping["commands"])
    assert set(mapping["external_side_effects"]) == set()
    receipts.append(
        {
            "name": "authority/control mapping closed",
            "result": "13 commands, no external side effects",
            "passed": True,
        }
    )
    return {"version": "A1-0.1", "checks": len(receipts), "all_passed": True, "receipts": receipts}


if __name__ == "__main__":
    result = run()
    evidence = ROOT / "evidence" / "a1-verification.json"
    evidence.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"checks": result["checks"], "all_passed": result["all_passed"]}))
