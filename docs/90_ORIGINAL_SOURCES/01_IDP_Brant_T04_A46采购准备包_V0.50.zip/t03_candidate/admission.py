"""Candidate action admission over declared pre-state; never commits a quote."""

from copy import deepcopy
from datetime import timedelta

from .calculation import calculate
from .dependencies import References
from .protocol import NORMALIZATION, business_hash, instant, require, validate


def commercial(data, registry, quote_id, revision, issued_at):
    calculated, refs, parties = calculate(data, registry, issued_at)
    policy = refs.get(data["pricing_policy_ref"])
    require(
        instant(issued_at)
        < instant(data["expires_at"])
        <= instant(issued_at) + timedelta(days=policy["quote_valid_days"]),
        "QUOTE_EXPIRED",
    )
    value = {
        "quote_id": quote_id,
        "business_revision": revision,
        "issued_at": issued_at,
        "data": data,
        "calculation": calculated,
        "party_snapshots": parties,
        "dependency_manifest": list(refs.used.values()),
        "normalization_version": NORMALIZATION,
    }
    validate(value, "commercial.schema.json")
    return value


def admit(request, facts, registry, as_of):
    """The facts argument is trusted synthetic pre-state, not user JSON."""
    validate(request, "commands.schema.json")
    command = request["command"]
    args = request["args"]
    actor = facts["actor"]
    require(command in actor["grants"] and actor["readable"], "PERMISSION_DENIED")
    require(command == "quote.save_draft" or actor["kind"] == "human", "PERMISSION_DENIED")
    require(facts["server_control"] == "unbound_verified", "OBJECT_CONTROL_CONFLICT")
    require(args["quote_id"] == facts["quote_id"], "NOT_FOUND")
    require(args["expected_root_version"] == facts["root_version"], "VERSION_CONFLICT")
    refs = References(registry, as_of)
    refs.evidence(args.get("evidence", []))
    status = facts.get("status")
    if "business_revision" in args:
        require(args["business_revision"] == facts["business_revision"], "REFERENCE_INVALID")
    if command == "quote.save_draft":
        require(facts["root_version"] == 0 or facts["working"], "INVALID_STATE")

        draft = args["data"]
        # Drafts may cite readable history; forward adoption happens at freeze.
        refs.document(draft, historical=True)
        if "snapshot_ref" in draft:
            captured = refs.history(
                {"kind": "cost_snapshot", "id": draft["snapshot_ref"]["id"], "revision": 1}
            )
            require(
                captured["snapshot"]["result_hash"] == draft["snapshot_ref"]["result_hash"],
                "REFERENCE_INVALID",
            )
        for line in draft.get("lines", []):
            from .calculation import number

            require(
                all(number(line[k]) > 0 for k in ("quantity", "unit_price", "price_basis_quantity"))
                and 0 <= number(line["discount_ratio"]) < 1,
                "INVALID_KNOWN_VALUE",
            )
    elif command == "quote.revise":
        require(
            not facts["working"] and args["base_revision"] in facts["sealed_revisions"],
            "INVALID_STATE",
        )
    elif command in ("quote.discard_draft", "quote.freeze"):
        require(
            facts["working"] and args["draft_generation"] == facts["draft_generation"],
            "INVALID_STATE",
        )
    elif command == "quote.submit_review":
        require(
            status in ("frozen", "pending_approval") and not facts["review_open"], "INVALID_STATE"
        )
        require(status == "frozen" or not facts["approval_current"], "INVALID_STATE")
        target = args["target"]
        require(
            (target["command"] == "quote.activate" and facts.get("active_revision") is None)
            or (
                target["command"] == "quote.replace"
                and target["expected_old_active_revision"] == facts.get("active_revision")
            ),
            "QUOTE_NOT_CURRENT",
        )
    elif command.startswith("quote.review."):
        require(
            status == "pending_approval"
            and facts["review_open"]
            and args["review_request_id"] == facts["review_request_id"],
            "INVALID_STATE",
        )
        require(actor["id"] not in facts["contributors"], "INDEPENDENT_REVIEW_REQUIRED")
        if command == "quote.review.approve":
            require(args["business_hash"] == facts["business_hash"], "REFERENCE_INVALID")
            require(
                instant(as_of) < instant(args["expires_at"]) <= instant(facts["expires_at"]),
                "APPROVAL_EXPIRED",
            )
    elif command == "quote.approval.revoke":
        approval = facts["approval"]
        require(
            args["approval_id"] == approval["id"]
            and args["expected_effectivity_version"] == approval["effectivity_version"],
            "VERSION_CONFLICT",
        )
        require(approval["effectivity"] == "valid", "INVALID_STATE")
    elif command in ("quote.activate", "quote.replace"):
        require(status == "pending_approval" and not facts["review_open"], "INVALID_STATE")
        require(not facts["conversion_slot"], "ROOT_CONVERSION_LOCKED")
        require(not facts["hold"], "INVALID_STATE")
        if command == "quote.activate":
            require(facts.get("active_revision") is None, "QUOTE_NOT_CURRENT")
        else:
            require(
                args["expected_old_active_revision"] == facts.get("active_revision"),
                "QUOTE_NOT_CURRENT",
            )
        approval = facts["approval"]
        require(
            args["approval_id"] == approval["id"]
            and args["expected_approval_effectivity_version"] == approval["effectivity_version"],
            "VERSION_CONFLICT",
        )
        require(approval["effectivity"] == "valid", "APPROVAL_REVOKED")
        require(
            instant(facts["commercial"]["issued_at"])
            <= instant(approval["decided_at"])
            <= instant(as_of),
            "APPROVAL_REQUIRED",
        )
        require(instant(as_of) < instant(approval["expires_at"]), "APPROVAL_EXPIRED")
        require(
            facts["reviewer_currently_authorized"]
            and approval["reviewer"] not in facts["contributors"],
            "INDEPENDENT_REVIEW_REQUIRED",
        )
        require(
            approval["command"] == command
            and approval["quote_id"] == args["quote_id"]
            and approval["business_revision"] == args["business_revision"]
            and approval["business_hash"] == facts["business_hash"]
            and approval["policy_ref"] == facts["data"]["pricing_policy_ref"],
            "APPROVAL_REQUIRED",
        )
        if command == "quote.replace":
            require(
                approval.get("expected_old_active_revision")
                == args["expected_old_active_revision"],
                "APPROVAL_REQUIRED",
            )
    elif command == "quote.withdraw":
        require(status in ("frozen", "pending_approval"), "INVALID_STATE")
    elif command == "quote.cancel":
        require(
            status == "active" and args["business_revision"] == facts.get("active_revision"),
            "QUOTE_NOT_CURRENT",
        )
        require(not facts["conversion_slot"], "ROOT_CONVERSION_LOCKED")
    if command in (
        "quote.freeze",
        "quote.submit_review",
        "quote.review.approve",
        "quote.activate",
        "quote.replace",
    ):
        calculated, _, _ = calculate(facts["data"], registry, as_of)
        require(instant(as_of) < instant(facts["expires_at"]), "QUOTE_EXPIRED")
        if command != "quote.freeze":
            require(calculated["margin_rule"] == "pass", "APPROVAL_REQUIRED")
        if command in ("quote.activate", "quote.replace"):
            require(calculated == facts["commercial"]["calculation"], "COMPARISON_BASIS_MISMATCH")
            require(
                business_hash(facts["commercial"]) == facts["business_hash"], "REFERENCE_INVALID"
            )
            rebound = deepcopy(facts["commercial"])
            rebound["data"] = facts["data"]
            require(business_hash(rebound) == facts["business_hash"], "REFERENCE_INVALID")
        if command == "quote.freeze":
            commercial(facts["data"], registry, args["quote_id"], facts["business_revision"], as_of)
    return {"admitted": True, "command": command}
