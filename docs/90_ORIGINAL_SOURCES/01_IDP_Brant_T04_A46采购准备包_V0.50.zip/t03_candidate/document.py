"""Bounded plain-text reference rendering, with no I/O or outbound delivery."""

import hashlib

from .dependencies import References
from .protocol import business_hash, require


def render(commercial, registry, document_number):
    data = commercial["data"]
    calculation = commercial["calculation"]
    refs = References(registry, commercial["issued_at"])
    template = refs.get(data["document_template_ref"])
    require(template["renderer_version"] == "quote-text/0.1.0", "DEPENDENCY_NOT_SUPPORTED")
    required = {
        "issuer",
        "recipient",
        "identity",
        "lines",
        "totals",
        "terms",
        "delivery",
        "payments",
        "validity",
        "notes",
    }
    require(
        len(template["sections"]) == len(required) and set(template["sections"]) == required,
        "REFERENCE_INVALID",
    )
    money = {row["id"]: row for row in calculation["lines"]}
    lines = []
    for line in sorted(data["lines"], key=lambda row: row["line_id"]):
        values = money[line["line_id"]]
        sku = refs.get(line["sku_profile_ref"])
        unit = refs.get(line["unit_ref"])
        lines.append(
            f"{line['line_id']} | {sku['item_name']} | {sku['specification_version']} | {line['quantity']} {unit['code']} | price {line['unit_price']} per {line['price_basis_quantity']} | discount {line['discount_ratio']} | net {values['net_minor']} | tax {values['tax_minor']} | payable {values['payable_minor']}"
        )
    for charge in data["charges"]:
        values = next(row for row in calculation["charges"] if row["id"] == charge["charge_id"])
        lines.append(
            f"charge {charge['charge_id']} | {charge['obligation_key']} | {charge['inclusion']} | net {values['net_minor']} | tax {values['tax_minor']} | payable {values['payable_minor']}"
        )
    parties = commercial["party_snapshots"]
    currency = refs.get(data["currency_ref"])
    term = refs.get(data["trade_terms_ref"])
    place = refs.get(data["named_place_ref"])
    payments = [
        f"{p['stage_id']} | {p['percent']}% | {p['amount_minor']} | {p['trigger']} | {p['days']} {p['day_basis']} days | calendar {p['calendar']['id']} r{p['calendar']['revision']}"
        for p in calculation["payments"]
    ]
    blocks = {
        "issuer": "Issuer: " + parties["issuer"]["name"] + "\n" + parties["issuer"]["address"],
        "recipient": "Customer: "
        + parties["customer"]["name"]
        + "\n"
        + parties["customer"]["address"]
        + "\nContact: "
        + parties["contact_name"],
        "identity": f"Number: {document_number}\nQuote: {commercial['quote_id']} r{commercial['business_revision']}\nBusiness SHA-256: {business_hash(commercial)}",
        "lines": "Lines (all amounts in currency minor units):\n" + "\n".join(lines),
        "totals": f"Currency: {currency['code']} | minor digits: {currency['minor_units']}\nNet: {calculation['net_minor']} | Tax: {calculation['tax_minor']} | Payable: {calculation['payable_minor']}",
        "terms": f"Terms: {term['incoterm']} {term['edition']} | {term['responsibility_note']}\nNamed place: {place['name']} | Scope: {data['trade_scope_ref']['id']} r{data['trade_scope_ref']['revision']}",
        "delivery": "Delivery: "
        + data["delivery"]["date"]
        + " | "
        + data["delivery"]["milestone"]
        + " | "
        + data["delivery"]["time_zone"],
        "payments": "Payment plan (minor units; not receipts):\n" + "\n".join(payments),
        "validity": f"Commercial issue: {commercial['issued_at']}\nExpires exclusively: {data['expires_at']}",
        "notes": data["customer_notes"] + "\n" + template["footer_note"],
    }
    require(template["language"] == "en", "DEPENDENCY_NOT_SUPPORTED")
    text = (
        template["title"]
        + "\n\n"
        + "\n\n".join(blocks[section] for section in template["sections"])
        + "\n"
    )
    encoded = text.encode("utf-8")
    require(len(encoded) <= 1048576, "CALCULATION_LIMIT_EXCEEDED")
    return {
        "id": "document.sample",
        "quote_id": commercial["quote_id"],
        "business_revision": commercial["business_revision"],
        "business_hash": business_hash(commercial),
        "document_number": document_number,
        "content_sha256": hashlib.sha256(encoded).hexdigest(),
        "size_bytes": len(encoded),
        "mime_type": "text/plain",
        "template_ref": data["document_template_ref"],
        "renderer_version": "quote-text/0.1.0",
        "content_text": text,
    }
