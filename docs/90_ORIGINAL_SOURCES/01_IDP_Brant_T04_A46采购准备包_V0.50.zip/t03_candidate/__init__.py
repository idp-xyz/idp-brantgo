"""T03 candidate contracts; no production command registration."""
