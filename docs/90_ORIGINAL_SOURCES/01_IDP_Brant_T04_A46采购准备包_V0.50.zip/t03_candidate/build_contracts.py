"""Build closed, local JSON Schemas from one set of typed definitions."""

import json
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).parent
CONTRACT = "brant.quotation/0.1.0"
CONFIG_CONTRACT = "brant.quotation-foundation/0.1.0"
COMMANDS = (
    "quote.save_draft",
    "quote.revise",
    "quote.discard_draft",
    "quote.freeze",
    "quote.submit_review",
    "quote.review.approve",
    "quote.review.return",
    "quote.review.reject",
    "quote.approval.revoke",
    "quote.activate",
    "quote.replace",
    "quote.withdraw",
    "quote.cancel",
)
CONFIG_KINDS = ("quote_document_template", "sales_tax_application")
CONFIG_ACTIONS = ("save_draft", "revise", "discard_draft", "publish", "retire")
ERRORS = (
    "UNSUPPORTED_CONTRACT",
    "SCHEMA_INVALID",
    "PERMISSION_DENIED",
    "NOT_FOUND",
    "IDEMPOTENCY_PAYLOAD_CONFLICT",
    "VERSION_CONFLICT",
    "INVALID_STATE",
    "DRAFT_NOT_READY",
    "REFERENCE_INVALID",
    "REFERENCE_STALE",
    "QUOTE_NOT_CURRENT",
    "QUOTE_EXPIRED",
    "COST_SNAPSHOT_NOT_ELIGIBLE",
    "APPROVAL_REQUIRED",
    "APPROVAL_REVOKED",
    "APPROVAL_EXPIRED",
    "INDEPENDENT_REVIEW_REQUIRED",
    "ROOT_CONVERSION_LOCKED",
    "OBJECT_CONTROL_CONFLICT",
    "DEPENDENCY_NOT_SUPPORTED",
    "CALCULATION_LIMIT_EXCEEDED",
    "INVALID_KNOWN_VALUE",
    "PAYMENT_TOTAL_MISMATCH",
    "CHARGE_SCOPE_UNRESOLVED",
    "COMPARISON_BASIS_MISMATCH",
    "BUSINESS_KEY_CONFLICT",
    "CONFIG_EXPIRED",
    "CONFIG_NOT_ACTIVE",
    "COST_SNAPSHOT_MISSING",
    "COST_INPUT_NOT_READY",
    "DUPLICATE_LINE_ID",
    "FILE_INVALID",
    "FX_SCOPE_MISMATCH",
    "FX_STALE",
    "IMMUTABLE_DEFINITION",
    "MARGIN_POLICY_REQUIRES_APPROVAL",
    "QUOTE_VALIDITY_INVALID",
    "SEQUENCE_EXHAUSTED",
    "TAX_POLICY_UNCONFIRMED",
    "TEMPLATE_INVALID",
    "UNIT_SCOPE_MISMATCH",
)
STATES = ("frozen", "pending_approval", "active", "superseded", "withdrawn", "cancelled")
SECTIONS = (
    "issuer",
    "recipient",
    "identity",
    "lines",
    "totals",
    "terms",
    "delivery",
    "payments",
    "validity",
    "notes",
)


def obj(properties, required=None):
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties) if required is None else required,
        "additionalProperties": False,
    }


def arr(items, minimum=0, maximum=200, unique=False):
    value = {"type": "array", "items": items, "minItems": minimum, "maxItems": maximum}
    if unique:
        value["uniqueItems"] = True
    return value


def ref(name):
    return {"$ref": "#/$defs/" + name}


def const(value):
    return {"const": value}


def enum(values):
    return {"enum": list(values)}


def cfg(kind):
    return obj({"kind": const(kind), "id": ref("id"), "revision": ref("positive_version")})


def decimal(places):
    return {
        "type": "string",
        "maxLength": 26,
        "pattern": rf"^(?:0|[1-9][0-9]{{0,11}})(?:\.[0-9]{{1,{places}}})?$",
        "not": {"pattern": "[^0-9.]"},
    }


def definitions():
    d = {
        "id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 64,
            "pattern": "^[A-Za-z0-9][A-Za-z0-9._:-]*$",
            "not": {"pattern": "[^A-Za-z0-9._:-]"},
        },
        "version": {"type": "integer", "minimum": 0, "maximum": 2147483647},
        "positive_version": {"type": "integer", "minimum": 1, "maximum": 2147483647},
        "hash": {
            "type": "string",
            "minLength": 64,
            "maxLength": 64,
            "pattern": "^[0-9a-f]{64}$",
            "not": {"pattern": "[^0-9a-f]"},
        },
        "time": {
            "type": "string",
            "format": "date-time",
            "maxLength": 27,
            "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\\.[0-9]{1,6})?Z$",
            "not": {"pattern": "[^0-9T:Z.\\-]"},
        },
        "text": {"type": "string", "minLength": 1, "maxLength": 2000, "pattern": "\\S"},
        "note": {"type": "string", "maxLength": 5000},
        "quantity": decimal(6),
        "price": decimal(8),
        "ratio": decimal(8),
        "minor": {
            "type": "string",
            "maxLength": 24,
            "pattern": "^(?:0|[1-9][0-9]{0,23})$",
            "not": {"pattern": "[^0-9]"},
        },
        "signed_minor": {
            "type": "string",
            "maxLength": 25,
            "pattern": "^(?:0|-?[1-9][0-9]{0,23})$",
            "not": {"pattern": "[^0-9-]"},
        },
        "evidence": obj({"source_id": ref("id"), "locator": ref("text")}),
        "master_ref": obj(
            {
                "kind": enum(("customer", "contact", "supplier", "sku")),
                "id": ref("id"),
                "row_version": ref("positive_version"),
            }
        ),
        "rfq_ref": obj({"id": ref("id"), "row_version": ref("positive_version")}),
        "snapshot_ref": obj({"id": ref("id"), "result_hash": ref("hash")}),
        "dependency": obj(
            {
                "kind": ref("id"),
                "id": ref("id"),
                "version": ref("positive_version"),
                "content_hash": ref("hash"),
            }
        ),
    }
    for kind in (
        "company",
        "currency",
        "unit",
        "conversion",
        "sku_profile",
        "party_profile",
        "pricing_policy",
        "trade_terms",
        "trade_scope",
        "location",
        "payment_terms",
        "calendar",
        "delivery_calendar",
        "tax_profile",
        "fee_type",
        "fx",
        "sequence",
        *CONFIG_KINDS,
    ):
        d[kind + "_ref"] = cfg(kind)
    d["delivery"] = obj(
        {
            "kind": const("fixed"),
            "date": {"type": "string", "format": "date"},
            "milestone": enum(("goods_ready", "handover", "arrival")),
            "place_ref": ref("location_ref"),
            "time_zone": ref("text"),
        }
    )
    # This first candidate maps a resolved delivery date; relative event claims
    # remain in the T02 snapshot, not a new customer-confirmed event.
    line = {
        "line_id": ref("id"),
        "rfq_line_id": ref("id"),
        "sku_profile_ref": ref("sku_profile_ref"),
        "quantity": ref("quantity"),
        "unit_ref": ref("unit_ref"),
        "unit_price": ref("price"),
        "price_basis_quantity": ref("quantity"),
        "discount_ratio": ref("ratio"),
        "tax_application_ref": ref("sales_tax_application_ref"),
        "evidence": arr(ref("evidence"), 1),
        "conversion_ref": ref("conversion_ref"),
    }
    d["line"] = obj(line, [k for k in line if k != "conversion_ref"])
    d["charge"] = obj(
        {
            "charge_id": ref("id"),
            "fee_type_ref": ref("fee_type_ref"),
            "obligation_key": ref("id"),
            "amount": ref("price"),
            "inclusion": enum(("separate", "included_in_line")),
            "included_line_id": ref("id"),
            "tax_application_ref": ref("sales_tax_application_ref"),
            "evidence": arr(ref("evidence"), 1),
        },
        [
            "charge_id",
            "fee_type_ref",
            "obligation_key",
            "amount",
            "inclusion",
            "tax_application_ref",
            "evidence",
        ],
    )
    fields = {
        "issuer_ref": ref("company_ref"),
        "customer_ref": ref("master_ref"),
        "contact_ref": ref("master_ref"),
        "customer_profile_ref": ref("party_profile_ref"),
        "customer_address_id": ref("id"),
        "rfq_ref": ref("rfq_ref"),
        "snapshot_ref": ref("snapshot_ref"),
        "lines": arr(ref("line"), 1),
        "charges": arr(ref("charge"), 0, 100),
        "currency_ref": ref("currency_ref"),
        "pricing_policy_ref": ref("pricing_policy_ref"),
        "sales_fx_ref": ref("fx_ref"),
        "trade_terms_ref": ref("trade_terms_ref"),
        "trade_scope_ref": ref("trade_scope_ref"),
        "named_place_ref": ref("location_ref"),
        "payment_terms_ref": ref("payment_terms_ref"),
        "delivery": ref("delivery"),
        "expires_at": ref("time"),
        "document_template_ref": ref("quote_document_template_ref"),
        "sequence_ref": ref("sequence_ref"),
        "customer_notes": ref("note"),
        "evidence": arr(ref("evidence"), 1),
    }
    d["quote_data"] = obj(fields, [k for k in fields if k != "sales_fx_ref"])
    d["quote_draft"] = obj(deepcopy(fields), [])
    d["amount_line"] = obj(
        {
            "id": ref("id"),
            "net_minor": ref("minor"),
            "tax_minor": ref("minor"),
            "payable_minor": ref("minor"),
        }
    )
    d["payment"] = obj(
        {
            "stage_id": ref("id"),
            "percent": ref("ratio"),
            "amount_minor": ref("minor"),
            "trigger": ref("text"),
            "days": {"type": "integer", "minimum": 0, "maximum": 3650},
            "day_basis": enum(("calendar", "business")),
            "calendar": ref("calendar_ref"),
        }
    )
    d["calculation"] = obj(
        {
            "lines": arr(ref("amount_line"), 1),
            "charges": arr(ref("amount_line"), 0, 100),
            "net_minor": ref("minor"),
            "tax_minor": ref("minor"),
            "payable_minor": ref("minor"),
            "comparison_currency_ref": ref("currency_ref"),
            "comparison_revenue_minor": ref("minor"),
            "cost_minor": ref("minor"),
            "profit_minor": ref("signed_minor"),
            "margin_numerator": ref("signed_minor"),
            "margin_denominator": ref("minor"),
            "margin_rule": enum(("pass", "requires_approval")),
            "cost_basis": const("nominal_direct_cost"),
            "excluded_cost_categories": arr(ref("id"), 0, 50, True),
            "payments": arr(ref("payment"), 1, 20),
        }
    )
    party = obj({"id": ref("id"), "name": ref("text"), "address": ref("text")})
    d["party_snapshots"] = obj({"issuer": party, "customer": party, "contact_name": ref("text")})
    d["commercial"] = obj(
        {
            "quote_id": ref("id"),
            "business_revision": ref("positive_version"),
            "issued_at": ref("time"),
            "data": ref("quote_data"),
            "calculation": ref("calculation"),
            "party_snapshots": ref("party_snapshots"),
            "dependency_manifest": arr(ref("dependency"), 1, 5000),
            "normalization_version": const("brant.quote-normalization/0.1.0"),
        }
    )
    d["revision"] = obj(
        {"commercial": ref("commercial"), "business_hash": ref("hash"), "status": enum(STATES)}
    )
    d["approval"] = obj(
        {
            "id": ref("id"),
            "quote_id": ref("id"),
            "business_revision": ref("positive_version"),
            "business_hash": ref("hash"),
            "command": enum(("quote.activate", "quote.replace")),
            "expected_old_active_revision": ref("positive_version"),
            "policy_ref": ref("pricing_policy_ref"),
            "reviewer": ref("id"),
            "decision": const("approved"),
            "decided_at": ref("time"),
            "expires_at": ref("time"),
            "effectivity_version": ref("positive_version"),
            "effectivity": enum(("valid", "revoked")),
        },
        [
            "id",
            "quote_id",
            "business_revision",
            "business_hash",
            "command",
            "policy_ref",
            "reviewer",
            "decision",
            "decided_at",
            "expires_at",
            "effectivity_version",
            "effectivity",
        ],
    )
    d["document"] = obj(
        {
            "id": ref("id"),
            "quote_id": ref("id"),
            "business_revision": ref("positive_version"),
            "business_hash": ref("hash"),
            "document_number": ref("text"),
            "content_sha256": ref("hash"),
            "size_bytes": {"type": "integer", "minimum": 1, "maximum": 1048576},
            "mime_type": const("text/plain"),
            "template_ref": ref("quote_document_template_ref"),
            "renderer_version": const("quote-text/0.1.0"),
            "content_text": {"type": "string", "minLength": 1, "maxLength": 1048576},
        }
    )
    return d


def schema(body, defs):
    return {"$schema": "https://json-schema.org/draft/2020-12/schema", **body, "$defs": defs}


def command_args(command):
    common = {"quote_id": ref("id"), "expected_root_version": ref("version")}
    revision = {**common, "business_revision": ref("positive_version")}
    reason = {"reason": ref("text"), "evidence": arr(ref("evidence"), 1)}
    by_command = {
        "quote.save_draft": {**common, "data": ref("quote_draft")},
        "quote.revise": {**common, "base_revision": ref("positive_version")},
        "quote.discard_draft": {**common, "draft_generation": ref("positive_version"), **reason},
        "quote.freeze": {**common, "draft_generation": ref("positive_version")},
        "quote.submit_review": {
            **revision,
            "target": {
                "oneOf": [
                    obj({"command": const("quote.activate")}),
                    obj(
                        {
                            "command": const("quote.replace"),
                            "expected_old_active_revision": ref("positive_version"),
                        }
                    ),
                ]
            },
        },
        "quote.review.approve": {
            **revision,
            "review_request_id": ref("id"),
            "business_hash": ref("hash"),
            "expires_at": ref("time"),
            **reason,
        },
        "quote.review.return": {**revision, "review_request_id": ref("id"), **reason},
        "quote.review.reject": {**revision, "review_request_id": ref("id"), **reason},
        "quote.approval.revoke": {
            **revision,
            "approval_id": ref("id"),
            "expected_effectivity_version": ref("positive_version"),
            **reason,
        },
        "quote.activate": {
            **revision,
            "approval_id": ref("id"),
            "expected_approval_effectivity_version": ref("positive_version"),
        },
        "quote.replace": {
            **revision,
            "expected_old_active_revision": ref("positive_version"),
            "approval_id": ref("id"),
            "expected_approval_effectivity_version": ref("positive_version"),
        },
        "quote.withdraw": {**revision, **reason},
        "quote.cancel": {**revision, **reason},
    }
    return obj(by_command[command])


def config_definitions(defs):
    defs["quote_document_template"] = obj(
        {
            "name": ref("text"),
            "language": enum(("zh-CN", "en")),
            "renderer_version": const("quote-text/0.1.0"),
            "title": ref("text"),
            "sections": arr(enum(SECTIONS), len(SECTIONS), len(SECTIONS), True),
            "footer_note": ref("note"),
        }
    )
    defs["sales_tax_application"] = {
        "oneOf": [
            obj(
                {
                    "name": ref("text"),
                    "business_model": const("CN-M01"),
                    "use": const("quotation_sale"),
                    "subject_kind": const(kind),
                    "subject_ref": ref(kind + "_ref"),
                    "issuer_ref": ref("company_ref"),
                    "customer_ref": ref("master_ref"),
                    "tax_profile_ref": ref("tax_profile_ref"),
                    "jurisdiction": ref("text"),
                    "basis_note": ref("text"),
                    "valid_from": ref("time"),
                    "valid_until": ref("time"),
                }
            )
            for kind in ("sku_profile", "fee_type")
        ]
    }


def build():
    defs = definitions()
    config_definitions(defs)
    request = {
        "oneOf": [
            obj(
                {
                    "contract": const(CONTRACT),
                    "command": const(c),
                    "idempotency_key": ref("id"),
                    "args": command_args(c),
                }
            )
            for c in COMMANDS
        ]
    }
    config_branches = []
    for kind in CONFIG_KINDS:
        for action in CONFIG_ACTIONS:
            args = {"kind": const(kind), "id": ref("id"), "expected_version": ref("version")}
            if action == "save_draft":
                args["data"] = ref(kind)
            elif action == "revise":
                args["base_revision"] = ref("positive_version")
            elif action in ("discard_draft", "publish"):
                args["working_revision"] = ref("positive_version")
            else:
                args["target_revision"] = ref("positive_version")
            if action in ("publish", "retire", "discard_draft"):
                args.update(reason=ref("text"), evidence=arr(ref("evidence"), 1))
            config_branches.append(
                obj(
                    {
                        "contract": const(CONFIG_CONTRACT),
                        "command": const("quotation_foundation." + action),
                        "idempotency_key": ref("id"),
                        "args": obj(args),
                    }
                )
            )
    ack = obj(
        {
            "object_id": ref("id"),
            "root_version": ref("positive_version"),
            "status": enum(("draft", "discarded", *STATES)),
            "business_revision": ref("positive_version"),
            "business_hash": ref("hash"),
            "review_request_id": ref("id"),
            "approval_id": ref("id"),
            "document_id": ref("id"),
        },
        ["object_id", "root_version", "status"],
    )
    error = obj(
        {
            "ok": const(False),
            "command": {
                "type": "string",
                "minLength": 1,
                "maxLength": 100,
                "pattern": "^quote\\.",
            },
            "code": enum(ERRORS),
            "retriable": const(False),
        }
    )
    statuses = (
        "draft",
        "draft",
        "discarded",
        "frozen",
        "pending_approval",
        "pending_approval",
        "frozen",
        "frozen",
        None,
        "active",
        "active",
        "withdrawn",
        "cancelled",
    )
    success = []
    for c, state in zip(COMMANDS, statuses, strict=True):
        typed = deepcopy(ack)
        if state:
            typed["properties"]["status"] = const(state)
        if c not in COMMANDS[:3]:
            typed["required"] += ["business_revision", "business_hash"]
        if c == "quote.submit_review" or c.startswith("quote.review."):
            typed["required"].append("review_request_id")
        if c in (
            "quote.activate",
            "quote.replace",
            "quote.review.approve",
            "quote.approval.revoke",
        ):
            typed["required"].append("approval_id")
        if c in ("quote.activate", "quote.replace"):
            typed["required"].append("document_id")
        success.append(
            obj(
                {
                    "ok": const(True),
                    "command": const(c),
                    "action_id": ref("id"),
                    "replayed": {"type": "boolean"},
                    "result": typed,
                }
            )
        )
    config_responses = []
    for kind in CONFIG_KINDS:
        for action in CONFIG_ACTIONS:
            config_responses.append(
                obj(
                    {
                        "ok": const(True),
                        "command": const("quotation_foundation." + action),
                        "action_id": ref("id"),
                        "replayed": {"type": "boolean"},
                        "kind": const(kind),
                        "id": ref("id"),
                        "root_version": ref("positive_version"),
                        "last_revision": ref("positive_version"),
                        "active_revision": ref("positive_version"),
                        "working_revision": ref("positive_version"),
                    },
                    [
                        "ok",
                        "command",
                        "action_id",
                        "replayed",
                        "kind",
                        "id",
                        "root_version",
                        "last_revision",
                    ],
                )
            )
    config_responses.append(
        obj(
            {
                "ok": const(False),
                "command": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 100,
                    "pattern": "^quotation_foundation\\.",
                },
                "code": enum(ERRORS),
                "retriable": const(False),
            }
        )
    )
    config_views = []
    for config_kind in CONFIG_KINDS:
        config_views.append(
            obj(
                {
                    "ok": const(True),
                    "kind": const(config_kind),
                    "id": ref("id"),
                    "root_version": ref("positive_version"),
                    "revision": ref("positive_version"),
                    "sealed": {"type": "boolean"},
                    "effectivity": enum(("draft", "active", "superseded", "retired", "discarded")),
                    "data": ref(config_kind),
                    "data_hash": ref("hash"),
                    "record_hash": ref("hash"),
                    "contributors": arr(ref("id"), 1, 200, True),
                    "publication": obj(
                        {
                            "published_by": ref("id"),
                            "published_at": ref("time"),
                            "policy_ref": ref("pricing_policy_ref"),
                            "evidence": arr(ref("evidence"), 1),
                        }
                    ),
                },
                [
                    "ok",
                    "kind",
                    "id",
                    "root_version",
                    "revision",
                    "sealed",
                    "effectivity",
                    "data",
                    "data_hash",
                    "record_hash",
                    "contributors",
                ],
            )
        )
    config_views.append(
        obj(
            {
                "ok": const(False),
                "kind": enum(CONFIG_KINDS),
                "code": enum(ERRORS),
            }
        )
    )
    query_args = {
        "quote_root": obj({"quote_id": ref("id")}),
        "quote_revision": obj(
            {"quote_id": ref("id"), "business_revision": ref("positive_version")}
        ),
        "quote_ready": obj({"quote_id": ref("id")}),
        "approval": obj({"approval_id": ref("id")}),
        "document": obj({"document_id": ref("id")}),
    }
    root_view = obj(
        {
            "quote_id": ref("id"),
            "root_version": ref("positive_version"),
            "current_active_revision": ref("positive_version"),
            "working_generation": ref("positive_version"),
        },
        ["quote_id", "root_version"],
    )
    ready = obj(
        {
            "quote_id": ref("id"),
            "currently_ready": {"type": "boolean"},
            "checked_at": ref("time"),
            "reason_codes": arr(enum(ERRORS), 0, 50, True),
            "business_revision": ref("positive_version"),
        },
        ["quote_id", "currently_ready", "checked_at", "reason_codes"],
    )
    views = {
        "quote_root": root_view,
        "quote_revision": ref("revision"),
        "quote_ready": ready,
        "approval": ref("approval"),
        "document": ref("document"),
    }
    result = {
        "commands.schema.json": schema(request, defs),
        "configuration.commands.schema.json": schema({"oneOf": config_branches}, defs),
        "configuration.responses.schema.json": schema({"oneOf": config_responses}, defs),
        "configuration.queries.schema.json": schema(
            obj(
                {
                    "contract": const(CONFIG_CONTRACT),
                    "kind": enum(CONFIG_KINDS),
                    "id": ref("id"),
                    "revision": ref("positive_version"),
                },
                ["contract", "kind", "id"],
            ),
            defs,
        ),
        "configuration.query-responses.schema.json": schema({"oneOf": config_views}, defs),
        "quote-data.schema.json": schema(ref("quote_data"), defs),
        "commercial.schema.json": schema(ref("commercial"), defs),
        "responses.schema.json": schema({"oneOf": [*success, error]}, defs),
        "queries.schema.json": schema(
            {
                "oneOf": [
                    obj({"contract": const(CONTRACT), "kind": const(k), "args": a})
                    for k, a in query_args.items()
                ]
            },
            defs,
        ),
        "query-responses.schema.json": schema(
            {
                "oneOf": [
                    *[
                        obj({"ok": const(True), "kind": const(k), "value": v})
                        for k, v in views.items()
                    ],
                    obj({"ok": const(False), "kind": enum(views), "code": enum(ERRORS)}),
                ]
            },
            defs,
        ),
    }
    directory = ROOT / "contracts"
    directory.mkdir(exist_ok=True)
    for name, body in result.items():
        (directory / name).write_text(json.dumps(body, ensure_ascii=False, indent=2) + "\n")
    return result


if __name__ == "__main__":
    build()
