"""Adversarial checks of the public reference closure and calculation boundary."""

import json
from copy import deepcopy

from jsonschema import Draft202012Validator

from .admission import admit
from .build_contracts import ROOT
from .calculation import calculate
from .dependencies import References
from .protocol import digest


def checks(registry, quote, cases, passed, reject):
    as_of = registry["as_of"]

    def check(name, condition=True):
        passed("dependency-closure", name, condition)

    def denied(name, code, operation):
        reject("dependency-closure", name, code, operation)

    def row(host, kind, id_=None):
        return next(
            r
            for r in host["records"]
            if r["ref"]["kind"] == kind and (id_ is None or r["ref"]["id"] == id_)
        )

    def inherited(record):
        validator = Draft202012Validator(
            json.loads(
                (ROOT.parent / "brant_core/contracts/foundation.commands.schema.json").read_text()
            )
        )
        request = {
            "contract": "brant.foundation/0.1.0",
            "command": "foundation.save",
            "idempotency_key": "dependency.check",
            "args": {
                "id": record["ref"]["id"],
                "kind": record["ref"]["kind"],
                "expected_version": 0,
                "data": record["data"],
                "evidence_ids": ["source.1"],
            },
        }
        check(record["ref"]["kind"] + ":valid inherited schema", validator.is_valid(request))

    for kind, data, blocked_kind in (
        (
            "contact_profile",
            {
                "party_id": quote["customer_ref"]["id"],
                "party_role": "customer",
                "party_row_version": 2,
                "name": "Synthetic legacy contact",
                "email": "synthetic@example.invalid",
                "legacy_contact_ref": {"id": quote["contact_ref"]["id"], "row_version": 2},
            },
            "contact",
        ),
        (
            "bank_account",
            {
                "owner_kind": "party",
                "owner_id": quote["customer_ref"]["id"],
                "owner_row_version": 2,
                "bank_name": "Synthetic bank",
                "account_number": "SYNTHETIC-12345678",
                "currency": quote["currency_ref"],
                "purpose": "receipt",
            },
            "customer",
        ),
    ):
        changed = deepcopy(registry)
        ref = {"kind": kind, "id": "closure." + kind, "revision": 1}
        added = {
            "ref": ref,
            "data": data,
            "content_hash": digest(data),
            "active": True,
            "readable": True,
            "evidence": [],
        }
        inherited(added)
        changed["records"].append(added)
        row(changed, blocked_kind)["readable"] = False
        denied(
            kind + ":legacy path blocks new use",
            "PERMISSION_DENIED",
            lambda: References(changed, as_of).get(ref),
        )
        denied(
            kind + ":legacy path blocks historical read",
            "PERMISSION_DENIED",
            lambda: References(changed, as_of).history(ref),
        )

    for name, kind, id_ in (
        ("issuer base currency", "currency", "CNY"),
        ("SKU canonical unit", "unit", "PCS"),
        ("SKU master", "sku", None),
        ("customer profile contact", "contact", None),
        ("payment calendar", "calendar", None),
        ("tax applicability profile", "tax_profile", None),
    ):
        changed = deepcopy(registry)
        target = row(changed, kind, id_)
        target["readable"] = False
        if name == "issuer base currency":
            ref = quote["issuer_ref"]
        elif name == "customer profile contact":
            ref = quote["customer_profile_ref"]
        elif name.startswith("SKU"):
            ref = quote["lines"][0]["sku_profile_ref"]
        elif name == "payment calendar":
            ref = quote["payment_terms_ref"]
        else:
            ref = quote["lines"][0]["tax_application_ref"]
        denied(
            name + ":recursive read denied",
            "PERMISSION_DENIED",
            lambda: References(changed, as_of).get(ref),
        )
        denied(
            name + ":historical access rechecked",
            "PERMISSION_DENIED",
            lambda: References(changed, as_of).history(ref),
        )

    snapshot = {"kind": "cost_snapshot", "id": quote["snapshot_ref"]["id"], "revision": 1}
    for prefix in (
        "master.supplier",
        "foundation_publication.tax_application",
        "business_verification.logistics_offer",
    ):
        changed = deepcopy(registry)
        proof = next(p for p in changed["manifest_access"] if p["kind"] == prefix)
        proof["readable"] = False
        denied(
            prefix + ":T02 hidden dependency denies new use",
            "PERMISSION_DENIED",
            lambda: calculate(quote, changed, as_of),
        )
        denied(
            prefix + ":T02 hidden dependency denies history",
            "PERMISSION_DENIED",
            lambda: References(changed, as_of).history(snapshot),
        )
    changed = deepcopy(registry)
    changed["manifest_access"].pop()
    denied(
        "missing T02 access adapter fact",
        "DEPENDENCY_NOT_SUPPORTED",
        lambda: References(changed, as_of).get(snapshot),
    )
    changed = deepcopy(registry)
    changed["manifest_access"][0]["content_hash"] = "0" * 64
    denied(
        "T02 adapter hash must bind original manifest",
        "REFERENCE_INVALID",
        lambda: References(changed, as_of).get(snapshot),
    )
    changed = deepcopy(registry)
    changed["manifest_access"].append(deepcopy(changed["manifest_access"][0]))
    denied("duplicate adapter identity", "REFERENCE_INVALID", lambda: References(changed, as_of))
    changed = deepcopy(registry)
    changed["sources"]["source.1"]["denied"] = True
    denied(
        "source denial blocks recursive adoption",
        "REFERENCE_STALE",
        lambda: References(changed, as_of).get(quote["issuer_ref"]),
    )
    check(
        "source denial preserves readable snapshot history",
        References(changed, as_of).history(snapshot)["snapshot"]["id"] == snapshot["id"],
    )
    changed = deepcopy(registry)
    row(changed, "currency", "CNY")["active"] = False
    denied(
        "nested retirement blocks new adoption",
        "REFERENCE_STALE",
        lambda: References(changed, as_of).get(quote["issuer_ref"]),
    )
    check(
        "nested retirement preserves history",
        References(changed, as_of).history(quote["issuer_ref"])["base_currency"]["id"] == "CNY",
    )
    changed = deepcopy(registry)
    row(changed, "company")["readable"] = False
    # Corrupt valid JSON without its hash: access must fail before validation.
    row(changed, "company")["data"] = {"hidden": "must not appear in error"}
    denied(
        "unreadable record before content validation",
        "PERMISSION_DENIED",
        lambda: References(changed, as_of).get(quote["issuer_ref"]),
    )
    row(changed, "company")["data"] = {"unserializable_private_body": object()}
    denied(
        "private body is not serialized before authorization",
        "PERMISSION_DENIED",
        lambda: References(changed, as_of).get(quote["issuer_ref"]),
    )

    changed = deepcopy(registry)
    row(changed, "currency", "CNY")["data"]["name"] = "Changed without hash"
    denied(
        "nested content hash mismatch",
        "REFERENCE_INVALID",
        lambda: References(changed, as_of).get(quote["issuer_ref"]),
    )
    changed = deepcopy(registry)
    changed["records"].append(deepcopy(changed["records"][0]))
    denied("duplicate record identity", "REFERENCE_INVALID", lambda: References(changed, as_of))
    denied(
        "unsupported reference kind",
        "DEPENDENCY_NOT_SUPPORTED",
        lambda: References(registry, as_of).get(
            {"kind": "unregistered", "id": "unknown", "revision": 1}
        ),
    )
    changed = deepcopy(registry)
    company = row(changed, "company")
    company["data"]["cycle_ref"] = quote["issuer_ref"]
    company["content_hash"] = digest(company["data"])
    denied(
        "self dependency cycle",
        "REFERENCE_INVALID",
        lambda: References(changed, as_of).get(quote["issuer_ref"]),
    )

    def chain(edges):
        records = []
        for number in range(edges + 1):
            data = (
                {"next": {"kind": "currency", "id": f"node.{number + 1}", "revision": 1}}
                if number < edges
                else {"end": True}
            )
            records.append(
                {
                    "ref": {"kind": "currency", "id": f"node.{number}", "revision": 1},
                    "data": data,
                    "content_hash": digest(data),
                    "readable": True,
                    "active": True,
                    "evidence": [],
                }
            )
        return {"records": records, "sources": {}}

    ref = {"kind": "currency", "id": "node.0", "revision": 1}
    check(
        "eight dependency edges accepted",
        References(chain(8), as_of).get(ref)["next"]["id"] == "node.1",
    )
    denied(
        "ninth dependency edge rejected",
        "CALCULATION_LIMIT_EXCEEDED",
        lambda: References(chain(9), as_of).get(ref),
    )
    shared = chain(4)
    for i in range(5):
        child = {"kind": "currency", "id": f"head.{i + 1}", "revision": 1} if i < 4 else ref
        data = {"next": child}
        shared["records"].append(
            {
                "ref": {"kind": "currency", "id": f"head.{i}", "revision": 1},
                "data": data,
                "content_hash": digest(data),
                "readable": True,
                "active": True,
                "evidence": [],
            }
        )
    branches = {"branches": [ref, {"kind": "currency", "id": "head.0", "revision": 1}]}
    shared["records"].append(
        {
            "ref": {"kind": "currency", "id": "shared.root", "revision": 1},
            "data": branches,
            "content_hash": digest(branches),
            "readable": True,
            "active": True,
            "evidence": [],
        }
    )
    denied(
        "shared DAG cannot hide an overlong path",
        "CALCULATION_LIMIT_EXCEEDED",
        lambda: References(shared, as_of).get(
            {"kind": "currency", "id": "shared.root", "revision": 1}
        ),
    )
    historical = chain(0)
    historical["records"][0]["history_dependencies"] = []
    for i in range(1001):
        child = {"kind": "currency", "id": f"historical.{i}", "revision": 1}
        historical["records"].append(
            {
                "ref": child,
                "data": {},
                "content_hash": digest({}),
                "readable": True,
                "active": False,
                "evidence": [],
            }
        )
        historical["records"][0]["history_dependencies"].append(child)
    denied(
        "historical edges count toward reference limit",
        "CALCULATION_LIMIT_EXCEEDED",
        lambda: References(historical, as_of).get(ref),
    )
    changed = chain(0)
    changed["records"] = []
    for i in range(5001):
        changed["records"].append(
            {
                **chain(0)["records"][0],
                "ref": {"kind": "currency", "id": f"bulk.{i}", "revision": 1},
            }
        )
    denied(
        "5001 loaded records rejected",
        "CALCULATION_LIMIT_EXCEEDED",
        lambda: References(changed, as_of),
    )
    changed = chain(0)
    changed["manifest_access"] = [
        {
            "kind": "source",
            "id": f"bulk.{i}",
            "version": 1,
            "readable": True,
            "content_hash": "0" * 64,
        }
        for i in range(5001)
    ]
    denied(
        "5001 loaded manifest facts rejected",
        "CALCULATION_LIMIT_EXCEEDED",
        lambda: References(changed, as_of),
    )
    # Repetition must consume direct and operation budgets even when cached.
    resolver = References(chain(0), as_of)
    for _ in range(1000):
        resolver.get(ref)
    denied(
        "direct-reference limit applies to cached reads",
        "CALCULATION_LIMIT_EXCEEDED",
        lambda: resolver.get(ref),
    )
    resolver = References(registry, as_of)
    for _ in range(10000):
        resolver.source({"source_id": "source.1"})
    denied(
        "source repetition cannot evade operation limit",
        "CALCULATION_LIMIT_EXCEEDED",
        lambda: resolver.source({"source_id": "source.1"}),
    )
    large = chain(0)
    large["records"][0]["data"] = {"oversize": "x" * (64 * 1024 * 1024)}
    denied(
        "64MiB admitted load budget",
        "CALCULATION_LIMIT_EXCEEDED",
        lambda: References(large, as_of).get(ref),
    )
    result, refs, _ = calculate(quote, registry, as_of)
    check(
        "deduplicated exact flat manifest",
        len(refs.used) == len({(v["kind"], v["id"], v["version"]) for v in refs.used.values()})
        and any(k[0].startswith("t02_access.") for k in refs.used)
        and result["payable_minor"] == "96000",
    )
    # Saving a draft allows old business effectivity, but never unreadable data.
    draft_case = next(case for case in cases if case["name"] == "quote.save_draft")
    changed = deepcopy(registry)
    row(changed, "currency", "CNY")["active"] = False
    admit(draft_case["request"], draft_case["before"], changed, as_of)
    check("draft can preserve readable retired dependency")
    row(changed, "currency", "CNY")["readable"] = False
    denied(
        "draft cannot bypass nested current access",
        "PERMISSION_DENIED",
        lambda: admit(draft_case["request"], draft_case["before"], changed, as_of),
    )
