import copy
import hashlib
import json
import sqlite3
import subprocess
import sys
import unittest
from pathlib import Path

from brant_core import Core, Principal, t03_query, t03_reconciliation
from brant_core.common import canonical
from tests import test_t03_a20_acceptance_order as fixtures
from tests.order_review_fixture import approve_order


class A23ReconciliationAccessTests(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.A20AcceptanceOrderTests(
            "test_action_reconciliation_classifies_committed_missing_and_conflict"
        )
        self.fixture.setUp()
        self.core = self.fixture.core
        self.author = self.fixture.author
        self.reviewer = self.fixture.reviewer
        acceptance = dict(self.fixture.acceptance)
        acceptance.pop("verification_mode")
        self.acceptance_request = self.request(
            "quote.acceptance.verify", "a23.acceptance", acceptance
        )
        accepted = self.core.execute(self.reviewer, self.acceptance_request)
        self.assertTrue(accepted["ok"], accepted)
        self.prepare_request = self.request(
            "order.prepare",
            "a23.prepare",
            {
                "quote_id": "quote.a20",
                "business_revision": 1,
                "business_hash": self.fixture.business_hash,
                "acceptance_id": "acceptance.a20",
                "conversion_slot": "full_v1",
            },
        )
        self.prepared = self.core.execute(self.author, self.prepare_request)
        self.assertTrue(self.prepared["ok"], self.prepared)
        self.order_id = self.prepared["result"]["order_id"]
        self.activate_request = self.request(
            "order.activate",
            "a23.activate",
            {
                "order_id": self.order_id,
                "expected_row_version": 1,
                "approval_id": "approval.a20",
                "order_review_id": approve_order(self.core, self.author, self.reviewer, self.order_id),
            },
        )

    def tearDown(self):
        self.fixture.tearDown()

    @staticmethod
    def request(command, key, args):
        return {
            "contract": "brant.quotation/0.1.0",
            "command": command,
            "idempotency_key": key,
            "args": args,
        }

    @staticmethod
    def query(request, *, conflict=False):
        return {
            "contract": "brant.quotation/0.1.0",
            "kind": "action_reconciliation",
            "args": {
                "command": request["command"],
                "idempotency_key": request["idempotency_key"],
                "request_hash": "0" * 64
                if conflict
                else hashlib.sha256(canonical(request).encode("utf-8")).hexdigest(),
            },
        }

    def reader(
        self, name, grants=("quote.read", "read"), *, scope=None, data_scope="company", team_id=None
    ):
        reader = Principal(*(scope or self.author.scope), name)
        self.core.provision(reader, list(grants), data_scope=data_scope, team_id=team_id)
        return reader

    def reconcile(self, who, request, *, conflict=False):
        response = self.core.execute(who, self.query(request, conflict=conflict))
        t03_query.RESPONSE_VALIDATOR.validate(response)
        return response

    def assert_denied(self, who, request, code, *, conflict=False):
        result = self.reconcile(who, request, conflict=conflict)
        self.assertEqual(result, {"ok": False, "kind": "action_reconciliation", "code": code})

    def test_business_read_permission_is_required_for_order_and_acceptance_receipts(self):
        activated = self.core.execute(self.author, self.activate_request)
        self.assertTrue(activated["ok"], activated)
        reader = self.reader("quote-only", grants=("quote.read",))
        for request in (self.acceptance_request, self.prepare_request, self.activate_request):
            for conflict in (False, True):
                with self.subTest(command=request["command"], conflict=conflict):
                    self.assert_denied(reader, request, "PERMISSION_DENIED", conflict=conflict)

    def test_readers_can_recover_receipts_without_write_grants(self):
        self.assertTrue(self.core.execute(self.author, self.activate_request)["ok"])
        reader = self.reader("read-only")
        for request in (self.acceptance_request, self.prepare_request, self.activate_request):
            result = self.reconcile(reader, request)
            self.assertEqual(result["value"]["state"], "committed")
            self.assertEqual(result["value"]["result"]["command"], request["command"])
            conflict = self.reconcile(reader, request, conflict=True)
            self.assertEqual(conflict["value"]["state"], "payload_conflict")
            self.assertIsNone(conflict["value"]["result"])

    def test_own_team_company_scope_applies_to_committed_and_conflicting_receipts(self):
        self.assertTrue(self.core.execute(self.author, self.activate_request)["ok"])
        owner = self.reader("author", data_scope="own", team_id="trade")
        teammate = self.reader("teammate", data_scope="team", team_id="trade")
        company = self.reader("company-reader")
        outsider = self.reader("outsider", data_scope="own", team_id="trade")
        other_team = self.reader("other-team", data_scope="team", team_id="other")
        for request in (self.acceptance_request, self.prepare_request, self.activate_request):
            for conflict in (False, True):
                for allowed in (owner, teammate, company):
                    self.assertTrue(self.reconcile(allowed, request, conflict=conflict)["ok"])
                for denied in (outsider, other_team):
                    self.assert_denied(denied, request, "NOT_FOUND", conflict=conflict)

    def test_revoked_grants_and_team_changes_apply_after_reopening(self):
        reader = self.reader("revocable", data_scope="team", team_id="trade")
        self.assertTrue(self.reconcile(reader, self.prepare_request)["ok"])
        self.core.provision(reader, ["quote.read"], data_scope="team", team_id="trade")
        self.core = Core(self.core.path, enable_t03=True)
        self.assert_denied(reader, self.prepare_request, "PERMISSION_DENIED")
        self.core.provision(reader, ["quote.read", "read"], data_scope="team", team_id="other")
        self.assert_denied(reader, self.prepare_request, "NOT_FOUND", conflict=True)
        self.core.provision(reader, ["read"], data_scope="company")
        self.assert_denied(reader, self.prepare_request, "PERMISSION_DENIED")

    def test_company_and_tenant_boundaries_do_not_reveal_another_ledger(self):
        for scope in (
            (self.author.scope[0], "other.company"),
            ("other.tenant", self.author.scope[1]),
        ):
            reader = self.reader("reader", scope=scope)
            for conflict in (False, True):
                value = self.reconcile(reader, self.prepare_request, conflict=conflict)["value"]
                self.assertEqual(value["state"], "not_committed")
                for key in ("action_id", "object_id", "result"):
                    self.assertIsNone(value[key])

    def test_unknown_command_is_rejected_by_both_request_schemas(self):
        root = Path(__file__).parents[1]
        from jsonschema import Draft202012Validator

        for command in ("order.unknown", "quote.unknown", "order.prepare\n"):
            query = self.query(self.prepare_request)
            query["args"]["command"] = command
            for path in (
                "brant_core/contracts/T03_queries.schema.json",
                "t03_candidate/contracts/queries.schema.json",
            ):
                validator = Draft202012Validator(json.loads((root / path).read_text()))
                self.assertFalse(validator.is_valid(query), (path, command))
            response = self.core.execute(self.author, query)
            self.assertEqual(response["code"], "SCHEMA_INVALID")

    def test_committed_schema_rejects_unknown_result_fields_and_inconsistent_states(self):
        response = self.reconcile(self.author, self.prepare_request)
        self.assertTrue(response["ok"], response)
        malformed = copy.deepcopy(response)
        malformed["value"]["result"]["result"]["secret_internal_payload"] = "hidden"
        self.assertFalse(t03_query.RESPONSE_VALIDATOR.is_valid(malformed))
        malformed = copy.deepcopy(response)
        malformed["value"]["state"] = "not_committed"
        self.assertFalse(t03_query.RESPONSE_VALIDATOR.is_valid(malformed))
        malformed = copy.deepcopy(response)
        malformed["value"]["command"] = "order.activate"
        self.assertFalse(t03_query.RESPONSE_VALIDATOR.is_valid(malformed))

    def test_invalid_stored_receipts_fail_closed_instead_of_appearing_committed(self):
        original = copy.deepcopy(self.prepared)
        variants = []
        changed = copy.deepcopy(original)
        changed["result"]["secret_internal_payload"] = "hidden"
        variants.append(changed)
        changed = copy.deepcopy(original)
        changed["command"] = "order.activate"
        variants.append(changed)
        changed = copy.deepcopy(original)
        changed["action_id"] = "wrong-action"
        variants.append(changed)
        variants.extend(([], {"ok": True}))
        for receipt in variants:
            with self.subTest(receipt=receipt):
                with sqlite3.connect(self.core.path) as db:
                    db.execute(
                        "UPDATE action_result SET result_json=? WHERE command=? AND idempotency_key=?",
                        (canonical(receipt), "order.prepare", "a23.prepare"),
                    )
                self.assert_denied(self.author, self.prepare_request, "REFERENCE_INVALID")
                self.assert_denied(
                    self.author, self.prepare_request, "REFERENCE_INVALID", conflict=True
                )

    def test_reconciliation_is_observational_and_audited(self):
        def business_snapshot():
            with sqlite3.connect(self.core.path) as db:
                tables = [
                    row[0]
                    for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")
                    if row[0] != "audit_event"
                ]
                return {
                    name: db.execute('SELECT * FROM "' + name.replace('"', '""') + '"').fetchall()
                    for name in tables
                    if name != "sqlite_sequence"
                }

        before = business_snapshot()
        with sqlite3.connect(self.core.path) as db:
            audit_before = db.execute("SELECT count(*) FROM audit_event").fetchone()[0]
        for conflict in (False, True):
            self.assertTrue(
                self.reconcile(self.author, self.prepare_request, conflict=conflict)["ok"]
            )
        self.assertEqual(business_snapshot(), before)
        with sqlite3.connect(self.core.path) as db:
            audits = db.execute(
                "SELECT command,outcome,object_id FROM audit_event ORDER BY seq"
            ).fetchall()
        self.assertEqual(len(audits), audit_before + 2)
        self.assertEqual(
            audits[-2:], [("quote.query.action_reconciliation", "read", self.order_id)] * 2
        )

    def test_commit_then_process_exit_recovers_public_action_and_replays_once(self):
        script = "\n".join(
            [
                "import json, os, sys",
                "from datetime import UTC, datetime",
                "from brant_core import Core, Principal",
                "core = Core(sys.argv[1], enable_t03=True, clock=lambda: datetime(2026,10,22,12,tzinfo=UTC))",
                "result = core.execute(Principal('tenant.live','company.live','author'), json.loads(sys.argv[2]))",
                "os._exit(73 if result['ok'] else 74)",
            ]
        )
        child = subprocess.run(
            [sys.executable, "-c", script, str(self.core.path), canonical(self.activate_request)],
            capture_output=True,
            text=True,
            cwd=Path(__file__).parents[1],
            timeout=30,
        )
        self.assertEqual(child.returncode, 73, child.stderr)
        self.core = Core(self.core.path, enable_t03=True)
        value = self.reconcile(self.author, self.activate_request)["value"]
        self.assertEqual(value["state"], "committed")
        replay = self.core.execute(self.author, self.activate_request)
        self.assertTrue(replay["replayed"], replay)
        self.assertEqual(replay["action_id"], value["action_id"])
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(
                db.execute(
                    "SELECT count(*) FROM t03_order_event WHERE event_type='activated'"
                ).fetchone()[0],
                1,
            )

    def test_public_receipt_insert_failure_rolls_back_activation_then_same_key_recovers(self):
        with sqlite3.connect(self.core.path) as db:
            db.execute(
                "CREATE TRIGGER a23_failure BEFORE INSERT ON action_result "
                "WHEN NEW.command='order.activate' BEGIN SELECT RAISE(ABORT,'a23 ledger failure'); END"
            )
        with self.assertRaises(sqlite3.IntegrityError):
            self.core.execute(self.author, self.activate_request)
        self.assertEqual(
            self.reconcile(self.author, self.activate_request)["value"]["state"], "not_committed"
        )
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(db.execute("SELECT status FROM t03_order").fetchone()[0], "draft")
            self.assertEqual(
                db.execute(
                    "SELECT count(*) FROM t03_order_event WHERE event_type='activated'"
                ).fetchone()[0],
                0,
            )
            db.execute("DROP TRIGGER a23_failure")
        retried = self.core.execute(self.author, self.activate_request)
        self.assertTrue(retried["ok"], retried)
        self.assertEqual(
            self.reconcile(self.author, self.activate_request)["value"]["state"], "committed"
        )

    def test_runtime_and_candidate_query_schemas_match(self):
        root = Path(__file__).parents[1]
        for runtime, candidate in (
            ("T03_queries.schema.json", "queries.schema.json"),
            ("T03_query-responses.schema.json", "query-responses.schema.json"),
        ):
            self.assertEqual(
                json.loads((root / "brant_core/contracts" / runtime).read_text()),
                json.loads((root / "t03_candidate/contracts" / candidate).read_text()),
            )

    def test_bound_root_allows_observation_but_blocks_another_write_replay(self):
        self.core.t03_bind_object_control(self.author, "quote_root", "quote.a20", "server.task.a23")
        self.assertEqual(
            self.reconcile(self.author, self.prepare_request)["value"]["state"], "committed"
        )
        replay = self.core.execute(self.author, self.prepare_request)
        self.assertEqual(replay["code"], "OBJECT_CONTROL_CONFLICT")
        self.assertEqual(
            self.reconcile(self.author, self.prepare_request, conflict=True)["value"]["state"],
            "payload_conflict",
        )
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM t03_order").fetchone()[0], 1)

    def test_quote_metadata_receipts_keep_quote_read_scope_without_business_write_grants(self):
        request = self.request(
            "quote.save_draft",
            "a23.quote.metadata",
            {
                "quote_id": "quote.a23.metadata",
                "expected_root_version": 0,
                "data": {},
            },
        )
        receipt = self.core.execute(self.author, request)
        self.assertTrue(receipt["ok"], receipt)
        reader = self.reader("metadata-reader", grants=("quote.read",))
        self.assertEqual(self.reconcile(reader, request)["value"]["result"], receipt)
        mapping = json.loads(
            (
                Path(__file__).parents[1]
                / "t03_candidate/contracts/reconciliation-authority-mapping-v0.27.json"
            ).read_text()
        )
        self.assertEqual(
            {k: tuple(v["read_permissions"]) for k, v in mapping["commands"].items()},
            t03_reconciliation.READ_PERMISSIONS,
        )

    def test_missing_order_source_fails_closed_for_matching_and_conflicting_receipts(self):
        changed = copy.deepcopy(self.prepared)
        changed["result"]["order_id"] = "order.not.present"
        with sqlite3.connect(self.core.path) as db:
            db.execute(
                "UPDATE action_result SET result_json=? WHERE command=? AND idempotency_key=?",
                (canonical(changed), "order.prepare", "a23.prepare"),
            )
        self.assert_denied(self.author, self.prepare_request, "REFERENCE_INVALID")
        self.assert_denied(self.author, self.prepare_request, "REFERENCE_INVALID", conflict=True)
