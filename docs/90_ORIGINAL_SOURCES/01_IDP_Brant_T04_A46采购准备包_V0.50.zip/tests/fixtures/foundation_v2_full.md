# 非空版本 2 迁移样本

foundation_v2_full.sql 为全合成数据，由提交 161c9ec 的 0.2.0 程序生成。
使用旧版 `uv run --frozen python -m brant_core foundation-demo --directory 新目录`，
随后以旧版 execute-local 调用 foundation 契约的 master.revise（customer，expected_version=2）。
通过 SQLite iterdump 导出；没有由当前版 Core 先创建迁移 3 再伪装为旧库。

含 22 份配置／18 类配置、银行账户测试值、原文及生成文件、编号、基础快照、
主数据历史、原成功动作、Outbox、身份／归属和审计。
日期、金额、账户、税率及汇率仅为合成演示资料，非真实企业或市场数据。

测试仅把该受版本控制的 SQL 装入全新临时空库，并在升级前后逐表比较。
不得把该 SQL 当作用户数据库的修复或导入脚本。
