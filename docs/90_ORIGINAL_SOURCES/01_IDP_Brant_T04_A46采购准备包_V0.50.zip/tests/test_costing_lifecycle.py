"""All declared command branches exercised against a restarted SQLite service."""

import json
import tempfile
import unittest
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path

from costing_fixture import TradeFixture

from brant_core import Core, Principal


class PersistentLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name, "business.sqlite")
        self.clock = lambda: datetime(2026, 10, 22, 9, tzinfo=UTC)
        self.core = Core(self.path, clock=self.clock)
        self.author = Principal("tenant.live", "company.live", "author")
        self.reviewer = Principal("tenant.live", "company.live", "reviewer")
        for who in (self.author, self.reviewer):
            self.core.provision(who, ["*"], team_id="trade", data_scope="company")
        self.fixture = TradeFixture(self.core).prepare()
        self.seen = set()
        self.n = 0
        self.evidence = [{"source_id": "source.1", "locator": "合成生命周期依据"}]

    def call(self, command, args, who=None, contract="brant.costing/0.1.0"):
        self.n += 1
        who = who or self.author
        request = {
            "contract": contract,
            "command": command,
            "args": deepcopy(args),
            "idempotency_key": f"matrix.{self.n}",
        }
        self.check_before_command(who, request)
        result = Core(self.path, clock=self.clock).execute(who, request)
        self.assertTrue(result["ok"], (command, args, result))
        self.assertFalse(result["replayed"])
        replay = Core(self.path, clock=self.clock).execute(who, request)
        self.assertEqual(replay, {**result, "replayed": True})
        self.check_after_command(who, request, result)
        self.seen.add((command, args["kind"]) if contract.endswith("extension/0.1.0") else command)
        return result

    def check_before_command(self, who, request):
        """Failure-matrix subclasses exercise the same public command traces."""

    def check_after_command(self, who, request, result):
        """Keep the successful lifecycle assertions shared across both matrices."""

    def lifecycle(self, kind, data, extension=False):
        id_ = "matrix." + kind
        contract = "brant.foundation-extension/0.1.0" if extension else "brant.costing/0.1.0"
        prefix = "foundation_extension" if extension else kind
        common = {"kind": kind, "id": id_} if extension else {"id": id_}

        def call(action, args, who=None):
            return self.call(prefix + "." + action, {**common, **args}, who, contract)

        seal = "publish" if extension or kind == "purchase_terms" else "verify"
        retire = "retire" if extension or kind == "purchase_terms" else "withdraw"
        call("save_draft", {"expected_version": 0, "data": data})
        call(
            seal,
            {"expected_version": 1, "working_revision": 1, "evidence": self.evidence},
            self.reviewer,
        )
        call("revise", {"expected_version": 2, "base_revision": 1, "reason": "修订测试"})
        call(
            "discard_draft",
            {"expected_version": 3, "working_revision": 2, "reason": "丢弃未完成修订"},
        )
        call("revise", {"expected_version": 4, "base_revision": 1, "reason": "重新修订"})
        call("save_draft", {"expected_version": 5, "data": data})
        latest = call(
            seal,
            {
                "expected_version": 6,
                "working_revision": 3,
                "supersedes_revision": 1,
                "evidence": self.evidence,
            },
            self.reviewer,
        )
        old = call(
            retire,
            {
                "expected_version": 7,
                "target_revision": 1,
                "reason": "撤销旧修订",
                "evidence": self.evidence,
            },
            self.reviewer,
        )
        if extension:
            self.assertEqual(
                (latest["root_version"], old["root_version"], old["active_revision"]), (7, 8, 3)
            )
        else:
            self.assertEqual(
                (latest["row_version"], old["row_version"], old["result"]["active_revision"]),
                (7, 8, 3),
            )
            saved = Core(self.path, clock=self.clock).costing_get(self.author, kind, id_)
            self.assertEqual(
                (saved["root_version"], saved["revision"], saved["data"]), (8, 3, data)
            )

    def test_all_35_costing_commands_persist_and_replay(self):
        for kind, id_ in [
            ("costing_context", "context.1"),
            ("supplier_offer", "offer.1"),
            ("service_party_role", "provider.role"),
            ("logistics_offer", "log.1"),
        ]:
            data = self.core.costing_get(self.author, kind, id_)["data"]
            self.lifecycle(kind, data)
        offer = self.core.costing_get(self.author, "supplier_offer", "offer.1")["data"]
        terms = {k: deepcopy(offer[k]) for k in ("supplier_ref", "interval", "lines", "evidence")}
        terms.update(
            source_offer_ref={"kind": "supplier_offer", "id": "offer.1", "revision": 1},
            validity_mode="independent_validity",
        )
        self.lifecycle("purchase_terms", terms)
        self.call(
            "supplier_rfq.save_draft",
            {
                "id": "request.1",
                "expected_version": 0,
                "data": {
                    "supplier_ref": offer["supplier_ref"],
                    "rfq_ref": offer["rfq_ref"],
                    "rfq_line_ids": ["L1"],
                    "evidence": self.evidence,
                },
            },
        )
        for action, version in (("record_issued", 1), ("close", 2)):
            result = self.call(
                "supplier_rfq." + action,
                {
                    "id": "request.1",
                    "expected_version": version,
                    "reason": "人工处理合成询价",
                    "evidence": self.evidence,
                },
                self.reviewer,
            )
            self.assertEqual(result["row_version"], version + 1)
        inputs = json.loads((Path(__file__).parent / "fixtures/costing_inputs.json").read_text())
        measurement = next(
            r["args"]["data"] for r in inputs if r["command"] == "measurement.record_verified"
        )
        self.call(
            "measurement.record_verified",
            {"id": "measurement.1", "expected_version": 0, "data": measurement},
            self.reviewer,
        )
        self.call(
            "measurement.supersede",
            {
                "id": "measurement.1",
                "expected_version": 1,
                "active_revision": 1,
                "data": measurement,
                "reason": "重新实测",
            },
            self.reviewer,
        )
        result = self.call(
            "measurement.withdraw",
            {
                "id": "measurement.1",
                "expected_version": 2,
                "target_revision": 1,
                "reason": "撤销旧实测",
                "evidence": self.evidence,
            },
            self.reviewer,
        )
        self.assertEqual(result["result"]["active_revision"], 2)
        scenario = self.core.costing_get(self.author, "cost_scenario", "scenario.1")["data"]
        self.call(
            "cost_scenario.save_draft",
            {"id": "scenario.1", "expected_version": 1, "data": scenario},
        )
        result = self.call(
            "cost_scenario.evaluate", {"id": "scenario.1", "expected_version": 2}, self.reviewer
        )
        self.assertEqual(result["result"]["total_minor"], "66000")
        args = self.fixture.freeze_request(result)["args"]
        args["expected_version"] = 2
        frozen = self.call("cost_snapshot.freeze", args, self.reviewer)
        self.assertTrue(
            self.core.costing_get(self.reviewer, "snapshot_query", frozen["result"]["id"])[
                "currently_eligible_for_quote"
            ]
        )
        self.call(
            "source_denial.record",
            {
                "id": "denial.matrix",
                "source_id": "source.2",
                "reason": "反证记录",
                "evidence": self.evidence,
            },
            self.reviewer,
        )
        schema = json.loads(
            (
                Path(__file__).resolve().parents[1]
                / "brant_core/costing_engine/contracts/commands.schema.json"
            ).read_text()
        )
        expected = {b["properties"]["command"]["const"] for b in schema["oneOf"]}
        self.assertEqual(self.seen, expected)
        self.assertEqual(len(self.seen), 35)

    def test_all_25_extension_branches_persist_and_replay(self):
        inputs = json.loads((Path(__file__).parent / "fixtures/extension_inputs.json").read_text())
        for item in inputs:
            data = deepcopy(item["data"])
            if item["kind"] == "tax_application":
                data["counterparty_ref"]["row_version"] = 2
            self.lifecycle(item["kind"], data, extension=True)
        schema = json.loads(
            (
                Path(__file__).resolve().parents[1]
                / "brant_core/costing_engine/contracts/foundation-extension.commands.schema.json"
            ).read_text()
        )
        expected = {
            (
                b["properties"]["command"]["const"],
                b["properties"]["args"]["properties"]["kind"]["const"],
            )
            for b in schema["oneOf"]
        }
        self.assertEqual(self.seen, expected)
        self.assertEqual(len(self.seen), 25)
