"""Current adoption decisions through the existing public read boundary."""

import json
import sqlite3
import tempfile
import unittest
from datetime import UTC, datetime
from pathlib import Path

from costing_fixture import TradeFixture
from jsonschema import Draft202012Validator

from brant_core import Core, Principal
from brant_core.common import Rejected


class SnapshotQueryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name, "business.sqlite")
        self.now = datetime(2026, 10, 22, 9, tzinfo=UTC)
        self.clock = lambda: self.now
        self.core = Core(self.path, clock=self.clock)
        self.author = Principal("tenant.live", "company.live", "author")
        self.reviewer = Principal("tenant.live", "company.live", "reviewer")
        for who in (self.author, self.reviewer):
            self.core.provision(who, ["*"], team_id="trade", data_scope="company")
        self.fixture = TradeFixture(self.core).prepare()
        evaluation = self.fixture.evaluate()
        frozen = self.core.execute(self.reviewer, self.fixture.freeze_request(evaluation))
        self.assertTrue(frozen["ok"], frozen)
        self.snapshot = frozen["result"]

    def test_query_uses_current_clock_and_preserves_immutable_snapshot(self):
        self.now = datetime(2026, 10, 23, 10, tzinfo=UTC)
        reopened = Core(self.path, clock=self.clock)
        query = reopened.costing_get(self.reviewer, "snapshot_query", self.snapshot["id"])
        self.assertTrue(query["currently_eligible_for_quote"])
        self.assertEqual(query["eligibility_checked_at"], "2026-10-23T10:00:00Z")
        self.assertEqual(query["snapshot"], self.snapshot)
        schema = json.loads(
            (
                Path(__file__).resolve().parents[1]
                / "brant_core/costing_engine/contracts/query.schema.json"
            ).read_text()
        )
        Draft202012Validator(schema).validate(query)
        self.assertEqual(
            reopened.costing_get(self.reviewer, "snapshot", self.snapshot["id"]), self.snapshot
        )

    def assert_ineligible_with_history(self):
        reopened = Core(self.path, clock=self.clock)
        query = reopened.costing_get(self.reviewer, "snapshot_query", self.snapshot["id"])
        self.assertFalse(query["currently_eligible_for_quote"])
        self.assertEqual(query["snapshot"], self.snapshot)
        self.assertEqual(
            reopened.costing_get(self.reviewer, "snapshot", self.snapshot["id"]), self.snapshot
        )

    def test_source_denial_changes_eligibility_without_rewriting_history(self):
        self.fixture.call(
            "brant.costing/0.1.0",
            "source_denial.record",
            {
                "id": "denial.query",
                "source_id": "source.1",
                "reason": "新反证确认原资料不能继续采用",
                "evidence": [{"source_id": "source.2", "locator": "反证资料"}],
            },
            self.reviewer,
        )
        self.assert_ineligible_with_history()

    def test_expiration_at_exclusive_upper_bound_blocks_adoption(self):
        self.now = datetime(2026, 10, 29, tzinfo=UTC)
        self.assert_ineligible_with_history()

    def test_withdrawn_input_blocks_adoption(self):
        self.fixture.call(
            "brant.costing/0.1.0",
            "costing_context.withdraw",
            {
                "id": "context.1",
                "expected_version": 2,
                "target_revision": 1,
                "reason": "原询价范围已经撤销",
                "evidence": [{"source_id": "source.2", "locator": "撤销通知"}],
            },
            self.reviewer,
        )
        self.assert_ineligible_with_history()

    def test_retired_policy_blocks_adoption(self):
        self.fixture.call(
            "brant.foundation/0.1.0",
            "foundation.retire",
            {
                "id": "policy.1",
                "kind": "pricing_policy",
                "expected_version": 2,
                "reason": "规则停止采用",
            },
            self.reviewer,
        )
        self.assert_ineligible_with_history()

    def test_permissions_are_rejected_instead_of_returning_a_business_false(self):
        self.core.provision(self.reviewer, ["*"], team_id="other", data_scope="own")
        with self.assertRaises(Rejected) as caught:
            self.core.costing_get(self.reviewer, "snapshot_query", self.snapshot["id"])
        self.assertEqual(caught.exception.code, "PERMISSION_DENIED")

    def test_evaluation_cannot_be_queried_as_a_frozen_snapshot(self):
        with self.assertRaises(Rejected) as caught:
            self.core.costing_get(self.reviewer, "snapshot_query", self.snapshot["evaluation_id"])
        self.assertEqual(caught.exception.code, "NOT_FOUND")

    def test_unpublished_revision_does_not_remove_current_eligibility(self):
        self.fixture.call(
            "brant.costing/0.1.0",
            "costing_context.revise",
            {
                "id": "context.1",
                "expected_version": 2,
                "base_revision": 1,
                "reason": "新稿尚未核实，旧版继续有效",
            },
        )
        query = self.core.costing_get(self.reviewer, "snapshot_query", self.snapshot["id"])
        self.assertTrue(query["currently_eligible_for_quote"])
        self.assertEqual(query["snapshot"], self.snapshot)

    def test_replacement_revision_invalidates_old_snapshot_adoption(self):
        self.fixture.call(
            "brant.costing/0.1.0",
            "costing_context.revise",
            {
                "id": "context.1",
                "expected_version": 2,
                "base_revision": 1,
                "reason": "重新核实询价范围",
            },
        )
        self.fixture.call(
            "brant.costing/0.1.0",
            "costing_context.verify",
            {
                "id": "context.1",
                "expected_version": 3,
                "working_revision": 2,
                "supersedes_revision": 1,
                "evidence": [{"source_id": "source.1", "locator": "重新核实"}],
            },
            self.reviewer,
        )
        self.assert_ineligible_with_history()

    def test_revised_supplier_master_blocks_adoption(self):
        self.fixture.call(
            "brant.foundation/0.1.0",
            "master.revise",
            {"id": "supplier.1", "expected_version": 2, "reason": "供应商资料待重新核实"},
        )
        self.assert_ineligible_with_history()

    def test_loader_budget_is_an_error_not_business_ineligibility(self):
        # Bulk capacity setup at the documented SQLite file-format boundary.
        # Rows have valid scope, source and actor references; no rule is mocked.
        with sqlite3.connect(self.path) as db:
            db.execute("PRAGMA foreign_keys=ON")
            db.executemany(
                "INSERT INTO t02_source_attestation VALUES(?,?,?,?,?,?,?)",
                [
                    (
                        *self.reviewer.scope,
                        f"capacity.{i}",
                        "source.1",
                        self.reviewer.actor,
                        "2026-10-22T09:00:00Z",
                        "容量边界测试确认",
                    )
                    for i in range(5001)
                ],
            )
        with self.assertRaises(Rejected) as caught:
            self.core.costing_get(self.reviewer, "snapshot_query", self.snapshot["id"])
        self.assertEqual(caught.exception.code, "CALCULATION_LIMIT_EXCEEDED")

    def test_sqlite_backup_restores_snapshot_and_successful_action_replay(self):
        backup = Path(self.temp.name, "checkpoint.sqlite")
        restored = Path(self.temp.name, "restored.sqlite")
        with sqlite3.connect(self.path) as source, sqlite3.connect(backup) as target:
            source.backup(target)
        self.fixture.call(
            "brant.costing/0.1.0",
            "cost_scenario.save_draft",
            {
                "id": "after.backup",
                "expected_version": 0,
                "data": {},
            },
        )
        with sqlite3.connect(backup) as source, sqlite3.connect(restored) as target:
            source.backup(target)
        recovered = Core(restored, clock=self.clock)
        query = recovered.costing_get(self.reviewer, "snapshot_query", self.snapshot["id"])
        self.assertTrue(query["currently_eligible_for_quote"])
        self.assertEqual(query["snapshot"], self.snapshot)
        with self.assertRaises(Rejected):
            recovered.costing_get(self.reviewer, "cost_scenario", "after.backup")
        evaluation = {
            "result": {"id": self.snapshot["evaluation_id"]},
            "result_hash": self.snapshot["result_hash"],
        }
        replay = recovered.execute(self.reviewer, self.fixture.freeze_request(evaluation))
        self.assertTrue(replay["ok"], replay)
        self.assertTrue(replay["replayed"])
        self.assertEqual(replay["result"], self.snapshot)
        with sqlite3.connect(restored) as db:
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchall(), [("ok",)])
            self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])
