"""SQLite format migration and recovery, using disposable databases only."""

import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from brant_core import Core, Principal
from brant_core.foundation_storage import migrate as foundation_migrate
from brant_core.service import SCHEMAS
from brant_core.storage import initialize


def database_contents(path):
    with sqlite3.connect(path) as db:
        schema = db.execute(
            "SELECT type,name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name"
        ).fetchall()
        data = {
            name: db.execute('SELECT * FROM "' + name + '" ORDER BY rowid').fetchall()
            for kind, name, _ in schema
            if kind == "table"
        }
        return schema, data


class CostingMigrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name, "v2.sqlite")
        # Build the documented pre-T02 file format, including its original audit.
        with sqlite3.connect(self.path, isolation_level=None) as db:
            initialize(db, SCHEMAS / "BC_T01_reference.sql")
            db.execute("INSERT INTO scope VALUES('t','c')")
            db.execute("INSERT INTO authorization VALUES('t','c','owner','[\"*\"]','human')")
            db.execute("INSERT INTO rfq VALUES('t','c','old',NULL,NULL,'draft',1,'[]')")
            db.execute(
                "INSERT INTO audit_event(tenant,company,actor,event_id,command,object_id,outcome,code,correlation_id,recorded_at,reason) VALUES('t','c','owner','e','rfq.save_draft','old','succeeded',NULL,'trace','2026-10-21T00:00:00Z',NULL)"
            )
            foundation_migrate(db)
        self.owner = Principal("t", "c", "owner")

    def test_v2_upgrade_preserves_every_existing_table_and_is_repeatable(self):
        old_schema, old_data = database_contents(self.path)
        Core(self.path)
        schema, data = database_contents(self.path)
        self.assertTrue(set(old_schema) <= set(schema))
        for name, rows in old_data.items():
            if name != "schema_migration":
                self.assertEqual(data[name], rows, name)
        self.assertEqual([r[0] for r in data["schema_migration"]], [1, 2, 3])
        Core(self.path)
        self.assertEqual(database_contents(self.path), (schema, data))
        self.assertEqual(Core(self.path).get(self.owner, "rfq", "old")["row_version"], 1)

    def test_late_ddl_failure_rolls_back_schema_and_data_then_retry_succeeds(self):
        # A conflicting late table forces failure after many earlier DDL statements.
        with sqlite3.connect(self.path) as db:
            db.execute("CREATE TABLE t02_command_event(sentinel TEXT)")
            db.execute("INSERT INTO t02_command_event VALUES('preserve this preexisting object')")
        before = database_contents(self.path)
        with self.assertRaises(sqlite3.OperationalError):
            Core(self.path)
        self.assertEqual(database_contents(self.path), before)
        # Remove only the deliberately injected object in this temporary fixture.
        with sqlite3.connect(self.path) as db:
            db.execute("DROP TABLE t02_command_event")
        self.assertEqual(Core(self.path).get(self.owner, "rfq", "old")["status"], "draft")

    def test_unknown_migration_history_is_rejected_without_changes(self):
        with sqlite3.connect(self.path) as db:
            db.execute("INSERT INTO schema_migration VALUES(99,'2026-10-22T00:00:00Z')")
        before = database_contents(self.path)
        with self.assertRaises(RuntimeError):
            Core(self.path)
        self.assertEqual(database_contents(self.path), before)

    def test_parallel_upgrade_produces_one_complete_schema(self):
        with ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(lambda _: Core(self.path), range(2)))
        with sqlite3.connect(self.path) as db:
            self.assertEqual(
                db.execute("SELECT version FROM schema_migration ORDER BY version").fetchall(),
                [(1,), (2,), (3,)],
            )
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchall(), [("ok",)])
            self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])
        self.assertEqual(Core(self.path).get(self.owner, "rfq", "old")["row_version"], 1)

    def test_pre_upgrade_backup_can_be_restored_and_upgraded(self):
        backup = Path(self.temp.name, "backup.sqlite")
        restored = Path(self.temp.name, "restored.sqlite")
        before = database_contents(self.path)
        with sqlite3.connect(self.path) as source, sqlite3.connect(backup) as target:
            source.backup(target)
        Core(self.path)
        with sqlite3.connect(backup) as source, sqlite3.connect(restored) as target:
            source.backup(target)
        self.assertEqual(database_contents(restored), before)
        self.assertEqual(Core(restored).get(self.owner, "rfq", "old")["row_version"], 1)

    def rich_database(self):
        path = Path(self.temp.name, "full-v2.sqlite")
        with sqlite3.connect(path) as db:
            db.executescript(
                (Path(__file__).parent / "fixtures/foundation_v2_full.sql").read_text()
            )
            self.assertEqual(
                db.execute("SELECT version FROM schema_migration ORDER BY version").fetchall(),
                [(1,), (2,)],
            )
            for table in (
                "foundation_revision",
                "foundation_snapshot",
                "business_file",
                "document_number",
                "master_history",
                "action_result",
                "outbox",
                "audit_event",
            ):
                self.assertGreater(
                    db.execute("SELECT count(*) FROM " + table).fetchone()[0], 0, table
                )
        return path

    def test_nonempty_v2_foundation_files_numbers_history_and_actions_are_preserved(self):
        path = self.rich_database()
        old_schema, before = database_contents(path)
        core = Core(path)
        schema, after = database_contents(path)
        self.assertTrue(set(old_schema) <= set(schema))
        for table, rows in before.items():
            if table != "schema_migration":
                self.assertEqual(after[table], rows, table)
        who = Principal("tenant.demo", "company.demo", "editor")
        self.assertEqual(
            core.foundation_get(who, "master_history", "customer", 2)["status"], "confirmed"
        )
        self.assertEqual(
            core.foundation_get(who, "file", "original.file")["file_name"], "original.txt"
        )
        with sqlite3.connect(path) as db:
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchall(), [("ok",)])
            self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])

    def test_nonempty_v2_failure_rolls_back_every_existing_record(self):
        path = self.rich_database()
        with sqlite3.connect(path) as db:
            db.execute("CREATE TABLE t02_command_event(sentinel TEXT)")
        before = database_contents(path)
        with self.assertRaises(sqlite3.OperationalError):
            Core(path)
        self.assertEqual(database_contents(path), before)
