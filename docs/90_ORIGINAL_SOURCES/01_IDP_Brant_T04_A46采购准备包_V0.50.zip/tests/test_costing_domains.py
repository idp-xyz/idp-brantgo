"""Cost-domain behavior through current Core commands and a real SQLite store."""

import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path

import test_costing_failures as failures
from costing_fixture import TradeFixture

from brant_core import Core, Principal
from brant_core.common import Rejected


def ref(kind, id_):
    return {"kind": kind, "id": id_, "revision": 1}


class DomainCostingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name, "business.sqlite")
        self.clock = lambda: datetime(2026, 10, 22, 9, tzinfo=UTC)
        self.core = Core(self.path, clock=self.clock)
        self.author = Principal("tenant.live", "company.live", "author")
        self.reviewer = Principal("tenant.live", "company.live", "reviewer")
        for who in (self.author, self.reviewer):
            self.core.provision(who, ["*"], team_id="trade", data_scope="company")
        self.fixture = TradeFixture(self.core).prepare()
        self.n = 0
        self.scenario_version = 1
        self.domain_coverage = []
        self.evidence = [{"source_id": "source.1", "locator": "合成领域校验依据"}]

    def data(self, kind, id_):
        return self.core.costing_get(self.author, kind, id_)["data"]

    def request(self, command, args):
        self.n += 1
        return {
            "contract": "brant.costing/0.1.0",
            "command": command,
            "idempotency_key": f"domain.check.{self.n}",
            "args": args,
        }

    def reject(self, command, args, code, category, contract="brant.costing/0.1.0"):
        before = failures.store_state(self.path)
        request = self.request(command, args)
        request["contract"] = contract
        result = Core(self.path, clock=self.clock).execute(self.reviewer, request)
        self.assertFalse(result["ok"], result)
        self.assertEqual(result["code"], code, result)
        self.assertEqual(failures.store_state(self.path), before)
        self.domain_coverage.append(
            {
                "test": self.id(),
                "category": category,
                "command": command,
                "observed_code": code,
                "business_store_unchanged": True,
            }
        )
        return result

    def save_input(self, kind, data):
        self.n += 1
        id_ = f"domain.{kind}.{self.n}"
        self.fixture.call(
            "brant.costing/0.1.0",
            kind + ".save_draft",
            {"id": id_, "expected_version": 0, "data": data},
        )
        return id_

    def verify_input(self, kind, data):
        id_ = self.save_input(kind, data)
        self.fixture.call(
            "brant.costing/0.1.0",
            kind + ".verify",
            {"id": id_, "expected_version": 1, "working_revision": 1, "evidence": self.evidence},
            self.reviewer,
        )
        return ref(kind, id_)

    def reject_input(self, kind, data, code, category):
        id_ = self.save_input(kind, data)
        return self.reject(
            kind + ".verify",
            {"id": id_, "expected_version": 1, "working_revision": 1, "evidence": self.evidence},
            code,
            category,
        )

    def scenario(self, offer=None, logistics=None, fx=None, allocation=None):
        data = self.data("cost_scenario", "scenario.1")
        if offer:
            data["allocations"][0]["source"].update(kind="offer", id=offer["id"], revision=1)
        if logistics:
            data["logistics_offer_refs"] = [logistics]
        if fx is not None:
            data["fx_refs"] = fx
        if allocation:
            data["allocations"][0].update(allocation)
        self.fixture.call(
            "brant.costing/0.1.0",
            "cost_scenario.save_draft",
            {"id": "scenario.1", "expected_version": self.scenario_version, "data": data},
        )
        self.scenario_version += 1

    def evaluate(self):
        return self.fixture.call(
            "brant.costing/0.1.0",
            "cost_scenario.evaluate",
            {"id": "scenario.1", "expected_version": self.scenario_version},
            self.reviewer,
        )

    def reject_evaluation(self, code, category):
        return self.reject(
            "cost_scenario.evaluate",
            {"id": "scenario.1", "expected_version": self.scenario_version},
            code,
            category,
        )

    def foreign_offer(self):
        self.fixture.foundation(
            "currency",
            "EUR",
            {"code": "EUR", "name": "合成欧元", "minor_units": 2, "rounding": "HALF_UP"},
        )
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["currency_ref"] = ref("currency", "EUR")
        return self.verify_input("supplier_offer", data)

    def fx(self, **changes):
        data = {
            "from_currency": ref("currency", "EUR"),
            "to_currency": ref("currency", "USD"),
            "rate": "1.1",
            "purpose": "cost_estimate",
            "source_name": "合成汇率依据",
            "observed_at": "2026-10-22T08:50:00Z",
            "valid_from": "2026-10-22T08:50:00Z",
            "valid_until": "2026-10-29T00:00:00Z",
        }
        data.update(changes)
        self.fixture.foundation("fx", "domain.fx", data)
        return ref("fx", "domain.fx")

    def test_missing_cross_currency_fx_is_not_assumed_one(self):
        self.scenario(offer=self.foreign_offer())
        self.reject_evaluation("FX_NOT_APPLICABLE", "fx")

    def test_reverse_fx_is_not_inverted_automatically(self):
        offer = self.foreign_offer()
        fx = self.fx(from_currency=ref("currency", "USD"), to_currency=ref("currency", "EUR"))
        self.scenario(offer=offer, fx=[fx])
        self.reject_evaluation("FX_NOT_APPLICABLE", "fx")

    def test_quotation_fx_cannot_price_cost(self):
        offer = self.foreign_offer()
        fx = self.fx(purpose="quotation")
        self.scenario(offer=offer, fx=[fx])
        self.reject_evaluation("FX_NOT_APPLICABLE", "fx")

    def test_fx_older_than_policy_limit_is_rejected(self):
        offer = self.foreign_offer()
        fx = self.fx(observed_at="2026-10-22T00:00:00Z")
        self.scenario(offer=offer, fx=[fx])
        self.reject_evaluation("FX_NOT_APPLICABLE", "fx")

    def test_explicit_fx_produces_independent_known_cost(self):
        offer = self.foreign_offer()
        self.scenario(offer=offer, fx=[self.fx()])
        self.assertEqual(self.evaluate()["result"]["total_minor"], "72000")

    def test_goods_cannot_reuse_service_tax_application(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["tax_application_ref"] = ref("tax_application", "tax.service")
        self.reject_input("supplier_offer", data, "REFERENCE_INVALID", "tax")

    def test_service_cannot_reuse_goods_tax_application(self):
        data = self.data("logistics_offer", "log.1")
        data["fees"][0]["tax_application_ref"] = ref("tax_application", "tax.goods")
        self.reject_input("logistics_offer", data, "REFERENCE_INVALID", "tax")

    def test_duplicate_fee_obligation_cannot_be_hidden_by_new_id(self):
        data = self.data("logistics_offer", "log.1")
        fee = deepcopy(data["fees"][0])
        fee["id"] = "different.name"
        data["fees"].append(fee)
        self.reject_input("logistics_offer", data, "CHARGE_DOUBLE_COUNT", "fee_inclusion")

    def test_zero_explicit_allocation_weights_are_rejected(self):
        data = self.data("logistics_offer", "log.1")
        data["fees"][0]["allocation"] = {
            "basis": "explicit",
            "weights": [{"line_id": "L1", "weight": "0"}],
        }
        self.reject_input("logistics_offer", data, "ALLOCATION_INVALID", "allocation")

    def test_weight_allocation_requires_measurement(self):
        data = self.data("logistics_offer", "log.1")
        data["fees"][0]["allocation"] = {"basis": "weight", "target_line_ids": ["L1"]}
        self.reject_input("logistics_offer", data, "COST_INPUT_NOT_READY", "measurement")

    def test_fractional_piece_quantity_is_rejected(self):
        self.scenario(allocation={"purchase_quantity": "119.5"})
        self.reject_evaluation("INVALID_KNOWN_VALUE", "unit")

    def test_unexplained_zero_unit_price_is_rejected(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["tiers"][0]["unit_price"] = "0"
        self.reject_input("supplier_offer", data, "COST_INPUT_NOT_READY", "pricing")

    def taxed_offer(self, **changes):
        data = deepcopy(self.core.foundation_get(self.author, "tax_profile", "tax.zero")["data"])
        data.update(changes)
        self.fixture.foundation("tax_profile", "domain.tax", data)
        registry = json.loads(
            (Path(__file__).parent / "fixtures/costing_registry.json").read_text()
        )
        application = deepcopy(
            next(c["data"] for c in registry["configs"] if c["ref"]["id"] == "tax.goods")
        )
        application["counterparty_ref"]["row_version"] = 2
        application["tax_profile_ref"] = ref("tax_profile", "domain.tax")
        self.fixture.extension("tax_application", "domain.tax.app", application)
        offer = self.data("supplier_offer", "offer.1")
        offer["lines"][0].update(
            tax_profile_ref=ref("tax_profile", "domain.tax"),
            tax_application_ref=ref("tax_application", "domain.tax.app"),
        )
        return self.verify_input("supplier_offer", offer)

    def test_unknown_tax_recovery_cannot_be_assumed_nonrecoverable(self):
        self.scenario(offer=self.taxed_offer(recovery_treatment="unknown"))
        self.reject_evaluation("TAX_TREATMENT_UNKNOWN", "tax")

    def test_nonrecoverable_exclusive_tax_increases_cost(self):
        self.scenario(offer=self.taxed_offer(rate="0.13", recovery_treatment="nonrecoverable"))
        self.assertEqual(self.evaluate()["result"]["total_minor"], "73800")

    def test_recoverable_exclusive_tax_does_not_increase_cost(self):
        self.scenario(offer=self.taxed_offer(rate="0.13", recovery_treatment="recoverable"))
        self.assertEqual(self.evaluate()["result"]["total_minor"], "66000")

    def test_inclusive_recoverable_tax_is_removed_once(self):
        self.scenario(
            offer=self.taxed_offer(
                rate="0.13", price_basis="inclusive", recovery_treatment="recoverable"
            )
        )
        self.assertEqual(self.evaluate()["result"]["total_minor"], "59097")

    def test_nonexistent_fee_inclusion_parent_is_not_silently_ignored(self):
        data = self.data("logistics_offer", "log.1")
        data["fees"][0]["included_in_component_ref"] = "unknown.parent"
        logistics = self.verify_input("logistics_offer", data)
        self.scenario(logistics=logistics)
        self.reject_evaluation("CHARGE_SCOPE_UNRESOLVED", "fee_inclusion")

    def test_fee_inclusion_cycle_cannot_remove_its_own_cost(self):
        data = self.data("logistics_offer", "log.1")
        data["fees"][0]["included_in_component_ref"] = "F1"
        logistics = self.verify_input("logistics_offer", data)
        self.scenario(logistics=logistics)
        self.reject_evaluation("CHARGE_DOUBLE_COUNT", "fee_inclusion")

    def test_allocation_cannot_target_an_unpurchased_line(self):
        data = self.data("logistics_offer", "log.1")
        data["fees"][0]["allocation"] = {
            "basis": "explicit",
            "weights": [{"line_id": "not.purchased", "weight": "1"}],
        }
        self.scenario(logistics=self.verify_input("logistics_offer", data))
        self.reject_evaluation("REFERENCE_INVALID", "allocation")

    def test_missing_required_freight_is_not_zero_cost(self):
        data = self.data("cost_scenario", "scenario.1")
        data["logistics_offer_refs"] = []
        self.fixture.call(
            "brant.costing/0.1.0",
            "cost_scenario.save_draft",
            {"id": "scenario.1", "expected_version": 1, "data": data},
        )
        self.scenario_version = 2
        self.reject_evaluation("COST_INPUT_NOT_READY", "fee_inclusion")

    def measurement_data(self):
        inputs = json.loads((Path(__file__).parent / "fixtures/costing_inputs.json").read_text())
        return next(
            x["args"]["data"] for x in inputs if x["command"] == "measurement.record_verified"
        )

    def test_measurement_volume_contradiction_is_rejected(self):
        data = self.measurement_data()
        data["declared_volume_m3"] = "2"
        self.reject(
            "measurement.record_verified",
            {"id": "domain.measure", "expected_version": 0, "data": data},
            "MEASUREMENT_CONFLICT",
            "measurement",
        )

    def test_gross_weight_cannot_be_less_than_net_weight(self):
        data = self.measurement_data()
        data["packages"][0]["gross_kg"] = "8"
        self.reject(
            "measurement.record_verified",
            {"id": "domain.measure", "expected_version": 0, "data": data},
            "INVALID_KNOWN_VALUE",
            "measurement",
        )

    def test_future_measurement_is_not_a_verified_fact(self):
        data = self.measurement_data()
        data["observed_at"] = "2026-10-22T10:00:00Z"
        self.reject(
            "measurement.record_verified",
            {"id": "domain.measure", "expected_version": 0, "data": data},
            "INVALID_KNOWN_VALUE",
            "measurement",
        )

    def test_invalid_delivery_time_zone_cannot_be_verified(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["delivery"]["time_zone"] = "Invalid/Nowhere"
        self.reject_input("supplier_offer", data, "INVALID_KNOWN_VALUE", "delivery")

    def test_late_delivery_can_be_analyzed_but_cannot_be_frozen(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["delivery"]["date"] = "2026-11-16"
        self.scenario(offer=self.verify_input("supplier_offer", data))
        evaluation = self.evaluate()
        self.assertEqual(evaluation["result"]["comparison_status"], "not_comparable")
        args = self.fixture.freeze_request(evaluation)["args"]
        args["expected_version"] = self.scenario_version
        self.reject("cost_snapshot.freeze", args, "COMPARISON_BASIS_MISMATCH", "delivery")

    def dozen_offer(self, conversion=True, reverse=False):
        self.fixture.foundation(
            "unit", "DOZEN", {"code": "DOZEN", "name": "打", "precision": 0, "dimension": "count"}
        )
        data = self.data("supplier_offer", "offer.1")
        line = data["lines"][0]
        for key in ("purchase_unit_ref", "price_unit_ref", "tier_unit_ref"):
            line[key] = ref("unit", "DOZEN")
        line["moq"] = {"quantity": "1", "unit_ref": ref("unit", "DOZEN"), "scope": "sku"}
        line["tiers"][0]["unit_price"] = "60"
        if conversion:
            self.fixture.foundation(
                "conversion",
                "domain.dozen",
                {
                    "sku_profile": ref("sku_profile", "sku.1.profile"),
                    "from_unit": ref("unit", "PCS" if reverse else "DOZEN"),
                    "to_unit": ref("unit", "DOZEN" if reverse else "PCS"),
                    "factor": "12",
                    "basis": "合成包装资料：每打12件",
                    "valid_from": "2026-10-22T00:00:00Z",
                    "valid_until": "2026-10-29T00:00:00Z",
                },
            )
            line["conversion_refs"] = [ref("conversion", "domain.dozen")]
        offer = self.verify_input("supplier_offer", data)
        self.scenario(
            offer=offer,
            allocation={"purchase_quantity": "10", "purchase_unit_ref": ref("unit", "DOZEN")},
        )

    def test_explicit_sku_conversion_prices_ten_dozen_as_120_pieces(self):
        self.dozen_offer()
        self.assertEqual(self.evaluate()["result"]["total_minor"], "66000")

    def test_missing_sku_conversion_is_not_inferred_from_unit_name(self):
        self.dozen_offer(conversion=False)
        self.reject_evaluation("REFERENCE_INVALID", "unit")

    def test_reverse_unit_conversion_is_not_automatically_inverted(self):
        self.dozen_offer(reverse=True)
        self.reject_evaluation("REFERENCE_INVALID", "unit")

    def test_purchase_quantity_must_cover_original_demand(self):
        self.scenario(allocation={"purchase_quantity": "119"})
        self.reject_evaluation("COMPARISON_BASIS_MISMATCH", "pricing")

    def test_moq_is_not_bypassed_by_demand_equality(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["moq"]["quantity"] = "121"
        self.scenario(offer=self.verify_input("supplier_offer", data))
        self.reject_evaluation("MOQ_NOT_MET", "pricing")

    def test_order_multiple_is_checked_after_quantity_aggregation(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["order_multiple"] = "7"
        self.scenario(offer=self.verify_input("supplier_offer", data))
        self.reject_evaluation("ORDER_MULTIPLE_INVALID", "pricing")

    def test_graduated_tiers_price_each_band_once(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0].update(
            pricing_mode="graduated",
            tiers=[
                {"lower_inclusive": "0", "upper_exclusive": "100", "unit_price": "5"},
                {"lower_inclusive": "100", "unit_price": "4"},
            ],
        )
        self.scenario(offer=self.verify_input("supplier_offer", data))
        self.assertEqual(self.evaluate()["result"]["total_minor"], "64000")

    def test_gap_in_price_tiers_cannot_be_verified(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0].update(
            pricing_mode="graduated",
            tiers=[
                {"lower_inclusive": "0", "upper_exclusive": "100", "unit_price": "5"},
                {"lower_inclusive": "101", "unit_price": "4"},
            ],
        )
        self.reject_input("supplier_offer", data, "PRICE_TIER_AMBIGUOUS", "pricing")

    def test_different_supplier_payment_schedule_is_not_imputed_financing(self):
        payment = deepcopy(
            self.core.foundation_get(self.author, "payment_terms", "payment.test")["data"]
        )
        payment["stages"][0]["days"] = 14
        self.fixture.foundation("payment_terms", "domain.payment", payment)
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["payment_terms_ref"] = ref("payment_terms", "domain.payment")
        self.scenario(offer=self.verify_input("supplier_offer", data))
        result = self.evaluate()["result"]
        self.assertEqual(result["total_minor"], "66000")
        self.assertEqual(result["comparison_status"], "comparable")
        self.assertTrue(
            any(x["status"] == "different_cashflow" for x in result["commercial_checks"])
        )
        self.assertIn("imputed_financing_cost", result["excluded_cost_categories"])

    def delivery_calendar(self, **changes):
        inputs = json.loads((Path(__file__).parent / "fixtures/extension_inputs.json").read_text())
        data = deepcopy(next(x["data"] for x in inputs if x["kind"] == "delivery_calendar"))
        data.update(changes)
        self.fixture.extension("delivery_calendar", "domain.calendar", data)
        return ref("delivery_calendar", "domain.calendar")

    def lead_time(self, anchor="supplier_offer:offer.1", **calendar_changes):
        return {
            "kind": "lead_time",
            "anchor_ref": ref("delivery_anchor", anchor),
            "days": 3,
            "day_basis": "working",
            "calendar_ref": self.delivery_calendar(**calendar_changes),
            "milestone": "handover",
            "place_ref": ref("location", "port.test"),
            "time_zone": "Asia/Shanghai",
        }

    def test_working_days_use_real_verification_event_and_reviewed_overrides(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["delivery"] = self.lead_time()
        self.scenario(offer=self.verify_input("supplier_offer", data))
        evaluation = self.evaluate()
        checks = [x for x in evaluation["result"]["delivery_checks"] if x["role"] == "supply"]
        self.assertEqual([x["date"] for x in checks], ["2026-10-27"])
        self.assertEqual(evaluation["result"]["total_minor"], "66000")
        args = self.fixture.freeze_request(evaluation)["args"]
        args["expected_version"] = self.scenario_version
        frozen = self.fixture.call(
            "brant.costing/0.1.0", "cost_snapshot.freeze", args, self.reviewer
        )
        query = Core(self.path, clock=self.clock).costing_get(
            self.reviewer, "snapshot_query", frozen["result"]["id"]
        )
        self.assertTrue(query["currently_eligible_for_quote"])
        self.fixture.call(
            "brant.costing/0.1.0",
            "supplier_offer.withdraw",
            {
                "id": "offer.1",
                "expected_version": 2,
                "target_revision": 1,
                "reason": "撤销锚点所依赖核实事件的生效版本",
                "evidence": self.evidence,
            },
            self.reviewer,
        )
        query = self.core.costing_get(self.reviewer, "snapshot_query", frozen["result"]["id"])
        self.assertFalse(query["currently_eligible_for_quote"])
        self.assertEqual(query["snapshot"], frozen["result"])

    def test_pending_verification_anchor_does_not_invent_a_date(self):
        id_ = self.save_input("supplier_offer", self.data("supplier_offer", "offer.1"))
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["delivery"] = self.lead_time("supplier_offer:" + id_)
        self.scenario(offer=self.verify_input("supplier_offer", data))
        evaluation = self.evaluate()
        self.assertEqual(evaluation["result"]["verification_status"], "provisional")
        self.assertTrue(
            any(
                x["status"] == "unresolved" and "date" not in x
                for x in evaluation["result"]["delivery_checks"]
            )
        )
        args = self.fixture.freeze_request(evaluation)["args"]
        args["expected_version"] = self.scenario_version
        self.reject("cost_snapshot.freeze", args, "COST_INPUT_NOT_READY", "delivery")

    def test_delivery_calendar_cannot_extrapolate_outside_coverage(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["delivery"] = self.lead_time(coverage_until="2026-10-26")
        self.reject_input("supplier_offer", data, "COST_INPUT_NOT_READY", "delivery")

    def test_delivery_calendar_time_zone_must_match_rule(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["delivery"] = self.lead_time(time_zone="UTC")
        self.reject_input("supplier_offer", data, "INVALID_KNOWN_VALUE", "delivery")

    def test_anchor_original_source_denial_blocks_new_adoption(self):
        origin = self.data("supplier_offer", "offer.1")
        origin["evidence"] = [{"source_id": "source.2", "locator": "锚点原始来源"}]
        anchor = self.verify_input("supplier_offer", origin)
        offer = self.data("supplier_offer", "offer.1")
        offer["lines"][0]["delivery"] = self.lead_time("supplier_offer:" + anchor["id"])
        self.scenario(offer=self.verify_input("supplier_offer", offer))
        evaluation = self.evaluate()
        args = self.fixture.freeze_request(evaluation)["args"]
        args["expected_version"] = self.scenario_version
        frozen = self.fixture.call(
            "brant.costing/0.1.0", "cost_snapshot.freeze", args, self.reviewer
        )
        self.fixture.call(
            "brant.costing/0.1.0",
            "source_denial.record",
            {
                "id": "domain.anchor.denial",
                "source_id": "source.2",
                "reason": "锚点原资料已被反证否认",
                "evidence": self.evidence,
            },
            self.reviewer,
        )
        query = self.core.costing_get(self.reviewer, "snapshot_query", frozen["result"]["id"])
        self.assertFalse(query["currently_eligible_for_quote"])
        self.assertEqual(query["snapshot"], frozen["result"])

    def test_anchor_original_source_permission_is_rechecked_for_history(self):
        other = Principal("tenant.live", "company.live", "private.owner")
        self.core.provision(other, ["*"], data_scope="company")
        self.fixture.old(
            "source.register",
            {
                "id": "domain.private.source",
                "source_kind": "manual_text",
                "content_text": "合成锚点私有来源",
            },
            other,
        )
        self.core.attest_costing_source(self.reviewer, "domain.private.source", "人工核实")
        origin = self.data("supplier_offer", "offer.1")
        origin["evidence"] = [{"source_id": "domain.private.source", "locator": "独立原始来源"}]
        anchor = self.verify_input("supplier_offer", origin)
        offer = self.data("supplier_offer", "offer.1")
        offer["lines"][0]["delivery"] = self.lead_time("supplier_offer:" + anchor["id"])
        self.scenario(offer=self.verify_input("supplier_offer", offer))
        evaluation = self.evaluate()
        self.core.provision(self.author, ["*"], team_id="trade", data_scope="own")
        with self.assertRaises(Rejected) as caught:
            self.core.costing_get(self.author, "evaluation", evaluation["result"]["id"])
        self.assertEqual(caught.exception.code, "PERMISSION_DENIED")

    def test_anchor_transitive_private_role_permission_is_rechecked(self):
        other = Principal("tenant.live", "company.live", "private.role.owner")
        self.core.provision(other, ["*"], data_scope="company")
        self.fixture.call(
            "brant.costing/0.1.0",
            "service_party_role.save_draft",
            {
                "id": "private.anchor.role",
                "expected_version": 0,
                "data": self.data("service_party_role", "provider.role"),
            },
            other,
        )
        self.fixture.call(
            "brant.costing/0.1.0",
            "service_party_role.verify",
            {
                "id": "private.anchor.role",
                "expected_version": 1,
                "working_revision": 1,
                "evidence": self.evidence,
            },
            self.reviewer,
        )
        logistics = self.data("logistics_offer", "log.1")
        logistics["service_role_ref"] = ref("service_party_role", "private.anchor.role")
        anchor = self.verify_input("logistics_offer", logistics)
        offer = self.data("supplier_offer", "offer.1")
        offer["lines"][0]["delivery"] = self.lead_time("logistics_offer:" + anchor["id"])
        self.scenario(offer=self.verify_input("supplier_offer", offer))
        evaluation = self.evaluate()
        self.core.provision(self.author, ["*"], team_id="trade", data_scope="own")
        with self.assertRaises(Rejected):
            self.core.costing_get(self.author, "service_party_role", "private.anchor.role")
        with self.assertRaises(Rejected) as caught:
            self.core.costing_get(self.author, "evaluation", evaluation["result"]["id"])
        self.assertEqual(caught.exception.code, "PERMISSION_DENIED")

    def test_anchor_transitive_source_denial_blocks_new_adoption(self):
        role = self.data("service_party_role", "provider.role")
        role["evidence"] = [{"source_id": "source.2", "locator": "传递角色原资料"}]
        role_ref = self.verify_input("service_party_role", role)
        logistics = self.data("logistics_offer", "log.1")
        logistics["service_role_ref"] = role_ref
        anchor = self.verify_input("logistics_offer", logistics)
        offer = self.data("supplier_offer", "offer.1")
        offer["lines"][0]["delivery"] = self.lead_time("logistics_offer:" + anchor["id"])
        self.scenario(offer=self.verify_input("supplier_offer", offer))
        evaluation = self.evaluate()
        self.fixture.call(
            "brant.costing/0.1.0",
            "source_denial.record",
            {
                "id": "domain.nested.denial",
                "source_id": "source.2",
                "reason": "传递依赖来源被否认",
                "evidence": self.evidence,
            },
            self.reviewer,
        )
        args = self.fixture.freeze_request(evaluation)["args"]
        args["expected_version"] = self.scenario_version
        self.reject("cost_snapshot.freeze", args, "REFERENCE_STALE", "delivery")

    def test_anchor_history_does_not_reactivate_old_commercial_role(self):
        role_ref = self.verify_input(
            "service_party_role", self.data("service_party_role", "provider.role")
        )
        logistics = self.data("logistics_offer", "log.1")
        logistics["service_role_ref"] = role_ref
        anchor = self.verify_input("logistics_offer", logistics)
        self.fixture.call(
            "brant.costing/0.1.0",
            "service_party_role.withdraw",
            {
                "id": role_ref["id"],
                "expected_version": 2,
                "target_revision": 1,
                "reason": "角色停止新商业使用，原核实事件仍保留",
                "evidence": self.evidence,
            },
            self.reviewer,
        )
        offer = self.data("supplier_offer", "offer.1")
        offer["lines"][0]["delivery"] = self.lead_time("logistics_offer:" + anchor["id"])
        self.scenario(offer=self.verify_input("supplier_offer", offer))
        self.assertEqual(self.evaluate()["result"]["total_minor"], "66000")

    def test_unmapped_order_event_is_explicitly_unsupported(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["delivery"] = self.lead_time("order_confirmed:order.1")
        self.reject(
            "supplier_offer.save_draft",
            {"id": "domain.unmapped", "expected_version": 0, "data": data},
            "DEPENDENCY_NOT_SUPPORTED",
            "delivery",
        )

    def test_zero_lead_days_resolves_to_anchor_local_date(self):
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["delivery"] = self.lead_time()
        data["lines"][0]["delivery"]["days"] = 0
        self.scenario(offer=self.verify_input("supplier_offer", data))
        checks = self.evaluate()["result"]["delivery_checks"]
        self.assertEqual([x["date"] for x in checks if x["role"] == "supply"], ["2026-10-22"])

    def test_future_anchor_event_is_not_treated_as_already_occurred(self):
        self.fixture.core = Core(self.path, clock=lambda: datetime(2026, 10, 22, 10, tzinfo=UTC))
        anchor = self.verify_input("supplier_offer", self.data("supplier_offer", "offer.1"))
        self.fixture.core = self.core
        data = self.data("supplier_offer", "offer.1")
        data["lines"][0]["delivery"] = self.lead_time("supplier_offer:" + anchor["id"])
        self.reject_input("supplier_offer", data, "INVALID_KNOWN_VALUE", "delivery")

    def test_conflicting_holiday_and_workday_cannot_be_published(self):
        inputs = json.loads((Path(__file__).parent / "fixtures/extension_inputs.json").read_text())
        data = deepcopy(next(x["data"] for x in inputs if x["kind"] == "delivery_calendar"))
        data["working_overrides"].append(data["holidays"][0])
        self.fixture.call(
            "brant.foundation-extension/0.1.0",
            "foundation_extension.save_draft",
            {
                "kind": "delivery_calendar",
                "id": "domain.conflict.calendar",
                "expected_version": 0,
                "data": data,
            },
        )
        self.reject(
            "foundation_extension.publish",
            {
                "kind": "delivery_calendar",
                "id": "domain.conflict.calendar",
                "expected_version": 1,
                "working_revision": 1,
                "evidence": self.evidence,
            },
            "INVALID_KNOWN_VALUE",
            "delivery",
            "brant.foundation-extension/0.1.0",
        )

    def test_three_line_one_cent_allocation_has_deterministic_remainder(self):
        self.fixture.old(
            "rfq.save_draft",
            {
                "id": "domain.rfq",
                "expected_version": 0,
                "customer_id": "customer.1",
                "contact_id": "contact.1",
                "source_ids": ["source.1"],
                "lines": [
                    {
                        "line_id": id_,
                        "sku_id": "sku.1",
                        "quantity": "1",
                        "uom": "PCS",
                        "source_id": "source.1",
                        "locator": id_,
                    }
                    for id_ in ("L3", "L2", "L1")
                ],
            },
        )
        self.fixture.old(
            "rfq.confirm_scope",
            {"id": "domain.rfq", "expected_version": 1, "evidence_ids": ["source.1"]},
            self.reviewer,
        )
        context = self.data("costing_context", "context.1")
        context["rfq_ref"] = {"id": "domain.rfq", "row_version": 2}
        context["lines"] = [
            {**deepcopy(context["lines"][0]), "line_id": id_, "quantity": "1"}
            for id_ in ("L3", "L2", "L1")
        ]
        context_ref = self.verify_input("costing_context", context)
        offer = self.data("supplier_offer", "offer.1")
        offer["rfq_ref"] = context["rfq_ref"]
        offer["rfq_line_ids"] = ["L3", "L2", "L1"]
        offer["lines"][0]["moq"]["quantity"] = "1"
        offer_ref = self.verify_input("supplier_offer", offer)
        logistics = self.data("logistics_offer", "log.1")
        logistics["fees"][0]["billing"]["amount"] = "0.01"
        logistics["fees"][0]["allocation"]["target_line_ids"] = ["L3", "L2", "L1"]
        log_ref = self.verify_input("logistics_offer", logistics)
        scenario = self.data("cost_scenario", "scenario.1")
        scenario.update(context_ref=context_ref, logistics_offer_refs=[log_ref])
        scenario["allocations"] = [
            {
                "rfq_line_id": id_,
                "purchase_quantity": "1",
                "purchase_unit_ref": ref("unit", "PCS"),
                "source": {
                    "kind": "offer",
                    "id": offer_ref["id"],
                    "revision": 1,
                    "condition_line_id": "OL1",
                },
            }
            for id_ in ("L3", "L2", "L1")
        ]
        self.fixture.call(
            "brant.costing/0.1.0",
            "cost_scenario.save_draft",
            {"id": "scenario.1", "expected_version": 1, "data": scenario},
        )
        self.scenario_version = 2
        evaluation = self.evaluate()
        self.assertEqual(evaluation["result"]["total_minor"], "1501")
        fee = next(
            c for c in evaluation["result"]["components"] if c["obligation_id"] == "freight.1"
        )
        self.assertEqual(
            [(a["line_id"], a["amount_minor"]) for a in fee["allocations"]],
            [("L1", "1"), ("L2", "0"), ("L3", "0")],
        )
        args = self.fixture.freeze_request(evaluation)["args"]
        args["expected_version"] = 2
        frozen = self.fixture.call(
            "brant.costing/0.1.0", "cost_snapshot.freeze", args, self.reviewer
        )
        self.assertEqual(
            Core(self.path, clock=self.clock).costing_get(
                self.reviewer, "snapshot", frozen["result"]["id"]
            )["total_minor"],
            "1501",
        )

    def test_competing_verifications_cannot_seal_the_same_input_twice(self):
        id_ = self.save_input("costing_context", self.data("costing_context", "context.1"))
        requests = [
            self.request(
                "costing_context.verify",
                {
                    "id": id_,
                    "expected_version": 1,
                    "working_revision": 1,
                    "evidence": self.evidence,
                },
            )
            for _ in range(2)
        ]
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(
                pool.map(
                    lambda r: Core(self.path, clock=self.clock).execute(self.reviewer, r), requests
                )
            )
        self.assertEqual(sum(r["ok"] for r in results), 1, results)
        self.assertEqual(next(r["code"] for r in results if not r["ok"]), "VERSION_CONFLICT")
        record = self.core.costing_get(self.reviewer, "costing_context", id_)
        self.assertEqual(
            (record["root_version"], record["revision"], record["sealed"]), (2, 1, True)
        )

    def test_freeze_racing_source_denial_cannot_leave_an_eligible_snapshot(self):
        evaluation = self.evaluate()
        freeze = self.fixture.freeze_request(evaluation)
        denial = self.request(
            "source_denial.record",
            {
                "id": "domain.racing.denial",
                "source_id": "source.1",
                "reason": "冻结同时到达的有效反证",
                "evidence": [{"source_id": "source.2", "locator": "独立反证"}],
            },
        )
        with ThreadPoolExecutor(max_workers=2) as pool:
            frozen, denied = list(
                pool.map(
                    lambda r: Core(self.path, clock=self.clock).execute(self.reviewer, r),
                    [freeze, denial],
                )
            )
        self.assertTrue(denied["ok"], denied)
        if frozen["ok"]:
            query = self.core.costing_get(self.reviewer, "snapshot_query", frozen["result"]["id"])
            self.assertFalse(query["currently_eligible_for_quote"])
            self.assertEqual(query["snapshot"], frozen["result"])
        else:
            self.assertEqual(frozen["code"], "REFERENCE_STALE")
            self.assertEqual(
                self.core.costing_get(self.reviewer, "cost_scenario", "scenario.1")["status"],
                "draft",
            )
