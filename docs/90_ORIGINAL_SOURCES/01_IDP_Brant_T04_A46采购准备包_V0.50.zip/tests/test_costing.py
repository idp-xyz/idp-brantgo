import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
from pathlib import Path

from costing_fixture import TradeFixture

from brant_core import Core, Principal
from brant_core.common import Rejected


class CostingPersistenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name, "business.sqlite")
        self.clock = lambda: datetime(2026, 10, 22, 9, tzinfo=UTC)
        self.core = Core(self.path, clock=self.clock)
        self.author = Principal("tenant.live", "company.live", "author")
        self.reviewer = Principal("tenant.live", "company.live", "reviewer")
        for who in (self.author, self.reviewer):
            self.core.provision(who, ["*"], team_id="trade", data_scope="company")

    def request(self, command, args, key="test.command"):
        return {
            "contract": "brant.costing/0.1.0",
            "command": command,
            "idempotency_key": key,
            "args": args,
        }

    def test_draft_survives_restart_and_replays_original_action(self):
        request = self.request(
            "cost_scenario.save_draft", {"id": "scenario.1", "expected_version": 0, "data": {}}
        )
        first = self.core.execute(self.author, request)
        self.assertTrue(first["ok"], first)
        reopened = Core(self.path, clock=self.clock)
        saved = reopened.costing_get(self.author, "cost_scenario", "scenario.1")
        self.assertEqual((saved["row_version"], saved["status"], saved["data"]), (1, "draft", {}))
        replay = reopened.execute(self.author, request)
        self.assertTrue(replay["replayed"], replay)
        self.assertEqual(replay["action_id"], first["action_id"])

    def test_authorization_and_missing_history_rejections_are_audited(self):
        reader = Principal("tenant.live", "company.live", "reader")
        self.core.provision(reader, ["read"], data_scope="company")
        for who in (reader, self.reviewer):
            with self.assertRaises(Rejected):
                self.core.costing_get(who, "snapshot", "missing")
        denied = [
            a
            for a in self.core.audit(self.reviewer)
            if a["command"] == "costing.get" and a["outcome"] == "rejected"
        ]
        self.assertEqual(len(denied), 2)

    def test_discard_keeps_exact_command_fact_after_restart(self):
        saved = self.core.execute(
            self.author,
            self.request(
                "costing_context.save_draft",
                {
                    "id": "ctx.discard",
                    "expected_version": 0,
                    "data": {},
                },
                "draft.discard",
            ),
        )
        self.assertTrue(saved["ok"], saved)
        args = {
            "id": "ctx.discard",
            "expected_version": 1,
            "working_revision": 1,
            "reason": "重复询价，明确丢弃此草稿",
        }
        discarded = self.core.execute(
            self.author, self.request("costing_context.discard_draft", args, "discard.fact")
        )
        self.assertTrue(discarded["ok"], discarded)
        Core(self.path, clock=self.clock)
        with sqlite3.connect(self.path) as db:
            row = db.execute(
                "SELECT args_json,actor_id,events_json FROM t02_command_event WHERE action_id=?",
                (discarded["action_id"],),
            ).fetchone()
        import json

        self.assertEqual(json.loads(row[0]), args)
        self.assertEqual(row[1], self.author.actor)
        self.assertEqual(json.loads(row[2])[0]["events"], [["discard", 1]])

    def test_history_root_rechecks_private_verification_evidence(self):
        fixture = TradeFixture(self.core).prepare()
        other = Principal("tenant.live", "company.live", "other")
        self.core.provision(other, ["*"], data_scope="company")
        fixture.old(
            "source.register",
            {
                "id": "private.proof",
                "source_kind": "manual_text",
                "content_text": "独立私有核实来源",
            },
            other,
        )
        self.core.attest_costing_source(self.reviewer, "private.proof", "人工核实")
        data = self.core.costing_get(self.author, "costing_context", "context.1")["data"]
        fixture.call(
            "brant.costing/0.1.0",
            "costing_context.save_draft",
            {"id": "context.private", "expected_version": 0, "data": data},
        )
        fixture.call(
            "brant.costing/0.1.0",
            "costing_context.verify",
            {
                "id": "context.private",
                "expected_version": 1,
                "working_revision": 1,
                "evidence": [{"source_id": "private.proof", "locator": "核实依据"}],
            },
            self.reviewer,
        )
        self.core.provision(self.author, ["*"], team_id="trade", data_scope="own")
        with self.assertRaises(Rejected):
            Core(self.path, clock=self.clock).costing_get(
                self.author, "costing_context", "context.private"
            )

    def test_actual_database_inputs_evaluate_freeze_and_read_after_restart(self):
        fixture = TradeFixture(self.core).prepare()
        result = fixture.evaluate()
        self.assertEqual(result["result"]["total_minor"], "66000")
        frozen = self.core.execute(self.reviewer, fixture.freeze_request(result))
        self.assertTrue(frozen["ok"], frozen)
        reopened = Core(self.path, clock=self.clock)
        history = reopened.costing_get(self.reviewer, "snapshot", frozen["result"]["id"])
        self.assertEqual(history["total_minor"], "66000")
        self.assertEqual(history["result_hash"], result["result_hash"])
        scenario = reopened.costing_get(self.reviewer, "cost_scenario", "scenario.1")
        self.assertEqual((scenario["status"], scenario["row_version"]), ("frozen", 2))

    def test_expired_inputs_block_new_freeze_without_consuming_key(self):
        fixture = TradeFixture(self.core).prepare()
        result = fixture.evaluate()
        request = fixture.freeze_request(result)
        late = Core(self.path, clock=lambda: datetime(2026, 10, 29, tzinfo=UTC))
        refused = late.execute(self.reviewer, request)
        self.assertEqual(refused["code"], "REFERENCE_STALE")
        saved = self.core.costing_get(self.reviewer, "cost_scenario", "scenario.1")
        self.assertEqual((saved["status"], saved["row_version"]), ("draft", 1))
        history = late.costing_get(self.reviewer, "evaluation", result["result"]["id"])
        self.assertEqual(history["total_minor"], "66000")
        # A rejected attempt has no successful idempotency result. Recheck at
        # the original synthetic clock to observe that the key was not consumed.
        accepted = self.core.execute(self.reviewer, request)
        self.assertTrue(accepted["ok"], accepted)
        self.assertFalse(accepted["replayed"])

    def test_same_key_parallel_freeze_returns_one_original_action(self):
        fixture = TradeFixture(self.core).prepare()
        result = fixture.evaluate()
        request = fixture.freeze_request(result)

        def freeze(_):
            return Core(self.path, clock=self.clock).execute(self.reviewer, request)

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(freeze, range(2)))
        self.assertTrue(all(r["ok"] for r in results), results)
        self.assertEqual(len({r["action_id"] for r in results}), 1)
        self.assertEqual(sorted(r["replayed"] for r in results), [False, True])
        successful = [
            a
            for a in self.core.audit(self.reviewer)
            if a["command"] == "cost_snapshot.freeze" and a["outcome"] == "succeeded"
        ]
        self.assertEqual(len(successful), 1)

    def test_different_key_parallel_freeze_commits_only_one_snapshot(self):
        fixture = TradeFixture(self.core).prepare()
        result = fixture.evaluate()

        def freeze(i):
            return Core(self.path, clock=self.clock).execute(
                self.reviewer, fixture.freeze_request(result, "parallel." + str(i))
            )

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(freeze, range(2)))
        self.assertEqual(sum(r["ok"] for r in results), 1, results)
        self.assertEqual(next(r["code"] for r in results if not r["ok"]), "VERSION_CONFLICT")

    def test_outbox_failure_rolls_back_freeze_and_key_can_be_retried(self):
        fixture = TradeFixture(self.core).prepare()
        result = fixture.evaluate()
        request = fixture.freeze_request(result)
        # The SQLite store is a declared deployment boundary. A real database
        # trigger injects a storage failure, without mocking service internals.
        with sqlite3.connect(self.path) as db:
            db.execute(
                "CREATE TRIGGER reject_freeze_outbox BEFORE INSERT ON outbox WHEN json_extract(NEW.payload_json,'$.command')='cost_snapshot.freeze' BEGIN SELECT RAISE(ABORT,'test storage failure'); END"
            )
        failed = self.core.execute(self.reviewer, request)
        self.assertEqual(failed["code"], "STORAGE_FAILURE")
        saved = Core(self.path, clock=self.clock).costing_get(
            self.reviewer, "cost_scenario", "scenario.1"
        )
        self.assertEqual((saved["status"], saved["row_version"]), ("draft", 1))
        with self.assertRaises(Rejected):
            self.core.costing_get(self.reviewer, "snapshot", "snapshot.1")
        self.assertFalse(
            any(
                a["command"] == "cost_snapshot.freeze" and a["outcome"] == "succeeded"
                for a in self.core.audit(self.reviewer)
            )
        )
        with sqlite3.connect(self.path) as db:
            db.execute("DROP TRIGGER reject_freeze_outbox")
        retried = self.core.execute(self.reviewer, request)
        self.assertTrue(retried["ok"], retried)
        self.assertFalse(retried["replayed"])

    def test_source_denial_blocks_new_freeze_but_keeps_history(self):
        fixture = TradeFixture(self.core).prepare()
        result = fixture.evaluate()
        denied = self.core.execute(
            self.reviewer,
            self.request(
                "source_denial.record",
                {
                    "id": "denial.1",
                    "source_id": "source.1",
                    "reason": "新反证明确否认原来源",
                    "evidence": [{"source_id": "source.2", "locator": "独立反证"}],
                },
                "deny.source",
            ),
        )
        self.assertTrue(denied["ok"], denied)
        refused = Core(self.path, clock=self.clock).execute(
            self.reviewer, fixture.freeze_request(result)
        )
        self.assertEqual(refused["code"], "REFERENCE_STALE")
        history = self.core.costing_get(self.reviewer, "evaluation", result["result"]["id"])
        self.assertEqual(history["total_minor"], "66000")

    def test_source_access_revocation_blocks_successful_replay_and_history(self):
        TradeFixture(self.core).prepare()
        request = self.request(
            "cost_scenario.evaluate", {"id": "scenario.1", "expected_version": 1}, "evaluate.saved"
        )
        result = self.core.execute(self.reviewer, request)
        self.assertTrue(result["ok"], result)
        self.core.provision(self.reviewer, ["*"], team_id="other", data_scope="own")
        replay = Core(self.path, clock=self.clock).execute(self.reviewer, request)
        self.assertFalse(replay["ok"], replay)
        self.assertNotIn("field_errors", replay)
        with self.assertRaises(Rejected):
            self.core.costing_get(self.reviewer, "evaluation", result["result"]["id"])

    def test_raw_json_duplicate_keys_are_rejected(self):
        result = self.core.costing_execute_json(
            self.author,
            '{"contract":"brant.costing/0.1.0","command":"cost_scenario.save_draft","command":"cost_snapshot.freeze"}',
        )
        self.assertEqual(result, {"ok": False, "code": "SCHEMA_INVALID"})

    def test_ai_with_wildcard_cannot_attest_or_freeze(self):
        fixture = TradeFixture(self.core).prepare()
        result = fixture.evaluate()
        ai = Principal("tenant.live", "company.live", "assistant")
        self.core.provision(ai, ["*"], actor_kind="ai", data_scope="company")
        with self.assertRaises(Rejected) as caught:
            self.core.attest_costing_source(ai, "source.1", "AI 不能代替人工核实")
        self.assertEqual(caught.exception.code, "PERMISSION_DENIED")
        refused = self.core.execute(ai, fixture.freeze_request(result))
        self.assertEqual(refused["code"], "PERMISSION_DENIED")
        self.assertTrue(self.core.execute(self.reviewer, fixture.freeze_request(result))["ok"])

    def test_snapshot_store_rejects_edits_deletion_and_late_children(self):
        fixture = TradeFixture(self.core).prepare()
        result = fixture.evaluate()
        frozen = self.core.execute(self.reviewer, fixture.freeze_request(result))
        self.assertTrue(frozen["ok"], frozen)
        snapshot_id = frozen["result"]["id"]
        # Store immutability is itself a deployment contract, tested at SQLite.
        statements = [
            ("UPDATE t02_result SET result_hash=? WHERE id=?", ("0" * 64, snapshot_id)),
            ("DELETE FROM t02_result WHERE id=?", (snapshot_id,)),
            ("UPDATE t02_component SET amount_minor=0 WHERE snapshot_id=?", (snapshot_id,)),
            ("DELETE FROM t02_allocation WHERE snapshot_id=?", (snapshot_id,)),
            (
                "INSERT INTO t02_component VALUES(?,?,?,?,?)",
                (*self.author.scope, snapshot_id, "late", 0),
            ),
        ]
        for sql, args in statements:
            with self.subTest(sql=sql), sqlite3.connect(self.path) as db:
                with self.assertRaises(sqlite3.IntegrityError):
                    db.execute(sql, args)
        self.assertEqual(
            self.core.costing_get(self.reviewer, "snapshot", snapshot_id)["total_minor"], "66000"
        )

    def test_cross_company_cannot_read_or_replay_same_named_objects(self):
        request = self.request(
            "cost_scenario.save_draft", {"id": "same", "expected_version": 0, "data": {}}
        )
        result = self.core.execute(self.author, request)
        outsider = Principal("tenant.other", "company.other", "author")
        self.core.provision(outsider, ["*"], data_scope="company")
        with self.assertRaises(Rejected):
            self.core.costing_get(outsider, "cost_scenario", "same")
        other = self.core.execute(outsider, request)
        self.assertTrue(other["ok"], other)
        self.assertFalse(other["replayed"])
        self.assertNotEqual(result["action_id"], other["action_id"])

    def test_restart_keeps_raw_input_binding_separate_from_business_normalization(self):
        fixture = TradeFixture(self.core).prepare()
        scenario = self.core.costing_get(self.author, "cost_scenario", "scenario.1")
        scenario["data"]["allocations"][0]["purchase_quantity"] = "120.000000"
        saved = self.core.execute(
            self.author,
            self.request(
                "cost_scenario.save_draft",
                {
                    "id": "scenario.1",
                    "expected_version": 1,
                    "data": scenario["data"],
                },
                "numeric.spelling",
            ),
        )
        self.assertTrue(saved["ok"], saved)
        result = self.core.execute(
            self.reviewer,
            self.request(
                "cost_scenario.evaluate",
                {
                    "id": "scenario.1",
                    "expected_version": 2,
                },
                "evaluate.raw",
            ),
        )
        self.assertTrue(result["ok"], result)
        reopened = Core(self.path, clock=self.clock)
        request = fixture.freeze_request(result)
        request["args"]["expected_version"] = 2
        frozen = reopened.execute(self.reviewer, request)
        self.assertTrue(frozen["ok"], frozen)
        self.assertTrue(
            reopened.costing_get(self.reviewer, "snapshot_query", frozen["result"]["id"])[
                "currently_eligible_for_quote"
            ]
        )
