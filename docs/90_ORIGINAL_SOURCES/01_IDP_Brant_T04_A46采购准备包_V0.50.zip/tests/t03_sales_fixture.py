"""Synthetic dedicated sales-side tax facts, published through Core APIs."""
import copy


def prepare_sales(fixture):
    core=fixture.core
    with core._connection() as db:
        exists=db.execute("SELECT 1 FROM foundation_root WHERE kind='company' AND id=?",
                          (fixture.author.company,)).fetchone()
    if not exists:
        fixture.foundation("company",fixture.author.company,{
            "legal_name":"Synthetic sales issuer", "registration_no":"SYNTHETIC",
            "country":"US", "address":"Synthetic local fixture",
            "base_currency":{"kind":"currency","id":"USD","revision":1},
            "timezone":"UTC", "policy_scope":"Synthetic tests only",
        })
    core.t03_config_verify_source(fixture.reviewer,"source.1",verified=True,reason="Synthetic sales evidence")
    core.t03_config_select_pricing_policy(fixture.reviewer,
        {"kind":"pricing_policy","id":"policy.1","revision":1},reason="Synthetic sales policy")
    publish_application(fixture,"sales.goods.default",
                        {"kind":"sku_profile","id":"sku.1.profile","revision":1})
    fixture.foundation("party_profile", "customer.profile", {
        "party_id": "customer.1",
        "legal_name": "Synthetic A29 Customer",
        "country": "US",
        "addresses": [{"address_id": "customer.billing", "role": "billing",
                       "address": "Synthetic customer billing address"}],
        "trade_terms": {"kind": "trade_terms", "id": "terms.test", "revision": 1},
        "payment_terms": {"kind": "payment_terms", "id": "payment.test", "revision": 1},
        "party_row_version": 2,
        "contact_refs": [{"id": "contact.1", "row_version": 2}],
    })


def application_data(subject, tax_id="tax.zero"):
    return {
        "name":"Synthetic reviewed sales applicability","business_model":"CN-M01","use":"quotation_sale",
        "subject_kind":subject["kind"],"subject_ref":copy.deepcopy(subject),
        "issuer_ref":{"kind":"company","id":"company.live","revision":1},
        "customer_ref":{"kind":"customer","id":"customer.1","row_version":2},
        "tax_profile_ref":{"kind":"tax_profile","id":tax_id,"revision":1},
        "jurisdiction":"SYNTHETIC","basis_note":"Synthetic arithmetic, no tax-law claim",
        "valid_from":"2026-10-22T00:00:00Z","valid_until":"2026-10-29T00:00:00Z",
    }


def publish_application(fixture,id_,subject,tax_id="tax.zero",data=None):
    value=application_data(subject,tax_id) if data is None else data
    fixture.call("brant.quotation-foundation/0.1.0","quotation_foundation.save_draft",{
        "kind":"sales_tax_application","id":id_,"expected_version":0,"data":value})
    fixture.call("brant.quotation-foundation/0.1.0","quotation_foundation.publish",{
        "kind":"sales_tax_application","id":id_,"expected_version":1,"working_revision":1,
        "reason":"Synthetic independent sales review",
        "evidence":[{"source_id":"source.1","locator":"Synthetic sales terms"}]},fixture.reviewer)
    return {"kind":"sales_tax_application","id":id_,"revision":1}


def sales_charge(fixture,id_="sales.freight",inclusion="separate",amount="10",tax_id="tax.zero"):
    fixture.foundation("fee_type",id_,{
        "name":"Synthetic sales freight","category":"freight","side":"sales_charge","inclusion":inclusion,
        "allocation_basis":"quantity","policy_basis":"Synthetic fixed seller income",
    })
    fee={"kind":"fee_type","id":id_,"revision":1}
    tax=publish_application(fixture,id_+".tax",fee,tax_id)
    return {"charge_id":id_+".charge","obligation_key":id_+".obligation","fee_type_ref":fee,
            "amount":amount,"inclusion":inclusion,"tax_application_ref":tax,
            "evidence":[{"source_id":"source.1","locator":"Synthetic seller income"}]}
