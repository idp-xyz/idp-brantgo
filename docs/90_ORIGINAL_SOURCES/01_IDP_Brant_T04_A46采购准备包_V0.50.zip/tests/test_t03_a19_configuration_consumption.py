import sqlite3
import tempfile
import unittest
from datetime import UTC, datetime
from pathlib import Path

from brant_core import Core, Principal
from brant_core.common import Rejected
from t03_candidate.build_contracts import SECTIONS
from tests.costing_fixture import TradeFixture
from tests.t03_sales_fixture import prepare_sales
from tests.t03_scope_fixture import complete


class A19ConfigurationConsumptionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.core = Core(
            Path(self.tmp.name) / "a19.sqlite",
            enable_t03=True,
            clock=lambda: datetime(2026, 10, 22, 9, tzinfo=UTC),
        )
        self.author = Principal("tenant.live", "company.live", "author")
        self.reviewer = Principal("tenant.live", "company.live", "reviewer")
        for actor in (self.author, self.reviewer):
            self.core.provision(actor, ["*"], team_id="trade", data_scope="company")
        fixture = TradeFixture(self.core)
        fixture.prepare()
        fixture.foundation(
            "company",
            "company.live",
            {
                "legal_name": "Synthetic A19 Company",
                "registration_no": "SYNTHETIC-A19",
                "country": "US",
                "address": "Synthetic address",
                "base_currency": {"kind": "currency", "id": "USD", "revision": 1},
                "timezone": "UTC",
                "policy_scope": "Synthetic tests only",
            },
        )
        evaluation = fixture.evaluate()
        self.snapshot = self.core.execute(
            self.reviewer, fixture.freeze_request(evaluation)
        )["result"]
        self.core.t03_config_verify_source(
            self.reviewer, "source.1", verified=True, reason="Synthetic A19 source"
        )
        self.core.t03_config_select_pricing_policy(
            self.reviewer,
            {"kind": "pricing_policy", "id": "policy.1", "revision": 1},
            reason="Synthetic A19 policy",
        )
        prepare_sales(fixture)

    def tearDown(self):
        self.tmp.cleanup()

    def config(self, actor, action, key, args):
        return self.core.execute(
            actor,
            {
                "contract": "brant.quotation-foundation/0.1.0",
                "command": "quotation_foundation." + action,
                "idempotency_key": key,
                "args": args,
            },
        )

    def publish_template(self):
        template = {
            "name": "Synthetic A19 template",
            "language": "en",
            "renderer_version": "quote-text/0.1.0",
            "title": "SYNTHETIC QUOTATION",
            "sections": list(SECTIONS),
            "footer_note": "Synthetic only; not an offer.",
        }
        saved = self.config(
            self.author,
            "save_draft",
            "a19.template.save",
            {
                "kind": "quote_document_template",
                "id": "template.a19",
                "expected_version": 0,
                "data": template,
            },
        )
        self.assertTrue(saved["ok"], saved)
        published = self.config(
            self.reviewer,
            "publish",
            "a19.template.publish",
            {
                "kind": "quote_document_template",
                "id": "template.a19",
                "expected_version": 1,
                "working_revision": 1,
                "reason": "Synthetic independent review",
                "evidence": [{"source_id": "source.1", "locator": "A19 test"}],
            },
        )
        self.assertTrue(published["ok"], published)

    def quote_data(self):
        return complete({
            "issuer_ref": {"kind": "company", "id": "company.live", "revision": 1},
            "snapshot_ref": {
                "id": self.snapshot["id"],
                "result_hash": self.snapshot["result_hash"],
            },
            "currency_ref": {"kind": "currency", "id": "USD", "revision": 1},
            "pricing_policy_ref": {
                "kind": "pricing_policy",
                "id": "policy.1",
                "revision": 1,
            },
            "payment_terms_ref": {
                "kind": "payment_terms",
                "id": "payment.test",
                "revision": 1,
            },
            "customer_ref": {
                "kind": "customer",
                "id": "customer.1",
                "row_version": 2,
            },
            "customer_profile_ref": {
                "kind": "party_profile", "id": "customer.profile", "revision": 1,
            },
            "customer_address_id": "customer.billing",
            "document_template_ref": {
                "kind": "quote_document_template",
                "id": "template.a19",
                "revision": 1,
            },
            "lines": [
                {
                    "line_id": "L1",
                    "sku_profile_ref": {
                        "kind": "sku_profile",
                        "id": "sku.1.profile",
                        "revision": 1,
                    },
                    "quantity": "120",
                    "unit_price": "8",
                    "price_basis_quantity": "1",
                    "discount_ratio": "0",
                    "tax_application_ref": {
                        "kind": "sales_tax_application",
                        "id": "sales.goods.default",
                        "revision": 1,
                    },
                }
            ],
            "charges": [],
            "expires_at": "2026-10-29T09:00:00Z",
        })

    def publish_tax_application(self):
        data = {
            "name": "Synthetic A19 tax application",
            "business_model": "CN-M01",
            "use": "quotation_sale",
            "subject_kind": "sku_profile",
            "subject_ref": {
                "kind": "sku_profile",
                "id": "sku.1.profile",
                "revision": 1,
            },
            "issuer_ref": {"kind": "company", "id": "company.live", "revision": 1},
            "customer_ref": {
                "kind": "customer",
                "id": "customer.1",
                "row_version": 2,
            },
            "tax_profile_ref": {"kind": "tax_profile", "id": "tax.zero", "revision": 1},
            "jurisdiction": "SYNTHETIC",
            "basis_note": "Synthetic arithmetic only; no legal tax conclusion.",
            "valid_from": "2026-10-22T00:00:00Z",
            "valid_until": "2026-10-29T00:00:00Z",
        }
        saved = self.config(
            self.author,
            "save_draft",
            "a19.tax.save",
            {
                "kind": "sales_tax_application",
                "id": "tax.a19",
                "expected_version": 0,
                "data": data,
            },
        )
        self.assertTrue(saved["ok"], saved)
        published = self.config(
            self.reviewer,
            "publish",
            "a19.tax.publish",
            {
                "kind": "sales_tax_application",
                "id": "tax.a19",
                "expected_version": 1,
                "working_revision": 1,
                "reason": "Synthetic independent review",
                "evidence": [{"source_id": "source.1", "locator": "A19 tax test"}],
            },
        )
        self.assertTrue(published["ok"], published)

    def test_published_template_is_consumed_and_bound_to_formal_file(self):
        self.publish_template()
        draft = self.core.t03_quote_save_draft(self.author, "quote.a19", self.quote_data())
        frozen = self.core.t03_quote_freeze(
            self.author, "quote.a19", expected_root_version=draft["root_version"]
        )
        request = self.core.t03_quote_submit_review(
            self.author,
            "quote.a19",
            expected_root_version=frozen["root_version"],
            review_request_id="review.a19",
            target_command="quote.activate",
        )
        self.core.t03_quote_decide_review(
            self.reviewer,
            "review.a19",
            decision="approved",
            approval_id="approval.a19",
            business_hash=request["business_hash"],
            expires_at="2026-10-28T09:00:00Z",
        )
        activated = self.core.t03_quote_activate(
            self.author,
            "quote.a19",
            expected_root_version=request["root_version"],
            approval_id="approval.a19",
            number_id="number.a19",
            document_id="document.a19",
            file_id="file.a19",
        )
        self.assertEqual(activated["status"], "active")
        with sqlite3.connect(self.core.path) as db:
            content = db.execute(
                "SELECT content FROM business_file WHERE id='file.a19'"
            ).fetchone()[0]
            file_template = db.execute(
                "SELECT template_id,template_revision FROM business_file WHERE id='file.a19'"
            ).fetchone()
            bindings = db.execute(
                "SELECT role,kind,id,revision FROM t03_document_config_binding"
            ).fetchall()
        self.assertIn(b"SYNTHETIC QUOTATION", content)
        self.assertIn(b"template_data_sha256=", content)
        self.assertEqual(file_template, ("template.a19", 1))
        self.assertEqual(bindings, [
            ("document_template", "quote_document_template", "template.a19", 1),
            ("line:L1:sales_tax_application", "sales_tax_application", "sales.goods.default", 1),
        ])
        history = self.core.execute(
            self.reviewer,
            {
                "contract": "brant.quotation/0.1.0",
                "kind": "document_history",
                "args": {"document_id": "document.a19"},
            },
        )
        self.assertTrue(history["ok"], history)
        self.assertEqual(history["value"]["configuration_bindings"][0]["id"], "template.a19")

    def test_published_sales_tax_application_is_consumed_and_bound(self):
        self.publish_template()
        self.publish_tax_application()
        data = self.quote_data()
        data["lines"][0]["tax_application_ref"] = {
            "kind": "sales_tax_application",
            "id": "tax.a19",
            "revision": 1,
        }
        draft = self.core.t03_quote_save_draft(self.author, "quote.a19.tax", data)
        frozen = self.core.t03_quote_freeze(
            self.author, "quote.a19.tax", expected_root_version=draft["root_version"]
        )
        with sqlite3.connect(self.core.path) as db:
            calculation = db.execute(
                "SELECT calculation_json FROM t03_quote_revision WHERE quote_id='quote.a19.tax'"
            ).fetchone()[0]
        self.assertIn("configuration_bindings", calculation)
        self.assertIn("tax.a19", calculation)
        self.assertEqual(frozen["status"], "frozen")
        request = self.core.t03_quote_submit_review(
            self.author,
            "quote.a19.tax",
            expected_root_version=frozen["root_version"],
            review_request_id="review.a19.tax",
            target_command="quote.activate",
        )
        self.core.t03_quote_decide_review(
            self.reviewer,
            "review.a19.tax",
            decision="approved",
            approval_id="approval.a19.tax",
            business_hash=request["business_hash"],
            expires_at="2026-10-28T09:00:00Z",
        )
        self.core.t03_quote_activate(
            self.author,
            "quote.a19.tax",
            expected_root_version=request["root_version"],
            approval_id="approval.a19.tax",
            number_id="number.a19.tax",
            document_id="document.a19.tax",
            file_id="file.a19.tax",
        )
        with sqlite3.connect(self.core.path) as db:
            binding_roles = db.execute(
                "SELECT role,kind,id FROM t03_document_config_binding "
                "WHERE document_id='document.a19.tax' ORDER BY role"
            ).fetchall()
        self.assertEqual(
            binding_roles,
            [
                ("document_template", "quote_document_template", "template.a19"),
                ("line:L1:sales_tax_application", "sales_tax_application", "tax.a19"),
            ],
        )

    def test_controlled_configuration_cannot_be_consumed_during_freeze(self):
        self.publish_template()
        self.core.t03_bind_object_control(
            self.author,
            "quotation_foundation.quote_document_template",
            "template.a19",
            "task.a19.template",
        )
        draft = self.core.t03_quote_save_draft(
            self.author, "quote.a19.control", self.quote_data()
        )
        with self.assertRaises(Rejected) as rejected:
            self.core.t03_quote_freeze(
                self.author,
                "quote.a19.control",
                expected_root_version=draft["root_version"],
            )
        self.assertEqual(rejected.exception.code, "OBJECT_CONTROL_CONFLICT")
        with sqlite3.connect(self.core.path) as db:
            status = db.execute(
                "SELECT status FROM t03_quote_revision WHERE quote_id='quote.a19.control'"
            ).fetchone()[0]
        self.assertEqual(status, "working")

    def test_configuration_reference_requires_conditional_read_permission(self):
        self.publish_template()
        limited = Principal("tenant.live", "company.live", "limited")
        self.core.provision(
            limited,
            [
                "quote.write",
                "quote.read",
                "quote.freeze",
                "costing.read",
                "read",
                "foundation.read",
            ],
            team_id="trade",
            data_scope="company",
        )
        draft = self.core.t03_quote_save_draft(
            limited, "quote.a19.permission", self.quote_data()
        )
        with self.assertRaises(Rejected) as rejected:
            self.core.t03_quote_freeze(
                limited,
                "quote.a19.permission",
                expected_root_version=draft["root_version"],
            )
        self.assertEqual(rejected.exception.code, "PERMISSION_DENIED")

    def test_revoked_publication_evidence_blocks_formalization_atomically(self):
        self.publish_template()
        draft = self.core.t03_quote_save_draft(
            self.author, "quote.a19.revoked", self.quote_data()
        )
        frozen = self.core.t03_quote_freeze(
            self.author, "quote.a19.revoked", expected_root_version=draft["root_version"]
        )
        request = self.core.t03_quote_submit_review(
            self.author,
            "quote.a19.revoked",
            expected_root_version=frozen["root_version"],
            review_request_id="review.a19.revoked",
            target_command="quote.activate",
        )
        self.core.t03_quote_decide_review(
            self.reviewer,
            "review.a19.revoked",
            decision="approved",
            approval_id="approval.a19.revoked",
            business_hash=request["business_hash"],
            expires_at="2026-10-28T09:00:00Z",
        )
        self.core.t03_config_verify_source(
            self.reviewer,
            "source.1",
            verified=False,
            reason="Synthetic post-approval evidence revocation",
        )
        with self.assertRaises(Rejected) as rejected:
            self.core.t03_quote_activate(
                self.author,
                "quote.a19.revoked",
                expected_root_version=request["root_version"],
                approval_id="approval.a19.revoked",
                number_id="number.a19.revoked",
                document_id="document.a19.revoked",
                file_id="file.a19.revoked",
            )
        self.assertEqual(rejected.exception.code, "REFERENCE_STALE")
        with sqlite3.connect(self.core.path) as db:
            for table in (
                "t03_document_binding",
                "t03_document_config_binding",
                "document_number",
                "business_file",
                "t03_commit_evidence",
                "t03_quote_outbox",
            ):
                count = db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                self.assertEqual(count, 0, table)


if __name__ == "__main__":
    unittest.main()
