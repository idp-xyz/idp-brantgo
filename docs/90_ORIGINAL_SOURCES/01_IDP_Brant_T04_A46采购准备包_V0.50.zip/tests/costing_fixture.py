"""Synthetic business records created exclusively through public Core APIs."""

import json
from copy import deepcopy
from pathlib import Path

from brant_core import Principal


class TradeFixture:
    def __init__(self, core):
        self.core = core
        self.author = Principal("tenant.live", "company.live", "author")
        self.reviewer = Principal("tenant.live", "company.live", "reviewer")
        self.n = 0

    def call(self, contract, command, args, who=None, key=None):
        self.n += 1
        result = self.core.execute(
            who or self.author,
            {
                "contract": contract,
                "command": command,
                "args": deepcopy(args),
                "idempotency_key": key or f"fixture.{self.n}",
            },
        )
        if not result["ok"]:
            raise AssertionError((command, args, result))
        return result

    def old(self, command, args, who=None):
        return self.call("brant.trade-core/0.1.0", command, args, who)

    def foundation(self, kind, id_, data):
        saved = self.call(
            "brant.foundation/0.1.0",
            "foundation.save",
            {
                "kind": kind,
                "id": id_,
                "expected_version": 0,
                "data": data,
                "evidence_ids": ["source.1"],
            },
        )
        self.call(
            "brant.foundation/0.1.0",
            "foundation.publish",
            {
                "kind": kind,
                "id": id_,
                "expected_version": saved["row_version"],
                "revision": saved["revision"],
                "reason": "合成资料独立复核",
            },
            self.reviewer,
        )

    def extension(self, kind, id_, data):
        self.call(
            "brant.foundation-extension/0.1.0",
            "foundation_extension.save_draft",
            {
                "kind": kind,
                "id": id_,
                "expected_version": 0,
                "data": data,
            },
        )
        self.call(
            "brant.foundation-extension/0.1.0",
            "foundation_extension.publish",
            {
                "kind": kind,
                "id": id_,
                "expected_version": 1,
                "working_revision": 1,
                "evidence": [{"source_id": "source.1", "locator": "合成复核资料"}],
            },
            self.reviewer,
        )

    def prepare(self):
        for id_ in ("source.1", "source.2"):
            self.old(
                "source.register",
                {"id": id_, "source_kind": "manual_text", "content_text": "合成核价来源 " + id_},
            )
            self.core.attest_costing_source(self.reviewer, id_, "人工核实合成来源真实性")
        for id_, kind, extra in [
            ("customer.1", "customer", {}),
            ("contact.1", "contact", {"parent_customer_id": "customer.1"}),
            ("supplier.1", "supplier", {}),
            ("provider.1", "supplier", {}),
            ("sku.1", "sku", {"base_uom": "PCS"}),
        ]:
            self.old(
                "master.upsert_draft",
                {"id": id_, "kind": kind, "name": id_, "expected_version": 0, **extra},
            )
            self.old(
                "master.confirm",
                {"id": id_, "expected_version": 1, "evidence_ids": ["source.1"]},
                self.reviewer,
            )
        registry = json.loads(
            (Path(__file__).parent / "fixtures/costing_registry.json").read_text()
        )
        for item in registry["configs"]:
            kind, id_ = item["ref"]["kind"], item["ref"]["id"]
            data = deepcopy(item["data"])
            if kind in ("location", "trade_scope", "tax_application"):
                if kind == "location":
                    data = {"code": id_, "name": "合成地点", "country": "CN", "place_type": "port"}
                if kind == "tax_application":
                    data["counterparty_ref"]["row_version"] = 2
                self.extension(kind, id_, data)
                continue
            if kind == "unit":
                data["name"] = "件"
            elif kind == "currency":
                data["name"] = "美元"
            elif kind == "sku_profile":
                data.update(
                    item_name="合成商品",
                    description="合成规格",
                    sku_row_version=2,
                    base_unit={"kind": "unit", "id": "PCS", "revision": 1},
                )
            elif kind == "pricing_policy":
                data = {
                    "name": "合成核价政策",
                    "calculation_currency": {"kind": "currency", "id": "USD", "revision": 1},
                    "minimum_margin": "0.1",
                    "quote_valid_days": 7,
                    "max_fx_age_seconds": 3600,
                    "independent_review": True,
                    "tax_profile": {"kind": "tax_profile", "id": "tax.zero", "revision": 1},
                }
            elif kind == "fee_type":
                data = {
                    "name": "合成运费",
                    "category": "freight",
                    "side": "purchase_cost",
                    "inclusion": "separate",
                    "allocation_basis": "quantity",
                    "policy_basis": "合成依据",
                }
            # Payment terms depend on a calendar appearing later in the candidate
            # fixture; create it before publishing the referencing configuration.
            if kind == "payment_terms":
                calendar = next(c for c in registry["configs"] if c["ref"]["kind"] == "calendar")
                self.foundation("calendar", calendar["ref"]["id"], calendar["data"])
            if kind == "calendar":
                continue
            self.foundation(kind, id_, data)
        self.core.configure_costing(
            self.reviewer, {"kind": "pricing_policy", "id": "policy.1", "revision": 1}
        )
        self.old(
            "rfq.save_draft",
            {
                "id": "rfq.1",
                "expected_version": 0,
                "customer_id": "customer.1",
                "contact_id": "contact.1",
                "source_ids": ["source.1"],
                "lines": [
                    {
                        "line_id": "L1",
                        "sku_id": "sku.1",
                        "quantity": "120",
                        "uom": "PCS",
                        "source_id": "source.1",
                        "locator": "第1行",
                    }
                ],
            },
        )
        self.old(
            "rfq.confirm_scope",
            {"id": "rfq.1", "expected_version": 1, "evidence_ids": ["source.1"]},
            self.reviewer,
        )
        inputs = json.loads((Path(__file__).parent / "fixtures/costing_inputs.json").read_text())
        for request in inputs:
            if request["command"] == "measurement.record_verified":
                continue
            if "supplier_ref" in request["args"]["data"]:
                request["args"]["data"]["supplier_ref"]["row_version"] = 2
            if "party_ref" in request["args"]["data"]:
                request["args"]["data"]["party_ref"]["row_version"] = 2
        # Dependency order: context, supplier, service role, logistics, scenario.
        for request in inputs:
            command = request["command"]
            if command == "measurement.record_verified":
                continue
            self.call("brant.costing/0.1.0", command, request["args"])
            kind = command.split(".")[0]
            if kind != "cost_scenario":
                self.call(
                    "brant.costing/0.1.0",
                    kind + ".verify",
                    {
                        "id": request["args"]["id"],
                        "expected_version": 1,
                        "working_revision": 1,
                        "evidence": [{"source_id": "source.1", "locator": "核实合成输入"}],
                    },
                    self.reviewer,
                )
        return self

    def evaluate(self):
        return self.call(
            "brant.costing/0.1.0",
            "cost_scenario.evaluate",
            {"id": "scenario.1", "expected_version": 1},
            self.reviewer,
        )

    def freeze_request(self, evaluation, key="freeze.one"):
        return {
            "contract": "brant.costing/0.1.0",
            "command": "cost_snapshot.freeze",
            "idempotency_key": key,
            "args": {
                "scenario_id": "scenario.1",
                "expected_version": 1,
                "result_id": evaluation["result"]["id"],
                "result_hash": evaluation["result_hash"],
                "selection_reason": "同口径成本已核实",
            },
        }
