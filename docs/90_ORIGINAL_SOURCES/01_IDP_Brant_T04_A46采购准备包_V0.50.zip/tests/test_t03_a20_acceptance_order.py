import copy
import hashlib
import sqlite3
import subprocess
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from brant_core import t03_storage
from brant_core.common import Rejected
from tests.test_t03_a19_configuration_consumption import A19ConfigurationConsumptionTests


class A20AcceptanceOrderTests(unittest.TestCase):
    def setUp(self):
        self.base = A19ConfigurationConsumptionTests(
            "test_published_template_is_consumed_and_bound_to_formal_file"
        )
        self.base.setUp()
        self.core, self.author, self.reviewer = (
            self.base.core,
            self.base.author,
            self.base.reviewer,
        )
        self.base.publish_template()
        self.base.publish_tax_application()
        data = self.base.quote_data()
        data["contact_ref"] = {"kind": "contact", "id": "contact.1", "row_version": 2}
        draft = self.core.t03_quote_save_draft(self.author, "quote.a20", data)
        frozen = self.core.t03_quote_freeze(
            self.author, "quote.a20", expected_root_version=draft["root_version"]
        )
        submitted = self.core.t03_quote_submit_review(
            self.author,
            "quote.a20",
            expected_root_version=frozen["root_version"],
            review_request_id="review.a20",
            target_command="quote.activate",
        )
        self.core.t03_quote_decide_review(
            self.reviewer,
            "review.a20",
            decision="approved",
            approval_id="approval.a20",
            business_hash=submitted["business_hash"],
            expires_at="2026-10-28T09:00:00Z",
        )
        self.active = self.core.t03_quote_activate(
            self.author,
            "quote.a20",
            expected_root_version=submitted["root_version"],
            approval_id="approval.a20",
            number_id="number.a20",
            document_id="document.a20",
            file_id="file.a20",
        )
        revision = self.core.t03_quote_get(self.author, "quote.a20")["revisions"][0]
        self.acceptance = {
            "acceptance_id": "acceptance.a20",
            "quote_id": "quote.a20",
            "quote_business_revision": self.active["business_revision"],
            "quote_business_hash": revision["business_hash"],
            "customer_ref": data["customer_ref"],
            "contact_ref": data["contact_ref"],
            "kind": "full_unconditional",
            "source_ref": {"source_id": "source.1", "locator": "synthetic acceptance"},
            "source_message_id": "message.a20",
            "source_author": "Synthetic customer",
            "forward_chain_ref": None,
            "recorded_at": "2026-10-22T10:00:00Z",
            "verified_at": "2026-10-22T11:00:00Z",
            "verification_mode": "human_verified",
            "verified_by": "reviewer",
            "line_ids": ["L1"],
        }
        self.business_hash = revision["business_hash"]
        self.core.clock = lambda: __import__("datetime").datetime(
            2026, 10, 22, 12, tzinfo=__import__("datetime").UTC
        )

    def tearDown(self):
        self.base.tearDown()

    def test_acceptance_is_version_bound_and_order_full_v1_is_idempotent(self):
        accepted = self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        self.assertEqual(accepted["status"], "verified")
        order = self.core.t03_order_prepare(
            self.author,
            "quote.a20",
            business_revision=1,
            business_hash=self.business_hash,
            acceptance_id="acceptance.a20",
        )
        replay = self.core.t03_order_prepare(
            self.author,
            "quote.a20",
            business_revision=1,
            business_hash=self.business_hash,
            acceptance_id="acceptance.a20",
        )
        self.assertEqual(order["order_id"], replay["order_id"])
        with self.assertRaises(Rejected) as ctx:
            self.core.t03_order_prepare(
                self.author,
                "quote.a20",
                business_revision=1,
                business_hash=self.business_hash,
                acceptance_id="acceptance.a20b",
            )
        self.assertEqual(ctx.exception.code, "ACCEPTANCE_SCOPE_MISMATCH")

    def test_late_and_duplicate_confirmation_are_rejected_without_residue(self):
        late = dict(
            self.acceptance,
            acceptance_id="acceptance.late",
            source_message_id="message.late",
            verified_at="2026-10-30T10:00:00Z",
        )
        self.core.clock = lambda: __import__("datetime").datetime(2026, 10, 30, 12, tzinfo=__import__("datetime").UTC)
        with self.assertRaises(Rejected) as ctx:
            self.core.t03_quote_record_acceptance(self.reviewer, late)
        self.assertEqual(ctx.exception.code, "QUOTE_EXPIRED")
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        duplicate = dict(self.acceptance, acceptance_id="acceptance.other")
        with self.assertRaises(Rejected) as ctx:
            self.core.t03_quote_record_acceptance(self.reviewer, duplicate)
        self.assertEqual(ctx.exception.code, "SOURCE_MESSAGE_DUPLICATE")
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(db.execute("select count(*) from t03_acceptance").fetchone()[0], 1)

    def test_wrong_version_and_unapproved_activation_are_blocked(self):
        wrong = dict(self.acceptance, acceptance_id="acceptance.wrong", quote_business_hash="0" * 64)
        with self.assertRaises(Rejected) as ctx:
            self.core.t03_quote_record_acceptance(self.reviewer, wrong)
        self.assertEqual(ctx.exception.code, "ACCEPTANCE_SCOPE_MISMATCH")
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        order = self.core.t03_order_prepare(
            self.author,
            "quote.a20",
            business_revision=1,
            business_hash=self.business_hash,
            acceptance_id="acceptance.a20",
        )
        with self.assertRaises(Rejected) as ctx:
            self.core.t03_order_activate(
                self.author,
                order["order_id"],
                expected_row_version=1,
                approval_id="approval.missing",
            )
        self.assertEqual(ctx.exception.code, "APPROVAL_REQUIRED")

    def test_acceptance_and_order_queries_are_scoped(self):
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        order = self.core.t03_order_prepare(
            self.author,
            "quote.a20",
            business_revision=1,
            business_hash=self.business_hash,
            acceptance_id="acceptance.a20",
        )
        acceptance = self.core.execute(
            self.reviewer,
            {"contract": "brant.quotation/0.1.0", "kind": "acceptance_history", "args": {"acceptance_id": "acceptance.a20"}},
        )
        order_view = self.core.execute(
            self.author,
            {"contract": "brant.quotation/0.1.0", "kind": "order_history", "args": {"order_id": order["order_id"]}},
        )
        self.assertTrue(acceptance["ok"])
        self.assertTrue(order_view["ok"])
        self.assertEqual(order_view["value"]["acceptance_id"], "acceptance.a20")

    def test_order_prepare_failure_rolls_back_order_and_event(self):
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        original = t03_storage.prepare_order

        def fail_after_write(*args, **kwargs):
            original(*args, **kwargs)
            raise RuntimeError("injected A21 failure before commit")

        t03_storage.prepare_order = fail_after_write
        try:
            with self.assertRaisesRegex(RuntimeError, "injected A21"):
                self.core.t03_order_prepare(
                    self.author, "quote.a20", business_revision=1,
                    business_hash=self.business_hash, acceptance_id="acceptance.a20"
                )
        finally:
            t03_storage.prepare_order = original
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(db.execute("select count(*) from t03_order").fetchone()[0], 0)
            self.assertEqual(db.execute("select count(*) from t03_order_event").fetchone()[0], 0)
        order = self.core.t03_order_prepare(
            self.author, "quote.a20", business_revision=1,
            business_hash=self.business_hash, acceptance_id="acceptance.a20"
        )
        self.assertEqual(order["status"], "draft")

    def test_commit_then_process_exit_reopens_one_active_order(self):
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        order = self.core.t03_order_prepare(
            self.author, "quote.a20", business_revision=1,
            business_hash=self.business_hash, acceptance_id="acceptance.a20"
        )
        script = """
import os, sys
from datetime import UTC, datetime
from brant_core import Core, Principal
core = Core(sys.argv[1], enable_t03=True, clock=lambda: datetime(2026, 10, 22, 12, tzinfo=UTC))
from tests.order_review_fixture import approve_order
author = Principal('tenant.live', 'company.live', 'author')
reviewer = Principal('tenant.live', 'company.live', 'reviewer')
review = approve_order(core, author, reviewer, sys.argv[2])
core.t03_order_activate(author, sys.argv[2], expected_row_version=1, approval_id='approval.a20', order_review_id=review)
os._exit(73)
"""
        child = subprocess.run(
            ["python3", "-c", script, str(self.core.path), order["order_id"]],
            capture_output=True, text=True, timeout=15,
            cwd=str(Path(__file__).parents[1]),
        )
        self.assertEqual(child.returncode, 73, child.stderr)
        from brant_core import Core
        reopened = Core(self.core.path, enable_t03=True)
        replay = reopened.t03_order_activate(
            self.author, order["order_id"], expected_row_version=1, approval_id="approval.a20",
            order_review_id="review.order.fixture"
        )
        self.assertEqual(replay["status"], "active")
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(db.execute("select count(*) from t03_order where status='active'").fetchone()[0], 1)
            self.assertEqual(db.execute("select count(*) from t03_order_event where event_type='activated'").fetchone()[0], 1)

    def test_distinct_public_actions_cannot_bypass_full_v1_slot(self):
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        args = {
            "quote_id": "quote.a20", "business_revision": 1,
            "business_hash": self.business_hash, "acceptance_id": "acceptance.a20",
            "conversion_slot": "full_v1",
        }
        def call(key):
            return self.core.execute(self.author, {
                "contract": "brant.quotation/0.1.0", "command": "order.prepare",
                "idempotency_key": key, "args": copy.deepcopy(args),
            })
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(call, ["order.race.1", "order.race.2"]))
        # The public envelope must expose the domain result or its mapped conflict.
        self.assertTrue(all(result.get("ok") or result.get("code") for result in results), results)
        self.assertEqual(sum(result["ok"] for result in results), 1, results)
        self.assertEqual(sum(result.get("code") == "ROOT_CONVERSION_LOCKED" for result in results), 1)
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(db.execute("select count(*) from t03_order").fetchone()[0], 1)

    def test_action_reconciliation_classifies_committed_missing_and_conflict(self):
        request = {
            "contract": "brant.quotation/0.1.0", "command": "order.prepare",
            "idempotency_key": "reconcile.order", "args": {
                "quote_id": "quote.a20", "business_revision": 1,
                "business_hash": self.business_hash, "acceptance_id": "acceptance.a20",
                "conversion_slot": "full_v1",
            },
        }
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        self.core.execute(self.author, request)
        request_hash = hashlib.sha256(
            __import__("brant_core").common.canonical(request).encode()
        ).hexdigest()
        committed = self.core.execute(
            self.author,
            {"contract": "brant.quotation/0.1.0", "kind": "action_reconciliation", "args": {
                "command": "order.prepare", "idempotency_key": "reconcile.order", "request_hash": request_hash,
            }},
        )
        self.assertEqual(committed["value"]["state"], "committed")
        missing = self.core.execute(
            self.author,
            {"contract": "brant.quotation/0.1.0", "kind": "action_reconciliation", "args": {
                "command": "order.prepare", "idempotency_key": "reconcile.missing", "request_hash": request_hash,
            }},
        )
        self.assertEqual(missing["value"]["state"], "not_committed")
        conflict = self.core.execute(
            self.author,
            {"contract": "brant.quotation/0.1.0", "kind": "action_reconciliation", "args": {
                "command": "order.prepare", "idempotency_key": "reconcile.order", "request_hash": "0" * 64,
            }},
        )
        self.assertEqual(conflict["value"]["state"], "payload_conflict")
