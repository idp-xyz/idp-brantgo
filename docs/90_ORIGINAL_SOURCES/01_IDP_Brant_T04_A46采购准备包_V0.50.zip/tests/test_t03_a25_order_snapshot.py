"""Synthetic local order snapshot checks; no downstream or production admission."""

import copy
import hashlib
import json
import sqlite3
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

from brant_core import Core, t03_storage, t03_write
from brant_core.common import Rejected, canonical
from tests import test_t03_a20_acceptance_order as fixtures
from tests import test_t03_a23_reconciliation_access as recovery
from tests.costing_fixture import TradeFixture
from tests.order_review_fixture import approve_order
from tests.t03_sales_fixture import publish_application
from tests.t03_scope_fixture import recost


class A25OrderSnapshotTests(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.A20AcceptanceOrderTests(
            "test_acceptance_is_version_bound_and_order_full_v1_is_idempotent"
        )
        self.fixture.setUp()
        self.addCleanup(self.fixture.tearDown)
        self.core = self.fixture.core
        self.author, self.reviewer = self.fixture.author, self.fixture.reviewer
        self.quote_id = "quote.a20"
        self.acceptance = dict(self.fixture.acceptance)
        self.acceptance.pop("verification_mode")
        self.business_hash = self.fixture.business_hash

    def prepare_args(self):
        return {
            "quote_id": self.quote_id,
            "business_revision": 1,
            "business_hash": self.business_hash,
            "acceptance_id": self.acceptance["acceptance_id"],
            "conversion_slot": "full_v1",
        }

    def prepare(self):
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        args = self.prepare_args()
        quote_id = args.pop("quote_id")
        return self.core.t03_order_prepare(self.author, quote_id, **args)

    def public_prepare(self):
        request = recovery.A23ReconciliationAccessTests.request
        accepted = self.core.execute(
            self.reviewer, request("quote.acceptance.verify", "a25.acceptance", self.acceptance)
        )
        self.assertTrue(accepted["ok"], accepted)
        self.prepare_request = request("order.prepare", "a25.prepare", self.prepare_args())
        result = self.core.execute(self.author, self.prepare_request)
        self.assertTrue(result["ok"], result)
        self.activate_request = request(
            "order.activate", "a25.activate",
            {"order_id": result["result"]["order_id"], "expected_row_version": 1,
             "approval_id": "approval.a20", "order_review_id": approve_order(
                 self.core, self.author, self.reviewer, result["result"]["order_id"])},
        )
        return result

    def order(self, order_id):
        with self.core._connection() as db:
            return t03_storage.order_history(db, self.author.scope, order_id)

    def source(self):
        with sqlite3.connect(self.core.path) as db:
            data, calculation = db.execute(
                "SELECT data_json,calculation_json FROM t03_quote_revision WHERE quote_id=?",
                (self.quote_id,),
            ).fetchone()
        return json.loads(data), json.loads(calculation) if calculation else None

    def business_snapshot(self):
        with sqlite3.connect(self.core.path) as db:
            tables = [r[0] for r in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ) if r[0] not in ("audit_event", "sqlite_sequence")]
            return {name: db.execute('SELECT * FROM "' + name + '"').fetchall() for name in tables}

    def corrupt_order(self, order_id, change, *, rehash=False):
        """Explicit corruption injection bypasses the new immutable-column guard."""
        value = self.order(order_id)
        body = value["body"]
        change(body)
        with sqlite3.connect(self.core.path) as db:
            db.execute("DROP TRIGGER IF EXISTS immutable_t03_order_commercial_update")
            db.execute(
                "UPDATE t03_order SET body_json=?,order_hash=? WHERE order_id=?",
                (canonical(body), hashlib.sha256(canonical(body).encode()).hexdigest()
                 if rehash else value["order_hash"], order_id),
            )

    def extended_quote(self):
        """Transfer an extended quote backed by a matching complete cost scope."""
        fixture = TradeFixture(self.core)
        fixture.n = 1000
        fixture.foundation("fee_type", "sales.a25.freight", {
            "name": "Synthetic freight", "category": "freight", "side": "sales_charge",
            "inclusion": "separate", "allocation_basis": "quantity", "policy_basis": "Synthetic",
        })
        charge_tax = publish_application(
            fixture, "sales.a25.tax", {"kind": "fee_type", "id": "sales.a25.freight", "revision": 1}
        )
        data = self.fixture.base.quote_data()
        data.update({
            "contact_ref": self.acceptance["contact_ref"],
            "customer_notes": ["Synthetic agreed note"],
            "evidence": [{"source_id": "source.1", "locator": "synthetic commercial snapshot"}],
            "charges": [{
                "charge_id": "freight.a25", "obligation_key": "freight.a25.1",
                "fee_type_ref": {"kind": "fee_type", "id": "sales.a25.freight", "revision": 1},
                "amount": "10.01", "inclusion": "separate",
                "evidence": [{"source_id": "source.1", "locator": "Synthetic A25 sales obligation"}],
                "tax_application_ref": charge_tax,
            }],
        })
        data["lines"][0]["quantity"] = "60"
        line = copy.deepcopy(data["lines"][0])
        line.update(line_id="L2", rfq_line_id="L2", quantity="60")
        data["lines"].append(line)
        recost(fixture, data)
        self.quote_id = "quote.a25"
        draft = self.core.t03_quote_save_draft(self.author, self.quote_id, data)
        frozen = self.core.t03_quote_freeze(
            self.author, self.quote_id, expected_root_version=draft["root_version"]
        )
        submitted = self.core.t03_quote_submit_review(
            self.author, self.quote_id, expected_root_version=frozen["root_version"],
            review_request_id="review.a25", target_command="quote.activate",
        )
        self.core.t03_quote_decide_review(
            self.reviewer, "review.a25", decision="approved", approval_id="approval.a25",
            business_hash=submitted["business_hash"], expires_at="2026-10-28T09:00:00Z",
        )
        self.core.t03_quote_activate(
            self.author, self.quote_id, expected_root_version=submitted["root_version"],
            approval_id="approval.a25", number_id="number.a25", document_id="document.a25",
            file_id="file.a25",
        )
        self.business_hash = submitted["business_hash"]
        self.acceptance.update(
            acceptance_id="acceptance.a25", quote_id=self.quote_id,
            quote_business_hash=self.business_hash, source_message_id="message.a25",
            line_ids=["L2", "L1"],
        )

    def test_complete_source_and_actual_terms_are_preserved(self):
        self.extended_quote()
        order = self.order(self.prepare()["order_id"])
        payload, calculation = self.source()
        self.assertEqual(order["body"]["terms"]["delivery"], payload["delivery"])
        for key in ("trade_terms_ref", "trade_scope_ref", "named_place_ref", "payment_terms_ref",
                    "issued_at", "expires_at"):
            self.assertEqual(order["body"]["terms"][key], payload[key])
        self.assertEqual(order["body"]["charges"], payload["charges"])
        self.assertEqual(order["body"]["contact_ref"], payload["contact_ref"])
        self.assertEqual(order["body"]["source_quote_snapshot"],
                         {"data": payload, "calculation": calculation})
        self.assertEqual(order["body"]["snapshot_contract"], "brant.order-commercial-snapshot/0.1.0")

    def test_nonzero_charges_lines_and_payment_amounts_are_exact(self):
        self.extended_quote()
        body = self.order(self.prepare()["order_id"])["body"]
        payload, calculation = self.source()
        self.assertEqual(body.get("charges"), payload["charges"])
        self.assertEqual(body["lines"], payload["lines"])
        self.assertEqual(body["calculation"], calculation)
        self.assertEqual(calculation["charges"][0]["net_minor"], "1001")
        self.assertEqual(int(calculation["net_minor"]), 97001)
        payable = int(calculation["payable_minor"])
        self.assertEqual(sum(int(p["amount_minor"]) for p in calculation["payments"]), payable)
        self.assertEqual(sum(int(r["payable_minor"]) for r in
                             calculation["lines"] + calculation["charges"]), payable)

    def test_database_rejects_commercial_column_changes_and_delete(self):
        prepared = self.prepare()
        columns = {
            "tenant": "other", "company": "other", "order_id": "order.other",
            "root_quote_id": "quote.other", "conversion_slot": "other",
            "customer_ref_json": "{}", "source_quote_id": "quote.other",
            "source_quote_revision": 2, "source_quote_hash": "0" * 64,
            "acceptance_id": "other", "body_json": "{}", "order_hash": "0" * 64,
            "created_at": "2099-01-01T00:00:00Z",
        }
        before = self.business_snapshot()
        for column, value in columns.items():
            with self.subTest(column=column), sqlite3.connect(self.core.path) as db:
                with self.assertRaisesRegex(sqlite3.IntegrityError, "immutable.*order"):
                    db.execute(f"UPDATE t03_order SET {column}=? WHERE order_id=?",
                               (value, prepared["order_id"]))
        with sqlite3.connect(self.core.path) as db:
            with self.assertRaisesRegex(sqlite3.IntegrityError, "immutable.*order"):
                db.execute("DELETE FROM t03_order WHERE order_id=?", (prepared["order_id"],))
        self.assertEqual(self.business_snapshot(), before)

    def test_source_hash_corruption_rejects_prepare_without_business_residue(self):
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        with sqlite3.connect(self.core.path) as db:
            db.execute("DROP TRIGGER immutable_t03_quote_revision_payload")
            payload, _ = self.source()
            payload["customer_notes"] = ["corrupt source"]
            db.execute("UPDATE t03_quote_revision SET data_json=? WHERE quote_id=?",
                       (canonical(payload), self.quote_id))
        before = self.business_snapshot()
        with self.assertRaises(Rejected) as rejected:
            args = self.prepare_args()
            quote_id = args.pop("quote_id")
            self.core.t03_order_prepare(self.author, quote_id, **args)
        self.assertEqual(rejected.exception.code, "REFERENCE_INVALID")
        self.assertEqual(self.business_snapshot(), before)

    def test_prepare_does_not_recalculate_an_approved_snapshot(self):
        with patch.object(t03_storage, "_server_calculation", side_effect=AssertionError("recalculated")):
            order = self.order(self.prepare()["order_id"])
        self.assertEqual(order["body"]["calculation"], self.source()[1])

    def test_activation_changes_state_without_changing_commercial_snapshot(self):
        prepared = self.prepare()
        before = self.order(prepared["order_id"])
        self.core.t03_order_activate(self.author, prepared["order_id"],
                                    expected_row_version=1, approval_id="approval.a20",
                                    order_review_id=approve_order(self.core, self.author, self.reviewer,
                                                                  prepared["order_id"]))
        after = self.order(prepared["order_id"])
        self.assertEqual(after["body"], before["body"])
        self.assertEqual(after["order_hash"], before["order_hash"])
        self.assertEqual((after["status"], after["row_version"]), ("active", 2))
        self.assertEqual([e["event_type"] for e in after["events"]], ["prepared", "activated"])
        self.assertEqual(after["order_hash"],
                         hashlib.sha256(canonical(after["body"]).encode()).hexdigest())

    def test_local_public_replay_and_restart_keep_one_snapshot(self):
        public = self.public_prepare()
        order_id = public["result"]["order_id"]
        before = self.order(order_id)
        self.core = Core(self.core.path, enable_t03=True, clock=self.core.clock)
        replay = self.core.execute(self.author, self.prepare_request)
        self.assertTrue(replay["replayed"], replay)
        self.assertEqual(replay["action_id"], public["action_id"])
        local = self.prepare()
        self.assertTrue(local["replayed"])
        self.assertEqual(local["order_id"], order_id)
        self.assertEqual(self.order(order_id), before)

    def test_two_local_preparations_share_one_snapshot_and_event(self):
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        args = self.prepare_args()
        quote_id = args.pop("quote_id")
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: self.core.t03_order_prepare(
                self.author, quote_id, **args), range(2)))
        self.assertEqual(results[0]["order_id"], results[1]["order_id"])
        order = self.order(results[0]["order_id"])
        self.assertEqual(len(order["events"]), 1)
        self.assertEqual(order["body"]["source_quote_snapshot"]["data"], self.source()[0])

    def test_rehashed_changed_projection_is_rejected_before_activation(self):
        order_id = self.prepare()["order_id"]
        self.corrupt_order(order_id, lambda body: body["lines"][0].update(quantity="1"), rehash=True)
        before = self.business_snapshot()
        with self.assertRaises(Rejected) as rejected:
            self.core.t03_order_activate(self.author, order_id, expected_row_version=1,
                                        approval_id="approval.a20")
        self.assertEqual(rejected.exception.code, "REFERENCE_INVALID")
        self.assertEqual(self.business_snapshot(), before)

    def test_hash_corruption_is_rejected_on_local_existing_result(self):
        order_id = self.prepare()["order_id"]
        self.corrupt_order(order_id, lambda body: body.update(customer_ref={}))
        before = self.business_snapshot()
        with self.assertRaises(Rejected) as rejected:
            self.prepare()
        self.assertEqual(rejected.exception.code, "REFERENCE_INVALID")
        self.assertEqual(self.business_snapshot(), before)

    def test_public_prepare_receipt_replay_rechecks_persisted_snapshot(self):
        order_id = self.public_prepare()["result"]["order_id"]
        self.corrupt_order(order_id, lambda body: body.update(charges=[{"amount": "1"}]), rehash=True)
        before = self.business_snapshot()
        response = self.core.execute(self.author, self.prepare_request)
        self.assertEqual(response.get("code"), "REFERENCE_INVALID", response)
        self.assertEqual(self.business_snapshot(), before)

    def test_public_active_receipt_replay_rechecks_persisted_snapshot(self):
        order_id = self.public_prepare()["result"]["order_id"]
        self.assertTrue(self.core.execute(self.author, self.activate_request)["ok"])
        self.corrupt_order(order_id, lambda body: body.update(currency_ref={}), rehash=True)
        before = self.business_snapshot()
        response = self.core.execute(self.author, self.activate_request)
        self.assertEqual(response.get("code"), "REFERENCE_INVALID", response)
        self.assertEqual(self.business_snapshot(), before)

    def test_local_active_replay_rechecks_persisted_snapshot(self):
        order_id = self.prepare()["order_id"]
        self.core.t03_order_activate(self.author, order_id, expected_row_version=1,
                                    approval_id="approval.a20", order_review_id=approve_order(
                                        self.core, self.author, self.reviewer, order_id))
        self.corrupt_order(order_id, lambda body: body.update(calculation=None), rehash=True)
        before = self.business_snapshot()
        with self.assertRaises(Rejected) as rejected:
            self.core.t03_order_activate(self.author, order_id, expected_row_version=1,
                                        approval_id="approval.a20")
        self.assertEqual(rejected.exception.code, "REFERENCE_INVALID")
        self.assertEqual(self.business_snapshot(), before)

    def test_prepare_failure_rolls_back_snapshot_events_and_success_ledger(self):
        request = recovery.A23ReconciliationAccessTests.request
        self.assertTrue(self.core.execute(self.reviewer, request(
            "quote.acceptance.verify", "a25.acceptance", self.acceptance))["ok"])
        prepare = request("order.prepare", "a25.prepare.failure", self.prepare_args())
        before = self.business_snapshot()
        original = t03_storage.prepare_order

        def fail(*args, **kwargs):
            original(*args, **kwargs)
            raise RuntimeError("A25 synthetic failure before commit")

        with patch.object(t03_storage, "prepare_order", side_effect=fail):
            with self.assertRaisesRegex(RuntimeError, "A25 synthetic"):
                self.core.execute(self.author, prepare)
        self.assertEqual(self.business_snapshot(), before)
        self.assertTrue(self.core.execute(self.author, prepare)["ok"])

    def legacy_order(self, order_id):
        def legacy(body):
            body.pop("snapshot_contract", None)
            body.pop("source_quote_snapshot", None)
            body.pop("contact_ref", None)
            body.pop("charges", None)
        self.corrupt_order(order_id, legacy, rehash=True)

    def test_legacy_order_is_readable_but_not_silently_upgraded_or_activated(self):
        order_id = self.prepare()["order_id"]
        self.legacy_order(order_id)
        query = {"contract": "brant.quotation/0.1.0", "kind": "order_history",
                 "args": {"order_id": order_id}}
        history = self.core.execute(self.author, query)
        self.assertTrue(history["ok"], history)
        self.assertNotIn("snapshot_contract", history["value"]["body"])
        before = self.business_snapshot()
        with self.assertRaises(Rejected) as rejected:
            self.core.t03_order_activate(self.author, order_id, expected_row_version=1,
                                        approval_id="approval.a20")
        self.assertEqual(rejected.exception.code, "REFERENCE_INVALID")
        self.assertEqual(self.business_snapshot(), before)

    def test_legacy_committed_receipt_remains_observational_but_write_replay_is_blocked(self):
        original = self.public_prepare()
        order_id = original["result"]["order_id"]
        self.legacy_order(order_id)
        before = self.business_snapshot()
        receipt = self.core.execute(
            self.author, recovery.A23ReconciliationAccessTests.query(self.prepare_request)
        )
        self.assertEqual(receipt["value"]["state"], "committed")
        replay = self.core.execute(self.author, self.prepare_request)
        self.assertEqual(replay.get("code"), "REFERENCE_INVALID", replay)
        self.assertEqual(self.business_snapshot(), before)

    def downgrade_to_eleven(self):
        with sqlite3.connect(self.core.path) as db:
            for table in ("t04_purchase_draft_line", "t04_purchase_draft", "t04_order_review_revocation", "t04_order_review_activation", "t04_order_review_decision", "t04_order_review_request"):
                db.execute(f"DROP TABLE {table}")
            db.execute("DROP TABLE t04_response_verification")
            db.execute("DROP TABLE t04_customer_response")
            db.execute("DROP TRIGGER IF EXISTS immutable_t03_order_commercial_update")
            db.execute("DROP TRIGGER IF EXISTS immutable_t03_order_delete")
            db.execute("DROP TRIGGER IF EXISTS immutable_t03_order_replace")
            db.execute("DELETE FROM schema_migration WHERE version IN (12,13,14,15,16,17)")

    def test_migration_twelve_keeps_legacy_bytes_and_adds_guards_idempotently(self):
        order_id = self.prepare()["order_id"]
        self.legacy_order(order_id)
        self.downgrade_to_eleven()
        before = self.order(order_id)
        for _ in range(2):
            self.core = Core(self.core.path, enable_t03=True, clock=self.core.clock)
            self.assertEqual(self.order(order_id), before)
            with sqlite3.connect(self.core.path) as db:
                self.assertEqual([r[0] for r in db.execute(
                    "SELECT version FROM schema_migration ORDER BY version")], list(range(1, 18)))
                self.assertEqual(db.execute(
                    "SELECT count(*) FROM sqlite_master WHERE type='trigger' "
                    "AND name IN ('immutable_t03_order_commercial_update','immutable_t03_order_delete',"
                    "'immutable_t03_order_replace')"
                ).fetchone()[0], 3)

    def test_migration_failure_rolls_back_version_and_new_triggers(self):
        self.downgrade_to_eleven()
        original = getattr(t03_storage, "_migrate_a10", None)
        self.assertIsNotNone(original)

        def fail(db):
            original(db)
            raise RuntimeError("A25 migration failure")

        with patch.object(t03_storage, "_migrate_a10", side_effect=fail):
            with self.assertRaisesRegex(RuntimeError, "A25 migration failure"):
                Core(self.core.path, enable_t03=True)
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(db.execute("SELECT max(version) FROM schema_migration").fetchone()[0], 11)
            self.assertEqual(db.execute(
                "SELECT count(*) FROM sqlite_master WHERE type='trigger' "
                "AND name IN ('immutable_t03_order_commercial_update','immutable_t03_order_delete',"
                    "'immutable_t03_order_replace')"
            ).fetchone()[0], 0)
        Core(self.core.path, enable_t03=True, clock=self.core.clock)

    def test_source_builder_rejects_unstructured_and_inconsistent_calculations(self):
        from brant_core import t03_order_snapshot

        payload, calculation = self.source()
        variants = [(payload, None), ({}, calculation)]
        for key in ("net_minor", "tax_minor", "payable_minor"):
            changed = copy.deepcopy(calculation)
            changed[key] = str(int(changed[key]) + 1)
            variants.append((payload, changed))
        changed = copy.deepcopy(calculation)
        changed["payments"][0]["amount_minor"] = "1"
        variants.append((payload, changed))
        changed = copy.deepcopy(calculation)
        changed["lines"][0]["id"] = "other"
        variants.append((payload, changed))
        for data, computed in variants:
            with self.subTest(data=data, calculation=computed), self.assertRaises(Rejected):
                t03_order_snapshot.build(
                    self.author.scope, "order.test", self.quote_id, 1,
                    t03_storage.quote_hash(data, computed), self.acceptance["acceptance_id"],
                    "full_v1", data, computed,
                )

    def test_rehashed_boolean_revision_is_not_equal_to_integer_revision(self):
        order_id = self.prepare()["order_id"]
        self.corrupt_order(order_id, lambda body: body.update(source_quote_revision=True), rehash=True)
        before = self.business_snapshot()
        with self.assertRaises(Rejected) as rejected:
            self.core.t03_order_activate(self.author, order_id, expected_row_version=1,
                                        approval_id="approval.a20")
        self.assertEqual(rejected.exception.code, "REFERENCE_INVALID")
        self.assertEqual(self.business_snapshot(), before)

    def test_database_rejects_replace_by_primary_key_and_root_slot(self):
        order_id = self.prepare()["order_id"]
        before = self.business_snapshot()
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(db.execute("PRAGMA recursive_triggers").fetchone()[0], 0)
            values = list(db.execute("SELECT * FROM t03_order WHERE order_id=?", (order_id,)).fetchone())
            for use_other_id in (False, True):
                changed = list(values)
                if use_other_id:
                    changed[2] = "order.synthetic.replace"
                changed[12] = "{}"
                with self.subTest(other_id=use_other_id), self.assertRaisesRegex(
                    sqlite3.IntegrityError, "immutable.*order"
                ):
                    db.execute("INSERT OR REPLACE INTO t03_order VALUES(" +
                               ",".join("?" for _ in changed) + ")", changed)
        self.assertEqual(self.business_snapshot(), before)

    def test_persisted_order_columns_are_checked_against_snapshot(self):
        order_id = self.prepare()["order_id"]
        variants = {
            "root_quote_id": "other", "source_quote_revision": 2,
            "source_quote_hash": "0" * 64, "customer_ref_json": "{}",
            "acceptance_id": "other",
        }
        with sqlite3.connect(self.core.path) as db:
            db.execute("DROP TRIGGER immutable_t03_order_commercial_update")
            original = dict(zip([r[1] for r in db.execute("PRAGMA table_info(t03_order)")],
                               db.execute("SELECT * FROM t03_order WHERE order_id=?", (order_id,)).fetchone()))
        for key, value in variants.items():
            with sqlite3.connect(self.core.path) as db:
                db.execute(f"UPDATE t03_order SET {key}=? WHERE order_id=?", (value, order_id))
            before = self.business_snapshot()
            with self.subTest(column=key), self.assertRaises(Rejected) as rejected:
                self.core.t03_order_activate(self.author, order_id, expected_row_version=1,
                                            approval_id="approval.a20")
            self.assertEqual(rejected.exception.code, "REFERENCE_INVALID")
            self.assertEqual(self.business_snapshot(), before)
            with sqlite3.connect(self.core.path) as db:
                db.execute(f"UPDATE t03_order SET {key}=? WHERE order_id=?", (original[key], order_id))

    def test_acceptance_line_scope_corruption_rejects_new_order_atomically(self):
        self.core.t03_quote_record_acceptance(self.reviewer, self.acceptance)
        with sqlite3.connect(self.core.path) as db:
            db.execute("UPDATE t03_acceptance SET line_ids_json='[\"other\"]' WHERE acceptance_id=?",
                       (self.acceptance["acceptance_id"],))
        before = self.business_snapshot()
        args = self.prepare_args()
        quote_id = args.pop("quote_id")
        with self.assertRaises(Rejected) as rejected:
            self.core.t03_order_prepare(self.author, quote_id, **args)
        self.assertEqual(rejected.exception.code, "REFERENCE_INVALID")
        self.assertEqual(self.business_snapshot(), before)

    def test_public_receipt_source_identity_must_match_the_actual_order(self):
        receipt = self.public_prepare()
        request = copy.deepcopy(self.prepare_request)
        request["args"]["business_revision"] = 2
        receipt["result"]["source_quote_revision"] = 2
        with sqlite3.connect(self.core.path) as db:
            # Explicit ledger corruption: forge a coherent request/receipt pair
            # that still contradicts the independently persisted order.
            db.execute(
                "UPDATE action_result SET request_hash=?,result_json=? WHERE command=? AND idempotency_key=?",
                (hashlib.sha256(canonical(request).encode()).hexdigest(), canonical(receipt),
                 request["command"], request["idempotency_key"]),
            )
        before = self.business_snapshot()
        response = self.core.execute(self.author, request)
        self.assertEqual(response.get("code"), "REFERENCE_INVALID", response)
        self.assertEqual(self.business_snapshot(), before)


    def test_snapshot_contract_and_order_identity_are_hash_bound(self):
        from brant_core import t03_order_snapshot

        payload, calculation = self.source()
        body = t03_order_snapshot.build(
            self.author.scope, "order.test", self.quote_id, 1, self.business_hash,
            self.acceptance["acceptance_id"], "full_v1", payload, calculation,
        )
        self.assertEqual(body["source_quote_snapshot"], {"data": payload, "calculation": calculation})
        clone = copy.deepcopy(body)
        clone["source_quote_snapshot"]["data"]["lines"][0]["quantity"] = "1"
        self.assertNotEqual(hashlib.sha256(canonical(body).encode()).hexdigest(),
                            hashlib.sha256(canonical(clone).encode()).hexdigest())
        self.assertEqual(self.source()[0], payload)
        self.assertTrue(t03_write.RESPONSE_VALIDATOR.is_valid({
            "ok": False, "command": "order.prepare", "code": "REFERENCE_INVALID", "retriable": False,
        }))


if __name__ == "__main__":
    unittest.main()
