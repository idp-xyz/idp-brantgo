import copy
import sqlite3
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor

from brant_core import Core, Principal, t03_storage
from brant_core.common import Rejected
from tests import test_t03_a20_acceptance_order as fixtures
from tests import test_t03_a23_reconciliation_access as recovery
from tests.order_review_fixture import approve_order

COMMANDS = ("quote.acceptance.verify", "order.prepare", "order.activate")
TASK = "server.task.a24"


class A24WriteControlTests(unittest.TestCase):
    def scenario(self, command):
        fixture = fixtures.A20AcceptanceOrderTests(
            "test_acceptance_is_version_bound_and_order_full_v1_is_idempotent"
        )
        fixture.setUp()
        self.addCleanup(fixture.tearDown)
        self.fixture = fixture
        self.core, self.author, self.reviewer = fixture.core, fixture.author, fixture.reviewer
        acceptance = dict(fixture.acceptance)
        acceptance.pop("verification_mode")
        request = recovery.A23ReconciliationAccessTests.request
        self.acceptance_request = request("quote.acceptance.verify", "a24.acceptance", acceptance)
        self.prepare_request = request(
            "order.prepare",
            "a24.prepare",
            {
                "quote_id": "quote.a20",
                "business_revision": 1,
                "business_hash": fixture.business_hash,
                "acceptance_id": "acceptance.a20",
                "conversion_slot": "full_v1",
            },
        )
        if command != "quote.acceptance.verify":
            self.assertTrue(self.core.execute(self.reviewer, self.acceptance_request)["ok"])
        if command == "quote.acceptance.verify":
            self.who, self.request = self.reviewer, self.acceptance_request
        elif command == "order.prepare":
            self.who, self.request = self.author, self.prepare_request
        else:
            prepared = self.core.execute(self.author, self.prepare_request)
            self.assertTrue(prepared["ok"], prepared)
            self.who = self.author
            self.request = request(
                "order.activate",
                "a24.activate",
                {
                    "order_id": prepared["result"]["order_id"],
                    "expected_row_version": 1,
                    "approval_id": "approval.a20",
                    "order_review_id": approve_order(self.core, self.author, self.reviewer,
                                                     prepared["result"]["order_id"]),
                },
            )

    def local(self, task_id=None):
        command, args = self.request["command"], self.request["args"]
        if command == "quote.acceptance.verify":
            return self.core.t03_quote_record_acceptance(self.who, args, task_id=task_id)
        if command == "order.prepare":
            return self.core.t03_order_prepare(
                self.who,
                args["quote_id"],
                business_revision=args["business_revision"],
                business_hash=args["business_hash"],
                acceptance_id=args["acceptance_id"],
                conversion_slot=args["conversion_slot"],
                task_id=task_id,
            )
        return self.core.t03_order_activate(
            self.who,
            args["order_id"],
            expected_row_version=args["expected_row_version"],
            approval_id=args["approval_id"],
            order_review_id=args["order_review_id"],
            task_id=task_id,
        )

    def snapshot(self):
        with sqlite3.connect(self.core.path) as db:
            tables = [
                row[0]
                for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")
                if row[0] not in ("audit_event", "sqlite_sequence")
            ]
            return {
                name: db.execute('SELECT * FROM "' + name.replace('"', '""') + '"').fetchall()
                for name in tables
            }

    def deny_local(self, code="OBJECT_CONTROL_CONFLICT", task_id=None):
        before = self.snapshot()
        with self.assertRaises(Rejected) as rejected:
            self.local(task_id)
        self.assertEqual(rejected.exception.code, code)
        self.assertEqual(self.snapshot(), before)

    def deny_public(self, code="OBJECT_CONTROL_CONFLICT"):
        before = self.snapshot()
        result = self.core.execute(self.who, self.request)
        self.assertEqual(result.get("code"), code, result)
        self.assertEqual(self.snapshot(), before)

    def bind(self):
        return self.core.t03_bind_object_control(self.author, "quote_root", "quote.a20", TASK)

    def test_bound_root_rejects_missing_task_in_both_entrypoints_without_residue(self):
        for command in COMMANDS:
            with self.subTest(command=command):
                self.scenario(command)
                self.bind()
                self.deny_local()
                self.deny_public()

    def test_matching_server_task_allows_local_write_and_rechecks_replays(self):
        for command in COMMANDS:
            with self.subTest(command=command):
                self.scenario(command)
                self.bind()
                first = self.local(TASK)
                before = self.snapshot()
                replay = self.local(TASK)
                self.assertEqual(first["status"], replay["status"])
                self.assertTrue(replay["replayed"], replay)
                self.assertEqual(self.snapshot(), before)
                self.deny_local()
                self.deny_public()

    def test_wrong_task_and_stale_authority_block_current_task_for_all_three_commands(self):
        for command in COMMANDS:
            with self.subTest(command=command):
                self.scenario(command)
                self.bind()
                self.deny_local(task_id="wrong.task")
                self.core.provision(
                    Principal(*self.author.scope, "a24.observer"),
                    ["quote.read"],
                    data_scope="company",
                )
                self.deny_local(task_id=TASK)
                self.deny_public()

    def test_stopping_blocks_matching_task_until_cas_unbind(self):
        for command in COMMANDS:
            with self.subTest(command=command):
                self.scenario(command)
                bound = self.bind()
                stopped = self.core.t03_stop_object_control(
                    self.author,
                    "quote_root",
                    "quote.a20",
                    expected_control_epoch=bound["control_epoch"],
                )
                self.deny_local(task_id=TASK)
                self.deny_public()
                with self.assertRaises(Rejected):
                    self.core.t03_unbind_object_control(
                        self.author,
                        "quote_root",
                        "quote.a20",
                        expected_control_epoch=bound["control_epoch"],
                    )
                self.core.t03_unbind_object_control(
                    self.author,
                    "quote_root",
                    "quote.a20",
                    expected_control_epoch=stopped["control_epoch"],
                )
                self.assertIn(self.local()["status"], ("verified", "draft", "active"))

    def test_committed_public_replay_and_local_replay_cannot_bypass_new_binding(self):
        for command in COMMANDS:
            with self.subTest(command=command):
                self.scenario(command)
                receipt = self.core.execute(self.who, self.request)
                self.assertTrue(receipt["ok"], receipt)
                self.bind()
                self.deny_public()
                self.deny_local()
                query = recovery.A23ReconciliationAccessTests.query(self.request)
                observed = self.core.execute(self.who, query)
                self.assertEqual(observed["value"]["action_id"], receipt["action_id"])
                self.assertEqual(observed["value"]["state"], "committed")
                before = self.snapshot()
                self.assertTrue(self.local(TASK)["replayed"])
                self.assertEqual(self.snapshot(), before)

    def test_current_permissions_human_identity_and_scope_remain_required_with_task(self):
        for command in COMMANDS:
            with self.subTest(command=command):
                self.scenario(command)
                for grants in ([command], [command, "quote.read"], ["quote.read", "read"]):
                    self.core.provision(self.who, grants, data_scope="company")
                    self.deny_local("PERMISSION_DENIED")
                    self.deny_public("PERMISSION_DENIED")
                self.core.provision(self.who, ["*"], actor_kind="ai", data_scope="company")
                self.deny_local("PERMISSION_DENIED")
                self.deny_public("PERMISSION_DENIED")
                self.core.provision(self.who, ["*"], actor_kind="human", data_scope="company")
                self.bind()
                self.core.provision(self.who, [command, "quote.read"], data_scope="company")
                self.deny_local("PERMISSION_DENIED", task_id=TASK)

    def test_task_identity_cannot_be_supplied_through_public_json(self):
        for command in COMMANDS:
            with self.subTest(command=command):
                self.scenario(command)
                self.bind()
                for location in ("envelope", "args"):
                    forged = copy.deepcopy(self.request)
                    target = forged if location == "envelope" else forged["args"]
                    target["task_id"] = TASK
                    result = self.core.execute(self.who, forged)
                    self.assertEqual(result.get("code"), "SCHEMA_INVALID", result)
                self.deny_public()

    def test_order_activation_does_not_bypass_source_quote_scope(self):
        self.scenario("order.activate")
        outsider = Principal(*self.author.scope, "a24.outsider")
        self.core.provision(outsider, ["*"], data_scope="own", team_id="trade")
        self.who = outsider
        self.deny_local("NOT_FOUND")
        self.deny_public("NOT_FOUND")

    def test_order_activation_rechecks_binding_after_core_restart(self):
        self.scenario("order.activate")
        self.bind()
        self.core = Core(self.core.path, enable_t03=True, clock=self.fixture.core.clock)
        self.deny_local()
        self.deny_public()
        self.assertEqual(self.local(TASK)["status"], "active")

    def test_stop_commits_before_waiting_order_activation_is_rejected(self):
        self.scenario("order.activate")
        bound = self.bind()
        started = threading.Event()

        def activate():
            started.set()
            try:
                self.local(TASK)
                return "unexpected success"
            except Rejected as exc:
                return exc.code

        with ThreadPoolExecutor(max_workers=1) as pool:
            with self.core._connection() as db:
                db.execute("BEGIN IMMEDIATE")
                t03_storage.stop(
                    db,
                    self.author,
                    "quote_root",
                    "quote.a20",
                    expected_control_epoch=bound["control_epoch"],
                )
                future = pool.submit(activate)
                self.assertTrue(started.wait(5))
                db.commit()
            self.assertEqual(future.result(timeout=10), "OBJECT_CONTROL_CONFLICT")
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(db.execute("SELECT status FROM t03_order").fetchone()[0], "draft")
            self.assertEqual(
                db.execute(
                    "SELECT count(*) FROM t03_order_event WHERE event_type='activated'"
                ).fetchone()[0],
                0,
            )

    def test_storage_functions_also_enforce_binding_inside_caller_transaction(self):
        for command in COMMANDS:
            with self.subTest(command=command):
                self.scenario(command)
                self.bind()
                before = self.snapshot()
                args = self.request["args"]
                with self.core._connection() as db:
                    db.execute("BEGIN IMMEDIATE")
                    try:
                        with self.assertRaises(Rejected) as rejected:
                            if command == "quote.acceptance.verify":
                                t03_storage.register_acceptance(self.core, db, self.who, args)
                            elif command == "order.prepare":
                                t03_storage.prepare_order(
                                    self.core,
                                    db,
                                    self.who,
                                    args["quote_id"],
                                    args["business_revision"],
                                    args["business_hash"],
                                    args["acceptance_id"],
                                )
                            else:
                                t03_storage.activate_order(
                                    self.core,
                                    db,
                                    self.who,
                                    args["order_id"],
                                    args["expected_row_version"],
                                    args["approval_id"],
                                )
                        self.assertEqual(rejected.exception.code, "OBJECT_CONTROL_CONFLICT")
                    finally:
                        db.rollback()
                self.assertEqual(self.snapshot(), before)

    def test_task_rebinding_requires_new_server_identity_for_all_three_actions(self):
        for command in COMMANDS:
            with self.subTest(command=command):
                self.scenario(command)
                first = self.bind()
                released = self.core.t03_unbind_object_control(
                    self.author,
                    "quote_root",
                    "quote.a20",
                    expected_control_epoch=first["control_epoch"],
                )
                second = self.core.t03_bind_object_control(
                    self.author,
                    "quote_root",
                    "quote.a20",
                    "server.task.a24.new",
                    expected_control_epoch=released["control_epoch"],
                )
                self.assertGreater(second["control_epoch"], first["control_epoch"])
                self.deny_local(task_id=TASK)
                self.deny_public()
                self.assertIn(
                    self.local("server.task.a24.new")["status"], ("verified", "draft", "active")
                )

    def test_matching_task_does_not_bypass_scope_and_team_changes(self):
        for command in COMMANDS:
            with self.subTest(command=command):
                self.scenario(command)
                original = self.who
                outsider = Principal(*self.author.scope, "a24.scoped.outsider")
                self.core.provision(outsider, ["*"], data_scope="own", team_id="trade")
                self.bind()
                self.who = outsider
                self.deny_local("NOT_FOUND", task_id=TASK)
                self.deny_public("NOT_FOUND")
                self.who = original

    def test_two_local_activations_with_current_task_keep_one_event(self):
        self.scenario("order.activate")
        self.bind()
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: self.local(TASK), range(2)))
        self.assertTrue(all(value["status"] == "active" for value in results), results)
        self.assertEqual(sum(bool(value["replayed"]) for value in results), 1)
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(
                db.execute(
                    "SELECT count(*) FROM t03_order_event WHERE event_type='activated'"
                ).fetchone()[0],
                1,
            )
            self.assertEqual(db.execute("SELECT row_version FROM t03_order").fetchone()[0], 2)
