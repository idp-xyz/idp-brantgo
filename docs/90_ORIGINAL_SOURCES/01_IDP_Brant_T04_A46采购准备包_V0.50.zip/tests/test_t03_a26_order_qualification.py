"""Synthetic same-transaction source admission for new local order activation."""

import json
import sqlite3
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
from unittest.mock import patch

from brant_core import Core, costing, t03_query, t03_storage, t03_write
from brant_core.common import Rejected
from tests import test_t03_a20_acceptance_order as fixtures
from tests import test_t03_a23_reconciliation_access as recovery
from tests.costing_fixture import TradeFixture
from tests.order_review_fixture import approve_order


class A26OrderQualificationTests(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.A20AcceptanceOrderTests(
            "test_acceptance_is_version_bound_and_order_full_v1_is_idempotent"
        )
        self.fixture.setUp()
        self.addCleanup(self.fixture.tearDown)
        self.core = self.fixture.core
        self.author, self.reviewer = self.fixture.author, self.fixture.reviewer
        self.instant = datetime(2026, 10, 22, 12, tzinfo=UTC)
        self.core.clock = lambda: self.instant
        request = recovery.A23ReconciliationAccessTests.request
        acceptance = dict(self.fixture.acceptance)
        acceptance.pop("verification_mode")
        self.assertTrue(self.core.execute(self.reviewer, request(
            "quote.acceptance.verify", "a26.acceptance", acceptance))["ok"])
        self.prepare_request = request("order.prepare", "a26.prepare", {
            "quote_id": "quote.a20", "business_revision": 1,
            "business_hash": self.fixture.business_hash,
            "acceptance_id": "acceptance.a20", "conversion_slot": "full_v1",
        })
        prepared = self.core.execute(self.author, self.prepare_request)
        self.assertTrue(prepared["ok"], prepared)
        self.order_id = prepared["result"]["order_id"]
        self.request = request("order.activate", "a26.activate", {
            "order_id": self.order_id, "expected_row_version": 1, "approval_id": "approval.a20",
            "order_review_id": approve_order(self.core, self.author, self.reviewer, self.order_id),
        })

    def local(self, **overrides):
        return self.core.t03_order_activate(self.author, **dict(self.request["args"], **overrides))

    def public(self):
        response = self.core.execute(self.author, self.request)
        t03_write.RESPONSE_VALIDATOR.validate(response)
        return response

    def snapshot(self):
        with sqlite3.connect(self.core.path) as db:
            tables = [r[0] for r in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ) if r[0] not in ("audit_event", "sqlite_sequence")]
            return {name: db.execute('SELECT * FROM "' + name + '"').fetchall() for name in tables}

    def deny_both(self, code):
        before = self.snapshot()
        with self.assertRaises(Rejected) as rejected:
            self.local()
        self.assertEqual(rejected.exception.code, {
            "COST_SNAPSHOT_NOT_ELIGIBLE": "COST_SNAPSHOT_INELIGIBLE",
        }.get(code, code))
        self.assertEqual(self.snapshot(), before)
        response = self.public()
        self.assertEqual(response.get("code"), code, response)
        self.assertEqual(self.snapshot(), before)

    def deny_cost(self):
        fixture = TradeFixture(self.core)
        fixture.n = 3000
        return fixture.call("brant.costing/0.1.0", "source_denial.record", {
            "id": "denial.a26", "source_id": "source.1", "reason": "Synthetic current contradiction",
            "evidence": [{"source_id": "source.2", "locator": "A26 synthetic denial"}],
        }, self.reviewer)

    def retire_template(self):
        response = self.fixture.base.config(self.reviewer, "retire", "a26.template.retire", {
            "kind": "quote_document_template", "id": "template.a19", "expected_version": 2,
            "target_revision": 1, "reason": "Synthetic A26 retirement",
            "evidence": [{"source_id": "source.1", "locator": "A26 test"}],
        })
        self.assertTrue(response["ok"], response)

    def revoke(self):
        return self.core.t03_quote_revoke_approval(
            self.reviewer, "approval.a20", expected_effectivity_version=1
        )

    def history(self):
        with self.core._connection() as db:
            return t03_storage.order_history(db, self.author.scope, self.order_id)

    def test_current_cost_denial_blocks_new_activation_without_residue(self):
        self.deny_cost()
        self.assertFalse(self.core.t03_quote_ready(self.author, "quote.a20")["quote_ready"])
        self.deny_both("COST_SNAPSHOT_NOT_ELIGIBLE")

    def test_retired_template_blocks_new_activation_without_residue(self):
        self.retire_template()
        self.deny_both("REFERENCE_STALE")

    def test_unverified_publication_source_blocks_new_activation(self):
        self.core.t03_config_verify_source(
            self.reviewer, "source.1", verified=False, reason="Synthetic verification withdrawn"
        )
        self.deny_both("REFERENCE_STALE")

    def test_configuration_control_is_checked_independently_of_quote_control(self):
        self.core.t03_bind_object_control(
            self.author, "quotation_foundation.quote_document_template", "template.a19",
            "server.task.a26.template",
        )
        self.deny_both("OBJECT_CONTROL_CONFLICT")

    def test_revoked_reviewer_grant_blocks_new_activation(self):
        self.core.provision(self.reviewer, ["quote.read", "read"], data_scope="company")
        self.deny_both("APPROVAL_STALE")

    def test_reviewer_changed_to_ai_blocks_new_activation(self):
        self.core.provision(self.reviewer, ["*"], actor_kind="ai", data_scope="company")
        self.deny_both("APPROVAL_STALE")

    def test_reviewer_losing_source_quote_scope_blocks_new_activation(self):
        self.core.provision(self.reviewer, ["*"], data_scope="own", team_id="other")
        self.deny_both("APPROVAL_STALE")

    def test_quote_expiration_blocks_uncommitted_order_even_if_acceptance_was_timely(self):
        self.instant = datetime(2026, 10, 29, 9, tzinfo=UTC)
        self.deny_both("QUOTE_EXPIRED")

    def test_approval_expiry_is_exclusive_and_does_not_change_order(self):
        self.instant = datetime(2026, 10, 28, 9, tzinfo=UTC)
        self.deny_both("APPROVAL_STALE")

    def test_offset_approval_expiration_is_compared_as_an_instant(self):
        with sqlite3.connect(self.core.path) as db:
            db.execute("UPDATE t03_approval SET expires_at=? WHERE approval_id='approval.a20'",
                       ("2026-10-22T20:00:00+08:00",))
        self.deny_both("APPROVAL_STALE")

    def test_future_offset_approval_is_not_misclassified_as_expired(self):
        with sqlite3.connect(self.core.path) as db:
            db.execute("UPDATE t03_approval SET expires_at=? WHERE approval_id='approval.a20'",
                       ("2026-10-22T08:00:00-05:00",))
        self.assertEqual(self.local()["status"], "active")

    def test_missing_formal_commit_evidence_blocks_activation(self):
        with sqlite3.connect(self.core.path) as db:
            db.execute("DROP TRIGGER immutable_t03_commit_evidence_delete")
            db.execute("DELETE FROM t03_commit_evidence WHERE quote_id='quote.a20'")
        self.deny_both("REFERENCE_INVALID")

    def test_formal_file_bytes_are_rehashed_not_only_metadata_checked(self):
        with sqlite3.connect(self.core.path) as db:
            row = db.execute("SELECT content FROM business_file WHERE id='file.a20'").fetchone()
            data = row[0]
            changed = (b"X" if data[:1] != b"X" else b"Y") + data[1:]
            db.execute("DROP TRIGGER immutable_business_file_update")
        for content in (changed, "X" * len(data)):
            with self.subTest(content_type=type(content).__name__):
                with sqlite3.connect(self.core.path) as db:
                    db.execute("UPDATE business_file SET content=? WHERE id='file.a20'", (content,))
                self.deny_both("FILE_INVALID")

    def test_revocation_event_is_a_durable_revision_hold_even_if_effectivity_is_corrupted(self):
        self.revoke()
        with sqlite3.connect(self.core.path) as db:
            # Explicit corruption injection; immutable revocation evidence survives.
            db.execute("UPDATE t03_approval SET effectivity='valid' WHERE approval_id='approval.a20'")
        self.core = Core(self.core.path, enable_t03=True, clock=lambda: self.instant)
        self.deny_both("APPROVAL_REVOKED")

    def test_revoked_approval_cannot_be_substituted_by_another_row(self):
        self.revoke()
        with sqlite3.connect(self.core.path) as db:
            db.execute("INSERT INTO t03_review_request SELECT tenant,company,'review.a26.fake',"
                        "'quote.a26.fake',business_revision,business_hash,target_command,"
                       "expected_old_active_revision,status,requested_by,requested_at "
                       "FROM t03_review_request WHERE review_request_id='review.a20'")
            db.execute("INSERT INTO t03_approval SELECT tenant,company,'approval.a26.fake',"
                       "'review.a26.fake',quote_id,business_revision,business_hash,command,reviewer,"
                       "decided_at,expires_at,decision,'valid',1 FROM t03_approval "
                       "WHERE approval_id='approval.a20'")
        self.request["args"]["approval_id"] = "approval.a26.fake"
        self.deny_both("APPROVAL_REQUIRED")

    def test_new_activation_records_qualification_and_keeps_order_commercial_hash(self):
        before = self.history()
        self.assertTrue(self.public()["ok"])
        after = self.history()
        query = self.core.execute(self.author, {
            "contract": "brant.quotation/0.1.0", "kind": "order_history",
            "args": {"order_id": self.order_id},
        })
        self.assertTrue(query["ok"], query)
        self.assertEqual(query["value"]["events"], after["events"])
        for field, invalid in (
            ("approval_id", {}), ("source_quote_revision", True),
            ("source_quote_hash", "invalid"), ("order_id", None),
        ):
            malformed = json.loads(json.dumps(query))
            malformed["value"][field] = invalid
            self.assertFalse(t03_query.RESPONSE_VALIDATOR.is_valid(malformed), field)
        self.assertEqual(after["body"], before["body"])
        self.assertEqual(after["order_hash"], before["order_hash"])
        evidence = after["events"][-1]["payload"]["source_qualification"]
        self.assertEqual(evidence["contract"], "brant.order-source-qualification/0.1.0")
        self.assertEqual(evidence["checked_at"], "2026-10-22T12:00:00Z")
        self.assertEqual(evidence["approval_id"], "approval.a20")
        self.assertEqual(evidence["source_quote_hash"], self.fixture.business_hash)
        self.assertEqual(evidence["approval_effectivity_version"], 1)
        self.assertEqual(evidence["formalization_commit_id"], "commit.quote.a20.1")
        self.assertTrue(evidence["cost_qualification"]["currently_eligible_for_quote"])
        self.assertFalse(evidence["approval_revocation_hold"])
        self.assertEqual(evidence["document_id"], "document.a20")
        self.assertEqual(after["row_version"], 2)

    def test_advisory_quote_ready_is_not_used_as_a_write_token(self):
        self.deny_cost()
        with patch.object(self.core, "t03_quote_ready", return_value={"quote_ready": True}):
            self.deny_both("COST_SNAPSHOT_NOT_ELIGIBLE")

    def test_source_checks_use_the_exact_order_write_connection(self):
        original = self.core.costing_snapshot_in_transaction
        seen = []

        def inspect(db, who, snapshot_id):
            self.assertTrue(db.in_transaction)
            self.assertIs(db.row_factory, sqlite3.Row)
            with sqlite3.connect(self.core.path, timeout=0) as other:
                with self.assertRaises(sqlite3.OperationalError):
                    other.execute("BEGIN IMMEDIATE")
            seen.append(snapshot_id)
            return original(db, who, snapshot_id)

        with patch.object(self.core, "costing_snapshot_in_transaction", side_effect=inspect):
            self.assertEqual(self.local()["status"], "active")
        self.assertEqual(seen, [self.fixture.base.snapshot["id"]])

    def test_end_of_check_approval_expiry_rolls_back_before_state_change(self):
        original = t03_storage._formalization_configurations

        def crosses(*args, **kwargs):
            value = original(*args, **kwargs)
            self.instant = datetime(2026, 10, 28, 9, tzinfo=UTC)
            return value

        with patch.object(t03_storage, "_formalization_configurations", side_effect=crosses):
            self.deny_both("APPROVAL_STALE")

    def test_post_activation_failure_rolls_back_qualification_event_and_ledger(self):
        original = t03_storage.activate_order
        before = self.snapshot()

        def fail(*args, **kwargs):
            original(*args, **kwargs)
            raise RuntimeError("A26 synthetic failure before commit")

        with patch.object(t03_storage, "activate_order", side_effect=fail):
            with self.assertRaisesRegex(RuntimeError, "A26 synthetic"):
                self.public()
        self.assertEqual(self.snapshot(), before)
        self.assertTrue(self.public()["ok"])

    def test_caller_owned_storage_transaction_can_rollback_qualified_activation(self):
        before = self.snapshot()
        with self.core._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            result = t03_storage.activate_order(self.core, db, self.author, self.order_id,
                                                1, "approval.a20", order_review_id=self.request["args"]["order_review_id"])
            self.assertEqual(result["status"], "active")
            self.assertTrue(db.in_transaction)
            self.assertEqual(db.execute("SELECT status FROM t03_order").fetchone()[0], "active")
            db.rollback()
        self.assertEqual(self.snapshot(), before)

    def test_later_cost_denial_does_not_retroactively_reject_committed_recovery(self):
        original = self.public()
        self.assertTrue(original["ok"])
        before = self.history()
        self.deny_cost()
        self.instant = datetime(2026, 10, 30, 12, tzinfo=UTC)
        self.core = Core(self.core.path, enable_t03=True, clock=lambda: self.instant)
        self.assertTrue(self.local()["replayed"])
        replay = self.public()
        self.assertTrue(replay["replayed"])
        self.assertEqual(replay["action_id"], original["action_id"])
        self.assertEqual(self.history(), before)
        receipt = self.core.execute(self.author, recovery.A23ReconciliationAccessTests.query(self.request))
        self.assertEqual(receipt["value"]["state"], "committed")

    def test_later_revocation_and_configuration_retirement_keep_original_activation_fact(self):
        original = self.public()
        self.assertTrue(original["ok"])
        before = self.history()
        self.retire_template()
        self.revoke()
        self.core.provision(self.reviewer, ["quote.read", "read"], data_scope="company")
        self.assertTrue(self.local()["replayed"])
        replay = self.public()
        self.assertEqual(replay["action_id"], original["action_id"])
        self.assertTrue(replay["replayed"])
        self.assertEqual(self.history(), before)

    def test_restored_reviewer_permission_allows_a_previous_rejected_key(self):
        self.core.provision(self.reviewer, ["quote.read", "read"], data_scope="company")
        self.deny_both("APPROVAL_STALE")
        self.core.provision(self.reviewer, ["*"], data_scope="company")
        response = self.public()
        self.assertTrue(response["ok"], response)
        self.assertFalse(response["replayed"])

    def test_reviewer_independence_is_rechecked(self):
        with sqlite3.connect(self.core.path) as db:
            db.execute("UPDATE t03_approval SET reviewer='author' WHERE approval_id='approval.a20'")
        self.deny_both("INDEPENDENT_REVIEW_REQUIRED")

    def test_dependency_read_grants_are_required_for_new_activation(self):
        grants = ["order.activate", "quote.read", "read", "costing.read", "foundation.read",
                  "quotation_foundation.read", "foundation_extension.read"]
        for missing in ("costing.read", "foundation.read", "quotation_foundation.read"):
            with self.subTest(missing=missing):
                self.core.provision(self.author, [g for g in grants if g != missing], data_scope="company")
                self.deny_both("PERMISSION_DENIED")
        self.core.provision(self.author, grants, data_scope="company")
        self.assertEqual(self.local()["status"], "active")

    def test_cost_denial_committing_first_blocks_waiting_activation(self):
        persisted, release, started = threading.Event(), threading.Event(), threading.Event()
        original = costing.persist

        def pause(*args, **kwargs):
            original(*args, **kwargs)
            persisted.set()
            if not release.wait(5):
                raise RuntimeError("A26 test did not release synthetic denial transaction")

        def activate():
            started.set()
            return self.public()

        with patch.object(costing, "persist", side_effect=pause), ThreadPoolExecutor(max_workers=2) as pool:
            denial = pool.submit(self.deny_cost)
            try:
                self.assertTrue(persisted.wait(5))
                activation = pool.submit(activate)
                self.assertTrue(started.wait(5))
            finally:
                release.set()
            self.assertTrue(denial.result(timeout=10)["ok"])
            self.assertEqual(activation.result(timeout=10).get("code"), "COST_SNAPSHOT_NOT_ELIGIBLE")
        with sqlite3.connect(self.core.path) as db:
            self.assertEqual(db.execute("SELECT status FROM t03_order").fetchone()[0], "draft")
            self.assertEqual(db.execute("SELECT count(*) FROM t03_order_event "
                                        "WHERE event_type='activated'").fetchone()[0], 0)
            self.assertEqual(db.execute("SELECT count(*) FROM action_result "
                                        "WHERE command='order.activate'").fetchone()[0], 0)

    def test_matching_trusted_task_keeps_quote_control_and_qualification_checks(self):
        self.core.t03_bind_object_control(self.author, "quote_root", "quote.a20", "server.task.a26")
        result = self.local(task_id="server.task.a26")
        self.assertEqual(result["status"], "active")
        event = self.history()["events"][-1]["payload"]["source_qualification"]
        self.assertIsNotNone(event["control_epoch"])

    def test_retired_cost_pricing_policy_blocks_new_activation(self):
        fixture = TradeFixture(self.core)
        fixture.n = 4000
        fixture.call("brant.foundation/0.1.0", "foundation.retire", {
            "kind": "pricing_policy", "id": "policy.1", "expected_version": 2,
            "reason": "Synthetic A26 policy retired",
        }, self.reviewer)
        self.deny_both("COST_SNAPSHOT_NOT_ELIGIBLE")

    def test_recovery_needs_current_base_grants_but_not_new_dependency_grants(self):
        original = self.public()
        self.assertTrue(original["ok"], original)
        before = self.history()
        self.core.provision(self.author, ["order.activate", "quote.read", "read"], data_scope="company")
        self.assertTrue(self.local()["replayed"])
        replay = self.public()
        self.assertEqual(replay["action_id"], original["action_id"])
        self.assertTrue(replay["replayed"])
        self.assertEqual(self.history(), before)

    def test_end_of_check_quote_expiry_rolls_back_before_state_change(self):
        original = t03_storage._formalization_configurations

        def crosses(*args, **kwargs):
            value = original(*args, **kwargs)
            self.instant = datetime(2026, 10, 29, 9, tzinfo=UTC)
            return value

        with patch.object(t03_storage, "_formalization_configurations", side_effect=crosses):
            self.deny_both("QUOTE_EXPIRED")

    def test_formalized_replacement_uses_its_own_bound_approval(self):
        quote_id = "quote.a26.replaced"
        data = self.fixture.base.quote_data()
        data["contact_ref"] = self.fixture.acceptance["contact_ref"]
        draft = self.core.t03_quote_save_draft(self.author, quote_id, data)

        def formalize(root_version, revision_number, old_active=None):
            frozen = self.core.t03_quote_freeze(
                self.author, quote_id, expected_root_version=root_version
            )
            request = self.core.t03_quote_submit_review(
                self.author, quote_id, expected_root_version=frozen["root_version"],
                review_request_id=f"review.a26.replace.{revision_number}",
                target_command="quote.replace" if old_active is not None else "quote.activate",
                expected_old_active_revision=old_active,
            )
            approval_id = f"approval.a26.replace.{revision_number}"
            self.core.t03_quote_decide_review(
                self.reviewer, f"review.a26.replace.{revision_number}", decision="approved",
                approval_id=approval_id, business_hash=request["business_hash"],
                expires_at="2026-10-28T09:00:00Z",
            )
            activate = self.core.t03_quote_activate if old_active is None else self.core.t03_quote_replace
            extra = {} if old_active is None else {"expected_old_active_revision": old_active}
            active = activate(
                self.author, quote_id, expected_root_version=request["root_version"],
                approval_id=approval_id, number_id=f"number.a26.replace.{revision_number}",
                document_id=f"document.a26.replace.{revision_number}",
                file_id=f"file.a26.replace.{revision_number}", **extra,
            )
            return dict(active, business_hash=request["business_hash"])

        first = formalize(draft["root_version"], 1)
        revised = self.core.t03_quote_revise(
            self.author, quote_id, expected_root_version=first["root_version"], base_revision=1
        )
        second = formalize(revised["root_version"], 2, old_active=1)
        acceptance = dict(self.fixture.acceptance)
        acceptance.update(
            acceptance_id="acceptance.a26.replace", quote_id=quote_id,
            quote_business_revision=2, quote_business_hash=second["business_hash"],
            source_message_id="message.a26.replace", recorded_at="2026-10-22T11:00:00Z",
            verified_at="2026-10-22T12:00:00Z",
        )
        self.core.t03_quote_record_acceptance(self.reviewer, acceptance)
        order = self.core.t03_order_prepare(
            self.author, quote_id, business_revision=2, business_hash=second["business_hash"],
            acceptance_id=acceptance["acceptance_id"],
        )
        result = self.core.t03_order_activate(
            self.author, order["order_id"], expected_row_version=1,
            approval_id="approval.a26.replace.2",
            order_review_id=approve_order(self.core, self.author, self.reviewer,
                                          order["order_id"], "review.order.replacement"),
        )
        self.assertEqual(result["status"], "active")
        with self.core._connection() as db:
            history = t03_storage.order_history(db, self.author.scope, order["order_id"])
        evidence = history["events"][-1]["payload"]["source_qualification"]
        self.assertEqual(evidence["source_quote_revision"], 2)
        self.assertEqual(evidence["approval_id"], "approval.a26.replace.2")


    def test_sales_fx_is_current_for_new_activation_and_staleness_is_not_ignored(self):
        fixture = TradeFixture(self.core)
        fixture.n = 5000
        fixture.foundation("currency", "EUR", {
            "code": "EUR", "name": "Synthetic EUR", "minor_units": 2, "rounding": "HALF_UP",
        })
        with self.core._connection() as db:
            policy = json.loads(db.execute(
                "SELECT data_json FROM foundation_revision "
                "WHERE kind='pricing_policy' AND id='policy.1' AND revision=1"
            ).fetchone()[0])
        self.assertEqual(policy["max_fx_age_seconds"], 3600)
        fixture.foundation("fx", "fx.a26.sales", {
            "from_currency": {"kind": "currency", "id": "EUR", "revision": 1},
            "to_currency": {"kind": "currency", "id": "USD", "revision": 1},
            "rate": "1.1", "purpose": "quotation", "observed_at": "2026-10-22T11:00:01Z",
            "valid_from": "2026-10-22T11:00:01Z", "valid_until": "2026-10-29T00:00:00Z",
            "source_name": "Synthetic A26 FX only",
        })
        for suffix in ("valid", "stale"):
            quote_id = "quote.a26.fx." + suffix
            data = self.fixture.base.quote_data()
            data.update(
                contact_ref=self.fixture.acceptance["contact_ref"],
                currency_ref={"kind": "currency", "id": "EUR", "revision": 1},
                sales_fx_ref={"kind": "fx", "id": "fx.a26.sales", "revision": 1},
            )
            draft = self.core.t03_quote_save_draft(self.author, quote_id, data)
            frozen = self.core.t03_quote_freeze(self.author, quote_id,
                                               expected_root_version=draft["root_version"])
            request = self.core.t03_quote_submit_review(
                self.author, quote_id, expected_root_version=frozen["root_version"],
                review_request_id="review." + quote_id, target_command="quote.activate",
            )
            approval_id = "approval." + quote_id
            self.core.t03_quote_decide_review(
                self.reviewer, "review." + quote_id, decision="approved", approval_id=approval_id,
                business_hash=request["business_hash"], expires_at="2026-10-28T09:00:00Z",
            )
            self.core.t03_quote_activate(
                self.author, quote_id, expected_root_version=request["root_version"],
                approval_id=approval_id, number_id="number." + quote_id,
                document_id="document." + quote_id, file_id="file." + quote_id,
            )
            acceptance = dict(self.fixture.acceptance)
            acceptance.update(
                acceptance_id="acceptance." + quote_id, quote_id=quote_id,
                quote_business_hash=request["business_hash"], source_message_id="message." + quote_id,
                recorded_at="2026-10-22T11:00:00Z", verified_at="2026-10-22T12:00:00Z",
            )
            self.core.t03_quote_record_acceptance(self.reviewer, acceptance)
            order = self.core.t03_order_prepare(
                self.author, quote_id, business_revision=1, business_hash=request["business_hash"],
                acceptance_id=acceptance["acceptance_id"],
            )
            self.order_id = order["order_id"]
            self.request["args"].update(order_id=self.order_id, approval_id=approval_id,
                order_review_id=approve_order(self.core, self.author, self.reviewer,
                                              self.order_id, "review.order.fx." + suffix))
            if suffix == "valid":
                self.assertEqual(self.local()["status"], "active")
            else:
                self.instant = datetime(2026, 10, 22, 12, 0, 2, tzinfo=UTC)
                self.deny_both("FX_STALE")


    def test_malformed_approval_timestamp_fails_closed(self):
        with sqlite3.connect(self.core.path) as db:
            db.execute("UPDATE t03_approval SET expires_at='malformed' WHERE approval_id='approval.a20'")
        self.deny_both("REFERENCE_INVALID")


if __name__ == "__main__":
    unittest.main()
