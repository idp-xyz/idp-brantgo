"""Synthetic complete scope and recosted arithmetic fixtures via public APIs."""
import copy
import json


def complete(data):
    value = copy.deepcopy(data)
    value.update(
        customer_ref={"kind": "customer", "id": "customer.1", "row_version": 2},
        contact_ref={"kind": "contact", "id": "contact.1", "row_version": 2},
        rfq_ref={"id": "rfq.1", "row_version": 2},
        trade_terms_ref={"kind": "trade_terms", "id": "terms.test", "revision": 1},
        trade_scope_ref={"kind": "trade_scope", "id": "scope.sale", "revision": 1},
        named_place_ref={"kind": "location", "id": "port.test", "revision": 1},
        delivery={"kind": "fixed", "date": "2026-11-15", "milestone": "handover",
                  "place_ref": {"kind": "location", "id": "port.test", "revision": 1},
                  "time_zone": "Asia/Shanghai"},
    )
    for line in value["lines"]:
        line.update(rfq_line_id=line["line_id"],
                    sku_profile_ref={"kind": "sku_profile", "id": "sku.1.profile", "revision": 1},
                    unit_ref={"kind": "unit", "id": "PCS", "revision": 1})
    return value



def recost(fixture, data):
    """Create a matching RFQ/context/offer/scenario/snapshot, never forge a result."""
    core, reviewer = fixture.core, fixture.reviewer
    prefix = "a27.scope."+str(fixture.n)
    with core._connection() as db:
        context = json.loads(db.execute(
            "SELECT data_json FROM t02_revision WHERE kind='costing_context' AND id='context.1' AND revision=1"
        ).fetchone()[0])
        offer = json.loads(db.execute(
            "SELECT data_json FROM t02_revision WHERE kind='supplier_offer' AND id='offer.1' AND revision=1"
        ).fetchone()[0])
        scenario = json.loads(db.execute(
            "SELECT data_json FROM t02_record WHERE kind='cost_scenario' AND id='scenario.1'"
        ).fetchone()[0])
    rfq_id = prefix+".rfq"
    fixture.old("rfq.save_draft", {
        "id":rfq_id, "expected_version":0, "customer_id":data["customer_ref"]["id"],
        "contact_id":data["contact_ref"]["id"], "source_ids":["source.1"],
        "lines":[{"line_id":line["rfq_line_id"], "sku_id":"sku.1", "quantity":line["quantity"],
                  "uom":"PCS", "source_id":"source.1", "locator":"Synthetic scope"}
                 for line in data["lines"]],
    })
    fixture.old("rfq.confirm_scope", {"id":rfq_id,"expected_version":1,"evidence_ids":["source.1"]},reviewer)
    data["rfq_ref"] = {"id":rfq_id,"row_version":2}
    context["rfq_ref"] = data["rfq_ref"]
    context["lines"] = [{"line_id":line["rfq_line_id"],"sku_profile_ref":line["sku_profile_ref"],
                         "quantity":line["quantity"],"unit_ref":line["unit_ref"]} for line in data["lines"]]
    context["comparison_basis"].update(
        sales_trade_scope_ref=data["trade_scope_ref"], sales_payment_terms_ref=data["payment_terms_ref"],
        named_place_ref=data["named_place_ref"], delivery=data["delivery"])
    offer["rfq_ref"] = data["rfq_ref"]
    offer["rfq_line_ids"] = [line["rfq_line_id"] for line in data["lines"]]
    offer["lines"][0]["moq"]["quantity"] = "1"
    for kind, body in [("costing_context",context),("supplier_offer",offer)]:
        id_ = prefix+"."+kind
        fixture.call("brant.costing/0.1.0",kind+".save_draft",
                     {"id":id_,"expected_version":0,"data":body})
        fixture.call("brant.costing/0.1.0",kind+".verify",
                     {"id":id_,"expected_version":1,"working_revision":1,
                      "evidence":[{"source_id":"source.1","locator":"Synthetic re-cost"}]},reviewer)
    scenario["context_ref"] = {"kind":"costing_context","id":prefix+".costing_context","revision":1}
    scenario["allocations"] = [
        {"rfq_line_id":line["rfq_line_id"],"purchase_quantity":line["quantity"],
         "purchase_unit_ref":line["unit_ref"],"source":{"kind":"offer","id":prefix+".supplier_offer",
                                                      "revision":1,"condition_line_id":"OL1"}}
        for line in data["lines"]]
    id_ = prefix+".scenario"
    fixture.call("brant.costing/0.1.0","cost_scenario.save_draft",
                 {"id":id_,"expected_version":0,"data":scenario})
    evaluation = fixture.call("brant.costing/0.1.0","cost_scenario.evaluate",
                              {"id":id_,"expected_version":1},reviewer)
    snapshot = fixture.call("brant.costing/0.1.0","cost_snapshot.freeze",
                            {"scenario_id":id_,"expected_version":1,"result_id":evaluation["result"]["id"],
                             "result_hash":evaluation["result_hash"],"selection_reason":"Matching complete scope"},
                            reviewer)["result"]
    data["snapshot_ref"] = {"id":snapshot["id"],"result_hash":snapshot["result_hash"]}
    return data
