"""Explicit synthetic independent approval for tests that activate an order."""


def approve_order(core, author, reviewer, order_id, review_id="review.order.fixture"):
    core.t04_order_request_review(author, order_id, review_id)
    core.t04_order_decide_review(reviewer, review_id, "approved", "2026-10-28T09:00:00Z")
    return review_id
