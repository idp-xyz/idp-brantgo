"""Full RFQ and frozen cost-scope checks through real local SQLite."""
import json
import unittest

from brant_core.common import Rejected
from tests import test_t03_server_calculation as base
from tests.t03_scope_fixture import complete


class A27CostScopeTests(unittest.TestCase):
    def setUp(self):
        self.base = base.ServerCalculationTests()
        self.base.setUp()
        self.core, self.author, self.reviewer = self.base.core, self.base.author, self.base.reviewer
        self.fixture = self.base.fixture

    def tearDown(self):
        self.base.tearDown()

    def data(self):
        return complete(self.base.quote_data())

    def freeze(self, data, name="quote.a27"):
        draft = self.core.t03_quote_save_draft(self.author, name, data)
        return self.core.t03_quote_freeze(self.author, name, expected_root_version=draft["root_version"])

    def reject(self, data, code="COMPARISON_BASIS_MISMATCH"):
        draft = self.core.t03_quote_save_draft(self.author, "quote.a27", data)
        with self.core._connection() as db:
            before = [tuple(r) for r in db.execute("SELECT * FROM t03_quote_revision")]
            events = db.execute("SELECT COUNT(*) FROM t03_quote_event").fetchone()[0]
        with self.assertRaises(Rejected) as caught:
            self.core.t03_quote_freeze(self.author, "quote.a27", expected_root_version=draft["root_version"])
        self.assertEqual(caught.exception.code, code)
        with self.core._connection() as db:
            self.assertEqual(before, [tuple(r) for r in db.execute("SELECT * FROM t03_quote_revision")])
            self.assertEqual(events, db.execute("SELECT COUNT(*) FROM t03_quote_event").fetchone()[0])
            for table in ["document_number", "business_file", "t03_commit_evidence", "t03_quote_outbox"]:
                self.assertEqual(db.execute("SELECT COUNT(*) FROM "+table).fetchone()[0], 0)

    def test_quantity_must_match_full_cost_and_rfq_scope(self):
        data = self.data()
        data["lines"][0]["quantity"] = "60"
        self.reject(data)

    def test_delivery_cannot_be_changed_after_cost_freeze(self):
        data = self.data()
        data["delivery"]["date"] = "2026-11-14"
        self.reject(data)

    def test_scope_cannot_switch_from_export_sale_to_purchase(self):
        data = self.data()
        data["trade_scope_ref"]["id"] = "scope.purchase"
        self.reject(data)

    def test_complete_freeze_records_server_scope_binding(self):
        frozen = self.freeze(self.data())
        with self.core._connection() as db:
            row = db.execute("SELECT calculation_json FROM t03_quote_revision").fetchone()
        proof = json.loads(row[0])["cost_scope_binding"]
        self.assertEqual(proof["contract"], "brant.quote-cost-scope/0.1.0")
        self.assertEqual(proof["rfq_ref"], {"id":"rfq.1","row_version":2})
        self.assertEqual(proof["line_bindings"][0]["rfq_line_id"], "L1")
        self.assertEqual(frozen["status"], "frozen")

    def test_missing_rfq_is_not_a_way_to_skip_scope_checks(self):
        data = self.data()
        del data["rfq_ref"]
        self.reject(data, "DRAFT_NOT_READY")

    def test_missing_line_mapping_is_rejected(self):
        data = self.data()
        del data["lines"][0]["rfq_line_id"]
        self.reject(data, "DRAFT_NOT_READY")

    def test_unknown_and_duplicate_rfq_line_mapping_are_rejected(self):
        data = self.data()
        data["lines"][0]["rfq_line_id"] = "unknown"
        self.reject(data)

    def test_same_rfq_line_cannot_be_split_across_two_sales_lines(self):
        data = self.data()
        import copy
        line = copy.deepcopy(data["lines"][0])
        line["line_id"] = "L2"
        data["lines"].append(line)
        self.reject(data)

    def test_duplicate_sales_identity_is_rejected(self):
        data = self.data()
        import copy
        data["lines"].append(copy.deepcopy(data["lines"][0]))
        self.reject(data, "DUPLICATE_LINE_ID")

    def test_wrong_rfq_revision_is_rejected(self):
        data = self.data()
        data["rfq_ref"]["row_version"] = 1
        self.reject(data)

    def test_wrong_customer_cannot_adopt_the_snapshot(self):
        data = self.data()
        data["customer_ref"]["id"] = "supplier.1"
        self.reject(data, "REFERENCE_INVALID")

    def test_wrong_contact_revision_is_rejected(self):
        data = self.data()
        data["contact_ref"]["row_version"] = 1
        self.reject(data, "REFERENCE_INVALID")

    def test_different_trade_terms_cannot_use_equal_labels(self):
        data = self.data()
        data["trade_terms_ref"]["id"] = "other.same-label"
        self.reject(data)

    def test_different_payment_terms_require_recosting(self):
        data = self.data()
        data["payment_terms_ref"]["id"] = "other.same-schedule"
        self.reject(data)

    def test_delivery_milestone_is_part_of_the_comparison(self):
        data = self.data()
        data["delivery"]["milestone"] = "arrival"
        self.reject(data)

    def test_delivery_timezone_is_part_of_the_comparison(self):
        data = self.data()
        data["delivery"]["time_zone"] = "UTC"
        self.reject(data)

    def test_named_place_must_match_exact_cost_reference(self):
        data = self.data()
        data["named_place_ref"]["id"] = "origin.test"
        self.reject(data)

    def test_sku_profile_revision_must_match_cost_manifest(self):
        data = self.data()
        data["lines"][0]["sku_profile_ref"]["revision"] = 2
        self.reject(data)

    def test_unit_precision_is_checked_before_amount_rounding(self):
        data = self.data()
        data["lines"][0]["quantity"] = "120.5"
        self.reject(data, "INVALID_KNOWN_VALUE")

    def conversion(self, *, factor="12", id_="box.to.pcs", from_unit="BOX"):
        self.fixture.foundation("unit", "BOX", {
            "name":"Synthetic box", "code":"BOX", "precision":0, "dimension":"count"})
        self.fixture.foundation("conversion", id_, {
            "sku_profile":{"kind":"sku_profile","id":"sku.1.profile","revision":1},
            "from_unit":{"kind":"unit","id":from_unit,"revision":1},
            "to_unit":{"kind":"unit","id":"PCS","revision":1}, "factor":factor,
            "basis":"Synthetic verified package conversion",
            "valid_from":"2026-10-22T00:00:00Z", "valid_until":"2026-10-29T00:00:00Z",
        })

    def test_explicit_conversion_preserves_normalized_scope(self):
        self.conversion()
        data = self.data()
        data["lines"][0].update(quantity="10", unit_price="96",
                               unit_ref={"kind":"unit","id":"BOX","revision":1},
                               conversion_ref={"kind":"conversion","id":"box.to.pcs","revision":1})
        self.freeze(data)
        with self.core._connection() as db:
            calculation = json.loads(db.execute("SELECT calculation_json FROM t03_quote_revision").fetchone()[0])
        self.assertEqual(calculation["net_minor"], "96000")
        self.assertEqual(calculation["cost_scope_binding"]["line_bindings"][0]["normalized_quantity"], "120")

    def test_unknown_unit_cannot_be_guessed_as_a_package(self):
        self.fixture.foundation("unit", "BOX", {
            "name":"Synthetic box","code":"BOX","precision":0,"dimension":"count"})
        data = self.data()
        data["lines"][0].update(quantity="10",unit_ref={"kind":"unit","id":"BOX","revision":1})
        self.reject(data, "DEPENDENCY_NOT_SUPPORTED")

    def test_wrong_conversion_factor_does_not_allow_partial_cost_scope(self):
        self.conversion(factor="10")
        data = self.data()
        data["lines"][0].update(quantity="10",unit_ref={"kind":"unit","id":"BOX","revision":1},
                               conversion_ref={"kind":"conversion","id":"box.to.pcs","revision":1})
        self.reject(data)

    def test_redundant_conversion_is_rejected(self):
        data = self.data()
        data["lines"][0]["conversion_ref"] = {"kind":"conversion","id":"redundant","revision":1}
        self.reject(data, "REFERENCE_INVALID")

    def test_numeric_equivalent_quantity_has_one_normalized_scope(self):
        data = self.data()
        data["lines"][0]["quantity"] = "120.000000"
        self.assertEqual(self.freeze(data)["status"], "frozen")

    def test_forged_client_scope_certificate_is_ignored(self):
        data = self.data()
        saved = self.core.t03_quote_save_draft(self.author, "quote.a27", data,
                                               calculation={"cost_scope_binding":{"binding_hash":"forged"}})
        self.core.t03_quote_freeze(self.author,"quote.a27",expected_root_version=saved["root_version"])
        with self.core._connection() as db:
            calculation = json.loads(db.execute("SELECT calculation_json FROM t03_quote_revision").fetchone()[0])
        self.assertEqual(len(calculation["cost_scope_binding"]["binding_hash"]),64)

    def test_complete_multiline_and_missing_line(self):
        import copy

        from tests.t03_scope_fixture import recost
        data = self.data()
        data["lines"][0]["quantity"] = "60"
        other = copy.deepcopy(data["lines"][0])
        other.update(line_id="sale.B",rfq_line_id="L2")
        data["lines"].append(other)
        recost(self.fixture,data)
        partial = copy.deepcopy(data)
        partial["lines"].pop()
        self.reject(partial)
        self.assertEqual(self.freeze(data,"quote.complete")["status"],"frozen")

    def test_transaction_ownership_and_rollback_are_preserved(self):
        from brant_core import t03_storage
        data = self.data()
        draft = self.core.t03_quote_save_draft(self.author,"quote.a27",data)
        with self.core._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            t03_storage.freeze(self.core,db,self.author,"quote.a27",expected_root_version=draft["root_version"])
            self.assertTrue(db.in_transaction)
            self.assertEqual(db.execute("SELECT status FROM t03_quote_root").fetchone()[0],"frozen")
            db.rollback()
        with self.core._connection() as db:
            self.assertEqual(db.execute("SELECT status FROM t03_quote_root").fetchone()[0],"working")

    def test_context_manifest_is_checked_even_after_protective_layer_bypass(self):
        from unittest.mock import patch

        from brant_core import t03_cost_scope
        original = t03_cost_scope.costing.models
        def changed(*args):
            model, extension = original(*args)
            model.roots[("costing_context","context.1")].revisions[1]["data"]["comparison_basis"]["specification_basis"] = "CORRUPT"
            return model,extension
        with self.core._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            snapshot=self.core.costing_snapshot_in_transaction(db,self.author,self.base.snapshot["id"])["snapshot"]
            with patch.object(t03_cost_scope.costing,"models",side_effect=changed):
                with self.assertRaises(Rejected) as caught:
                    t03_cost_scope.bind(self.core,db,self.author,self.data(),snapshot)
            self.assertEqual(caught.exception.code,"REFERENCE_INVALID")
            db.rollback()

    def test_actual_context_is_required_even_with_matching_manifest(self):
        from unittest.mock import patch

        from brant_core import t03_cost_scope
        original = t03_cost_scope.costing.models
        def changed(*args):
            model, extension=original(*args)
            model.roots[("costing_context","context.1")].revisions[1]["data"]["context_kind"]="what_if"
            return model,extension
        with self.core._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            snapshot=self.core.costing_snapshot_in_transaction(db,self.author,self.base.snapshot["id"])["snapshot"]
            row=db.execute("SELECT data_json FROM t02_revision WHERE kind='costing_context'").fetchone()
            context=json.loads(row[0])
            context["context_kind"]="what_if"
            for item in snapshot["input_manifest"]:
                if item["kind"]=="costing_context":
                    item["content_hash"]=t03_cost_scope.foundation.digest(context)
            with patch.object(t03_cost_scope.costing,"models",side_effect=changed):
                with self.assertRaises(Rejected) as caught:
                    t03_cost_scope.bind(self.core,db,self.author,self.data(),snapshot)
            self.assertEqual(caught.exception.code,"COST_SNAPSHOT_INELIGIBLE")
            db.rollback()


class A27ScopeFormalizationTests(unittest.TestCase):
    def setUp(self):
        from tests import test_t03_a19_configuration_consumption as fixtures
        self.base=fixtures.A19ConfigurationConsumptionTests()
        self.base.setUp()
        self.core,self.author,self.reviewer=self.base.core,self.base.author,self.base.reviewer
        self.base.publish_template()
        self.base.publish_tax_application()

    def tearDown(self):
        self.base.tearDown()

    def data(self):
        value=self.base.quote_data()
        value["lines"][0]["tax_application_ref"]={"kind":"sales_tax_application","id":"tax.a19","revision":1}
        value["lines"][0]["evidence"]=[{"source_id":"source.1","locator":"A27 synthetic complete scope"}]
        return value

    def command(self,command,key,args,actor=None):
        from brant_core import t03_write
        request={"contract":"brant.quotation/0.1.0","command":command,"idempotency_key":key,"args":args}
        t03_write.REQUEST_VALIDATOR.validate(request)
        response=self.core.execute(actor or self.author,request)
        t03_write.RESPONSE_VALIDATOR.validate(response)
        return response

    def draft(self,data):
        response=self.command("quote.save_draft","a27.save",
                              {"quote_id":"quote.public.a27","expected_root_version":0,"data":data})
        self.assertTrue(response["ok"],response)
        return response["result"]

    def freeze(self,data):
        saved=self.draft(data)
        response=self.command("quote.freeze","a27.freeze",{
            "quote_id":"quote.public.a27","expected_root_version":saved["root_version"],
            "draft_generation":saved["business_revision"]})
        self.assertTrue(response["ok"],response)
        return response["result"]

    def approve(self,frozen):
        submitted=self.core.t03_quote_submit_review(
            self.author,"quote.public.a27",expected_root_version=frozen["root_version"],
            review_request_id="review.public.a27",target_command="quote.activate")
        self.core.t03_quote_decide_review(
            self.reviewer,"review.public.a27",decision="approved",approval_id="approval.public.a27",
            business_hash=submitted["business_hash"],expires_at="2026-10-28T09:00:00Z")
        return submitted

    def activate(self,submitted):
        return self.core.t03_quote_activate(
            self.author,"quote.public.a27",expected_root_version=submitted["root_version"],
            approval_id="approval.public.a27",number_id="number.public.a27",
            document_id="document.public.a27",file_id="file.public.a27")

    def test_public_complete_freeze_and_formalization_share_scope_evidence(self):
        frozen=self.freeze(self.data())
        submitted=self.approve(frozen)
        self.activate(submitted)
        with self.core._connection() as db:
            calculation=json.loads(db.execute("SELECT calculation_json FROM t03_quote_revision").fetchone()[0])
            committed=json.loads(db.execute("SELECT result_json FROM t03_commit_evidence").fetchone()[0])
        self.assertEqual(calculation["cost_scope_binding"],committed["cost_qualification"]["scope_binding"])
        self.assertTrue(self.core.t03_quote_ready(self.author,"quote.public.a27")["quote_ready"])

    def test_public_wrong_quantity_has_no_success_ledger_or_partial_freeze(self):
        data=self.data()
        data["lines"][0]["quantity"]="60"
        saved=self.draft(data)
        response=self.command("quote.freeze","a27.freeze",{
            "quote_id":"quote.public.a27","expected_root_version":saved["root_version"],
            "draft_generation":saved["business_revision"]})
        self.assertEqual(response.get("code"),"COMPARISON_BASIS_MISMATCH",response)
        with self.core._connection() as db:
            self.assertEqual(db.execute("SELECT status FROM t03_quote_root").fetchone()[0],"working")
            self.assertEqual(db.execute("SELECT COUNT(*) FROM action_result WHERE command='quote.freeze'").fetchone()[0],0)

    def test_public_missing_rfq_fails_closed(self):
        data=self.data()
        del data["rfq_ref"]
        saved=self.draft(data)
        response=self.command("quote.freeze","a27.freeze",{
            "quote_id":"quote.public.a27","expected_root_version":saved["root_version"],
            "draft_generation":saved["business_revision"]})
        self.assertEqual(response.get("code"),"DRAFT_NOT_READY",response)

    def test_old_unmapped_frozen_revision_cannot_be_newly_formalized(self):
        from unittest.mock import patch
        with patch("brant_core.t03_cost_scope.bind",return_value={"contract":"synthetic-legacy-unmapped"}):
            frozen=self.freeze(self.data())
        submitted=self.approve(frozen)
        with self.assertRaises(Rejected) as caught:
            self.activate(submitted)
        self.assertEqual(caught.exception.code,"REFERENCE_INVALID")
        with self.core._connection() as db:
            for table in ["document_number","business_file","t03_commit_evidence","t03_quote_outbox"]:
                self.assertEqual(db.execute("SELECT COUNT(*) FROM "+table).fetchone()[0],0)
        history=self.core.t03_quote_get(self.author,"quote.public.a27")
        self.assertEqual(history["revisions"][0]["status"],"pending_approval")

    def test_freeze_to_activation_does_not_trust_stale_scope_receipt(self):
        frozen=self.freeze(self.data())
        submitted=self.approve(frozen)
        with self.core._connection() as db:
            db.execute("UPDATE rfq_line SET quantity='60' WHERE rfq_id='rfq.1'")
        with self.assertRaises(Rejected) as caught:
            self.activate(submitted)
        self.assertEqual(caught.exception.code,"COMPARISON_BASIS_MISMATCH")
        with self.core._connection() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM t03_commit_evidence").fetchone()[0],0)

    def test_current_scope_failure_does_not_rewrite_committed_quote_history(self):
        submitted=self.approve(self.freeze(self.data()))
        self.activate(submitted)
        with self.core._connection() as db:
            original=db.execute("SELECT data_json,calculation_json,business_hash FROM t03_quote_revision").fetchone()
            db.execute("UPDATE rfq_line SET quantity='60' WHERE rfq_id='rfq.1'")
        ready=self.core.t03_quote_ready(self.author,"quote.public.a27")
        self.assertFalse(ready["quote_ready"])
        self.assertIn("COMPARISON_BASIS_MISMATCH",ready["reasons"])
        with self.core._connection() as db:
            current=db.execute("SELECT data_json,calculation_json,business_hash FROM t03_quote_revision").fetchone()
            self.assertEqual(tuple(original),tuple(current))
            self.assertEqual(db.execute("SELECT status FROM t03_quote_revision").fetchone()[0],"active")

    def test_old_structured_revision_with_no_calculation_cannot_formalize(self):
        from unittest.mock import patch
        # Use the legacy trusted calculation adapter without A18 bindings,
        # so an unrelated template/tax guard cannot mask this missing result.
        data=self.base.quote_data()
        data.pop("document_template_ref")
        saved=self.core.t03_quote_save_draft(self.author,"quote.public.a27",data)
        with patch("brant_core.t03_storage._server_calculation",return_value=(None,None)):
            frozen=self.core.t03_quote_freeze(
                self.author,"quote.public.a27",expected_root_version=saved["root_version"])
        submitted=self.approve(frozen)
        with self.assertRaises(Rejected) as caught:
            self.activate(submitted)
        self.assertEqual(caught.exception.code,"REFERENCE_INVALID")
        with self.core._connection() as db:
            for table in ["document_number","business_file","t03_commit_evidence","t03_quote_outbox"]:
                self.assertEqual(db.execute("SELECT COUNT(*) FROM "+table).fetchone()[0],0)
