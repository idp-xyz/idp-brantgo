"""All command success traces also exercise authorization, CAS and rollback."""

import sqlite3
from copy import deepcopy

import test_costing_lifecycle as lifecycles

from brant_core import Core, Principal


def store_state(path):
    """Logical store contents, excluding permitted rejection audit appends."""
    with sqlite3.connect(path) as db:
        tables = [
            r[0]
            for r in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name<>'audit_event' ORDER BY name"
            )
        ]
        return {
            name: db.execute('SELECT * FROM "' + name + '" ORDER BY rowid').fetchall()
            for name in tables
        }


class PersistentFailureMatrixTests(lifecycles.PersistentLifecycleTests):
    def setUp(self):
        super().setUp()
        self.coverage = []
        self.blocked = Principal("tenant.live", "company.live", "blocked")
        self.core.provision(
            self.blocked, ["read", "foundation.read", "costing.read"], data_scope="company"
        )
        self.ai = Principal("tenant.live", "company.live", "matrix.ai")
        self.core.provision(self.ai, ["*"], actor_kind="ai", data_scope="company")

    def record_check(self, request, check, code):
        self.coverage.append(
            {
                "contract": request["contract"],
                "command": request["command"],
                "kind": request["args"].get("kind"),
                "check": check,
                "observed_code": code,
                "business_store_unchanged": True,
            }
        )

    def check_before_command(self, who, request):
        before = store_state(self.path)
        denied = Core(self.path, clock=self.clock).execute(self.blocked, request)
        self.assertEqual(denied, {"ok": False, "code": "PERMISSION_DENIED"})
        self.assertEqual(store_state(self.path), before)
        self.record_check(request, "command_authorization", denied["code"])
        if request["command"].split(".")[1] in {
            "verify",
            "publish",
            "withdraw",
            "retire",
            "record_verified",
            "supersede",
            "record_issued",
            "close",
            "record",
            "freeze",
        }:
            denied = Core(self.path, clock=self.clock).execute(self.ai, request)
            self.assertEqual(denied, {"ok": False, "code": "PERMISSION_DENIED"})
            self.assertEqual(store_state(self.path), before)
            self.record_check(request, "human_actor_required", denied["code"])
        if request["command"].split(".")[1] in {
            "verify",
            "publish",
            "record_verified",
            "supersede",
        }:
            denied = Core(self.path, clock=self.clock).execute(self.author, request)
            self.assertEqual(denied, {"ok": False, "code": "PERMISSION_DENIED"}, request)
            self.assertEqual(store_state(self.path), before)
            self.record_check(request, "independent_reviewer_required", denied["code"])
        # The supported SQLite deployment boundary injects a real late failure.
        with sqlite3.connect(self.path) as db:
            db.execute(
                "CREATE TRIGGER matrix_outbox_failure BEFORE INSERT ON outbox BEGIN SELECT RAISE(ABORT,'matrix write failure'); END"
            )
        try:
            failed = Core(self.path, clock=self.clock).execute(who, request)
            self.assertEqual(failed, {"ok": False, "code": "STORAGE_FAILURE"}, request)
            self.assertEqual(store_state(self.path), before)
            self.record_check(request, "late_write_rollback", failed["code"])
        finally:
            with sqlite3.connect(self.path) as db:
                db.execute("DROP TRIGGER matrix_outbox_failure")

    def check_after_command(self, who, request, successful):
        before = store_state(self.path)
        changed = deepcopy(request)
        field = "scenario_id" if request["command"] == "cost_snapshot.freeze" else "id"
        changed["args"][field] += ".changed"
        conflict = self.core.execute(who, changed)
        self.assertEqual(conflict["code"], "IDEMPOTENCY_PAYLOAD_CONFLICT", (request, conflict))
        self.assertEqual(store_state(self.path), before)
        self.record_check(request, "idempotency_payload_conflict", conflict["code"])
        stale = deepcopy(request)
        stale["idempotency_key"] += ".stale"
        if request["command"] == "cost_scenario.evaluate":
            stale["args"]["expected_version"] += 1
        result = Core(self.path, clock=self.clock).execute(who, stale)
        self.assertEqual(result["code"], "VERSION_CONFLICT", (request, result))
        self.assertEqual(store_state(self.path), before)
        self.record_check(request, "version_or_duplicate_conflict", result["code"])
        if request["command"].endswith(
            (
                ".verify",
                ".publish",
                ".revise",
                ".discard_draft",
                ".record_issued",
                ".close",
                ".freeze",
            )
        ):
            invalid = deepcopy(request)
            invalid["idempotency_key"] += ".state"
            invalid["args"]["expected_version"] = successful.get(
                "row_version", successful.get("root_version")
            )
            result = Core(self.path, clock=self.clock).execute(who, invalid)
            self.assertEqual(result["code"], "INVALID_STATE", (request, result))
            self.assertEqual(store_state(self.path), before)
            self.record_check(request, "invalid_state_transition", result["code"])
