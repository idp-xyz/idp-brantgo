"""Read local T03 action receipts under current business and object permissions."""

from __future__ import annotations

import json
from typing import Any

from . import t03_write, t04_response
from .common import Rejected

# Historical result reads need read grants, never a grant to repeat the write.
READ_PERMISSIONS = {
    "quote.save_draft": ("quote.read",),
    "quote.revise": ("quote.read",),
    "quote.discard_draft": ("quote.read",),
    "quote.freeze": ("quote.read",),
    "quote.submit_review": ("quote.read",),
    "quote.review.approve": ("quote.read",),
    "quote.review.return": ("quote.read",),
    "quote.review.reject": ("quote.read",),
    "quote.approval.revoke": ("quote.read",),
    "quote.activate": ("quote.read",),
    "quote.replace": ("quote.read",),
    "quote.withdraw": ("quote.read",),
    "quote.cancel": ("quote.read",),
    "quote.acceptance.verify": ("quote.read", "read"),
    "quote.response.record": ("quote.read", "read"),
    "quote.response.verify": ("quote.read", "read"),
    "order.prepare": ("quote.read", "read"),
    "order.activate": ("quote.read", "read"),
    "order.approval.revoke": ("quote.read", "read"),
    "order.review.request": ("quote.read", "read"),
    "order.review.decide": ("quote.read", "read"),
}


def reconcile(core, db, who, command: str, key: str, request_hash: str) -> dict[str, Any]:
    """Observe committed local evidence; a missing row is not an external rollback."""
    if command not in READ_PERMISSIONS:
        raise Rejected("SCHEMA_INVALID")
    for permission in READ_PERMISSIONS[command]:
        core._authorize(db, who, permission)
    row = db.execute(
        "SELECT request_hash,action_id,result_json FROM action_result "
        "WHERE tenant=? AND company=? AND command=? AND idempotency_key=?",
        (*who.scope, command, key),
    ).fetchone()
    value: dict[str, Any] = {
        "command": command,
        "idempotency_key": key,
        "request_hash": request_hash,
        "state": "not_committed",
        "action_id": None,
        "object_id": None,
        "result": None,
    }
    if row is None:
        return value
    try:
        receipt = json.loads(row["result_json"])
    except (TypeError, ValueError):
        raise Rejected("REFERENCE_INVALID") from None
    if (
        not isinstance(receipt, dict)
        or not t03_write.RESPONSE_VALIDATOR.is_valid(receipt)
        or receipt.get("ok") is not True
        or receipt.get("command") != command
        or receipt.get("action_id") != row["action_id"]
    ):
        raise Rejected("REFERENCE_INVALID")
    payload = receipt["result"]
    if command.startswith("order."):
        if command == "order.review.request":
            object_id = payload["order_id"]
        elif command in ("order.approval.revoke", "order.review.decide"):
            review = db.execute(
                "SELECT order_id FROM t04_order_review_request WHERE tenant=? AND company=? AND review_id=?",
                (*who.scope, payload["review_id"]),
            ).fetchone()
            if review is None:
                raise Rejected("REFERENCE_INVALID")
            object_id = review["order_id"]
        else:
            object_id = payload["order_id"]
        order = db.execute(
            "SELECT source_quote_id FROM t03_order WHERE tenant=? AND company=? AND order_id=?",
            (*who.scope, object_id),
        ).fetchone()
        if order is None:
            raise Rejected("REFERENCE_INVALID")
        quote_id = order["source_quote_id"]
        if command == "order.prepare" and payload["source_quote_id"] != quote_id:
            raise Rejected("REFERENCE_INVALID")
    else:
        object_id = payload["quote_id"] if command in (
            "quote.acceptance.verify", "quote.response.record", "quote.response.verify"
        ) else payload["object_id"]
        quote_id = object_id
    # Check the same root for matching and conflicting hashes. A conflict must
    # not leak another owner's action ID or its associated business object.
    core._access(db, who, "quote", quote_id)
    if command.startswith("quote.response."):
        t04_response.validate_receipt(core, db, who, command, payload,
                                      key=key, request_hash=row["request_hash"])
    committed = row["request_hash"] == request_hash
    value.update(
        state="committed" if committed else "payload_conflict",
        action_id=row["action_id"],
        object_id=object_id,
        result=receipt if committed else None,
    )
    return value
