"""Validated historical response reads shared by local/public recovery paths."""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any

from .common import Rejected, canonical


def _json(value: str) -> dict[str, Any]:
    try:
        result = json.loads(value)
    except (TypeError, ValueError, RecursionError):
        raise Rejected("REFERENCE_INVALID") from None
    if not isinstance(result, dict):
        raise Rejected("REFERENCE_INVALID")
    try:
        canonical(result).encode("utf-8")
    except (TypeError, ValueError, UnicodeError, RecursionError):
        raise Rejected("REFERENCE_INVALID") from None
    return result


def public_time(value: Any) -> str:
    if not isinstance(value, str):
        raise Rejected("REFERENCE_INVALID")
    result = value.replace("+00:00", "Z")
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?Z", result) is None:
        raise Rejected("REFERENCE_INVALID")
    from datetime import datetime

    try:
        datetime.fromisoformat(result)
    except ValueError:
        raise Rejected("REFERENCE_INVALID") from None
    return result


def get(core, db, who, response_id: str) -> dict[str, Any]:
    """Read immutable facts under current quote/source access, without write guards."""
    from .t03_write import REQUEST_VALIDATOR

    row = db.execute(
        "SELECT * FROM t04_customer_response WHERE tenant=? AND company=? AND response_id=?",
        (*who.scope, response_id),
    ).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    core._access(db, who, "quote", row["quote_id"])
    core._source_ref(db, who, row["source_id"], "/response/source_id")
    response = _json(row["body_json"])
    fields = {"response_id": 64, "quote_id": 64, "source_id": 64, "locator": 500, "summary": 4000}
    if (set(response) != set(fields) | {"classification"}
            or any(not isinstance(response.get(key), str) or not response[key].strip()
                   or len(response[key]) > limit for key, limit in fields.items())
            or response.get("classification") not in (
                "full_unconditional", "conditional", "partial", "reject", "ambiguous")
            or any(response.get(key) != row[key] for key in ("response_id", "quote_id", "source_id"))
            or not isinstance(row["recorded_by"], str) or not row["recorded_by"].strip()):
        raise Rejected("REFERENCE_INVALID")
    public_time(row["recorded_at"])
    result = {**response, "recorded_by": row["recorded_by"], "recorded_at": row["recorded_at"],
              "verification": None}
    link = db.execute(
        "SELECT * FROM t04_response_verification WHERE tenant=? AND company=? AND response_id=?",
        (*who.scope, response_id),
    ).fetchone()
    if link is None:
        return result
    verification = _json(link["body_json"])
    # Local callers historically accept +00:00 timestamps. Normalize a copy only
    # for public schema validation; compare the original immutable facts below.
    normalized = dict(verification)
    normalized["recorded_at"] = public_time(verification.get("recorded_at"))
    request = {"contract": "brant.quotation/0.1.0", "command": "quote.response.verify",
               "idempotency_key": "response.read", "args": {
                   "response_id": "response.read", "verification": normalized}}
    if not REQUEST_VALIDATOR.is_valid(request) or response["classification"] != "full_unconditional":
        raise Rejected("REFERENCE_INVALID")
    acceptance = db.execute(
        "SELECT * FROM t03_acceptance WHERE tenant=? AND company=? AND acceptance_id=?",
        (*who.scope, link["acceptance_id"]),
    ).fetchone()
    if acceptance is None:
        raise Rejected("REFERENCE_INVALID")
    body = _json(acceptance["body_json"])
    expected = {**verification, "quote_id": response["quote_id"], "kind": "full_unconditional",
                "source_ref": {"source_id": response["source_id"], "locator": response["locator"]},
                "verified_by": link["verified_by"], "verified_at": link["verified_at"],
                "scope": {"tenant": who.scope[0], "company": who.scope[1]}}
    columns = {
        "acceptance_id": "acceptance_id", "quote_id": "quote_id",
        "quote_business_revision": "business_revision", "quote_business_hash": "business_hash",
        "kind": "kind", "source_message_id": "source_message_id", "source_author": "source_author",
        "forward_chain_ref": "forward_chain_ref", "recorded_at": "recorded_at",
        "verified_at": "verified_at", "verified_by": "verified_by",
    }
    if (body != expected or verification["acceptance_id"] != link["acceptance_id"]
            or any(expected[key] != acceptance[column] for key, column in columns.items())
            or not isinstance(link["verified_by"], str) or not link["verified_by"].strip()):
        raise Rejected("REFERENCE_INVALID")
    for key in ("customer_ref", "contact_ref", "source_ref", "line_ids"):
        try:
            stored = json.loads(acceptance[key + "_json"])
        except (TypeError, ValueError, RecursionError):
            raise Rejected("REFERENCE_INVALID") from None
        if stored != expected[key]:
            raise Rejected("REFERENCE_INVALID")
    public_time(link["verified_at"])
    result["verification"] = {key: link[key] for key in ("acceptance_id", "verified_by", "verified_at")}
    return result


def public_value(response: dict[str, Any]) -> dict[str, Any]:
    value = dict(response)
    value["recorded_at"] = public_time(value["recorded_at"])
    if value["verification"] is not None:
        value["verification"] = dict(value["verification"])
        value["verification"]["verified_at"] = public_time(value["verification"]["verified_at"])
    return value


def validate_receipt(core, db, who, command: str, payload: dict[str, Any], *,
                     key: str | None = None, request_hash: str | None = None) -> dict[str, Any]:
    """Bind a schema-validated receipt to the actual response and acceptance."""
    try:
        response = get(core, db, who, payload["response_id"])
    except Rejected as exc:
        if exc.code == "NOT_FOUND":
            raise Rejected("REFERENCE_INVALID") from None
        raise
    if response["quote_id"] != payload["quote_id"]:
        raise Rejected("REFERENCE_INVALID")
    if command == "quote.response.record":
        if (response["classification"] != payload["classification"]
                or public_time(response["recorded_at"]) != payload["recorded_at"]):
            raise Rejected("REFERENCE_INVALID")
    elif (response["verification"] is None
          or response["verification"]["acceptance_id"] != payload["acceptance_id"]):
        raise Rejected("REFERENCE_INVALID")
    if request_hash is not None:
        if command == "quote.response.record":
            args = {name: response[name] for name in (
                "response_id", "quote_id", "source_id", "locator", "classification", "summary")}
        else:
            link = db.execute(
                "SELECT body_json FROM t04_response_verification WHERE tenant=? AND company=? AND response_id=?",
                (*who.scope, response["response_id"]),
            ).fetchone()
            args = {"response_id": response["response_id"], "verification": _json(link["body_json"])}
        request = {"contract": "brant.quotation/0.1.0", "command": command,
                   "idempotency_key": key, "args": args}
        if hashlib.sha256(canonical(request).encode("utf-8")).hexdigest() != request_hash:
            raise Rejected("REFERENCE_INVALID")
    return response
