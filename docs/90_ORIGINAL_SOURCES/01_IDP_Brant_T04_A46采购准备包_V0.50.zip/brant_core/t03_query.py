"""Closed read-only adapter for the T03 quotation query contract.

The write methods remain trusted local methods.  This module exposes compact
runtime views whose public fields are backed by the current SQLite schema.
Candidate query kinds that would require unpersisted fields stay explicit
unsupported rather than leaking internal rows as an accidental contract.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from . import t03_reconciliation, t03_storage, t04_response
from .common import Rejected, canonical

CONTRACT = "brant.quotation/0.1.0"
SCHEMAS = Path(__file__).parent / "contracts"
REQUEST_VALIDATOR = Draft202012Validator(
    json.loads((SCHEMAS / "T03_queries.schema.json").read_text(encoding="utf-8"))
)
RESPONSE_VALIDATOR = Draft202012Validator(
    json.loads((SCHEMAS / "T03_query-responses.schema.json").read_text(encoding="utf-8"))
)

_SUPPORTED_KINDS = {
    "quote_root",
    "quote_ready",
    "quote_history",
    "approval_history",
    "document_history",
    "outbox_history",
    "commit_history",
    "dispatch_preflight",
    "dispatch_target",
    "acceptance_history",
    "order_history",
    "order_review",
    "customer_response",
    "action_reconciliation",
}
_REASON_MAP = {
    "NO_ACTIVE_REVISION": "QUOTE_NOT_CURRENT",
    "ACTIVE_REVISION_MISSING": "QUOTE_NOT_CURRENT",
    "FORMAL_DOCUMENT_MISSING": "REFERENCE_INVALID",
    "FORMAL_DOCUMENT_INTEGRITY_FAILURE": "REFERENCE_INVALID",
    "COST_SNAPSHOT_MISSING": "REFERENCE_INVALID",
    "COST_SNAPSHOT_INELIGIBLE": "COST_SNAPSHOT_NOT_ELIGIBLE",
    "COST_INPUT_NOT_READY": "DRAFT_NOT_READY",
    "FX_STALE": "REFERENCE_STALE",
    "APPROVAL_STALE": "REFERENCE_STALE",
    "CONFIG_NOT_ACTIVE": "REFERENCE_STALE",
    "CONFIG_EXPIRED": "REFERENCE_STALE",
}


def _kind(request: Any) -> str:
    value = request.get("kind") if isinstance(request, dict) else None
    return (
        value
        if isinstance(value, str)
        and value
        in {
            "quote_root",
            "quote_revision",
            "quote_ready",
            "quote_history",
            "approval_history",
            "document_history",
            "outbox_history",
            "commit_history",
            "dispatch_preflight",
            "dispatch_target",
            "approval",
            "document",
            "acceptance_history",
            "order_history",
            "order_review",
            "customer_response",
            "action_reconciliation",
        }
        else "quote_root"
    )


def _error(kind: str, code: str) -> dict[str, Any]:
    result = {"ok": False, "kind": kind, "code": code}
    RESPONSE_VALIDATOR.validate(result)
    return result


def _root_value(row) -> dict[str, Any]:
    value: dict[str, Any] = {
        "quote_id": row["quote_id"],
        "root_version": row["root_version"],
    }
    if row["active_revision"] is not None:
        value["current_active_revision"] = row["active_revision"]
    if row["working_revision"] is not None:
        value["working_generation"] = row["working_revision"]
    return value


def _ready_value(result: dict[str, Any]) -> dict[str, Any]:
    reasons: list[str] = []
    for reason in result.get("reasons", []):
        mapped = _REASON_MAP.get(reason, reason)
        if mapped not in reasons:
            reasons.append(mapped)
    value: dict[str, Any] = {
        "quote_id": result["object_id"],
        "currently_ready": bool(result["quote_ready"]),
        "checked_at": result["checked_at"],
        "reason_codes": reasons,
    }
    if result.get("business_revision") is not None:
        value["business_revision"] = result["business_revision"]
    return value


def _success(kind: str, value: dict[str, Any]) -> dict[str, Any]:
    result = {"ok": True, "kind": kind, "value": value}
    RESPONSE_VALIDATOR.validate(result)
    return result


def _history_value(result: dict[str, Any]) -> dict[str, Any]:
    root = result["root"]
    revisions = result["revisions"]
    if len(revisions) != 1:
        raise Rejected("NOT_FOUND")
    source = revisions[0]
    data = source["data"]
    value: dict[str, Any] = {
        "quote_id": result["object_id"],
        "root_version": root["root_version"],
        "status": root["status"],
        "revision": {
            "business_revision": source["business_revision"],
            "status": source["status"],
            "business_hash": source["business_hash"],
        },
        "event_count": len(result["events"]),
    }
    if root["active_revision"] is not None:
        value["current_active_revision"] = root["active_revision"]
    revision = value["revision"]
    for key in ("issued_at", "expires_at"):
        if isinstance(data.get(key), str):
            revision[key] = data[key]
    calculation = source.get("calculation")
    if isinstance(calculation, dict):
        fields = (
            "net_minor",
            "tax_minor",
            "payable_minor",
            "comparison_revenue_minor",
            "cost_minor",
            "profit_minor",
            "margin_rule",
        )
        if all(field in calculation for field in fields):
            revision["calculation"] = {field: calculation[field] for field in fields}
    qualification = source.get("current_cost_qualification")
    if isinstance(qualification, dict) and "snapshot_id" in qualification:
        revision["current_cost_qualification"] = {
            key: qualification[key]
            for key in (
                "snapshot_id",
                "currently_eligible_for_quote",
                "result_hash",
                "eligibility_checked_at",
                "reason",
            )
            if key in qualification
        }
    return value


def _approval_history_value(result: dict[str, Any]) -> dict[str, Any]:
    """Keep approval history separate from the candidate full approval view."""
    fields = (
        "approval_id",
        "review_request_id",
        "quote_id",
        "business_revision",
        "business_hash",
        "target_command",
        "reviewer",
        "decision",
        "decided_at",
        "expires_at",
        "effectivity",
        "effectivity_version",
        "review_request_status",
        "requested_by",
        "requested_at",
        "event_count",
        "events",
    )
    return {field: result[field] for field in fields}


def _document_history_value(result: dict[str, Any]) -> dict[str, Any]:
    fields = (
        "document_id",
        "quote_id",
        "business_revision",
        "business_hash",
        "number_id",
        "document_number",
        "file_id",
        "file_name",
        "file_sha256",
        "mime_type",
        "byte_size",
        "created_at",
        "number_integrity",
        "file_integrity",
        "integrity_status",
        "configuration_bindings",
    )
    return {field: result[field] for field in fields}


def _outbox_history_value(result: dict[str, Any]) -> dict[str, Any]:
    fields = (
        "event_id",
        "quote_id",
        "business_revision",
        "event_type",
        "created_at",
        "payload_sha256",
        "dispatch_state",
        "external_delivery_status",
    )
    return {field: result[field] for field in fields}


def _commit_history_value(result: dict[str, Any]) -> dict[str, Any]:
    fields = (
        "commit_id",
        "quote_id",
        "business_revision",
        "business_hash",
        "server_commit_at",
        "authority_epoch",
        "control_epoch",
        "approval_id",
        "cost_snapshot_id",
        "created_at",
        "result_sha256",
        "formal_number",
        "file_sha256",
        "has_cost_qualification",
    )
    return {field: result[field] for field in fields}


def _dispatch_preflight_value(result: dict[str, Any]) -> dict[str, Any]:
    fields = (
        "event_id",
        "quote_id",
        "business_revision",
        "event_type",
        "commit_id",
        "approval_id",
        "document_id",
        "checked_at",
        "ready_for_dispatch",
        "reason_codes",
        "external_delivery_status",
    )
    return {field: result[field] for field in fields}


def _dispatch_target_value(result: dict[str, Any]) -> dict[str, Any]:
    fields = (
        "event_id",
        "quote_id",
        "business_revision",
        "event_type",
        "customer_ref",
        "contact_ref",
        "document_id",
        "dispatch_preflight_ready",
        "recipient_snapshot_id",
        "recipient_snapshot_hash",
        "recipient_snapshot_available",
        "local_target_ready",
        "target_ready",
        "channel_status",
        "reason_codes",
        "external_delivery_status",
    )
    return {field: result[field] for field in fields}


def _acceptance_history_value(result: dict[str, Any]) -> dict[str, Any]:
    return result


def _order_history_value(result: dict[str, Any]) -> dict[str, Any]:
    return result


def _order_review_value(result: dict[str, Any]) -> dict[str, Any]:
    requested_at = result["requested_at"].replace("+00:00", "Z")
    return {
        "review_id": result["review_id"],
        "order_id": result["order_id"],
        "order_hash": result["order_hash"],
        "order_version": result["order_version"],
        "requested_by": result["requested_by"],
        "requested_at": requested_at,
        "decision": result["decision"],
        "activation": result["activation"],
        "revocation": result["revocation"],
        "decision_state": result["decision_state"],
    }


def execute(core, who, request: Any) -> dict[str, Any]:
    """Execute one bounded T03 query and return a closed response envelope."""

    kind = _kind(request)
    try:
        if not core._t03_enabled:
            raise Rejected("UNSUPPORTED_CONTRACT")
        try:
            encoded = canonical(request).encode("utf-8")
        except (TypeError, ValueError, UnicodeError, RecursionError):
            raise Rejected("SCHEMA_INVALID") from None
        if len(encoded) > 1024 * 1024 or not REQUEST_VALIDATOR.is_valid(request):
            raise Rejected("SCHEMA_INVALID")
        kind = request["kind"]
        if kind not in _SUPPORTED_KINDS:
            raise Rejected("UNSUPPORTED_CONTRACT")
        args = request["args"]
        object_id = (
            args.get("quote_id")
            or args.get("approval_id")
            or args.get("document_id")
            or args.get("event_id")
            or args.get("commit_id")
            or args.get("acceptance_id")
            or args.get("order_id")
            or args.get("review_id")
            or args.get("response_id")
        )
        with core._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                core._authorize(db, who, "quote.read")
                if kind == "quote_root":
                    core._access(db, who, "quote", object_id)
                    row = t03_storage.quote_row(db, who.scope, object_id)
                    result = _success(kind, _root_value(row))
                elif kind == "quote_history":
                    for permission in ("costing.read", "read", "foundation.read"):
                        core._authorize(db, who, permission)
                    core._access(db, who, "quote", object_id)
                    history = t03_storage.quote_get(
                        core, db, who, object_id, args["business_revision"]
                    )
                    result = _success(kind, _history_value(history))
                elif kind == "approval_history":
                    history = t03_storage.approval_history(db, who.scope, args["approval_id"])
                    core._access(db, who, "quote", history["quote_id"])
                    result = _success(kind, _approval_history_value(history))
                elif kind == "document_history":
                    for permission in ("read", "foundation.read"):
                        core._authorize(db, who, permission)
                    history = t03_storage.document_history(
                        db, who.scope, args["document_id"]
                    )
                    core._access(db, who, "quote", history["quote_id"])
                    result = _success(kind, _document_history_value(history))
                elif kind == "outbox_history":
                    for permission in ("read", "foundation.read"):
                        core._authorize(db, who, permission)
                    history = t03_storage.outbox_history(
                        db, who.scope, args["event_id"]
                    )
                    core._access(db, who, "quote", history["quote_id"])
                    result = _success(kind, _outbox_history_value(history))
                elif kind == "commit_history":
                    for permission in ("read", "foundation.read"):
                        core._authorize(db, who, permission)
                    history = t03_storage.commit_history(
                        db, who.scope, args["commit_id"]
                    )
                    core._access(db, who, "quote", history["quote_id"])
                    result = _success(kind, _commit_history_value(history))
                elif kind == "dispatch_preflight":
                    for permission in ("read", "foundation.read"):
                        core._authorize(db, who, permission)
                    history = t03_storage.dispatch_preflight(
                        core, db, who.scope, args["event_id"]
                    )
                    core._access(db, who, "quote", history["quote_id"])
                    result = _success(kind, _dispatch_preflight_value(history))
                elif kind == "dispatch_target":
                    for permission in ("read", "foundation.read"):
                        core._authorize(db, who, permission)
                    history = t03_storage.dispatch_target(
                        core, db, who.scope, args["event_id"]
                    )
                    core._access(db, who, "quote", history["quote_id"])
                    result = _success(kind, _dispatch_target_value(history))
                elif kind == "acceptance_history":
                    core._authorize(db, who, "read")
                    history = t03_storage.acceptance_history(db, who.scope, args["acceptance_id"])
                    core._access(db, who, "quote", history["quote_id"])
                    result = _success(kind, _acceptance_history_value(history))
                elif kind == "order_history":
                    core._authorize(db, who, "read")
                    history = t03_storage.order_history(db, who.scope, args["order_id"])
                    core._access(db, who, "quote", history["source_quote_id"])
                    result = _success(kind, _order_history_value(history))
                elif kind == "order_review":
                    core._authorize(db, who, "read")
                    from . import t04_order_review

                    review = t04_order_review.get(core, db, who, args["review_id"], None)
                    result = _success(kind, _order_review_value(review))
                elif kind == "customer_response":
                    core._authorize(db, who, "read")
                    response = t04_response.get(core, db, who, args["response_id"])
                    value = t04_response.public_value(response)
                    if not RESPONSE_VALIDATOR.is_valid({"ok": True, "kind": kind, "value": value}):
                        raise Rejected("REFERENCE_INVALID")
                    result = _success(kind, value)
                elif kind == "action_reconciliation":
                    reconciliation = t03_reconciliation.reconcile(
                        core, db, who, args["command"], args["idempotency_key"],
                        args["request_hash"],
                    )
                    object_id = reconciliation["object_id"]
                    result = _success(kind, reconciliation)
                else:
                    for permission in ("costing.read", "read", "foundation.read"):
                        core._authorize(db, who, permission)
                    core._access(db, who, "quote", object_id)
                    result = _success(
                        kind,
                        _ready_value(t03_storage.quote_ready(core, db, who, object_id)),
                    )
                core._audit(
                    db,
                    who,
                    f"quote.query.{kind}",
                    object_id,
                    "read",
                    None,
                    uuid.uuid4().hex,
                )
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise
    except Rejected as exc:
        rejected_args = request.get("args") if isinstance(request, dict) else None
        rejected_args = rejected_args if isinstance(rejected_args, dict) else {}
        with core._connection() as db:
            try:
                core._audit(
                    db,
                    who,
                    f"quote.query.{kind}",
                    (
                        rejected_args.get("quote_id")
                        or rejected_args.get("approval_id")
                        or rejected_args.get("document_id")
                        or rejected_args.get("event_id")
                        or rejected_args.get("commit_id")
                        or rejected_args.get("response_id")
                    )
                    if isinstance(request, dict)
                    else None,
                    "rejected",
                    exc.code,
                    uuid.uuid4().hex,
                )
                db.commit()
            except BaseException:
                db.rollback()
        return _error(kind, exc.code)
