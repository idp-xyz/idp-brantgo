"""Trusted local order review, bound to an immutable order snapshot."""

import json
import unicodedata
from datetime import UTC, datetime

from . import t03_storage
from .common import Principal, Rejected


def _id(value):
    if not isinstance(value, str) or not value or len(value) > 64:
        raise Rejected("SCHEMA_INVALID")


def _stamp(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("Timezone required")
    return parsed.astimezone(UTC)


def _human(core, db, who, permissions):
    for permission in permissions:
        core._authorize(db, who, permission)
    actor = db.execute("SELECT actor_kind FROM authorization WHERE tenant=? AND company=? AND actor=?",
                       (*who.scope, who.actor)).fetchone()
    if actor is None or actor["actor_kind"] != "human":
        raise Rejected("PERMISSION_DENIED")


def _order(core, db, who, order_id, task_id):
    _id(order_id)
    order = db.execute("SELECT * FROM t03_order WHERE tenant=? AND company=? AND order_id=?",
                       (*who.scope, order_id)).fetchone()
    if order is None:
        raise Rejected("NOT_FOUND")
    core._access(db, who, "quote", order["source_quote_id"])
    t03_storage._guard_quote(db, who, order["source_quote_id"], task_id)
    t03_storage.validate_order_snapshot(db, who.scope, order_id)
    return order


def _review(db, scope, review_id):
    _id(review_id)
    row = db.execute("SELECT * FROM t04_order_review_request WHERE tenant=? AND company=? AND review_id=?",
                     (*scope, review_id)).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    return row


def get(core, db, who, review_id, task_id):
    core._authorize(db, who, "quote.read")
    core._authorize(db, who, "read")
    review = _review(db, who.scope, review_id)
    _order(core, db, who, review["order_id"], task_id)
    decision = db.execute("SELECT decision,reviewer,decided_at,expires_at FROM t04_order_review_decision "
                          "WHERE tenant=? AND company=? AND review_id=?", (*who.scope, review_id)).fetchone()
    activation = db.execute("SELECT order_id,quote_approval_id,activated_by,activated_at "
                            "FROM t04_order_review_activation WHERE tenant=? AND company=? AND review_id=?",
                            (*who.scope, review_id)).fetchone()
    revocation = db.execute("SELECT revoked_by,revoked_at,reason FROM t04_order_review_revocation "
                           "WHERE tenant=? AND company=? AND review_id=?", (*who.scope, review_id)).fetchone()
    state = "pending" if decision is None else decision["decision"]
    if revocation:
        state = "revoked"
    elif state == "approved" and core.clock().astimezone(UTC) >= _stamp(decision["expires_at"]):
        state = "expired"
    return {**dict(review), "decision": dict(decision) if decision else None,
            "activation": dict(activation) if activation else None,
            "revocation": dict(revocation) if revocation else None, "decision_state": state}


def request(core, db, who, order_id, review_id, task_id):
    _human(core, db, who, ("order.review.request", "quote.read", "read"))
    _id(review_id)
    order = _order(core, db, who, order_id, task_id)
    existing = db.execute("SELECT * FROM t04_order_review_request WHERE tenant=? AND company=? AND review_id=?",
                          (*who.scope, review_id)).fetchone()
    if existing:
        if existing["order_id"] != order_id or existing["requested_by"] != who.actor:
            raise Rejected("ORDER_REVIEW_IMMUTABLE")
        return {"review_id": review_id, "order_id": order_id, "replayed": True}
    if order["status"] != "draft":
        raise Rejected("ORDER_NOT_DRAFT")
    db.execute("INSERT INTO t04_order_review_request VALUES(?,?,?,?,?,?,?,?)",
               (*who.scope, review_id, order_id, order["order_hash"], order["row_version"],
                who.actor, core.clock().astimezone(UTC).isoformat()))
    return {"review_id": review_id, "order_id": order_id, "replayed": False}


def decide(core, db, who, review_id, decision, expires_at, task_id):
    _human(core, db, who, ("order.review.decide", "quote.read", "read"))
    review = _review(db, who.scope, review_id)
    order = _order(core, db, who, review["order_id"], task_id)
    prepared = db.execute("SELECT actor FROM t03_order_event WHERE tenant=? AND company=? AND order_id=? "
                          "AND event_type='prepared'", (*who.scope, order["order_id"])).fetchall()
    if len(prepared) != 1 or who.actor in (review["requested_by"], prepared[0]["actor"]):
        raise Rejected("REVIEWER_NOT_INDEPENDENT")
    if decision not in ("approved", "rejected") or not isinstance(expires_at, str):
        raise Rejected("SCHEMA_INVALID")
    previous = db.execute("SELECT * FROM t04_order_review_decision WHERE tenant=? AND company=? AND review_id=?",
                          (*who.scope, review_id)).fetchone()
    if previous:
        if (previous["reviewer"], previous["decision"], previous["expires_at"]) != (who.actor, decision, expires_at):
            raise Rejected("ORDER_REVIEW_IMMUTABLE")
        return {"review_id": review_id, "decision": decision, "replayed": True}
    if order["status"] != "draft" or order["row_version"] != review["order_version"] or order["order_hash"] != review["order_hash"]:
        raise Rejected("ORDER_REVIEW_STALE")
    try:
        expires = _stamp(expires_at)
        quote = db.execute("SELECT data_json FROM t03_quote_revision WHERE tenant=? AND company=? "
                           "AND quote_id=? AND business_revision=?", (*who.scope, order["source_quote_id"],
                           order["source_quote_revision"])).fetchone()
        quote_expires = _stamp(json.loads(quote["data_json"])["expires_at"])
    except (KeyError, TypeError, ValueError, OverflowError):
        raise Rejected("SCHEMA_INVALID") from None
    instant = core.clock().astimezone(UTC)
    if expires <= instant or expires > quote_expires:
        raise Rejected("ORDER_REVIEW_EXPIRY_INVALID")
    db.execute("INSERT INTO t04_order_review_decision VALUES(?,?,?,?,?,?,?)",
               (*who.scope, review_id, decision, who.actor, instant.isoformat(), expires_at))
    return {"review_id": review_id, "decision": decision, "replayed": False}


def activate(core, db, who, order_id, review_id, quote_approval_id, task_id):
    _human(core, db, who, ("order.activate", "quote.read", "read"))
    _id(quote_approval_id)
    order = _order(core, db, who, order_id, task_id)
    _id(review_id)
    result = t03_storage.activate_order(core, db, who, order_id, order["row_version"],
                                        quote_approval_id, task_id=task_id, order_review_id=review_id)
    return {**result, "review_id": review_id}


def qualify(core, db, who, order, review_id):
    """Check a new activation inside its caller-owned IMMEDIATE transaction."""
    if review_id is None:
        raise Rejected("ORDER_APPROVAL_REQUIRED")
    review = _review(db, who.scope, review_id)
    if review["order_id"] != order["order_id"]:
        raise Rejected("ORDER_REVIEW_MISMATCH")
    if order["row_version"] != review["order_version"] or order["order_hash"] != review["order_hash"]:
        raise Rejected("ORDER_REVIEW_STALE")
    decision = db.execute("SELECT * FROM t04_order_review_decision WHERE tenant=? AND company=? AND review_id=?",
                          (*who.scope, review_id)).fetchone()
    if decision is None or decision["decision"] != "approved":
        raise Rejected("ORDER_APPROVAL_REQUIRED")
    if db.execute("SELECT 1 FROM t04_order_review_revocation WHERE tenant=? AND company=? AND review_id=?",
                  (*who.scope, review_id)).fetchone():
        raise Rejected("ORDER_APPROVAL_REVOKED")
    prepared = db.execute("SELECT actor FROM t03_order_event WHERE tenant=? AND company=? AND order_id=? "
                          "AND event_type='prepared'", (*who.scope, order["order_id"])).fetchall()
    if len(prepared) != 1 or decision["reviewer"] in (review["requested_by"], prepared[0]["actor"]):
        raise Rejected("REVIEWER_NOT_INDEPENDENT")
    reviewer = Principal(who.tenant, who.company, decision["reviewer"])
    _human(core, db, reviewer, ("order.review.decide", "quote.read", "read"))
    core._access(db, reviewer, "quote", order["source_quote_id"])
    try:
        expires = _stamp(decision["expires_at"])
    except (TypeError, ValueError, OverflowError):
        raise Rejected("REFERENCE_INVALID") from None
    if core.clock().astimezone(UTC) >= expires:
        raise Rejected("ORDER_APPROVAL_EXPIRED")
    return {"review_id": review_id, "order_hash": review["order_hash"],
            "order_version": review["order_version"], "requested_by": review["requested_by"],
            "reviewer": decision["reviewer"], "decided_at": decision["decided_at"],
            "expires_at": decision["expires_at"]}


def revoke(core, db, who, review_id, reason, task_id):
    _human(core, db, who, ("order.approval.revoke", "quote.read", "read"))
    review = _review(db, who.scope, review_id)
    _order(core, db, who, review["order_id"], task_id)
    if (not isinstance(reason, str) or not reason.strip() or len(reason) > 1000 or
            any(unicodedata.category(char).startswith("C") for char in reason)):
        raise Rejected("SCHEMA_INVALID")
    decision = db.execute("SELECT decision FROM t04_order_review_decision "
                          "WHERE tenant=? AND company=? AND review_id=?", (*who.scope, review_id)).fetchone()
    if decision is None or decision["decision"] != "approved":
        raise Rejected("ORDER_APPROVAL_REQUIRED")
    previous = db.execute("SELECT * FROM t04_order_review_revocation "
                          "WHERE tenant=? AND company=? AND review_id=?", (*who.scope, review_id)).fetchone()
    if previous:
        if (previous["revoked_by"], previous["reason"]) != (who.actor, reason):
            raise Rejected("ORDER_REVIEW_IMMUTABLE")
        return {"review_id": review_id, "revoked": True, "replayed": True}
    db.execute("INSERT INTO t04_order_review_revocation VALUES(?,?,?,?,?,?)",
               (*who.scope, review_id, who.actor, core.clock().astimezone(UTC).isoformat(), reason))
    return {"review_id": review_id, "revoked": True, "replayed": False}
