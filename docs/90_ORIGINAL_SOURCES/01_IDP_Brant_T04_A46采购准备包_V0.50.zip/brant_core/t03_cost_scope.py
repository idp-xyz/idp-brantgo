"""Bind a structured quote to the complete RFQ and exact frozen cost scope."""
from __future__ import annotations

import re
from fractions import Fraction
from typing import Any

from . import costing, foundation, t03_storage
from .common import Rejected, canonical
from .costing_engine.validator import Invalid

CONTRACT = "brant.quote-cost-scope/0.1.0"
FIELDS = ("rfq_ref", "customer_ref", "contact_ref", "pricing_policy_ref",
          "trade_terms_ref", "trade_scope_ref", "named_place_ref", "payment_terms_ref", "delivery")
FACTOR = re.compile(r"(?:0|[1-9][0-9]{0,11})(?:\.[0-9]{1,12})?")
NUMBER = re.compile(r"(?:0|[1-9][0-9]{0,11})(?:\.[0-9]{1,6})?")


def require(value: bool, code: str = "COMPARISON_BASIS_MISMATCH") -> None:
    if not value:
        raise Rejected(code)


def number(value: Any) -> Fraction:
    require(isinstance(value, str) and NUMBER.fullmatch(value) is not None, "INVALID_KNOWN_VALUE")
    return Fraction(value)


def ref(value: Any, kind: str) -> dict:
    require(isinstance(value, dict) and set(value) == {"kind", "id", "revision"}, "REFERENCE_INVALID")
    require(value["kind"] == kind and isinstance(value["id"], str)
            and type(value["revision"]) is int and value["revision"] > 0, "REFERENCE_INVALID")
    return value


def bind(core, db, who, data: dict, snapshot: dict, calculation: dict | None = None) -> dict:
    """Use only the existing writer connection; never commit or repair history."""
    if not db.in_transaction:
        raise RuntimeError("Cost-scope binding requires the caller transaction")
    try:
        return _bind(core, db, who, data, snapshot, calculation)
    except Invalid as exc:
        raise Rejected(exc.code) from None
    except (KeyError, TypeError, ValueError, ZeroDivisionError):
        raise Rejected("REFERENCE_INVALID") from None


def _bind(core, db, who, data, snapshot, calculation):
    require(all(key in data for key in FIELDS), "DRAFT_NOT_READY")
    require(snapshot["kind"] == "snapshot" and snapshot["verification_status"] == "verified"
            and snapshot["comparison_status"] == "comparable", "COST_SNAPSHOT_INELIGIBLE")
    require(snapshot["cost_basis"] == "nominal_direct_cost")
    model, _ = costing.models(core, db, who)
    model._actor = costing.actor(core, db, who)
    manifest: dict = {}
    configs: dict[str, dict] = {}

    def config(value, kind):
        value = ref(value, kind)
        key = canonical(value)
        if key not in configs:
            t03_storage.guard(db, who, kind, value["id"])
            resolved = model._cfg(value, manifest, kind)
            configs[key] = {"ref": value, "data_hash": foundation.digest(resolved), "data": resolved}
        return configs[key]["data"]

    def proof(kind, id_, version, value):
        proofs = [m for m in snapshot["input_manifest"]
                  if (m["kind"], m["id"], m["version"]) == (kind, id_, version)]
        require(len(proofs) == 1 and proofs[0]["content_hash"] == foundation.digest(value),
                "REFERENCE_INVALID")

    context_ref = ref(snapshot["context_ref"], "costing_context")
    context = model._business(context_ref, manifest, "costing_context")
    proof("costing_context", context_ref["id"], context_ref["revision"], context)
    require(context["context_kind"] == "actual", "COST_SNAPSHOT_INELIGIBLE")
    require(data["rfq_ref"] == context["rfq_ref"] == snapshot["rfq_ref"])
    rfq_ref = data["rfq_ref"]
    require(isinstance(rfq_ref, dict) and set(rfq_ref) == {"id", "row_version"}, "REFERENCE_INVALID")
    rfq = core._load(db, who, "rfq", rfq_ref["id"])
    require(rfq["row_version"] == rfq_ref["row_version"] and rfq["status"] == "ready", "REFERENCE_STALE")
    for field, kind in (("customer_ref", "customer"), ("contact_ref", "contact")):
        master = data[field]
        require(isinstance(master, dict) and master.get("kind") == kind, "REFERENCE_INVALID")
        model._master(master, manifest, kind)
        require(master["id"] == rfq[kind+"_id"], "REFERENCE_INVALID")
    contact = core._load(db, who, "master", data["contact_ref"]["id"])
    require(contact["parent_customer_id"] == data["customer_ref"]["id"], "REFERENCE_INVALID")
    policy = config(data["pricing_policy_ref"], "pricing_policy")
    require(data["pricing_policy_ref"] == context["pricing_policy_ref"])
    require(policy["calculation_currency"] == context["calculation_currency_ref"])
    require(snapshot["currency"] == context["calculation_currency_ref"]["id"])
    basis = context["comparison_basis"]
    require(basis["cost_basis"] == snapshot["cost_basis"])
    require(data["trade_scope_ref"] == basis["sales_trade_scope_ref"])
    scope = config(data["trade_scope_ref"], "trade_scope")
    require(scope["role"] == "export_sale")
    binding = {
        "trade_terms_ref": scope["trade_terms_ref"], "trade_scope_ref": basis["sales_trade_scope_ref"],
        "named_place_ref": basis["named_place_ref"], "payment_terms_ref": basis["sales_payment_terms_ref"],
        "delivery": basis["delivery"], "pricing_policy_ref": context["pricing_policy_ref"],
        "calculation_currency_ref": context["calculation_currency_ref"],
        "cost_basis": snapshot["cost_basis"],
    }
    require(scope["named_place_ref"] == basis["named_place_ref"])
    for field in ("trade_terms_ref", "named_place_ref", "payment_terms_ref", "delivery"):
        require(data[field] == binding[field])
    config(data["trade_terms_ref"], "trade_terms")
    config(data["named_place_ref"], "location")
    config(data["payment_terms_ref"], "payment_terms")
    require(data["delivery"].get("kind") == "fixed", "DEPENDENCY_NOT_SUPPORTED")
    config(data["delivery"]["place_ref"], "location")
    demand = {r["line_id"]: dict(r) for r in db.execute(
        "SELECT * FROM rfq_line WHERE tenant=? AND company=? AND rfq_id=? ORDER BY line_id",
        (*who.scope, rfq_ref["id"]))}
    context_lines = context["lines"]
    require(isinstance(context_lines, list) and 0 < len(context_lines) <= 200, "REFERENCE_INVALID")
    covered = {r["line_id"]: r for r in context_lines}
    require(len(covered) == len(context_lines) and set(covered) == set(demand))
    lines = data["lines"]
    require(isinstance(lines, list) and 0 < len(lines) <= 200, "DRAFT_NOT_READY")
    seen: set[str] = set()
    used: set[str] = set()
    line_bindings = []
    for line in lines:
        require(isinstance(line, dict) and all(k in line for k in
                ("line_id", "rfq_line_id", "sku_profile_ref", "unit_ref", "quantity")), "DRAFT_NOT_READY")
        identifier, target = line["line_id"], line["rfq_line_id"]
        require(isinstance(identifier, str) and bool(identifier) and identifier not in seen, "DUPLICATE_LINE_ID")
        seen.add(identifier)
        require(isinstance(target, str) and target not in used and target in demand)
        used.add(target)
        source, cost = demand[target], covered[target]
        require(line["sku_profile_ref"] == cost["sku_profile_ref"])
        sku_ref = ref(line["sku_profile_ref"], "sku_profile")
        sku = config(sku_ref, "sku_profile")
        proof("sku_profile", sku_ref["id"], sku_ref["revision"], sku)
        require(sku["sku_id"] == source["sku_id"])
        model._master({"kind": "sku", "id": sku["sku_id"], "row_version": sku["sku_row_version"]}, manifest, "sku")
        sale_unit = config(line["unit_ref"], "unit")
        standard_unit = config(cost["unit_ref"], "unit")
        require(standard_unit["code"] == source["uom"], "DEPENDENCY_NOT_SUPPORTED")
        quantity = number(line["quantity"])
        require(quantity > 0 and (quantity * 10**int(sale_unit["precision"])).denominator == 1,
                "INVALID_KNOWN_VALUE")
        normalized = quantity
        conversion_ref = line.get("conversion_ref")
        if line["unit_ref"] != cost["unit_ref"]:
            require(conversion_ref is not None, "DEPENDENCY_NOT_SUPPORTED")
            conversion = config(conversion_ref, "conversion")
            require(conversion["sku_profile"] == sku_ref and conversion["from_unit"] == line["unit_ref"]
                    and conversion["to_unit"] == cost["unit_ref"], "REFERENCE_INVALID")
            require(isinstance(conversion["factor"], str) and FACTOR.fullmatch(conversion["factor"]) is not None,
                    "REFERENCE_INVALID")
            factor = Fraction(conversion["factor"])
            require(factor > 0, "REFERENCE_INVALID")
            normalized *= factor
        else:
            require(conversion_ref is None, "REFERENCE_INVALID")
        require(normalized == number(source["quantity"]) == number(cost["quantity"]))
        require((normalized * 10**int(standard_unit["precision"])).denominator == 1, "INVALID_KNOWN_VALUE")
        line_bindings.append({
            "line_id": identifier, "rfq_line_id": target, "sku_profile_ref": sku_ref,
            "quantity": str(quantity), "unit_ref": line["unit_ref"],
            "normalized_quantity": str(normalized), "cost_unit_ref": cost["unit_ref"],
            "conversion_ref": conversion_ref,
        })
    require(used == set(demand))
    evidence = {
        "contract": CONTRACT, "snapshot_id": snapshot["id"], "snapshot_result_hash": snapshot["result_hash"],
        "snapshot_evidence_hash": snapshot["evidence_hash"],
        "input_manifest_hash": foundation.digest(snapshot["input_manifest"]),
        "context_ref": context_ref, "context_hash": foundation.digest(context),
        "rfq_ref": rfq_ref, "customer_ref": data["customer_ref"], "contact_ref": data["contact_ref"],
        "rfq_lines_hash": foundation.digest([demand[k] for k in sorted(demand)]),
        "comparison_binding": binding,
        "line_bindings": sorted(line_bindings, key=lambda r: r["line_id"]),
        "configuration_bindings": [
            {"ref": value["ref"], "data_hash": value["data_hash"]} for _, value in sorted(configs.items())
        ],
    }
    evidence["binding_hash"] = foundation.digest(evidence)
    if calculation is not None:
        require(calculation.get("cost_scope_binding") == evidence, "REFERENCE_INVALID")
    return evidence
