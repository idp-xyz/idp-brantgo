"""Current sales-side tax and fixed-income charge bindings, never tax-law inference."""
from __future__ import annotations

import re
from decimal import Decimal
from fractions import Fraction
from typing import Any

from . import foundation, t03_config, t03_storage
from .common import Rejected

CONTRACT = "brant.quote-sales-terms/0.1.0"
DECIMAL = re.compile(r"(?:0|[1-9][0-9]{0,11})(?:\.[0-9]{1,8})?")


def require(condition: bool, code: str) -> None:
    if not condition:
        raise Rejected(code)


def amount(value: Any) -> Fraction:
    require(isinstance(value,str) and DECIMAL.fullmatch(value) is not None,"INVALID_KNOWN_VALUE")
    result=Fraction(value)
    require(result>0,"INVALID_KNOWN_VALUE")
    return result


def bind(core,db,who,data:dict,calculation:dict|None=None)->dict:
    """Use the existing writer connection; do not commit, rollback or reprice."""
    if not db.in_transaction:
        raise RuntimeError("Sales terms require the caller writer transaction")
    try:
        return _bind(core,db,who,data,calculation)
    except (KeyError,TypeError,ValueError,ArithmeticError,AttributeError):
        raise Rejected("REFERENCE_INVALID") from None


def _bind(core,db,who,data,calculation):
    issuer=data.get("issuer_ref")
    require(isinstance(issuer,dict),"DRAFT_NOT_READY")
    require(set(issuer)=={"kind","id","revision"} and issuer["kind"]=="company"
            and issuer["id"]==who.company,"REFERENCE_INVALID")
    t03_storage.guard(db,who,"company",issuer["id"])
    company=foundation.active(core,db,who,issuer)
    customer=data.get("customer_ref")
    require(isinstance(customer,dict) and customer.get("kind")=="customer","REFERENCE_INVALID")
    current=core._master_ref(db,who,customer["id"],"customer","/args/data/customer_ref",True)
    require(current["row_version"]==customer["row_version"],"REFERENCE_STALE")
    tax_rows=[]
    tax_by_role={}

    def tax(role,application_ref,subject):
        require(isinstance(application_ref,dict)
                and application_ref.get("kind")=="sales_tax_application","TAX_POLICY_UNCONFIRMED")
        record=t03_config.active_in_transaction(core,db,who,application_ref)
        application=record["data"]
        require(application["use"]=="quotation_sale" and application["business_model"]=="CN-M01"
                and application["issuer_ref"]==issuer and application["customer_ref"]==customer,
                "TAX_POLICY_UNCONFIRMED")
        require(isinstance(subject,dict) and application["subject_kind"]==subject.get("kind")
                and application["subject_ref"]==subject,"TAX_POLICY_UNCONFIRMED")
        profile_ref=application["tax_profile_ref"]
        t03_storage.guard(db,who,"tax_profile",profile_ref["id"])
        profile=foundation.active(core,db,who,profile_ref)
        rate=Decimal(profile["rate"])
        require(rate.is_finite() and 0<=rate<=1
                and profile["price_basis"] in {"inclusive","exclusive","not_applicable"}
                and profile["recovery_treatment"]!="unknown"
                and (profile["price_basis"]!="not_applicable" or rate==0),"TAX_POLICY_UNCONFIRMED")
        entry={"role":role,"application_ref":record["ref"],
               **{key:record[key] for key in ("data_hash","record_hash","publication_hash")},
               "tax_profile_ref":profile_ref,"tax_profile_hash":foundation.digest(profile),
               "price_basis":profile["price_basis"],"rate":profile["rate"]}
        tax_rows.append(entry)
        tax_by_role[role]=entry
        return entry

    lines=data.get("lines")
    require(isinstance(lines,list) and 0<len(lines)<=200,"DRAFT_NOT_READY")
    line_map={}
    for line in lines:
        require(isinstance(line,dict) and isinstance(line.get("line_id"),str),"REFERENCE_INVALID")
        identifier=line["line_id"]
        require(bool(identifier) and identifier not in line_map,"DUPLICATE_LINE_ID")
        line_map[identifier]=line
        tax("line:"+identifier,line.get("tax_application_ref"),line.get("sku_profile_ref"))
    charges=data.get("charges",[])
    require(isinstance(charges,list) and len(charges)<=100,"CHARGE_SCOPE_UNRESOLVED")
    identifiers=set()
    obligations=set()
    fee_ids=set()
    charge_rows=[]
    included_totals: dict[str,Fraction]={}
    for charge in charges:
        require(isinstance(charge,dict),"CHARGE_SCOPE_UNRESOLVED")
        identifier,key=charge.get("charge_id"),charge.get("obligation_key")
        require(isinstance(identifier,str) and bool(identifier) and identifier not in identifiers
                and isinstance(key,str) and bool(key) and key not in obligations,"CHARGE_SCOPE_UNRESOLVED")
        require("obligation_id" not in charge,"CHARGE_SCOPE_UNRESOLVED")
        identifiers.add(identifier)
        obligations.add(key)
        fee_ref=charge.get("fee_type_ref")
        require(isinstance(fee_ref,dict) and set(fee_ref)=={"kind","id","revision"}
                and fee_ref.get("kind")=="fee_type","CHARGE_SCOPE_UNRESOLVED")
        identity=(fee_ref["kind"],fee_ref["id"])
        # This bounded slice has one fixed income obligation per fee type.
        # Multiple legs or reusing a fee under renamed keys remain unsupported.
        require(identity not in fee_ids,"CHARGE_SCOPE_UNRESOLVED")
        fee_ids.add(identity)
        t03_storage.guard(db,who,"fee_type",fee_ref["id"])
        fee=foundation.active(core,db,who,fee_ref)
        inclusion=charge.get("inclusion")
        require(fee["side"]=="sales_charge" and inclusion in {"separate","included_in_line"}
                and inclusion==fee["inclusion"],"CHARGE_SCOPE_UNRESOLVED")
        value=amount(charge.get("amount"))
        evidence=charge.get("evidence")
        require(isinstance(evidence,list) and 0<len(evidence)<=200,"CHARGE_SCOPE_UNRESOLVED")
        for item in evidence:
            require(isinstance(item,dict) and isinstance(item.get("locator"),str)
                    and bool(item["locator"].strip()),"REFERENCE_INVALID")
            t03_config._source(core,db,who,item,current=True)
        tax_row=tax("charge:"+key,charge.get("tax_application_ref"),fee_ref)
        included=charge.get("included_line_id")
        if inclusion=="included_in_line":
            require(isinstance(included,str) and included in line_map,"CHARGE_SCOPE_UNRESOLVED")
            covered=tax_by_role["line:"+included]
            require(tax_row["tax_profile_ref"]==covered["tax_profile_ref"],"CHARGE_SCOPE_UNRESOLVED")
            line=line_map[included]
            discount=Fraction(line["discount_ratio"])
            base=amount(line["quantity"])*amount(line["unit_price"])/amount(line["price_basis_quantity"])*(1-discount)
            included_totals[included]=included_totals.get(included,Fraction(0))+value
            require(0<=discount<1 and included_totals[included]<=base,"CHARGE_SCOPE_UNRESOLVED")
        else:
            require("included_line_id" not in charge,"CHARGE_SCOPE_UNRESOLVED")
        charge_rows.append({
            "charge_id":identifier,"obligation_key":key,"fee_type_ref":fee_ref,
            "fee_type_hash":foundation.digest(fee),"amount":charge["amount"],
            "inclusion":inclusion,"included_line_id":included,
            "scope_ref":data["trade_scope_ref"],"evidence_hash":foundation.digest(evidence),
        })
    result={
        "contract":CONTRACT,"issuer_ref":issuer,"issuer_hash":foundation.digest(company),
        "customer_ref":customer,"trade_scope_ref":data["trade_scope_ref"],
        "tax_bindings":sorted(tax_rows,key=lambda row:row["role"]),
        "charge_bindings":sorted(charge_rows,key=lambda row:row["charge_id"]),
    }
    result["binding_hash"]=foundation.digest(result)
    if calculation is not None:
        require(calculation.get("sales_terms_binding")==result,"REFERENCE_INVALID")
    return result
