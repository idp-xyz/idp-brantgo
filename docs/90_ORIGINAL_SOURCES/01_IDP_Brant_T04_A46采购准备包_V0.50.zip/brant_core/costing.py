"""Transactional T02 adapter over the existing local Core trust boundary.

Only Principal from the configured host adapter is trusted. Command requests
cannot supply grants, scope, verification identity or the server clock.
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import UTC
from pathlib import Path
from typing import Any

from .common import Principal, Rejected, canonical
from .costing_engine.command_model import ROOT_TYPES
from .costing_engine.extension_model import ExtensionModel
from .costing_engine.integrated_model import IntegratedModel
from .costing_engine.resource_budget import admit, decode_request
from .costing_engine.rules import RevisionModel
from .costing_engine.validator import SCHEMA, Invalid, digest
from .costing_engine.write_admission import HUMAN_ACTIONS
from .costing_registry import bounded_rows, registry

CONTRACT = "brant.costing/0.1.0"
EXTENSION = "brant.foundation-extension/0.1.0"


def actor(core, db, who):
    row = db.execute(
        "SELECT a.grants_json,a.actor_kind,x.team_id,x.data_scope FROM authorization a "
        "JOIN actor_access x USING(tenant,company,actor) WHERE tenant=? AND company=? AND actor=?",
        (*who.scope, who.actor),
    ).fetchone()
    if row is None:
        raise Rejected("PERMISSION_DENIED")
    grants = json.loads(row["grants_json"])
    if "*" in grants:
        grants = (
            [b["properties"]["command"]["const"] for b in SCHEMA["oneOf"]]
            + [
                "foundation_extension." + name
                for name in ("save_draft", "revise", "discard_draft", "publish", "retire")
            ]
            + ["costing.read", "foundation_extension.read", "foundation.sensitive.read"]
        )
    return {
        "tenant": who.tenant,
        "company": who.company,
        "id": who.actor,
        "kind": row["actor_kind"],
        "grants": grants,
        "readable": True,
        "data_scope": row["data_scope"],
        "team_ids": [row["team_id"]] if row["team_id"] else [],
    }


def record_scope(db, who, kind, id_):
    row = db.execute(
        "SELECT owner_id,team_id FROM record_access WHERE tenant=? AND company=? AND kind=? AND object_id=?",
        (*who.scope, kind, id_),
    ).fetchone()
    if row is None:
        # Missing ownership is not a shared-dictionary fallback for business roots.
        return {"readable": False}
    return {"scope": {"tenant": who.tenant, "company": who.company, **dict(row)}}


def load_roots(db, who, namespace):
    roots = {}
    for row in db.execute(
        "SELECT * FROM t02_root WHERE tenant=? AND company=? AND namespace=?",
        (*who.scope, namespace),
    ):
        model = RevisionModel(kind=row["kind"], independent=True)
        model.version = row["root_version"]
        model.last = row["last_revision"]
        model.working = row["working_revision"]
        model.active = row["active_revision"]
        model.access = record_scope(db, who, f"t02.{namespace}.{row['kind']}", row["id"])
        for revision in db.execute(
            "SELECT * FROM t02_revision WHERE tenant=? AND company=? AND namespace=? AND kind=? AND id=? ORDER BY revision",
            (*who.scope, namespace, row["kind"], row["id"]),
        ):
            model.revisions[revision["revision"]] = {
                **json.loads(revision["metadata_json"]),
                "data": json.loads(revision["data_json"]),
                "sealed": bool(revision["sealed"]),
            }
        roots[row["kind"], row["id"]] = model
    return roots


def models(core, db, who):
    # This first local slice intentionally fails closed above its working-set
    # budget. Do not materialize unbounded tenant histories into Python.
    for table in (
        "t02_root",
        "t02_revision",
        "t02_record",
        "t02_result",
        "t02_denial",
        "source_import",
        "t02_source_attestation",
        "rfq_line",
    ):
        bounded_rows(db, who, table)
    data = registry(core, db, who)
    extension = ExtensionModel(data)
    extension.roots = load_roots(db, who, "extension")
    extension.clock = data["as_of"]
    data["configs"] = extension.export_configs()
    roots = load_roots(db, who, "costing")
    data["delivery_anchor_event_kinds"] = list(ROOT_TYPES)
    # A qualified ID names the verification/publication event of one existing
    # business revision. No caller can provide an occurred_at or verified flag.
    for (kind, id_), root in roots.items():
        if kind not in ROOT_TYPES or len(kind + ":" + id_) > 64:
            continue
        for number, record in root.revisions.items():
            sealed = record["sealed"]
            if sealed and not all(
                k in record for k in ("verified_by", "verified_at", "verification_evidence")
            ):
                continue
            anchor = {
                "status": "verified" if sealed else "pending",
                "evidence": record.get("verification_evidence", []) if sealed else [],
            }
            if sealed:
                anchor["occurred_at"] = record["verified_at"]
            data["verified_business"].append(
                {
                    "ref": {"kind": "delivery_anchor", "id": kind + ":" + id_, "revision": number},
                    "data": anchor,
                    "active": number == (root.active if sealed else root.working),
                    **root.access,
                    "reference_dependencies": [{"kind": kind, "id": id_, "revision": number}]
                    + ([record["verification_policy_ref"]] if sealed else []),
                    "origin_evidence": record["data"].get("evidence", []),
                    "projection": {
                        "event": "published" if kind == "purchase_terms" else "verified",
                        "origin_ref": {"kind": kind, "id": id_, "revision": number},
                        "verified_by": record.get("verified_by"),
                        "verified_at": record.get("verified_at"),
                    },
                }
            )
    model = IntegratedModel(data)
    model.roots = roots
    for row in db.execute("SELECT * FROM t02_record WHERE tenant=? AND company=?", who.scope):
        value = {
            **json.loads(row["metadata_json"]),
            "version": row["row_version"],
            "status": row["status"],
            "data": json.loads(row["data_json"]),
            **record_scope(db, who, "t02.costing." + row["kind"], row["id"]),
        }
        if row["kind"] == "supplier_rfq":
            model.rfqs[row["id"]] = value
        elif row["kind"] == "cost_scenario":
            model.scenarios[row["id"]] = value
    for (kind, id_), root in list(model.roots.items()):
        if kind == "measurement":
            model.measurements[id_] = {
                "version": root.version,
                "last": root.last,
                "active": root.active,
                "revisions": {n: r["data"] for n, r in root.revisions.items()},
                "verification": {n: r["verification"] for n, r in root.revisions.items()},
                **root.access,
            }
            del model.roots[kind, id_]
    for row in db.execute(
        "SELECT * FROM t02_result WHERE tenant=? AND company=? AND sealed=1", who.scope
    ):
        result = json.loads(row["data_json"])
        if row["kind"] == "evaluation":
            model.complete_results[row["id"]] = result
            stored_binding = json.loads(row["binding_json"])
            binding = stored_binding["business"]
            model.bindings[row["id"]] = binding
            model.results[row["id"]] = stored_binding["control"]
        else:
            model.complete_snapshots[row["id"]] = result
            model.snapshots[result["scenario_id"]] = {"result_id": result["evaluation_id"]}
    for row in db.execute("SELECT * FROM t02_denial WHERE tenant=? AND company=?", who.scope):
        model.denials[row["id"]] = json.loads(row["data_json"])
    return model, extension


def persist_roots(core, db, who, namespace, roots):
    for (kind, id_), root in roots.items():
        old = db.execute(
            "SELECT * FROM t02_root WHERE tenant=? AND company=? AND namespace=? AND kind=? AND id=?",
            (*who.scope, namespace, kind, id_),
        ).fetchone()
        header = (root.version, root.last, root.working, root.active)
        if old is None:
            db.execute(
                "INSERT INTO t02_root VALUES(?,?,?,?,?,?,?,?,?)",
                (*who.scope, namespace, kind, id_, *header),
            )
            core._claim(db, who, f"t02.{namespace}.{kind}", id_)
        elif header != tuple(
            old[k] for k in ("root_version", "last_revision", "working_revision", "active_revision")
        ):
            updated = db.execute(
                "UPDATE t02_root SET root_version=?,last_revision=?,working_revision=?,active_revision=? "
                "WHERE tenant=? AND company=? AND namespace=? AND kind=? AND id=? AND root_version=?",
                (*header, *who.scope, namespace, kind, id_, old["root_version"]),
            )
            if updated.rowcount != 1:
                raise Rejected("VERSION_CONFLICT")
        for number, revision in root.revisions.items():
            data = canonical(revision["data"])
            metadata = canonical({k: v for k, v in revision.items() if k not in ("sealed", "data")})
            key = (*who.scope, namespace, kind, id_, number)
            old_revision = db.execute(
                "SELECT * FROM t02_revision WHERE tenant=? AND company=? AND namespace=? AND kind=? AND id=? AND revision=?",
                key,
            ).fetchone()
            values = (int(revision["sealed"]), data, metadata)
            if old_revision is None:
                db.execute("INSERT INTO t02_revision VALUES(?,?,?,?,?,?,?,?,?)", (*key, *values))
            elif values != tuple(old_revision[k] for k in ("sealed", "data_json", "metadata_json")):
                db.execute(
                    "UPDATE t02_revision SET sealed=?,data_json=?,metadata_json=? "
                    "WHERE tenant=? AND company=? AND namespace=? AND kind=? AND id=? AND revision=?",
                    (*values, *key),
                )


def persist(core, db, who, model, extension):
    persist_roots(core, db, who, "extension", extension.roots)
    roots = dict(model.roots)
    for id_, value in model.measurements.items():
        root = RevisionModel(kind="measurement")
        root.version, root.last, root.active = value["version"], value["last"], value["active"]
        root.revisions = {
            n: {"sealed": True, "data": data, "verification": value["verification"][n]}
            for n, data in value["revisions"].items()
        }
        roots["measurement", id_] = root
    persist_roots(core, db, who, "costing", roots)
    for kind, collection in (("supplier_rfq", model.rfqs), ("cost_scenario", model.scenarios)):
        for id_, value in collection.items():
            metadata = canonical(
                {
                    k: v
                    for k, v in value.items()
                    if k not in ("version", "status", "data", "scope", "readable")
                }
            )
            values = (value["version"], value["status"], canonical(value["data"]), metadata)
            old = db.execute(
                "SELECT * FROM t02_record WHERE tenant=? AND company=? AND kind=? AND id=?",
                (*who.scope, kind, id_),
            ).fetchone()
            if old is None:
                db.execute(
                    "INSERT INTO t02_record VALUES(?,?,?,?,?,?,?,?)",
                    (*who.scope, kind, id_, *values),
                )
                core._claim(db, who, "t02.costing." + kind, id_)
            elif values != tuple(
                old[k] for k in ("row_version", "status", "data_json", "metadata_json")
            ):
                result = db.execute(
                    "UPDATE t02_record SET row_version=?,status=?,data_json=?,metadata_json=? WHERE tenant=? AND company=? AND kind=? AND id=? AND row_version=?",
                    (*values, *who.scope, kind, id_, old["row_version"]),
                )
                if result.rowcount != 1:
                    raise Rejected("VERSION_CONFLICT")
    for result in [*model.complete_results.values(), *model.complete_snapshots.values()]:
        if db.execute(
            "SELECT 1 FROM t02_result WHERE tenant=? AND company=? AND id=?",
            (*who.scope, result["id"]),
        ).fetchone():
            continue
        snapshot = result["kind"] == "snapshot"
        evaluation_id = result["evaluation_id"] if snapshot else result["id"]
        binding = {
            "business": model.bindings[evaluation_id],
            "control": model.results[evaluation_id],
        }
        db.execute(
            "INSERT INTO t02_result VALUES(?,?,?,?,?,?,?,?,?,?)",
            (
                *who.scope,
                result["id"],
                result["kind"],
                result["scenario_id"],
                result["input_scenario_version"],
                result["result_hash"],
                canonical(result),
                canonical(binding),
                0 if snapshot else 1,
            ),
        )
        if snapshot:
            for component in result["components"]:
                db.execute(
                    "INSERT INTO t02_component VALUES(?,?,?,?,?)",
                    (*who.scope, result["id"], component["id"], int(component["amount_minor"])),
                )
                for allocation in component["allocations"]:
                    db.execute(
                        "INSERT INTO t02_allocation VALUES(?,?,?,?,?,?,?)",
                        (
                            *who.scope,
                            result["id"],
                            component["id"],
                            allocation["line_id"],
                            int(allocation["amount_minor"]),
                            allocation["base_integer"],
                        ),
                    )
            db.execute(
                "UPDATE t02_result SET sealed=1 WHERE tenant=? AND company=? AND id=?",
                (*who.scope, result["id"]),
            )
    for id_, denial in model.denials.items():
        if not db.execute(
            "SELECT 1 FROM t02_denial WHERE tenant=? AND company=? AND id=?", (*who.scope, id_)
        ).fetchone():
            db.execute(
                "INSERT INTO t02_denial VALUES(?,?,?,?,?)",
                (*who.scope, id_, denial["source_id"], canonical(denial)),
            )
    for rfq in model.registry["rfqs"]:
        if rfq["status"] == "ready":
            stored = {k: v for k, v in rfq.items() if k not in ("readable", "scope")}
            db.execute(
                "INSERT OR IGNORE INTO t02_rfq_binding VALUES(?,?,?,?,?)",
                (*who.scope, rfq["id"], rfq["row_version"], canonical(stored)),
            )


def check_dependencies(core, db, who, model, extension, action_id):
    principal = actor(core, db, who)
    model._actor = principal
    extension._actor = principal
    for row in db.execute(
        "SELECT * FROM t02_action_dependency WHERE tenant=? AND company=? AND action_id=?",
        (*who.scope, action_id),
    ):
        if row["kind"].startswith("ext-target."):
            core._access(db, who, "t02.extension." + row["kind"].split(".", 1)[1], row["id"])
        elif row["kind"].startswith("ext-config."):
            extension._history_ref_access(
                {"kind": row["kind"].split(".", 1)[1], "id": row["id"], "revision": row["version"]}
            )
        else:
            model._read_dependency(row["kind"], row["id"], row["version"])


def execute(core, who: Principal, request: Any):
    command = request.get("command", "invalid") if isinstance(request, dict) else "invalid"
    command = command if isinstance(command, str) and len(command) <= 100 else "invalid"
    correlation = uuid.uuid4().hex
    try:
        admit(request)
        contract = request.get("contract")
        if contract not in (CONTRACT, EXTENSION):
            raise Rejected("UNSUPPORTED_CONTRACT")
        with core._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                core._authorize(db, who, command)
                core._authorize(db, who, "read")
                core._authorize(db, who, "foundation.read")
                principal = actor(core, db, who)
                if command.split(".")[-1] in HUMAN_ACTIONS and principal["kind"] != "human":
                    raise Rejected("PERMISSION_DENIED")
                model, extension = models(core, db, who)
                validator = extension.schema if contract == EXTENSION else SCHEMA
                from jsonschema import Draft202012Validator

                from .costing_engine.strict_formats import FormatChecker

                if not Draft202012Validator(validator, format_checker=FormatChecker()).is_valid(
                    request
                ):
                    raise Rejected("SCHEMA_INVALID")
                signature = digest(request)
                old = db.execute(
                    "SELECT * FROM action_result WHERE tenant=? AND company=? AND command=? AND idempotency_key=?",
                    (*who.scope, command, request["idempotency_key"]),
                ).fetchone()
                if old:
                    if old["request_hash"] != signature:
                        raise Rejected("IDEMPOTENCY_PAYLOAD_CONFLICT")
                    check_dependencies(core, db, who, model, extension, old["action_id"])
                    response = json.loads(old["result_json"])
                    response["replayed"] = True
                    core._audit(
                        db, who, command, response.get("object_id"), "replayed", None, correlation
                    )
                else:
                    if contract == EXTENSION:
                        response = extension.execute(principal, request)
                        _, _, sources, refs = extension.replays[
                            (*who.scope, command, request["idempotency_key"])
                        ]
                        args = request["args"]
                        dependencies = [
                            {"kind": "source", "id": id_, "version": 1, "content_hash": ""}
                            for id_ in sources
                        ]
                        dependencies += [
                            {
                                "kind": "ext-config." + ref["kind"],
                                "id": ref["id"],
                                "version": ref["revision"],
                                "content_hash": "",
                            }
                            for ref in refs
                        ]
                        dependencies.append(
                            {
                                "kind": "ext-target." + args["kind"],
                                "id": args["id"],
                                "version": response["root_version"],
                                "content_hash": "",
                            }
                        )
                    else:
                        value = model.execute(principal, request)
                        response = model.response(command, value)
                        dependencies = model.command_dependencies[
                            (*who.scope, command, request["idempotency_key"])
                        ]
                    persist(core, db, who, model, extension)
                    action_id = uuid.uuid4().hex
                    if contract == CONTRACT:
                        response["action_id"] = action_id
                    object_id = response.get("object_id", response.get("object_ref", {}).get("id"))
                    db.execute(
                        "INSERT INTO action_result VALUES(?,?,?,?,?,?,?)",
                        (
                            *who.scope,
                            command,
                            request["idempotency_key"],
                            signature,
                            action_id,
                            canonical(response),
                        ),
                    )
                    events = [
                        {"namespace": namespace, "kind": kind, "id": id_, "events": root.events}
                        for namespace, roots in (
                            ("costing", model.roots),
                            ("extension", extension.roots),
                        )
                        for (kind, id_), root in roots.items()
                        if root.events
                    ]
                    db.execute(
                        "INSERT INTO t02_command_event VALUES(?,?,?,?,?,?,?,?)",
                        (
                            *who.scope,
                            action_id,
                            command,
                            who.actor,
                            core.clock().astimezone(UTC).isoformat().replace("+00:00", "Z"),
                            canonical(request["args"]),
                            canonical(events),
                        ),
                    )
                    for dep in dependencies:
                        db.execute(
                            "INSERT OR IGNORE INTO t02_action_dependency VALUES(?,?,?,?,?,?,?)",
                            (
                                *who.scope,
                                action_id,
                                dep["kind"],
                                dep["id"],
                                dep["version"],
                                dep["content_hash"],
                            ),
                        )
                    db.execute(
                        "INSERT INTO outbox VALUES(?,?,?,?,?)",
                        (
                            *who.scope,
                            uuid.uuid4().hex,
                            action_id,
                            canonical({"command": command, "object_id": object_id}),
                        ),
                    )
                    core._audit(
                        db,
                        who,
                        command,
                        object_id,
                        "succeeded",
                        None,
                        correlation,
                        request["args"].get("reason"),
                    )
                db.commit()
                return response
            except BaseException:
                db.rollback()
                raise
    except (Rejected, Invalid) as exc:
        with core._connection() as db:
            core._audit(db, who, command, None, "rejected", exc.code, correlation)
        response = {"ok": False, "code": exc.code}
        if exc.code not in ("PERMISSION_DENIED", "NOT_FOUND"):
            response["field_errors"] = [
                {
                    "path": exc.path if isinstance(exc, Invalid) else exc.fields[0]["path"],
                    "reason": exc.code,
                }
            ]
        return response
    except sqlite3.Error:
        return {"ok": False, "code": "STORAGE_FAILURE"}


def get(core, who, kind, id_, revision=None):
    try:
        return _get(core, who, kind, id_, revision)
    except (Invalid, Rejected) as exc:
        with core._connection() as db:
            core._audit(db, who, "costing.get", None, "rejected", exc.code, uuid.uuid4().hex)
        if isinstance(exc, Rejected):
            raise
        raise Rejected(exc.code) from exc


def _get(core, who, kind, id_, revision=None):
    with core._connection() as db:
        db.execute("BEGIN IMMEDIATE")
        if kind == "snapshot_query":
            output = snapshot_in_transaction(core, db, who, id_)
        else:
            output = _read_in_transaction(core, db, who, kind, id_, revision)
        core._audit(db, who, "costing.get", id_, "read", None, uuid.uuid4().hex)
        db.commit()
        return output


def snapshot_in_transaction(core, db, who, id_):
    """No transaction ownership: qualify using a validated caller connection."""
    if (
        not isinstance(db, sqlite3.Connection)
        or not db.in_transaction
        or db.isolation_level is not None
        or db.row_factory is not sqlite3.Row
    ):
        raise RuntimeError("Invalid caller transaction context")
    databases = list(db.execute("PRAGMA database_list"))
    main = next((r for r in databases if r["name"] == "main"), None)
    if (
        main is None
        or not main["file"]
        or Path(main["file"]).resolve() != core.path.resolve()
        or db.execute("PRAGMA foreign_keys").fetchone()[0] != 1
        or any(r["name"] not in ("main", "temp") for r in databases)
        or db.execute("SELECT 1 FROM sqlite_temp_master LIMIT 1").fetchone() is not None
    ):
        raise RuntimeError("Invalid caller transaction context")
    # An active DEFERRED transaction is not proof of a held writer reservation.
    # A fixed zero-row write acquires it without updating scope or firing row triggers.
    db.execute("UPDATE main.scope SET tenant=tenant WHERE 0")
    try:
        return _read_in_transaction(core, db, who, "snapshot_query", id_)
    except Invalid as exc:
        raise Rejected(exc.code) from exc


def _read_in_transaction(core, db, who, kind, id_, revision=None):
    core._authorize(db, who, "costing.read")
    core._authorize(db, who, "read")
    core._authorize(db, who, "foundation.read")
    model, extension = models(core, db, who)
    model._actor = actor(core, db, who)
    if kind == "snapshot_query":
        return model.snapshot_query(model._actor, id_)
    if kind in ("evaluation", "snapshot"):
        result = model.history(model._actor, id_)
        if result["kind"] != kind:
            raise Rejected("NOT_FOUND")
        return result
    if kind == "cost_scenario":
        value = model.scenarios.get(id_)
        if value is None:
            raise Rejected("NOT_FOUND")
        model._read_row(value)
        model._access_document(value["data"], {}, historical=True)
        return {
            "id": id_,
            "row_version": value["version"],
            "status": value["status"],
            "data": value["data"],
        }
    if kind in ROOT_TYPES:
        root = model.roots.get((kind, id_))
        if root is None:
            raise Rejected("NOT_FOUND")
        model._read_row(root.access)
        number = revision or root.working or root.active
        record = root.revisions.get(number)
        if record is None:
            raise Rejected("NOT_FOUND")
        model._access_document(record, {}, historical=True)
        return {
            "id": id_,
            "root_version": root.version,
            "revision": number,
            "sealed": record["sealed"],
            "data": record["data"],
        }
    raise Rejected("NOT_FOUND")


def execute_json(core, who, raw):
    try:
        request = decode_request(raw)
    except Invalid as exc:
        return {"ok": False, "code": exc.code}
    return execute(core, who, request)


def attest_source(core, who, source_id, reason):
    if not isinstance(reason, str) or not reason.strip() or len(reason) > 1000:
        raise Rejected("INVALID_KNOWN_VALUE")
    with core._connection() as db:
        db.execute("BEGIN IMMEDIATE")
        core._authorize(db, who, "source.verify")
        principal = actor(core, db, who)
        if principal["kind"] != "human":
            raise Rejected("PERMISSION_DENIED")
        core._source_ref(db, who, source_id, "/source_id")
        id_ = uuid.uuid4().hex
        db.execute(
            "INSERT INTO t02_source_attestation VALUES(?,?,?,?,?,?,?)",
            (
                *who.scope,
                id_,
                source_id,
                who.actor,
                core.clock().astimezone(UTC).isoformat().replace("+00:00", "Z"),
                reason,
            ),
        )
        core._audit(db, who, "source.verify", source_id, "succeeded", None, id_, reason)
        db.commit()
        return id_


def configure(core, who, policy_ref):
    with core._connection() as db:
        db.execute("BEGIN IMMEDIATE")
        core._authorize(db, who, "costing.configure")
        core._authorize(db, who, "read")
        core._authorize(db, who, "foundation.read")
        principal = actor(core, db, who)
        if principal["kind"] != "human":
            raise Rejected("PERMISSION_DENIED")
        model, _ = models(core, db, who)
        model._actor = principal
        if not isinstance(policy_ref, dict) or policy_ref.get("kind") != "pricing_policy":
            raise Rejected("REFERENCE_INVALID")
        try:
            model._access_document(policy_ref, {})
        except Invalid as exc:
            raise Rejected(exc.code) from None
        db.execute(
            "INSERT INTO t02_policy VALUES(?,?,?) ON CONFLICT(tenant,company) DO UPDATE SET ref_json=excluded.ref_json",
            (*who.scope, canonical(policy_ref)),
        )
        core._audit(
            db, who, "costing.configure", policy_ref["id"], "succeeded", None, uuid.uuid4().hex
        )
        db.commit()
