"""Exact local quotation-to-order commercial snapshots, not order admission."""

from __future__ import annotations

import copy
import hashlib
import re
from typing import Any

from .common import Rejected, canonical

CONTRACT = "brant.order-commercial-snapshot/0.1.0"
TERM_KEYS = (
    "trade_terms_ref", "trade_scope_ref", "named_place_ref", "payment_terms_ref",
    "delivery", "issued_at", "expires_at",
)


def _minor(value: Any) -> int:
    if not isinstance(value, str) or re.fullmatch(r"0|[1-9][0-9]*", value) is None:
        raise Rejected("REFERENCE_INVALID")
    return int(value)


def _validate_source(payload: Any, calculation: Any, business_hash: str) -> None:
    if not isinstance(payload, dict) or not isinstance(calculation, dict):
        raise Rejected("DRAFT_NOT_READY")
    required = ("customer_ref", "contact_ref", "currency_ref", "payment_terms_ref",
                "expires_at", "lines")
    if any(key not in payload for key in required):
        raise Rejected("DRAFT_NOT_READY")
    if hashlib.sha256(canonical({"data": payload, "calculation": calculation}).encode()).hexdigest() != business_hash:
        raise Rejected("REFERENCE_INVALID")
    try:
        lines, charges = payload["lines"], payload.get("charges", [])
        if not isinstance(lines, list) or not lines or not isinstance(charges, list):
            raise Rejected("REFERENCE_INVALID")
        source_ids = [row["line_id"] for row in lines]
        source_charge_ids = [
            row.get("charge_id") or row.get("obligation_key") or row.get("obligation_id")
            for row in charges
        ]
        groups = (calculation["lines"], calculation["charges"])
        for expected, rows in zip((source_ids, source_charge_ids), groups):
            if (
                not isinstance(rows, list)
                or any(not isinstance(value, str) or not value for value in expected)
                or len(set(expected)) != len(expected)
                or [row["id"] for row in rows] != expected
            ):
                raise Rejected("REFERENCE_INVALID")
            for row in rows:
                if _minor(row["net_minor"]) + _minor(row["tax_minor"]) != _minor(row["payable_minor"]):
                    raise Rejected("REFERENCE_INVALID")
        for key in ("net_minor", "tax_minor", "payable_minor"):
            if sum(_minor(row[key]) for rows in groups for row in rows) != _minor(calculation[key]):
                raise Rejected("REFERENCE_INVALID")
        if _minor(calculation["net_minor"]) + _minor(calculation["tax_minor"]) != _minor(calculation["payable_minor"]):
            raise Rejected("REFERENCE_INVALID")
        payments = calculation["payments"]
        if not isinstance(payments, list) or not payments:
            raise Rejected("REFERENCE_INVALID")
        stage_ids = [row["stage_id"] for row in payments]
        if (
            len(set(stage_ids)) != len(stage_ids)
            or any(not isinstance(value, str) or not value for value in stage_ids)
            or any(_minor(row["amount_minor"]) <= 0 for row in payments)
            or sum(_minor(row["amount_minor"]) for row in payments) != _minor(calculation["payable_minor"])
        ):
            raise Rejected("REFERENCE_INVALID")
    except (KeyError, TypeError, ValueError, AttributeError):
        raise Rejected("REFERENCE_INVALID") from None


def build(
    scope: tuple[str, str],
    order_id: str,
    quote_id: str,
    business_revision: int,
    business_hash: str,
    acceptance_id: str,
    conversion_slot: str,
    payload: dict[str, Any],
    calculation: dict[str, Any] | None,
) -> dict[str, Any]:
    """Copy the entire frozen input/result; do not reprice or fill missing terms."""
    if conversion_slot != "full_v1":
        raise Rejected("CONVERSION_SLOT_UNSUPPORTED")
    _validate_source(payload, calculation, business_hash)
    body = {
        "snapshot_contract": CONTRACT,
        "scope": {"tenant": scope[0], "company": scope[1]},
        "order_id": order_id,
        "customer_ref": payload["customer_ref"],
        "contact_ref": payload["contact_ref"],
        "source_quote_id": quote_id,
        "source_quote_revision": business_revision,
        "source_quote_hash": business_hash,
        "acceptance_id": acceptance_id,
        "currency_ref": payload["currency_ref"],
        "terms": {key: payload[key] for key in TERM_KEYS if key in payload},
        "lines": payload["lines"],
        "charges": payload.get("charges", []),
        "calculation": calculation,
        "source_quote_snapshot": {"data": payload, "calculation": calculation},
        "conversion_slot": conversion_slot,
    }
    return copy.deepcopy(body)
