"""A2 migration and trusted authorization/object-control storage helpers.

This module deliberately exposes no request-contract command.  The methods are
called by the local trusted adapter while it owns the SQLite transaction.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any

from . import foundation, t03_order_snapshot
from .common import Principal, Rejected, canonical, now

VERSION = 17


def migrate(db: sqlite3.Connection) -> None:
    """Install the T03 migration chain atomically after verified T02 history."""
    db.execute("BEGIN IMMEDIATE")
    try:
        versions = [
            row[0] for row in db.execute("SELECT version FROM schema_migration ORDER BY version")
        ]
        t03_installed = db.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='t03_document_binding'"
        ).fetchone() is not None
        if versions == list(range(1, VERSION + 1)) and t03_installed:
            db.commit()
            return
        if versions == list(range(1, 17)) and t03_installed:
            _install_purchase_drafts(db)
            db.commit()
            return
        if versions == list(range(1, 16)) and t03_installed:
            _install_order_revocations(db)
            db.commit()
            return
        if versions == list(range(1, 15)) and t03_installed:
            _install_order_reviews(db)
            db.commit()
            return
        if versions == list(range(1, 13)) and t03_installed:
            _install_customer_responses(db)
            db.commit()
            return
        if versions == list(range(1, 14)) and t03_installed:
            _install_response_verifications(db)
            db.commit()
            return
        if versions == list(range(1, 12)) and t03_installed:
            _install_order_snapshot_guards(db)
            db.commit()
            return
        if versions == list(range(1, 11)) and t03_installed:
            _migrate_a9(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(11,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            _install_order_snapshot_guards(db)
            db.commit()
            return
        if versions == list(range(1, 10)) and t03_installed:
            _migrate_a8(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(10,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            _migrate_a9(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(11,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            _install_order_snapshot_guards(db)
            db.commit()
            return
        if versions == list(range(1, 9)) and t03_installed:
            _migrate_a7(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(9,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            _migrate_a8(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(10,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            _migrate_a9(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(11,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            _install_order_snapshot_guards(db)
            db.commit()
            return
        if versions not in (
            [1, 2, 3],
            [1, 2, 3, 4],
            [1, 2, 3, 4, 5],
            [1, 2, 3, 4, 5, 6],
            [1, 2, 3, 4, 5, 6, 7],
            [1, 2, 3, 4, 5, 6, 7, 8],
            [1, 2, 3, 4, 5, 6, 7, 8, 9],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        ):
            raise RuntimeError("Unsupported T03 migration history")
        if versions == [1, 2, 3]:
            _migrate_a2(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(4,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            versions = [1, 2, 3, 4]
        if versions == [1, 2, 3, 4]:
            _migrate_a3(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(5,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            versions = [1, 2, 3, 4, 5]
        if versions == [1, 2, 3, 4, 5] or (versions == [1, 2, 3, 4, 5, 6] and not t03_installed):
            _migrate_a4(db)
            if versions == [1, 2, 3, 4, 5]:
                db.execute(
                    "INSERT INTO schema_migration VALUES(6,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
                )
                versions = [1, 2, 3, 4, 5, 6]
        if versions in ([1, 2, 3, 4, 5], [1, 2, 3, 4, 5, 6]):
            _migrate_a5(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(7,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            versions = [1, 2, 3, 4, 5, 6, 7]
        if versions == [1, 2, 3, 4, 5, 6, 7]:
            _migrate_a6(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(8,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            versions = [1, 2, 3, 4, 5, 6, 7, 8]
        if versions == [1, 2, 3, 4, 5, 6, 7, 8, 9]:
            _migrate_a8(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(10,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            versions = list(range(1, 11))
        if versions == list(range(1, 11)):
            _migrate_a9(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(11,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
        if versions == [1, 2, 3, 4, 5, 6, 7, 8]:
            _migrate_a7(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(9,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            _migrate_a8(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(10,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
            _migrate_a9(db)
            db.execute(
                "INSERT INTO schema_migration VALUES(11,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
            )
        _install_order_snapshot_guards(db)
        db.commit()
    except BaseException:
        db.rollback()
        raise


def _install_order_snapshot_guards(db: sqlite3.Connection) -> None:
    _migrate_a10(db)
    db.execute(
        "INSERT INTO schema_migration VALUES(12,strftime('%Y-%m-%dT%H:%M:%fZ','now'))"
    )
    _install_customer_responses(db)


def _install_customer_responses(db: sqlite3.Connection) -> None:
    db.execute("""CREATE TABLE t04_customer_response(
        tenant TEXT NOT NULL, company TEXT NOT NULL, response_id TEXT NOT NULL,
        quote_id TEXT NOT NULL, source_id TEXT NOT NULL, body_json TEXT NOT NULL,
        recorded_by TEXT NOT NULL, recorded_at TEXT NOT NULL,
        PRIMARY KEY(tenant,company,response_id),
        FOREIGN KEY(tenant,company,quote_id) REFERENCES t03_quote_root(tenant,company,quote_id),
        FOREIGN KEY(tenant,company,source_id) REFERENCES source_origin(tenant,company,id)
    )""")
    for operation in ("UPDATE", "DELETE"):
        db.execute(f"""CREATE TRIGGER immutable_t04_response_{operation.lower()}
            BEFORE {operation} ON t04_customer_response
            BEGIN SELECT RAISE(ABORT,'immutable customer response'); END""")
    db.execute("""CREATE TRIGGER immutable_t04_response_replace
        BEFORE INSERT ON t04_customer_response
        WHEN EXISTS(SELECT 1 FROM t04_customer_response WHERE tenant=NEW.tenant
                    AND company=NEW.company AND response_id=NEW.response_id)
        BEGIN SELECT RAISE(ABORT,'immutable customer response'); END""")
    db.execute("INSERT INTO schema_migration VALUES(13,strftime('%Y-%m-%dT%H:%M:%fZ','now'))")
    _install_response_verifications(db)


def _install_response_verifications(db: sqlite3.Connection) -> None:
    db.execute("""CREATE TABLE t04_response_verification(
        tenant TEXT NOT NULL, company TEXT NOT NULL, response_id TEXT NOT NULL,
        acceptance_id TEXT NOT NULL, body_json TEXT NOT NULL CHECK(json_valid(body_json)),
        verified_by TEXT NOT NULL, verified_at TEXT NOT NULL,
        PRIMARY KEY(tenant,company,response_id), UNIQUE(tenant,company,acceptance_id),
        FOREIGN KEY(tenant,company,response_id)
            REFERENCES t04_customer_response(tenant,company,response_id),
        FOREIGN KEY(tenant,company,acceptance_id)
            REFERENCES t03_acceptance(tenant,company,acceptance_id)
    )""")
    for operation in ("UPDATE", "DELETE"):
        db.execute(f"""CREATE TRIGGER immutable_t04_verification_{operation.lower()}
            BEFORE {operation} ON t04_response_verification
            BEGIN SELECT RAISE(ABORT,'immutable response verification'); END""")
    db.execute("""CREATE TRIGGER immutable_t04_verification_replace
        BEFORE INSERT ON t04_response_verification
        WHEN EXISTS(SELECT 1 FROM t04_response_verification WHERE tenant=NEW.tenant
                    AND company=NEW.company AND (response_id=NEW.response_id
                                                 OR acceptance_id=NEW.acceptance_id))
        BEGIN SELECT RAISE(ABORT,'immutable response verification'); END""")
    db.execute("INSERT INTO schema_migration VALUES(14,strftime('%Y-%m-%dT%H:%M:%fZ','now'))")
    _install_order_reviews(db)


def _install_order_reviews(db: sqlite3.Connection) -> None:
    db.execute("""CREATE TABLE t04_order_review_request(
        tenant TEXT NOT NULL, company TEXT NOT NULL, review_id TEXT NOT NULL,
        order_id TEXT NOT NULL, order_hash TEXT NOT NULL, order_version INTEGER NOT NULL,
        requested_by TEXT NOT NULL, requested_at TEXT NOT NULL,
        PRIMARY KEY(tenant,company,review_id),
        FOREIGN KEY(tenant,company,order_id) REFERENCES t03_order(tenant,company,order_id))""")
    db.execute("""CREATE TABLE t04_order_review_decision(
        tenant TEXT NOT NULL, company TEXT NOT NULL, review_id TEXT NOT NULL,
        decision TEXT NOT NULL CHECK(decision IN ('approved','rejected')),
        reviewer TEXT NOT NULL, decided_at TEXT NOT NULL, expires_at TEXT NOT NULL,
        PRIMARY KEY(tenant,company,review_id),
        FOREIGN KEY(tenant,company,review_id)
            REFERENCES t04_order_review_request(tenant,company,review_id))""")
    db.execute("""CREATE TABLE t04_order_review_activation(
        tenant TEXT NOT NULL, company TEXT NOT NULL, order_id TEXT NOT NULL,
        review_id TEXT NOT NULL, quote_approval_id TEXT NOT NULL,
        activated_by TEXT NOT NULL, activated_at TEXT NOT NULL,
        PRIMARY KEY(tenant,company,order_id), UNIQUE(tenant,company,review_id),
        FOREIGN KEY(tenant,company,order_id) REFERENCES t03_order(tenant,company,order_id),
        FOREIGN KEY(tenant,company,review_id) REFERENCES t04_order_review_request(tenant,company,review_id))""")
    for table, identity in (("t04_order_review_request", "review_id"),
                            ("t04_order_review_decision", "review_id"),
                            ("t04_order_review_activation", "order_id")):
        for operation in ("UPDATE", "DELETE"):
            db.execute(f"CREATE TRIGGER immutable_{table}_{operation.lower()} BEFORE {operation} ON {table} "
                       "BEGIN SELECT RAISE(ABORT,'immutable order review'); END")
        conflict = f"{identity}=NEW.{identity}"
        if table == "t04_order_review_activation":
            conflict = "(order_id=NEW.order_id OR review_id=NEW.review_id)"
        db.execute(f"CREATE TRIGGER immutable_{table}_replace BEFORE INSERT ON {table} "
                   f"WHEN EXISTS(SELECT 1 FROM {table} WHERE tenant=NEW.tenant AND company=NEW.company "
                   f"AND {conflict}) BEGIN SELECT RAISE(ABORT,'immutable order review'); END")
    db.execute("INSERT INTO schema_migration VALUES(15,strftime('%Y-%m-%dT%H:%M:%fZ','now'))")
    _install_order_revocations(db)


def _install_order_revocations(db: sqlite3.Connection) -> None:
    db.execute("""CREATE TABLE t04_order_review_revocation(
        tenant TEXT NOT NULL, company TEXT NOT NULL, review_id TEXT NOT NULL,
        revoked_by TEXT NOT NULL, revoked_at TEXT NOT NULL, reason TEXT NOT NULL,
        PRIMARY KEY(tenant,company,review_id),
        FOREIGN KEY(tenant,company,review_id)
            REFERENCES t04_order_review_decision(tenant,company,review_id))""")
    for operation in ("UPDATE", "DELETE"):
        db.execute(f"CREATE TRIGGER immutable_t04_order_review_revocation_{operation.lower()} "
                   f"BEFORE {operation} ON t04_order_review_revocation "
                   "BEGIN SELECT RAISE(ABORT,'immutable order approval revocation'); END")
    db.execute("CREATE TRIGGER immutable_t04_order_review_revocation_replace "
               "BEFORE INSERT ON t04_order_review_revocation WHEN EXISTS(SELECT 1 "
               "FROM t04_order_review_revocation WHERE tenant=NEW.tenant AND company=NEW.company "
               "AND review_id=NEW.review_id) "
               "BEGIN SELECT RAISE(ABORT,'immutable order approval revocation'); END")
    db.execute("INSERT INTO schema_migration VALUES(16,strftime('%Y-%m-%dT%H:%M:%fZ','now'))")
    _install_purchase_drafts(db)


def _install_purchase_drafts(db: sqlite3.Connection) -> None:
    db.execute("""CREATE TABLE t04_purchase_draft(
        tenant TEXT NOT NULL, company TEXT NOT NULL, draft_id TEXT NOT NULL,
        order_id TEXT NOT NULL, supplier_id TEXT NOT NULL,
        request_json TEXT NOT NULL CHECK(json_valid(request_json)),
        body_json TEXT NOT NULL CHECK(json_valid(body_json)),
        draft_hash TEXT NOT NULL CHECK(length(draft_hash)=64),
        prepared_by TEXT NOT NULL, prepared_at TEXT NOT NULL,
        PRIMARY KEY(tenant,company,draft_id),
        FOREIGN KEY(tenant,company,order_id) REFERENCES t03_order(tenant,company,order_id))""")
    db.execute("""CREATE TABLE t04_purchase_draft_line(
        tenant TEXT NOT NULL, company TEXT NOT NULL, order_id TEXT NOT NULL,
        order_line_id TEXT NOT NULL, draft_id TEXT NOT NULL,
        PRIMARY KEY(tenant,company,order_id,order_line_id),
        FOREIGN KEY(tenant,company,order_id) REFERENCES t03_order(tenant,company,order_id),
        FOREIGN KEY(tenant,company,draft_id) REFERENCES t04_purchase_draft(tenant,company,draft_id))""")
    for table, conflict in (("t04_purchase_draft", "draft_id=NEW.draft_id"),
                            ("t04_purchase_draft_line",
                             "order_id=NEW.order_id AND order_line_id=NEW.order_line_id")):
        for operation in ("UPDATE", "DELETE"):
            db.execute(f"CREATE TRIGGER immutable_{table}_{operation.lower()} BEFORE {operation} ON {table} "
                       "BEGIN SELECT RAISE(ABORT,'immutable purchase draft'); END")
        db.execute(f"CREATE TRIGGER immutable_{table}_replace BEFORE INSERT ON {table} "
                   f"WHEN EXISTS(SELECT 1 FROM {table} WHERE tenant=NEW.tenant AND company=NEW.company "
                   f"AND {conflict}) BEGIN SELECT RAISE(ABORT,'immutable purchase draft'); END")
    db.execute("INSERT INTO schema_migration VALUES(17,strftime('%Y-%m-%dT%H:%M:%fZ','now'))")


def _migrate_a10(db: sqlite3.Connection) -> None:
    """Protect order commercial columns without rewriting historical bodies."""
    columns = (
        "tenant", "company", "order_id", "root_quote_id", "conversion_slot",
        "customer_ref_json", "source_quote_id", "source_quote_revision",
        "source_quote_hash", "acceptance_id", "body_json", "order_hash", "created_at",
    )
    changed = " OR ".join(f"NEW.{key} IS NOT OLD.{key}" for key in columns)
    db.execute(
        "CREATE TRIGGER IF NOT EXISTS immutable_t03_order_commercial_update "
        "BEFORE UPDATE ON t03_order WHEN " + changed +
        " BEGIN SELECT RAISE(ABORT,'immutable commercial order snapshot'); END"
    )
    db.execute(
        "CREATE TRIGGER IF NOT EXISTS immutable_t03_order_delete BEFORE DELETE ON t03_order "
        "BEGIN SELECT RAISE(ABORT,'immutable commercial order history'); END"
    )
    # SQLite REPLACE can delete a conflicting row without firing DELETE
    # triggers when recursive_triggers is off (the default).
    db.execute(
        "CREATE TRIGGER IF NOT EXISTS immutable_t03_order_replace BEFORE INSERT ON t03_order "
        "WHEN EXISTS(SELECT 1 FROM t03_order WHERE tenant=NEW.tenant AND company=NEW.company "
        "AND (order_id=NEW.order_id OR "
        "(root_quote_id=NEW.root_quote_id AND conversion_slot=NEW.conversion_slot))) "
        "BEGIN SELECT RAISE(ABORT,'immutable commercial order replacement'); END"
    )


def _migrate_a7(db: sqlite3.Connection) -> None:
    """Persist quotation-foundation configuration lifecycle and evidence gates."""
    db.execute(
        """CREATE TABLE quotation_config_root(
            tenant TEXT NOT NULL, company TEXT NOT NULL,
            kind TEXT NOT NULL CHECK(kind IN ('quote_document_template','sales_tax_application')),
            id TEXT NOT NULL, row_version INTEGER NOT NULL CHECK(row_version > 0),
            last_revision INTEGER NOT NULL CHECK(last_revision >= 0),
            working_revision INTEGER, active_revision INTEGER,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,kind,id),
            FOREIGN KEY(tenant,company) REFERENCES scope
        )"""
    )
    db.execute(
        """CREATE TABLE quotation_config_revision(
            tenant TEXT NOT NULL, company TEXT NOT NULL,
            kind TEXT NOT NULL CHECK(kind IN ('quote_document_template','sales_tax_application')),
            id TEXT NOT NULL, revision INTEGER NOT NULL CHECK(revision > 0),
            data_json TEXT NOT NULL CHECK(json_valid(data_json)),
            content_hash TEXT NOT NULL CHECK(length(content_hash)=64),
            contributors_json TEXT NOT NULL CHECK(json_valid(contributors_json)),
            sealed INTEGER NOT NULL CHECK(sealed IN (0,1)),
            effectivity TEXT NOT NULL CHECK(effectivity IN ('draft','active','superseded','retired','discarded')),
            publication_json TEXT CHECK(publication_json IS NULL OR json_valid(publication_json)),
            base_ref_json TEXT CHECK(base_ref_json IS NULL OR json_valid(base_ref_json)),
            created_by TEXT NOT NULL, created_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,kind,id,revision),
            FOREIGN KEY(tenant,company,kind,id)
                REFERENCES quotation_config_root(tenant,company,kind,id)
        )"""
    )
    db.execute(
        "CREATE UNIQUE INDEX quotation_config_one_working ON quotation_config_revision(tenant,company,kind,id) WHERE effectivity='draft' AND sealed=0"
    )
    db.execute(
        "CREATE UNIQUE INDEX quotation_config_one_active ON quotation_config_revision(tenant,company,kind,id) WHERE effectivity='active' AND sealed=1"
    )
    db.execute(
        """CREATE TABLE quotation_config_event(
            seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL, company TEXT NOT NULL,
            kind TEXT NOT NULL, id TEXT NOT NULL, revision INTEGER NOT NULL,
            action_id TEXT NOT NULL UNIQUE, command TEXT NOT NULL,
            args_json TEXT NOT NULL CHECK(json_valid(args_json)), actor TEXT NOT NULL,
            root_version INTEGER NOT NULL, recorded_at TEXT NOT NULL,
            FOREIGN KEY(tenant,company,kind,id)
                REFERENCES quotation_config_root(tenant,company,kind,id)
        )"""
    )
    db.execute(
        """CREATE TABLE quotation_config_source_state(
            tenant TEXT NOT NULL, company TEXT NOT NULL, source_id TEXT NOT NULL,
            verified INTEGER NOT NULL CHECK(verified IN (0,1)),
            denied INTEGER NOT NULL CHECK(denied IN (0,1)),
            updated_by TEXT NOT NULL, updated_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,source_id),
            CHECK(NOT (verified=1 AND denied=1)),
            FOREIGN KEY(tenant,company,source_id) REFERENCES source_origin(tenant,company,id)
        )"""
    )
    db.execute(
        """CREATE TABLE quotation_config_source_event(
            seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL, company TEXT NOT NULL,
            source_id TEXT NOT NULL, verified INTEGER NOT NULL CHECK(verified IN (0,1)),
            denied INTEGER NOT NULL CHECK(denied IN (0,1)), actor TEXT NOT NULL,
            reason TEXT NOT NULL, recorded_at TEXT NOT NULL,
            FOREIGN KEY(tenant,company,source_id) REFERENCES source_origin(tenant,company,id)
        )"""
    )
    db.execute(
        """CREATE TABLE quotation_config_policy(
            tenant TEXT NOT NULL, company TEXT NOT NULL, policy_id TEXT NOT NULL,
            policy_revision INTEGER NOT NULL, updated_by TEXT NOT NULL, updated_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company),
            FOREIGN KEY(tenant,company) REFERENCES scope
        )"""
    )
    db.execute(
        """CREATE TABLE quotation_config_policy_event(
            seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL, company TEXT NOT NULL,
            policy_id TEXT NOT NULL, policy_revision INTEGER NOT NULL,
            actor TEXT NOT NULL, reason TEXT NOT NULL, recorded_at TEXT NOT NULL,
            FOREIGN KEY(tenant,company) REFERENCES scope
        )"""
    )
    db.execute(
        """CREATE TRIGGER quotation_config_sealed_payload_immutable
        BEFORE UPDATE ON quotation_config_revision
        WHEN OLD.sealed=1 AND (
            NEW.data_json!=OLD.data_json OR NEW.content_hash!=OLD.content_hash OR
            NEW.contributors_json!=OLD.contributors_json OR
            NEW.publication_json IS NOT OLD.publication_json OR
            NEW.base_ref_json IS NOT OLD.base_ref_json OR NEW.sealed!=OLD.sealed)
        BEGIN SELECT RAISE(ABORT,'immutable sealed quotation configuration'); END"""
    )
    for table in (
        "quotation_config_revision",
        "quotation_config_event",
        "quotation_config_source_event",
        "quotation_config_policy_event",
    ):
        db.execute(
            f"CREATE TRIGGER immutable_{table}_delete BEFORE DELETE ON {table} BEGIN SELECT RAISE(ABORT,'immutable quotation configuration history'); END"
        )
    db.execute(
        """CREATE TRIGGER immutable_quotation_config_event_update
        BEFORE UPDATE ON quotation_config_event
        BEGIN SELECT RAISE(ABORT,'immutable quotation configuration event'); END"""
    )
    db.execute(
        """CREATE TRIGGER immutable_quotation_config_source_event_update
        BEFORE UPDATE ON quotation_config_source_event
        BEGIN SELECT RAISE(ABORT,'immutable quotation configuration source event'); END"""
    )
    db.execute(
        """CREATE TRIGGER immutable_quotation_config_policy_event_update
        BEFORE UPDATE ON quotation_config_policy_event
        BEGIN SELECT RAISE(ABORT,'immutable quotation configuration policy event'); END"""
    )


def _migrate_a8(db: sqlite3.Connection) -> None:
    """Persist the exact published quotation configurations consumed by a file."""
    db.execute(
        """CREATE TABLE t03_document_config_binding(
            tenant TEXT NOT NULL, company TEXT NOT NULL, document_id TEXT NOT NULL,
            role TEXT NOT NULL CHECK(length(role) BETWEEN 1 AND 100),
            kind TEXT NOT NULL CHECK(kind IN ('quote_document_template','sales_tax_application')),
            id TEXT NOT NULL, revision INTEGER NOT NULL CHECK(revision > 0),
            data_hash TEXT NOT NULL CHECK(length(data_hash)=64),
            record_hash TEXT NOT NULL CHECK(length(record_hash)=64),
            publication_hash TEXT NOT NULL CHECK(length(publication_hash)=64),
            created_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,document_id,role),
            FOREIGN KEY(tenant,company,document_id)
                REFERENCES t03_document_binding(tenant,company,document_id)
        )"""
    )
    db.execute(
        """CREATE TRIGGER immutable_t03_document_config_binding_update
        BEFORE UPDATE ON t03_document_config_binding
        BEGIN SELECT RAISE(ABORT,'immutable T03 document configuration binding'); END"""
    )
    db.execute(
        """CREATE TRIGGER immutable_t03_document_config_binding_delete
        BEFORE DELETE ON t03_document_config_binding
        BEGIN SELECT RAISE(ABORT,'immutable T03 document configuration binding'); END"""
    )


def _migrate_a9(db: sqlite3.Connection) -> None:
    """Persist verified customer acceptance and the single full_v1 order slot."""
    if db.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='t03_acceptance'"
    ).fetchone() is not None:
        return
    db.execute(
        """CREATE TABLE t03_acceptance(
            tenant TEXT NOT NULL, company TEXT NOT NULL, acceptance_id TEXT NOT NULL,
            quote_id TEXT NOT NULL, business_revision INTEGER NOT NULL,
            business_hash TEXT NOT NULL CHECK(length(business_hash)=64),
            customer_ref_json TEXT NOT NULL CHECK(json_valid(customer_ref_json)),
            contact_ref_json TEXT NOT NULL CHECK(json_valid(contact_ref_json)),
            kind TEXT NOT NULL CHECK(kind='full_unconditional'),
            source_ref_json TEXT NOT NULL CHECK(json_valid(source_ref_json)),
            source_message_id TEXT NOT NULL, source_author TEXT NOT NULL,
            forward_chain_ref TEXT, recorded_at TEXT NOT NULL, verified_at TEXT NOT NULL,
            verified_by TEXT NOT NULL, line_ids_json TEXT NOT NULL CHECK(json_valid(line_ids_json)),
            body_json TEXT NOT NULL CHECK(json_valid(body_json)), created_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,acceptance_id),
            UNIQUE(tenant,company,source_message_id),
            FOREIGN KEY(tenant,company,quote_id) REFERENCES t03_quote_root(tenant,company,quote_id)
        )"""
    )
    db.execute(
        """CREATE TABLE t03_acceptance_event(
            seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL, company TEXT NOT NULL,
            acceptance_id TEXT NOT NULL, event_type TEXT NOT NULL, actor TEXT NOT NULL,
            payload_json TEXT NOT NULL CHECK(json_valid(payload_json)), recorded_at TEXT NOT NULL,
            FOREIGN KEY(tenant,company,acceptance_id) REFERENCES t03_acceptance(tenant,company,acceptance_id)
        )"""
    )
    db.execute(
        """CREATE TABLE t03_order(
            tenant TEXT NOT NULL, company TEXT NOT NULL, order_id TEXT NOT NULL,
            root_quote_id TEXT NOT NULL, conversion_slot TEXT NOT NULL CHECK(conversion_slot='full_v1'),
            customer_ref_json TEXT NOT NULL CHECK(json_valid(customer_ref_json)),
            source_quote_id TEXT NOT NULL, source_quote_revision INTEGER NOT NULL,
            source_quote_hash TEXT NOT NULL CHECK(length(source_quote_hash)=64),
            acceptance_id TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('draft','active','cancelled')),
            row_version INTEGER NOT NULL CHECK(row_version>0), body_json TEXT NOT NULL CHECK(json_valid(body_json)),
            order_hash TEXT NOT NULL CHECK(length(order_hash)=64), approval_id TEXT,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,order_id),
            UNIQUE(tenant,company,root_quote_id,conversion_slot),
            FOREIGN KEY(tenant,company,root_quote_id) REFERENCES t03_quote_root(tenant,company,quote_id),
            FOREIGN KEY(tenant,company,acceptance_id) REFERENCES t03_acceptance(tenant,company,acceptance_id)
        )"""
    )
    db.execute(
        """CREATE TABLE t03_order_event(
            seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL, company TEXT NOT NULL,
            order_id TEXT NOT NULL, event_type TEXT NOT NULL, actor TEXT NOT NULL,
            payload_json TEXT NOT NULL CHECK(json_valid(payload_json)), recorded_at TEXT NOT NULL,
            FOREIGN KEY(tenant,company,order_id) REFERENCES t03_order(tenant,company,order_id)
        )"""
    )
    for table in ("t03_acceptance_event", "t03_order_event"):
        db.execute(
            f"CREATE TRIGGER immutable_{table}_update BEFORE UPDATE ON {table} "
            "BEGIN SELECT RAISE(ABORT,'immutable customer acceptance/order history'); END"
        )
        db.execute(
            f"CREATE TRIGGER immutable_{table}_delete BEFORE DELETE ON {table} "
            "BEGIN SELECT RAISE(ABORT,'immutable customer acceptance/order history'); END"
        )
    db.execute(
        """CREATE TRIGGER immutable_t03_acceptance_body BEFORE UPDATE ON t03_acceptance
        WHEN NEW.body_json!=OLD.body_json OR NEW.business_hash!=OLD.business_hash OR
             NEW.quote_id!=OLD.quote_id OR NEW.business_revision!=OLD.business_revision
        BEGIN SELECT RAISE(ABORT,'immutable customer acceptance'); END"""
    )


def _migrate_a3(db: sqlite3.Connection) -> None:
    """Install immutable quote/review facts after the A2 control tables."""
    db.execute(
        """CREATE TABLE t03_quote_root(
            tenant TEXT NOT NULL, company TEXT NOT NULL, quote_id TEXT NOT NULL,
            root_version INTEGER NOT NULL CHECK(root_version > 0),
            working_revision INTEGER, active_revision INTEGER,
            status TEXT NOT NULL CHECK(status IN ('working','frozen','pending_approval','active','superseded','withdrawn','cancelled')),
            control_epoch INTEGER,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,quote_id),
            FOREIGN KEY(tenant,company) REFERENCES scope
        )"""
    )
    db.execute(
        """CREATE TABLE t03_quote_revision(
            tenant TEXT NOT NULL, company TEXT NOT NULL, quote_id TEXT NOT NULL,
            business_revision INTEGER NOT NULL CHECK(business_revision > 0),
            business_hash TEXT NOT NULL CHECK(length(business_hash)=64),
            data_json TEXT NOT NULL CHECK(json_valid(data_json)),
            calculation_json TEXT,
            contributors_json TEXT NOT NULL CHECK(json_valid(contributors_json)),
            status TEXT NOT NULL CHECK(status IN ('working','frozen','pending_approval','active','superseded','withdrawn','cancelled')),
            created_by TEXT NOT NULL, created_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,quote_id,business_revision),
            FOREIGN KEY(tenant,company,quote_id) REFERENCES t03_quote_root(tenant,company,quote_id)
        )"""
    )
    db.execute(
        """CREATE TABLE t03_quote_event(
            seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL, company TEXT NOT NULL,
            quote_id TEXT NOT NULL, business_revision INTEGER, event_type TEXT NOT NULL,
            payload_json TEXT NOT NULL CHECK(json_valid(payload_json)), actor TEXT NOT NULL,
            authority_epoch INTEGER NOT NULL, control_epoch INTEGER, recorded_at TEXT NOT NULL,
            FOREIGN KEY(tenant,company,quote_id) REFERENCES t03_quote_root(tenant,company,quote_id)
        )"""
    )
    db.execute(
        """CREATE TABLE t03_review_request(
            tenant TEXT NOT NULL, company TEXT NOT NULL, review_request_id TEXT NOT NULL,
            quote_id TEXT NOT NULL, business_revision INTEGER NOT NULL, business_hash TEXT NOT NULL,
            target_command TEXT NOT NULL CHECK(target_command IN ('quote.activate','quote.replace')),
            expected_old_active_revision INTEGER, status TEXT NOT NULL CHECK(status IN ('open','approved','returned','rejected')),
            requested_by TEXT NOT NULL, requested_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,review_request_id),
            UNIQUE(tenant,company,quote_id,business_revision),
            FOREIGN KEY(tenant,company,quote_id) REFERENCES t03_quote_root(tenant,company,quote_id)
        )"""
    )
    db.execute(
        """CREATE TABLE t03_approval(
            tenant TEXT NOT NULL, company TEXT NOT NULL, approval_id TEXT NOT NULL,
            review_request_id TEXT NOT NULL, quote_id TEXT NOT NULL, business_revision INTEGER NOT NULL,
            business_hash TEXT NOT NULL, command TEXT NOT NULL,
            reviewer TEXT NOT NULL, decided_at TEXT NOT NULL, expires_at TEXT NOT NULL,
            decision TEXT NOT NULL CHECK(decision IN ('approved','returned','rejected')),
            effectivity TEXT NOT NULL CHECK(effectivity IN ('valid','revoked')), effectivity_version INTEGER NOT NULL,
            PRIMARY KEY(tenant,company,approval_id),
            UNIQUE(tenant,company,review_request_id),
            FOREIGN KEY(tenant,company,review_request_id) REFERENCES t03_review_request(tenant,company,review_request_id)
        )"""
    )
    db.execute(
        """CREATE TABLE t03_approval_event(
            seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL, company TEXT NOT NULL,
            approval_id TEXT NOT NULL, event_type TEXT NOT NULL, actor TEXT NOT NULL,
            effectivity_version INTEGER NOT NULL, payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),
            recorded_at TEXT NOT NULL,
            FOREIGN KEY(tenant,company,approval_id) REFERENCES t03_approval(tenant,company,approval_id)
        )"""
    )
    db.execute(
        "CREATE TRIGGER immutable_t03_quote_revision_payload BEFORE UPDATE ON t03_quote_revision "
        "WHEN NEW.business_hash != OLD.business_hash OR NEW.data_json != OLD.data_json "
        "OR coalesce(NEW.calculation_json,'') != coalesce(OLD.calculation_json,'') "
        "OR NEW.contributors_json != OLD.contributors_json OR NEW.created_by != OLD.created_by "
        "BEGIN SELECT RAISE(ABORT,'immutable T03 payload'); END"
    )
    db.execute(
        "CREATE TRIGGER immutable_t03_quote_revision_delete BEFORE DELETE ON t03_quote_revision "
        "WHEN OLD.status != 'working' BEGIN SELECT RAISE(ABORT,'immutable T03 history'); END"
    )
    for table in ("t03_quote_event", "t03_approval_event"):
        for op in ("UPDATE", "DELETE"):
            db.execute(
                f"CREATE TRIGGER immutable_{table}_{op.lower()} BEFORE {op} ON {table} "
                "BEGIN SELECT RAISE(ABORT,'immutable T03 history'); END"
            )


def _migrate_a4(db: sqlite3.Connection) -> None:
    db.execute(
        """CREATE TABLE t03_document_binding(
            tenant TEXT NOT NULL, company TEXT NOT NULL, document_id TEXT NOT NULL,
            quote_id TEXT NOT NULL, business_revision INTEGER NOT NULL, business_hash TEXT NOT NULL,
            number_id TEXT NOT NULL, number TEXT NOT NULL, file_id TEXT NOT NULL,
            file_sha256 TEXT NOT NULL, mime_type TEXT NOT NULL, byte_size INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,document_id),
            UNIQUE(tenant,company,quote_id,business_revision),
            FOREIGN KEY(tenant,company,quote_id) REFERENCES t03_quote_root(tenant,company,quote_id)
        )"""
    )
    db.execute(
        """CREATE TABLE t03_commit_evidence(
            tenant TEXT NOT NULL, company TEXT NOT NULL, commit_id TEXT NOT NULL,
            quote_id TEXT NOT NULL, business_revision INTEGER NOT NULL, business_hash TEXT NOT NULL,
            server_commit_at TEXT NOT NULL, authority_epoch INTEGER NOT NULL, control_epoch INTEGER,
            approval_id TEXT NOT NULL, cost_snapshot_id TEXT, result_json TEXT NOT NULL CHECK(json_valid(result_json)),
            created_at TEXT NOT NULL, PRIMARY KEY(tenant,company,commit_id),
            FOREIGN KEY(tenant,company,quote_id) REFERENCES t03_quote_root(tenant,company,quote_id)
        )"""
    )
    db.execute(
        """CREATE TABLE t03_quote_outbox(
            tenant TEXT NOT NULL, company TEXT NOT NULL, event_id TEXT NOT NULL,
            quote_id TEXT NOT NULL, business_revision INTEGER NOT NULL, event_type TEXT NOT NULL,
            payload_json TEXT NOT NULL CHECK(json_valid(payload_json)), created_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,event_id),
            FOREIGN KEY(tenant,company,quote_id) REFERENCES t03_quote_root(tenant,company,quote_id)
        )"""
    )
    for table in ("t03_document_binding", "t03_commit_evidence", "t03_quote_outbox"):
        for op in ("UPDATE", "DELETE"):
            db.execute(
                f"CREATE TRIGGER immutable_{table}_{op.lower()} BEFORE {op} ON {table} "
                "BEGIN SELECT RAISE(ABORT,'immutable T03 formalization'); END"
            )


def _migrate_a5(db: sqlite3.Connection) -> None:
    """Persist the immutable customer/contact target selected at formalization."""
    db.execute(
        """CREATE TABLE t03_dispatch_target_snapshot(
            tenant TEXT NOT NULL, company TEXT NOT NULL, snapshot_id TEXT NOT NULL,
            event_id TEXT NOT NULL, quote_id TEXT NOT NULL, business_revision INTEGER NOT NULL,
            business_hash TEXT NOT NULL CHECK(length(business_hash)=64),
            customer_ref_json TEXT NOT NULL CHECK(json_valid(customer_ref_json)),
            contact_ref_json TEXT NOT NULL CHECK(json_valid(contact_ref_json)),
            customer_snapshot_json TEXT NOT NULL CHECK(json_valid(customer_snapshot_json)),
            contact_snapshot_json TEXT NOT NULL CHECK(json_valid(contact_snapshot_json)),
            snapshot_hash TEXT NOT NULL CHECK(length(snapshot_hash)=64),
            created_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,snapshot_id),
            UNIQUE(tenant,company,event_id),
            UNIQUE(tenant,company,quote_id,business_revision),
            FOREIGN KEY(tenant,company,quote_id) REFERENCES t03_quote_root(tenant,company,quote_id)
        )"""
    )
    for op in ("UPDATE", "DELETE"):
        db.execute(
            f"CREATE TRIGGER immutable_t03_dispatch_target_snapshot_{op.lower()} "
            f"BEFORE {op} ON t03_dispatch_target_snapshot "
            "BEGIN SELECT RAISE(ABORT,'immutable T03 dispatch target snapshot'); END"
        )


def _migrate_a6(db: sqlite3.Connection) -> None:
    """Backfill quote-root data ownership for own/team/company access checks."""
    changed_scopes: set[tuple[str, str]] = set()
    roots = db.execute(
        "SELECT tenant,company,quote_id FROM t03_quote_root ORDER BY tenant,company,quote_id"
    ).fetchall()
    for root in roots:
        existing = db.execute(
            "SELECT 1 FROM record_access WHERE tenant=? AND company=? AND kind='quote' AND object_id=?",
            (root["tenant"], root["company"], root["quote_id"]),
        ).fetchone()
        if existing is not None:
            continue
        creator = db.execute(
            "SELECT created_by FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? "
            "ORDER BY business_revision LIMIT 1",
            (root["tenant"], root["company"], root["quote_id"]),
        ).fetchone()
        if creator is None:
            raise RuntimeError("T03 quote root has no verifiable creating revision")
        actor = db.execute(
            "SELECT team_id FROM actor_access WHERE tenant=? AND company=? AND actor=?",
            (root["tenant"], root["company"], creator["created_by"]),
        ).fetchone()
        db.execute(
            "INSERT INTO record_access VALUES(?,?,?,?,?,?)",
            (
                root["tenant"],
                root["company"],
                "quote",
                root["quote_id"],
                creator["created_by"],
                actor["team_id"] if actor is not None else None,
            ),
        )
        changed_scopes.add((root["tenant"], root["company"]))
    for scope in changed_scopes:
        bump_authority_epoch(db, scope)


def _ensure_unbound(
    db: sqlite3.Connection, scope: tuple[str, str], kind: str, object_id: str
) -> None:
    db.execute(
        "INSERT OR IGNORE INTO t03_object_control VALUES(?,?,?,?,?,?,?,?,?,?)",
        (*scope, kind, object_id, "unbound", None, None, 1, None, now()),
    )


def quote_hash(data: dict, calculation: dict | None) -> str:
    return hashlib.sha256(
        canonical({"data": data, "calculation": calculation}).encode()
    ).hexdigest()


def _typed_party_ref(value: object, expected_kind: str) -> dict[str, Any] | None:
    if not isinstance(value, dict) or value.get("kind") != expected_kind:
        return None
    object_id = value.get("id")
    row_version = value.get("row_version")
    if not isinstance(object_id, str) or not object_id:
        return None
    result: dict[str, Any] = {"kind": expected_kind, "id": object_id}
    if isinstance(row_version, int) and row_version > 0:
        result["row_version"] = row_version
    return result


def _recipient_snapshot(
    db: sqlite3.Connection,
    who: Principal,
    payload: dict,
    *,
    quote_id: str,
    business_revision: int,
    business_hash: str,
    event_id: str,
) -> dict | None:
    """Capture authorized master rows for a formalized dispatch target.

    Older draft-only fixtures may carry illustrative refs without Foundation
    master rows.  They remain dispatch-ineligible and therefore produce no
    snapshot.  When both rows exist, the reference versions and access are
    checked in this same transaction before the immutable snapshot is written.
    """
    customer_ref = _typed_party_ref(payload.get("customer_ref"), "customer")
    contact_ref = _typed_party_ref(payload.get("contact_ref"), "contact")
    if customer_ref is None or contact_ref is None:
        return None
    customer = db.execute(
        "SELECT id,kind,name,parent_customer_id,base_uom,status,row_version FROM master "
        "WHERE tenant=? AND company=? AND id=? AND kind='customer'",
        (*who.scope, customer_ref["id"]),
    ).fetchone()
    contact = db.execute(
        "SELECT id,kind,name,parent_customer_id,base_uom,status,row_version FROM master "
        "WHERE tenant=? AND company=? AND id=? AND kind='contact'",
        (*who.scope, contact_ref["id"]),
    ).fetchone()
    # A reference without a local Foundation row cannot be made a trusted
    # snapshot.  Dispatch remains blocked by RECIPIENT_SNAPSHOT_MISSING.
    if customer is None or contact is None:
        return None
    access = db.execute(
        "SELECT team_id,data_scope FROM actor_access WHERE tenant=? AND company=? AND actor=?",
        (*who.scope, who.actor),
    ).fetchone()
    if access is None:
        raise Rejected("REFERENCE_INVALID")
    for object_id in (customer_ref["id"], contact_ref["id"]):
        record_access = db.execute(
            "SELECT owner_id,team_id FROM record_access WHERE tenant=? AND company=? "
            "AND kind='master' AND object_id=?",
            (*who.scope, object_id),
        ).fetchone()
        if record_access is None:
            raise Rejected("REFERENCE_INVALID")
        if not (
            record_access["owner_id"] == who.actor
            or access["data_scope"] == "company"
            or (
                access["data_scope"] == "team"
                and access["team_id"]
                and access["team_id"] == record_access["team_id"]
            )
        ):
            raise Rejected("REFERENCE_INVALID")
    if customer["status"] != "confirmed" or contact["status"] != "confirmed":
        raise Rejected("REFERENCE_STALE")
    if contact["parent_customer_id"] != customer["id"]:
        raise Rejected("REFERENCE_INVALID")
    for ref, row in ((customer_ref, customer), (contact_ref, contact)):
        if "row_version" in ref and ref["row_version"] != row["row_version"]:
            raise Rejected("REFERENCE_STALE")
        ref["row_version"] = row["row_version"]
    customer_value = dict(customer)
    contact_value = dict(contact)
    snapshot_hash = hashlib.sha256(
        canonical(
            {
                "business_hash": business_hash,
                "customer_ref": customer_ref,
                "contact_ref": contact_ref,
                "customer": customer_value,
                "contact": contact_value,
            }
        ).encode()
    ).hexdigest()
    snapshot_id = f"dispatch-target.{quote_id}.{business_revision}"
    db.execute(
        "INSERT INTO t03_dispatch_target_snapshot VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            snapshot_id,
            event_id,
            quote_id,
            business_revision,
            business_hash,
            canonical(customer_ref),
            canonical(contact_ref),
            canonical(customer_value),
            canonical(contact_value),
            snapshot_hash,
            now(),
        ),
    )
    return {
        "snapshot_id": snapshot_id,
        "snapshot_hash": snapshot_hash,
        "customer_ref": customer_ref,
        "contact_ref": contact_ref,
    }


def _snapshot_ref(data: dict, calculation: dict | None = None) -> dict | None:
    """Return the explicit T02 snapshot binding from a quote payload.

    The candidate contract puts this in ``data.snapshot_ref``.  The small
    calculation fallback keeps the trusted adapter tolerant of equivalent
    internal callers while never guessing a snapshot from a cost amount.
    """
    ref = data.get("snapshot_ref") if isinstance(data, dict) else None
    if ref is None and isinstance(calculation, dict):
        ref = calculation.get("snapshot_ref")
    if ref is None:
        return None
    if not isinstance(ref, dict) or not isinstance(ref.get("id"), str) or not ref["id"]:
        raise Rejected("REFERENCE_INVALID")
    result_hash = ref.get("result_hash")
    if result_hash is not None and (
        not isinstance(result_hash, str) or len(result_hash) != 64
    ):
        raise Rejected("REFERENCE_INVALID")
    return {"id": ref["id"], "result_hash": result_hash}


def _cost_qualification(core, db: sqlite3.Connection, who: Principal, data: dict,
                        calculation: dict | None = None) -> dict | None:
    """Recheck a bound snapshot on the caller's already-open write transaction."""
    ref = _snapshot_ref(data, calculation)
    if ref is None:
        return None
    query = core.costing_snapshot_in_transaction(db, who, ref["id"])
    snapshot = query.get("snapshot", {})
    actual_hash = snapshot.get("result_hash")
    if ref["result_hash"] is not None and ref["result_hash"] != actual_hash:
        raise Rejected("REFERENCE_INVALID")
    if not query.get("currently_eligible_for_quote", False):
        raise Rejected("COST_SNAPSHOT_INELIGIBLE")
    scope_binding = None
    if "lines" in data:
        from . import t03_cost_scope

        scope_binding = t03_cost_scope.bind(core, db, who, data, snapshot, calculation)
        from . import t03_sales_terms

        sales_binding = t03_sales_terms.bind(core, db, who, data, calculation)
        from . import t03_trade_parties

        trade_party_binding = t03_trade_parties.bind(core, db, who, data, calculation)
    return {
        **({"scope_binding": scope_binding, "sales_terms_binding": sales_binding,
            "trade_party_binding": trade_party_binding} if scope_binding is not None else {}),
        "snapshot_id": ref["id"],
        "snapshot_result_hash": actual_hash,
        "currently_eligible_for_quote": True,
        "eligibility_checked_at": query["eligibility_checked_at"],
        "snapshot_evidence_hash": snapshot.get("evidence_hash"),
    }


def current_reviewer(core, db: sqlite3.Connection, scope: tuple[str, str],
                     quote_id: str, approval, revision) -> Principal:
    """Require the approving reviewer to remain independent and authorized."""
    if approval["reviewer"] in json.loads(revision["contributors_json"]):
        raise Rejected("INDEPENDENT_REVIEW_REQUIRED")
    reviewer = Principal(*scope, approval["reviewer"])
    try:
        for permission in ("quote.review.decide", "quote.read", "read"):
            core._authorize(db, reviewer, permission)
        if actor_snapshot(db, reviewer)["actor_kind"] != "human":
            raise Rejected("PERMISSION_DENIED")
        core._access(db, reviewer, "quote", quote_id)
    except Rejected:
        raise Rejected("APPROVAL_STALE") from None
    return reviewer


def _current_sales_fx(core, db: sqlite3.Connection, who: Principal, payload: dict) -> None:
    """Recheck a frozen quote's sales FX at the point of a new business decision."""
    ref = payload.get("sales_fx_ref")
    if ref is None:
        return
    policy_ref = payload.get("pricing_policy_ref")
    if not isinstance(ref, dict) or ref.get("kind") != "fx" or not isinstance(policy_ref, dict):
        raise Rejected("REFERENCE_INVALID")
    for item in (policy_ref, ref):
        if not isinstance(item.get("kind"), str) or not isinstance(item.get("id"), str):
            raise Rejected("REFERENCE_INVALID")
    policy = foundation.active(core, db, who, policy_ref)
    guard(db, who, policy_ref["kind"], policy_ref["id"])
    fx = foundation.active(core, db, who, ref, purpose="quotation")
    guard(db, who, ref["kind"], ref["id"])
    try:
        age = (core.clock().astimezone(UTC) - foundation.stamp(fx["observed_at"])).total_seconds()
        max_age = int(policy["max_fx_age_seconds"])
        rate = Decimal(str(fx["rate"]))
        if not rate.is_finite() or rate <= 0 or max_age < 0 or age < 0 or age > max_age:
            raise Rejected("FX_STALE")
    except (KeyError, TypeError, ValueError, ArithmeticError) as exc:
        raise Rejected("REFERENCE_INVALID") from exc


def _server_calculation(core, db: sqlite3.Connection, who: Principal, data: dict) -> tuple[dict | None, dict | None]:
    """Calculate the first supported server-side quotation combination.

    Incomplete legacy drafts remain drafts. Once a structured quote is supplied,
    calculation is mandatory and is never taken from client JSON.
    """
    if "lines" not in data:
        return None, None
    if not isinstance(data.get("snapshot_ref"), dict):
        raise Rejected("COST_SNAPSHOT_MISSING")
    required = (
        "currency_ref",
        "pricing_policy_ref",
        "payment_terms_ref",
        "expires_at",
    )
    if any(key not in data for key in required):
        raise Rejected("DRAFT_NOT_READY")

    # Dedicated quotation configurations are resolved from A18's persisted
    # lifecycle inside this transaction.  The key is stable and role-specific
    # bindings are retained in the frozen calculation for later formalization.
    config_records: dict[tuple[str, str, int], dict] = {}
    config_roles: dict[str, tuple[str, str, int]] = {}

    def resolve_config(ref: dict) -> dict:
        if ref.get("kind") not in ("quote_document_template", "sales_tax_application"):
            raise Rejected("REFERENCE_INVALID")
        key = (ref["kind"], ref["id"], ref["revision"])
        if key not in config_records:
            from . import t03_config

            config_records[key] = t03_config.active_in_transaction(core, db, who, ref)
        return config_records[key]

    def bind_config(ref: dict, role: str) -> None:
        key = (ref["kind"], ref["id"], ref["revision"])
        resolve_config(ref)
        config_roles[role] = key

    def config(ref):
        if not isinstance(ref, dict) or not isinstance(ref.get("kind"), str):
            raise Rejected("REFERENCE_INVALID")
        kind, object_id, revision = ref.get("kind"), ref.get("id"), ref.get("revision")
        if kind in ("quote_document_template", "sales_tax_application"):
            return resolve_config(ref)["data"]
        if kind in {
            "currency", "pricing_policy", "payment_terms", "tax_profile", "fee_type", "fx", "unit",
            "calendar", "trade_terms", "trade_scope", "location", "sku_profile",
            "company", "party_profile", "sequence",
        }:
            return foundation.active(
                core, db, who, ref, purpose="quotation" if kind == "fx" else None
            )
        lookup_kind = kind
        row = db.execute(
            "SELECT r.data_json,h.active_revision,r.sealed FROM t02_revision r JOIN t02_root h "
            "ON h.tenant=r.tenant AND h.company=r.company AND h.namespace=r.namespace "
            "AND h.kind=r.kind AND h.id=r.id WHERE r.tenant=? AND r.company=? "
            "AND r.namespace='extension' AND r.kind=? AND r.id=? AND r.revision=?",
            (*who.scope, lookup_kind, object_id, revision),
        ).fetchone()
        if row is None or not row["sealed"] or row["active_revision"] != revision:
            raise Rejected("REFERENCE_STALE")
        data = json.loads(row["data_json"])
        if "valid_from" in data:
            instant = core.clock().astimezone(UTC)
            if not foundation.stamp(data["valid_from"]) <= instant < foundation.stamp(
                data["valid_until"]
            ):
                raise Rejected("REFERENCE_STALE")
        return data

    # Server-owned cost qualification is checked before any arithmetic and is
    # part of the caller's freeze transaction.
    qualification = _cost_qualification(core, db, who, data)
    if qualification is None:
        raise Rejected("COST_SNAPSHOT_MISSING")
    snapshot_query = core.costing_snapshot_in_transaction(
        db, who, data["snapshot_ref"]["id"]
    )
    snapshot = snapshot_query.get("snapshot", {})
    if data["snapshot_ref"].get("result_hash") != snapshot.get("result_hash"):
        raise Rejected("REFERENCE_INVALID")

    currency = config(data["currency_ref"])
    policy = config(data["pricing_policy_ref"])
    terms = config(data["payment_terms_ref"])
    template_ref = data.get("document_template_ref")
    if template_ref is not None:
        template = config(template_ref)
        if template.get("renderer_version") != "quote-text/0.1.0":
            raise Rejected("DEPENDENCY_NOT_SUPPORTED")
        bind_config(template_ref, "document_template")
    def ref_id(ref):
        return ref.get("id") if isinstance(ref, dict) else None

    quote_currency_id = ref_id(data["currency_ref"])
    policy_currency = policy.get("calculation_currency")
    comparison_currency_id = ref_id(policy_currency) or policy_currency
    if not quote_currency_id or not comparison_currency_id:
        raise Rejected("REFERENCE_INVALID")
    snapshot_currency_id = snapshot.get("currency")
    if snapshot_currency_id is not None and snapshot_currency_id != comparison_currency_id:
        raise Rejected("COMPARISON_BASIS_MISMATCH")
    if quote_currency_id != comparison_currency_id:
        if data.get("sales_fx_ref") is None:
            raise Rejected("REFERENCE_INVALID")
        fx = config(data["sales_fx_ref"])
        if not isinstance(fx, dict):
            raise Rejected("REFERENCE_INVALID")
        if ref_id(fx.get("from_currency")) != quote_currency_id or ref_id(
            fx.get("to_currency")
        ) != comparison_currency_id:
            raise Rejected("FX_SCOPE_MISMATCH")
        try:
            fx_rate = Decimal(str(fx["rate"]))
            fx_age = (
                core.clock().astimezone(UTC) - foundation.stamp(fx["observed_at"])
            ).total_seconds()
            max_age = int(policy.get("max_fx_age_seconds", 0))
        except (KeyError, ValueError, ArithmeticError) as exc:
            raise Rejected("REFERENCE_INVALID") from exc
        if fx_rate <= 0 or fx_age > max_age:
            raise Rejected("FX_STALE")
    elif data.get("sales_fx_ref") is not None:
        # A same-currency quote must not carry a redundant or ambiguous rate.
        raise Rejected("REFERENCE_INVALID")
    comparison_currency = currency if quote_currency_id == comparison_currency_id else config(
        {"kind": "currency", "id": comparison_currency_id, "revision": policy_currency["revision"]}
        if isinstance(policy_currency, dict)
        else {"kind": "currency", "id": comparison_currency_id, "revision": 1}
    )
    if not isinstance(data.get("lines"), list) or not data["lines"]:
        raise Rejected("DRAFT_NOT_READY", "/args/lines")
    if data.get("charges") is not None and not isinstance(data.get("charges"), list):
        raise Rejected("SCHEMA_INVALID", "/args/charges")
    stages = terms.get("stages")
    if not isinstance(stages, list) or not stages or len(stages) > 20:
        raise Rejected("PAYMENT_TOTAL_MISMATCH")
    from fractions import Fraction

    if any(not isinstance(stage, dict) or not isinstance(stage.get("stage_id"), str) for stage in stages):
        raise Rejected("PAYMENT_TOTAL_MISMATCH")
    if len({stage["stage_id"] for stage in stages}) != len(stages):
        raise Rejected("PAYMENT_TOTAL_MISMATCH")
    try:
        percentages = [Fraction(str(stage.get("percent"))) for stage in stages]
    except (TypeError, ValueError, ZeroDivisionError):
        raise Rejected("PAYMENT_TOTAL_MISMATCH") from None
    if any(value <= 0 for value in percentages) or sum(percentages, Fraction(0)) != 100:
        raise Rejected("PAYMENT_TOTAL_MISMATCH")
    minor_units = int(currency["minor_units"])

    def rounded_minor(value: Fraction, scale: int) -> int:
        # All inputs are finite decimal strings. Keep rational arithmetic exact
        # until the established per-line HALF_UP monetary boundary.
        scaled = value * 10**scale
        result = (2 * scaled.numerator + scaled.denominator) // (2 * scaled.denominator)
        if result >= 10**24:
            raise Rejected("CALCULATION_LIMIT_EXCEEDED")
        return result

    def minor(value: Fraction) -> int:
        return rounded_minor(value, minor_units)

    line_results = []

    def tax_parts(
        base: Fraction,
        tax_application_ref: dict | None,
        *,
        path: str,
        role: str,
        subject_ref: dict | None,
    ):
        if not isinstance(tax_application_ref, dict):
            raise Rejected("REFERENCE_INVALID", path)
        tax_application = config(tax_application_ref)
        if tax_application_ref.get("kind") == "sales_tax_application":
            quote_customer = data.get("customer_ref")
            application_customer = tax_application.get("customer_ref")
            quote_issuer = data.get("issuer_ref")
            application_issuer = tax_application.get("issuer_ref")
            if (
                not isinstance(quote_customer, dict)
                or not isinstance(application_customer, dict)
                or quote_customer.get("kind") != "customer"
                or application_customer.get("kind") != "customer"
                or quote_customer.get("id") != application_customer.get("id")
                or quote_customer.get("row_version") != application_customer.get("row_version")
            ):
                raise Rejected("REFERENCE_INVALID", path)
            if isinstance(quote_issuer, dict) and (
                not isinstance(application_issuer, dict)
                or any(
                    application_issuer.get(key) != quote_issuer.get(key)
                    for key in ("kind", "id", "revision")
                )
            ):
                raise Rejected("REFERENCE_INVALID", path)
            if tax_application.get("use") != "quotation_sale" or tax_application.get(
                "business_model"
            ) != "CN-M01":
                raise Rejected("TAX_POLICY_UNCONFIRMED", path)
            if not isinstance(subject_ref, dict) or tax_application.get(
                "subject_kind"
            ) != subject_ref.get("kind"):
                raise Rejected("TAX_POLICY_UNCONFIRMED", path)
            application_subject = tax_application.get("subject_ref")
            if not isinstance(application_subject, dict) or any(
                application_subject.get(key) != subject_ref.get(key)
                for key in ("kind", "id", "revision")
            ):
                raise Rejected("TAX_POLICY_UNCONFIRMED", path)
            bind_config(tax_application_ref, role)
        if tax_application.get("use") not in (None, "quotation_sale"):
            raise Rejected("TAX_POLICY_UNCONFIRMED", path)
        if tax_application.get("business_model") not in (None, "CN-M01"):
            raise Rejected("TAX_POLICY_UNCONFIRMED", path)
        tax_ref = tax_application.get("tax_profile_ref")
        if tax_ref is None:
            raise Rejected("TAX_POLICY_UNCONFIRMED", path)
        tax = config(tax_ref)
        if tax.get("price_basis") not in ("inclusive", "exclusive", "not_applicable"):
            raise Rejected("TAX_POLICY_UNCONFIRMED", path)
        if tax.get("recovery_treatment") == "unknown":
            raise Rejected("TAX_POLICY_UNCONFIRMED", path)
        try:
            rate = Decimal(str(tax.get("rate", "0")))
        except (ValueError, ArithmeticError):
            raise Rejected("TAX_POLICY_UNCONFIRMED", path) from None
        if rate < 0 or rate > 1 or (tax["price_basis"] == "not_applicable" and rate != 0):
            raise Rejected("TAX_POLICY_UNCONFIRMED", path)
        if base <= 0:
            raise Rejected("INVALID_KNOWN_VALUE", path)
        if tax["price_basis"] == "inclusive":
            gross = minor(base)
            net = minor(Fraction(gross, 10**minor_units) / (1 + Fraction(rate)))
            tax_minor = gross - net
        else:
            net = minor(base)
            tax_minor = minor(Fraction(net, 10**minor_units) * Fraction(rate))
            gross = net + tax_minor
        return net, tax_minor, gross

    seen_line_ids: set[str] = set()
    for line in data["lines"]:
        if not isinstance(line, dict) or line.get("tax_application_ref") is None:
            raise Rejected("TAX_POLICY_UNCONFIRMED")
        line_id = line.get("line_id")
        if not isinstance(line_id, str) or not line_id or line_id in seen_line_ids:
            raise Rejected("DUPLICATE_LINE_ID")
        seen_line_ids.add(line_id)
        try:
            quantity = Decimal(str(line["quantity"]))
            unit_price = Decimal(str(line["unit_price"]))
            basis_quantity = Decimal(str(line["price_basis_quantity"]))
            discount = Decimal(str(line["discount_ratio"]))
            if quantity <= 0 or unit_price <= 0 or basis_quantity <= 0 or not 0 <= discount < 1:
                raise ValueError
            base = (
                Fraction(quantity) * Fraction(unit_price) / Fraction(basis_quantity) * (1 - Fraction(discount))
            )
        except (KeyError, ValueError, ArithmeticError) as exc:
            raise Rejected("SCHEMA_INVALID") from exc
        net, tax_minor, gross = tax_parts(
            base,
            line["tax_application_ref"],
            path="/args/lines",
            role=f"line:{line_id}:sales_tax_application",
            subject_ref=line.get("sku_profile_ref"),
        )
        line_results.append(
            {
                "id": line_id,
                "net_minor": str(net),
                "tax_minor": str(tax_minor),
                "payable_minor": str(gross),
            }
        )
    charge_results = []
    obligation_keys: set[str] = set()
    for charge in data.get("charges") or []:
        if not isinstance(charge, dict):
            raise Rejected("SCHEMA_INVALID", "/args/charges")
        key = charge.get("obligation_key") or charge.get("obligation_id") or charge.get("charge_id")
        if not isinstance(key, str) or not key or key in obligation_keys:
            raise Rejected("CHARGE_SCOPE_UNRESOLVED", "/args/charges")
        obligation_keys.add(key)
        fee_ref = charge.get("fee_type_ref")
        if fee_ref is None:
            raise Rejected("CHARGE_SCOPE_UNRESOLVED", "/args/charges")
        fee = config(fee_ref)
        if fee.get("side") not in ("sales_charge", "sales_income", "sales", "seller_income"):
            raise Rejected("CHARGE_SCOPE_UNRESOLVED", "/args/charges")
        if charge.get("inclusion") != fee.get("inclusion"):
            raise Rejected("CHARGE_SCOPE_UNRESOLVED", "/args/charges")
        try:
            amount = Decimal(str(charge["amount"]))
        except (KeyError, ValueError, ArithmeticError) as exc:
            raise Rejected("SCHEMA_INVALID", "/args/charges") from exc
        net, tax_minor, gross = tax_parts(
            Fraction(amount),
            charge.get("tax_application_ref"),
            path="/args/charges",
            role=f"charge:{key}:sales_tax_application",
            subject_ref=fee_ref,
        )
        if charge["inclusion"] == "included_in_line":
            net, tax_minor, gross = 0, 0, 0
        charge_results.append(
            {
                "id": charge.get("charge_id", key),
                "obligation_key": key,
                "net_minor": str(net),
                "tax_minor": str(tax_minor),
                "payable_minor": str(gross),
            }
        )
    net_total = sum(int(row["net_minor"]) for row in line_results)
    tax_total = sum(int(row["tax_minor"]) for row in line_results)
    net_total += sum(int(row["net_minor"]) for row in charge_results)
    tax_total += sum(int(row["tax_minor"]) for row in charge_results)
    payable = net_total + tax_total
    if net_total <= 0:
        raise Rejected("INVALID_KNOWN_VALUE")
    cost = int(snapshot.get("total_minor", 0))
    comparison_revenue = net_total
    if quote_currency_id != comparison_currency_id:
        comparison_revenue = rounded_minor(
            Fraction(net_total, 10**minor_units) * Fraction(fx_rate),
            int(comparison_currency["minor_units"]),
        )
    if max(net_total, tax_total, payable, comparison_revenue, cost) >= 10**24:
        raise Rejected("CALCULATION_LIMIT_EXCEEDED")
    profit = comparison_revenue - cost
    minimum = Decimal(str(policy.get("minimum_margin", "0")))
    if minimum < 0 or minimum > 1:
        raise Rejected("INVALID_KNOWN_VALUE")
    shares = [Fraction(payable) * value / 100 for value in percentages]
    allocated = [value.numerator // value.denominator for value in shares]
    remainder = payable - sum(allocated)
    order = sorted(range(len(shares)), key=lambda i: (-(shares[i] - allocated[i]), str(stages[i]["stage_id"])))
    for index in order[:remainder]:
        allocated[index] += 1
    if any(value <= 0 for value in allocated):
        raise Rejected("PAYMENT_TOTAL_MISMATCH")
    payments = [
        {**stage, "amount_minor": str(amount)} for stage, amount in zip(stages, allocated)
    ]
    calculation = {
        "lines": line_results,
        "charges": charge_results,
        "net_minor": str(net_total),
        "tax_minor": str(tax_total),
        "payable_minor": str(payable),
        "comparison_currency_ref": (
            data["currency_ref"] if quote_currency_id == comparison_currency_id else {
                "kind": "currency", "id": comparison_currency_id,
                "revision": policy_currency.get("revision", 1)
                if isinstance(policy_currency, dict) else 1,
            }
        ),
        "sales_fx_ref": data.get("sales_fx_ref"),
        "comparison_revenue_minor": str(comparison_revenue),
        "cost_minor": str(cost),
        "profit_minor": str(profit),
        "margin_numerator": str(profit),
        "margin_denominator": str(comparison_revenue),
        "margin_rule": "pass" if Fraction(profit) >= Fraction(comparison_revenue) * Fraction(minimum) else "requires_approval",
        "cost_basis": "nominal_direct_cost",
        "excluded_cost_categories": snapshot.get("excluded_cost_categories", []),
        "payments": payments,
    }
    calculation["cost_scope_binding"] = qualification["scope_binding"]
    calculation["sales_terms_binding"] = qualification["sales_terms_binding"]
    calculation["trade_party_binding"] = qualification["trade_party_binding"]
    if config_roles:
        calculation["configuration_bindings"] = [
            {
                "role": role,
                "ref": {
                    "kind": config_records[key]["ref"]["kind"],
                    "id": config_records[key]["ref"]["id"],
                    "revision": config_records[key]["ref"]["revision"],
                },
                "data_hash": config_records[key]["data_hash"],
                "record_hash": config_records[key]["record_hash"],
                "publication_hash": config_records[key]["publication_hash"],
            }
            for role, key in sorted(config_roles.items())
        ]
    return calculation, {"cost_qualification": qualification}


def _seal_quote_timing(core, db: sqlite3.Connection, who: Principal, payload: dict) -> dict:
    """Fix server timing for a structured commercial revision.

    Legacy unstructured drafts remain usable for lifecycle regression tests, but
    a quote carrying calculation lines must have a bounded, future validity
    interval.  ``issued_at`` is server-owned and becomes part of the payload
    hash; callers cannot choose or replay it.
    """
    if "lines" not in payload:
        return payload
    ref = payload.get("pricing_policy_ref")
    if not isinstance(ref, dict):
        raise Rejected("DRAFT_NOT_READY")
    policy = foundation.active(core, db, who, ref)
    expires_at = payload.get("expires_at")
    if not isinstance(expires_at, str):
        raise Rejected("DRAFT_NOT_READY")
    try:
        issued = core.clock().astimezone(UTC)
        expires = foundation.stamp(expires_at)
        max_days = int(policy["quote_valid_days"])
    except (KeyError, TypeError, ValueError, ArithmeticError) as exc:
        raise Rejected("QUOTE_VALIDITY_INVALID") from exc
    if max_days <= 0 or expires <= issued:
        raise Rejected("QUOTE_EXPIRED")
    if expires > issued + timedelta(days=max_days):
        raise Rejected("QUOTE_VALIDITY_INVALID")
    sealed = dict(payload)
    sealed["issued_at"] = issued.isoformat().replace("+00:00", "Z")
    return sealed


def _unexpired(expires_at, as_of: datetime) -> bool:
    if not isinstance(expires_at, str):
        return False
    try:
        expiry = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
        return expiry.tzinfo is not None and as_of < expiry.astimezone(UTC)
    except (TypeError, ValueError, OverflowError):
        return False


def _quote_expiration(payload: dict, as_of: datetime) -> bool:
    return _unexpired(payload.get("expires_at"), as_of)


def quote_row(db: sqlite3.Connection, scope: tuple[str, str], quote_id: str):
    row = db.execute(
        "SELECT * FROM t03_quote_root WHERE tenant=? AND company=? AND quote_id=?",
        (*scope, quote_id),
    ).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    return row


def _guard_quote(
    db: sqlite3.Connection, who: Principal, quote_id: str, task_id: str | None
) -> dict:
    return guard(db, who, "quote_root", quote_id, task_id=task_id)


def _event(
    db,
    who: Principal,
    quote_id: str,
    revision: int | None,
    event_type: str,
    payload: dict,
    control_epoch,
):
    db.execute(
        "INSERT INTO t03_quote_event(tenant,company,quote_id,business_revision,event_type,payload_json,actor,authority_epoch,control_epoch,recorded_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            quote_id,
            revision,
            event_type,
            canonical(payload),
            who.actor,
            authority_epoch(db, who.scope),
            control_epoch,
            now(),
        ),
    )


def save_draft(
    db: sqlite3.Connection,
    who: Principal,
    quote_id: str,
    data: dict,
    *,
    expected_root_version: int = 0,
    calculation: dict | None = None,
    task_id: str | None = None,
) -> dict:
    _ensure_unbound(db, who.scope, "quote_root", quote_id)
    control = _guard_quote(db, who, quote_id, task_id)
    root = db.execute(
        "SELECT * FROM t03_quote_root WHERE tenant=? AND company=? AND quote_id=?",
        (*who.scope, quote_id),
    ).fetchone()
    if root is None:
        if expected_root_version != 0:
            raise Rejected("NOT_FOUND")
        version, revision = 1, 1
        db.execute(
            "INSERT INTO t03_quote_root VALUES(?,?,?,?,?,?,?,?,?,?)",
            (
                *who.scope,
                quote_id,
                version,
                revision,
                None,
                "working",
                control["control_epoch"],
                now(),
                now(),
            ),
        )
        contributors = [who.actor]
    else:
        if root["root_version"] != expected_root_version:
            raise Rejected("VERSION_CONFLICT")
        if root["status"] != "working" or root["working_revision"] is None:
            raise Rejected("INVALID_STATE")
        version, revision = root["root_version"] + 1, root["working_revision"]
        prior = db.execute(
            "SELECT contributors_json FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
            (*who.scope, quote_id, revision),
        ).fetchone()
        contributors = json.loads(prior[0]) if prior else []
        if who.actor not in contributors:
            contributors.append(who.actor)
        db.execute(
            "UPDATE t03_quote_root SET root_version=?,control_epoch=?,updated_at=? WHERE tenant=? AND company=? AND quote_id=?",
            (version, control["control_epoch"], now(), *who.scope, quote_id),
        )
        db.execute(
            "DELETE FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
            (*who.scope, quote_id, revision),
        )
    hashed = quote_hash(data, calculation)
    db.execute(
        "INSERT INTO t03_quote_revision VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            quote_id,
            revision,
            hashed,
            canonical(data),
            canonical(calculation) if calculation is not None else None,
            canonical(contributors),
            "working",
            who.actor,
            now(),
        ),
    )
    _event(
        db,
        who,
        quote_id,
        revision,
        "quote.draft_saved",
        {"business_hash": hashed},
        control["control_epoch"],
    )
    return {
        "object_id": quote_id,
        "root_version": version,
        "business_revision": revision,
        "business_hash": hashed,
        "status": "working",
    }


def revise(
    db: sqlite3.Connection,
    who: Principal,
    quote_id: str,
    *,
    expected_root_version: int,
    base_revision: int,
    task_id: str | None = None,
) -> dict:
    """Open a new working revision while retaining the prior sealed fact."""
    root = quote_row(db, who.scope, quote_id)
    if root["root_version"] != expected_root_version:
        raise Rejected("VERSION_CONFLICT")
    if root["working_revision"] is not None:
        raise Rejected("INVALID_STATE")
    base = db.execute(
        "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, quote_id, base_revision),
    ).fetchone()
    if base is None or base["status"] not in ("frozen", "active", "superseded"):
        raise Rejected("REFERENCE_INVALID")
    control = _guard_quote(db, who, quote_id, task_id)
    next_revision = (
        db.execute(
            "SELECT coalesce(max(business_revision),0)+1 FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=?",
            (*who.scope, quote_id),
        ).fetchone()[0]
    )
    data = json.loads(base["data_json"])
    # Issued/derived fields are never carried as a new commercial fact.
    data.pop("issued_at", None)
    contributors = json.loads(base["contributors_json"])
    if who.actor not in contributors:
        contributors.append(who.actor)
    business_hash = quote_hash(data, None)
    db.execute(
        "INSERT INTO t03_quote_revision VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            quote_id,
            next_revision,
            business_hash,
            canonical(data),
            None,
            canonical(contributors),
            "working",
            who.actor,
            now(),
        ),
    )
    version = root["root_version"] + 1
    db.execute(
        "UPDATE t03_quote_root SET root_version=?,working_revision=?,status='working',control_epoch=?,updated_at=? WHERE tenant=? AND company=? AND quote_id=?",
        (version, next_revision, control["control_epoch"], now(), *who.scope, quote_id),
    )
    _event(
        db,
        who,
        quote_id,
        next_revision,
        "quote.revised",
        {"base_revision": base_revision, "business_hash": business_hash},
        control["control_epoch"],
    )
    return {
        "object_id": quote_id,
        "root_version": version,
        "business_revision": next_revision,
        "business_hash": business_hash,
        "base_revision": base_revision,
        "status": "working",
    }


def discard_draft(
    db: sqlite3.Connection,
    who: Principal,
    quote_id: str,
    *,
    expected_root_version: int,
    task_id: str | None = None,
    reason: str | None = None,
    evidence: list[dict[str, str]] | None = None,
) -> dict:
    root = quote_row(db, who.scope, quote_id)
    if root["root_version"] != expected_root_version:
        raise Rejected("VERSION_CONFLICT")
    revision = root["working_revision"]
    if root["status"] != "working" or revision is None:
        raise Rejected("INVALID_STATE")
    control = _guard_quote(db, who, quote_id, task_id)
    db.execute(
        "DELETE FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=? AND status='working'",
        (*who.scope, quote_id, revision),
    )
    status = "active" if root["active_revision"] is not None else "frozen"
    version = root["root_version"] + 1
    db.execute(
        "UPDATE t03_quote_root SET root_version=?,working_revision=NULL,status=?,control_epoch=?,updated_at=? WHERE tenant=? AND company=? AND quote_id=?",
        (version, status, control["control_epoch"], now(), *who.scope, quote_id),
    )
    _event(
        db,
        who,
        quote_id,
        revision,
        "quote.draft_discarded",
        {
            "business_revision": revision,
            **({"reason": reason} if reason is not None else {}),
            **({"evidence": evidence} if evidence is not None else {}),
        },
        control["control_epoch"],
    )
    return {"object_id": quote_id, "root_version": version, "business_revision": revision, "status": status}


def withdraw(
    db: sqlite3.Connection,
    who: Principal,
    quote_id: str,
    *,
    business_revision: int,
    expected_root_version: int,
    task_id: str | None = None,
    reason: str | None = None,
    evidence: list[dict[str, str]] | None = None,
) -> dict:
    root = quote_row(db, who.scope, quote_id)
    if root["root_version"] != expected_root_version:
        raise Rejected("VERSION_CONFLICT")
    if root["status"] not in ("frozen", "pending_approval"):
        raise Rejected("INVALID_STATE")
    revision = db.execute(
        "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, quote_id, business_revision),
    ).fetchone()
    if revision is None or revision["status"] not in ("frozen", "pending_approval"):
        raise Rejected("INVALID_STATE")
    control = _guard_quote(db, who, quote_id, task_id)
    db.execute(
        "UPDATE t03_quote_revision SET status='withdrawn' WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, quote_id, business_revision),
    )
    for request in db.execute(
        "SELECT review_request_id FROM t03_review_request WHERE tenant=? AND company=? AND quote_id=? AND business_revision=? AND status='open'",
        (*who.scope, quote_id, business_revision),
    ).fetchall():
        db.execute(
            "UPDATE t03_review_request SET status='rejected' WHERE tenant=? AND company=? AND review_request_id=?",
            (*who.scope, request[0]),
        )
    approvals = db.execute(
        "SELECT * FROM t03_approval WHERE tenant=? AND company=? AND quote_id=? AND business_revision=? AND effectivity='valid'",
        (*who.scope, quote_id, business_revision),
    ).fetchall()
    for approval in approvals:
        version = approval["effectivity_version"] + 1
        db.execute(
            "UPDATE t03_approval SET effectivity='revoked',effectivity_version=? WHERE tenant=? AND company=? AND approval_id=?",
            (version, *who.scope, approval["approval_id"]),
        )
        db.execute(
            "INSERT INTO t03_approval_event VALUES(NULL,?,?,?,?,?,?,?,?)",
            (*who.scope, approval["approval_id"], "revoked", who.actor, version, canonical({"reason": "quote withdrawn"}), now()),
        )
    status = "active" if root["active_revision"] is not None else "frozen"
    version = root["root_version"] + 1
    db.execute(
        "UPDATE t03_quote_root SET root_version=?,working_revision=NULL,status=?,control_epoch=?,updated_at=? WHERE tenant=? AND company=? AND quote_id=?",
        (version, status, control["control_epoch"], now(), *who.scope, quote_id),
    )
    _event(
        db,
        who,
        quote_id,
        business_revision,
        "quote.withdrawn",
        {
            "business_revision": business_revision,
            **({"reason": reason} if reason is not None else {}),
            **({"evidence": evidence} if evidence is not None else {}),
        },
        control["control_epoch"],
    )
    return {"object_id": quote_id, "root_version": version, "business_revision": business_revision, "status": "withdrawn"}


def cancel(
    db: sqlite3.Connection,
    who: Principal,
    quote_id: str,
    *,
    expected_root_version: int,
    business_revision: int,
    task_id: str | None = None,
    reason: str | None = None,
    evidence: list[dict[str, str]] | None = None,
) -> dict:
    root = quote_row(db, who.scope, quote_id)
    if root["root_version"] != expected_root_version:
        raise Rejected("VERSION_CONFLICT")
    if root["status"] != "active" or root["active_revision"] != business_revision:
        raise Rejected("QUOTE_NOT_CURRENT")
    control = _guard_quote(db, who, quote_id, task_id)
    db.execute(
        "UPDATE t03_quote_revision SET status='cancelled' WHERE tenant=? AND company=? AND quote_id=? AND business_revision=? AND status='active'",
        (*who.scope, quote_id, business_revision),
    )
    version = root["root_version"] + 1
    db.execute(
        "UPDATE t03_quote_root SET root_version=?,active_revision=NULL,status='cancelled',control_epoch=?,updated_at=? WHERE tenant=? AND company=? AND quote_id=?",
        (version, control["control_epoch"], now(), *who.scope, quote_id),
    )
    _event(
        db,
        who,
        quote_id,
        business_revision,
        "quote.cancelled",
        {
            "business_revision": business_revision,
            **({"reason": reason} if reason is not None else {}),
            **({"evidence": evidence} if evidence is not None else {}),
        },
        control["control_epoch"],
    )
    return {"object_id": quote_id, "root_version": version, "business_revision": business_revision, "status": "cancelled"}


def freeze(
    core,
    db: sqlite3.Connection,
    who: Principal,
    quote_id: str,
    *,
    expected_root_version: int,
    task_id: str | None = None,
) -> dict:
    root = quote_row(db, who.scope, quote_id)
    if root["root_version"] != expected_root_version:
        raise Rejected("VERSION_CONFLICT")
    if root["status"] != "working" or root["working_revision"] is None:
        raise Rejected("INVALID_STATE")
    control = _guard_quote(db, who, quote_id, task_id)
    revision = db.execute(
        "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, quote_id, root["working_revision"]),
    ).fetchone()
    # Structured quotes are recalculated from the live Foundation/T02 closure
    # while this write transaction is still open.  The working row is replaced
    # because its commercial payload is immutable once persisted.
    payload = json.loads(revision["data_json"])
    payload = _seal_quote_timing(core, db, who, payload)
    calculation, _ = _server_calculation(core, db, who, payload)
    business_hash = quote_hash(payload, calculation)
    revision_number = root["working_revision"]
    db.execute(
        "DELETE FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=? AND status='working'",
        (*who.scope, quote_id, revision_number),
    )
    db.execute(
        "INSERT INTO t03_quote_revision VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            quote_id,
            revision_number,
            business_hash,
            canonical(payload),
            canonical(calculation) if calculation is not None else revision["calculation_json"],
            revision["contributors_json"],
            "frozen",
            revision["created_by"],
            revision["created_at"],
        ),
    )
    version = root["root_version"] + 1
    db.execute(
        "UPDATE t03_quote_root SET root_version=?,working_revision=NULL,status='frozen',control_epoch=?,updated_at=? WHERE tenant=? AND company=? AND quote_id=?",
        (version, control["control_epoch"], now(), *who.scope, quote_id),
    )
    _event(
        db,
        who,
        quote_id,
        revision_number,
        "quote.frozen",
        {"business_hash": business_hash, "calculation_server_owned": calculation is not None},
        control["control_epoch"],
    )
    return {
        "object_id": quote_id,
        "root_version": version,
        "business_revision": revision_number,
        "business_hash": business_hash,
        "status": "frozen",
    }


def submit_review(
    db: sqlite3.Connection,
    who: Principal,
    quote_id: str,
    *,
    expected_root_version: int,
    review_request_id: str,
    target_command: str,
    expected_old_active_revision: int | None = None,
    task_id: str | None = None,
) -> dict:
    root = quote_row(db, who.scope, quote_id)
    if root["root_version"] != expected_root_version:
        raise Rejected("VERSION_CONFLICT")
    if root["status"] not in ("frozen", "pending_approval"):
        raise Rejected("INVALID_STATE")
    if target_command not in ("quote.activate", "quote.replace"):
        raise Rejected("INVALID_KNOWN_VALUE")
    if target_command == "quote.activate" and root["active_revision"] is not None:
        raise Rejected("QUOTE_NOT_CURRENT")
    if (
        target_command == "quote.replace"
        and expected_old_active_revision != root["active_revision"]
    ):
        raise Rejected("QUOTE_NOT_CURRENT")
    if db.execute(
        "SELECT 1 FROM t03_review_request WHERE tenant=? AND company=? AND review_request_id=?",
        (*who.scope, review_request_id),
    ).fetchone():
        raise Rejected("BUSINESS_KEY_CONFLICT")
    control = _guard_quote(db, who, quote_id, task_id)
    if target_command == "quote.replace":
        # The replacement request binds the newly frozen revision.  The
        # existing active revision remains historical and must never receive
        # a second approval for a replacement action.
        row = db.execute(
            "SELECT business_revision FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? "
            "AND business_revision<>? AND status IN ('frozen','pending_approval') ORDER BY business_revision DESC LIMIT 1",
            (*who.scope, quote_id, root["active_revision"]),
        ).fetchone()
        revision = row[0] if row else None
    else:
        revision = max(root["working_revision"] or 0, root["active_revision"] or 0, 1)
    if revision is None:
        raise Rejected("DRAFT_NOT_READY")
    row = db.execute(
        "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, quote_id, revision),
    ).fetchone()
    if row is None or row["status"] not in ("frozen", "pending_approval"):
        raise Rejected("DRAFT_NOT_READY")
    if row["calculation_json"]:
        calculation = json.loads(row["calculation_json"])
        if calculation.get("margin_rule") != "pass":
            raise Rejected("MARGIN_POLICY_REQUIRES_APPROVAL")
    version = root["root_version"] + 1
    db.execute(
        "INSERT INTO t03_review_request VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            review_request_id,
            quote_id,
            revision,
            row["business_hash"],
            target_command,
            expected_old_active_revision,
            "open",
            who.actor,
            now(),
        ),
    )
    db.execute(
        "UPDATE t03_quote_revision SET status='pending_approval' WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, quote_id, revision),
    )
    db.execute(
        "UPDATE t03_quote_root SET root_version=?,status='pending_approval',control_epoch=?,updated_at=? WHERE tenant=? AND company=? AND quote_id=?",
        (version, control["control_epoch"], now(), *who.scope, quote_id),
    )
    _event(
        db,
        who,
        quote_id,
        revision,
        "quote.review_requested",
        {
            "review_request_id": review_request_id,
            "business_hash": row["business_hash"],
            "target_command": target_command,
        },
        control["control_epoch"],
    )
    return {
        "object_id": quote_id,
        "root_version": version,
        "business_revision": revision,
        "review_request_id": review_request_id,
        "business_hash": row["business_hash"],
        "status": "pending_approval",
    }


def decide_review(
    db: sqlite3.Connection,
    who: Principal,
    review_request_id: str,
    *,
    decision: str,
    approval_id: str,
    business_hash: str,
    expires_at: str | None = None,
    task_id: str | None = None,
    reason: str | None = None,
    evidence: list[dict[str, str]] | None = None,
) -> dict:
    request = db.execute(
        "SELECT * FROM t03_review_request WHERE tenant=? AND company=? AND review_request_id=?",
        (*who.scope, review_request_id),
    ).fetchone()
    if request is None:
        raise Rejected("NOT_FOUND")
    root = quote_row(db, who.scope, request["quote_id"])
    if root["status"] != "pending_approval" or request["status"] != "open":
        raise Rejected("INVALID_STATE")
    if decision not in ("approved", "returned", "rejected"):
        raise Rejected("INVALID_KNOWN_VALUE")
    revision = db.execute(
        "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, request["quote_id"], request["business_revision"]),
    ).fetchone()
    if revision["business_hash"] != business_hash:
        raise Rejected("REFERENCE_INVALID")
    contributors = json.loads(revision["contributors_json"])
    if who.actor in contributors:
        raise Rejected("INDEPENDENT_REVIEW_REQUIRED")
    actor = actor_snapshot(db, who)
    if actor["actor_kind"] != "human":
        raise Rejected("PERMISSION_DENIED")
    control = _guard_quote(db, who, request["quote_id"], task_id)
    if decision == "approved":
        if not expires_at:
            raise Rejected("APPROVAL_EXPIRED")
        payload = json.loads(revision["data_json"])
        if "lines" in payload:
            try:
                approval_expiry = foundation.stamp(expires_at)
                quote_expiry = foundation.stamp(payload["expires_at"])
            except (KeyError, TypeError, ValueError, OverflowError) as exc:
                raise Rejected("APPROVAL_EXPIRED") from exc
            if approval_expiry >= quote_expiry:
                raise Rejected("APPROVAL_EXPIRED")
        approval = db.execute(
            "SELECT 1 FROM t03_approval WHERE tenant=? AND company=? AND approval_id=?",
            (*who.scope, approval_id),
        ).fetchone()
        if approval:
            raise Rejected("BUSINESS_KEY_CONFLICT")
        db.execute(
            "UPDATE t03_review_request SET status='approved' WHERE tenant=? AND company=? AND review_request_id=?",
            (*who.scope, review_request_id),
        )
        db.execute(
            "INSERT INTO t03_approval VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                *who.scope,
                approval_id,
                review_request_id,
                request["quote_id"],
                request["business_revision"],
                business_hash,
                request["target_command"],
                who.actor,
                now(),
                expires_at,
                "approved",
                "valid",
                1,
            ),
        )
        db.execute(
            "INSERT INTO t03_approval_event VALUES(NULL,?,?,?,?,?,?,?,?)",
            (
                *who.scope,
                approval_id,
                "approved",
                who.actor,
                1,
                canonical(
                    {
                        "business_hash": business_hash,
                        **({"reason": reason} if reason is not None else {}),
                        **({"evidence": evidence} if evidence is not None else {}),
                    }
                ),
                now(),
            ),
        )
        event = "quote.review_decided"
    else:
        db.execute(
            "UPDATE t03_review_request SET status=? WHERE tenant=? AND company=? AND review_request_id=?",
            (decision, *who.scope, review_request_id),
        )
        db.execute(
            "UPDATE t03_quote_revision SET status='frozen' WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
            (*who.scope, request["quote_id"], request["business_revision"]),
        )
        db.execute(
            "UPDATE t03_quote_root SET root_version=root_version+1,status='frozen',control_epoch=?,updated_at=? WHERE tenant=? AND company=? AND quote_id=?",
            (control["control_epoch"], now(), *who.scope, request["quote_id"]),
        )
        event = "quote.review_decided"
    _event(
        db,
        who,
        request["quote_id"],
        request["business_revision"],
        event,
        {
            "decision": decision,
            "review_request_id": review_request_id,
            "business_hash": business_hash,
            **({"reason": reason} if reason is not None else {}),
            **({"evidence": evidence} if evidence is not None else {}),
        },
        control["control_epoch"],
    )
    return {
        "object_id": request["quote_id"],
        "review_request_id": review_request_id,
        "approval_id": approval_id if decision == "approved" else None,
        "status": decision,
    }


def revoke_approval(
    db: sqlite3.Connection,
    who: Principal,
    approval_id: str,
    *,
    expected_effectivity_version: int,
    task_id: str | None = None,
    reason: str | None = None,
    evidence: list[dict[str, str]] | None = None,
) -> dict:
    approval = db.execute(
        "SELECT * FROM t03_approval WHERE tenant=? AND company=? AND approval_id=?",
        (*who.scope, approval_id),
    ).fetchone()
    if approval is None:
        raise Rejected("NOT_FOUND")
    if approval["effectivity_version"] != expected_effectivity_version:
        raise Rejected("VERSION_CONFLICT")
    if approval["effectivity"] != "valid":
        raise Rejected("INVALID_STATE")
    control = _guard_quote(db, who, approval["quote_id"], task_id)
    version = approval["effectivity_version"] + 1
    db.execute(
        "UPDATE t03_approval SET effectivity='revoked',effectivity_version=? WHERE tenant=? AND company=? AND approval_id=?",
        (version, *who.scope, approval_id),
    )
    db.execute(
        "INSERT INTO t03_approval_event VALUES(NULL,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            approval_id,
            "revoked",
            who.actor,
            version,
            canonical(
                {
                    "reason": reason or "trusted revocation",
                    **({"evidence": evidence} if evidence is not None else {}),
                }
            ),
            now(),
        ),
    )
    _event(
        db,
        who,
        approval["quote_id"],
        approval["business_revision"],
        "quote.approval_revoked",
        {
            "approval_id": approval_id,
            "effectivity_version": version,
            **({"reason": reason} if reason is not None else {}),
            **({"evidence": evidence} if evidence is not None else {}),
        },
        control["control_epoch"],
    )
    return {
        "object_id": approval["quote_id"],
        "approval_id": approval_id,
        "effectivity_version": version,
        "status": "revoked",
    }


def _formalization_configurations(core, db, who: Principal, payload: dict, calculation: dict | None):
    """Recheck frozen A18 bindings and return their current sealed records."""
    stored = calculation.get("configuration_bindings", []) if calculation else []
    if not isinstance(stored, list):
        raise Rejected("REFERENCE_INVALID")
    from . import t03_config

    resolved_by_ref: dict[tuple[str, str, int], dict] = {}
    resolved_by_role: dict[str, dict] = {}
    for item in stored:
        if not isinstance(item, dict) or not isinstance(item.get("role"), str):
            raise Rejected("REFERENCE_INVALID")
        ref = item.get("ref")
        if not isinstance(ref, dict):
            raise Rejected("REFERENCE_INVALID")
        ref_kind, ref_id, ref_revision = (
            ref.get("kind"),
            ref.get("id"),
            ref.get("revision"),
        )
        if (
            not isinstance(ref_kind, str)
            or not isinstance(ref_id, str)
            or not isinstance(ref_revision, int)
            or isinstance(ref_revision, bool)
        ):
            raise Rejected("REFERENCE_INVALID")
        key = (ref_kind, ref_id, ref_revision)
        if key not in resolved_by_ref:
            resolved_by_ref[key] = t03_config.active_in_transaction(core, db, who, ref)
        current = resolved_by_ref[key]
        if any(
            item.get(field) != current[field]
            for field in ("data_hash", "record_hash", "publication_hash")
        ):
            raise Rejected("REFERENCE_STALE")
        if item["role"] in resolved_by_role:
            raise Rejected("REFERENCE_INVALID")
        resolved_by_role[item["role"]] = current

    expected_template = payload.get("document_template_ref")
    template_records = [
        (role, current)
        for role, current in resolved_by_role.items()
        if role == "document_template"
    ]
    if expected_template is None:
        if template_records:
            raise Rejected("REFERENCE_INVALID")
    elif (
        len(template_records) != 1
        or template_records[0][1]["ref"] != expected_template
        or expected_template.get("kind") != "quote_document_template"
    ):
        raise Rejected("REFERENCE_INVALID")
    expected_roles = {"document_template"} if expected_template is not None else set()

    def check_tax_scope(role: str, subject: dict | None) -> None:
        current = resolved_by_role.get(role)
        if current is None:
            raise Rejected("REFERENCE_INVALID")
        app = current["data"]
        quote_customer = payload.get("customer_ref")
        app_customer = app.get("customer_ref")
        quote_issuer = payload.get("issuer_ref")
        issuer = app.get("issuer_ref")
        if (
            not isinstance(quote_customer, dict)
            or not isinstance(app_customer, dict)
            or quote_customer.get("kind") != "customer"
            or app_customer.get("kind") != "customer"
            or quote_customer.get("id") != app_customer.get("id")
            or quote_customer.get("row_version") != app_customer.get("row_version")
            or not isinstance(issuer, dict)
            or issuer.get("id") != who.company
            or app.get("use") != "quotation_sale"
            or app.get("business_model") != "CN-M01"
            or not isinstance(subject, dict)
            or app.get("subject_kind") != subject.get("kind")
        ):
            raise Rejected("REFERENCE_INVALID")
        if isinstance(quote_issuer, dict) and any(
            issuer.get(key) != quote_issuer.get(key) for key in ("kind", "id", "revision")
        ):
            raise Rejected("REFERENCE_INVALID")
        app_subject = app.get("subject_ref")
        if not isinstance(app_subject, dict) or any(
            app_subject.get(key) != subject.get(key) for key in ("kind", "id", "revision")
        ):
            raise Rejected("REFERENCE_INVALID")

    for line in payload.get("lines", []):
        if not isinstance(line, dict):
            raise Rejected("REFERENCE_INVALID")
        tax_ref = line.get("tax_application_ref")
        if isinstance(tax_ref, dict) and tax_ref.get("kind") == "sales_tax_application":
            role = f"line:{line.get('line_id')}:sales_tax_application"
            expected_roles.add(role)
            role_current = resolved_by_role.get(role)
            if role_current is None:
                raise Rejected("REFERENCE_INVALID")
            if role_current["ref"] != tax_ref:
                raise Rejected("REFERENCE_INVALID")
            check_tax_scope(role, line.get("sku_profile_ref"))
    for charge in payload.get("charges", []):
        if not isinstance(charge, dict):
            raise Rejected("REFERENCE_INVALID")
        tax_ref = charge.get("tax_application_ref")
        if isinstance(tax_ref, dict) and tax_ref.get("kind") == "sales_tax_application":
            obligation_key = charge.get("obligation_key") or charge.get("obligation_id") or charge.get(
                "charge_id"
            )
            if not isinstance(obligation_key, str):
                raise Rejected("REFERENCE_INVALID")
            role = f"charge:{obligation_key}:sales_tax_application"
            expected_roles.add(role)
            role_current = resolved_by_role.get(role)
            if role_current is None:
                raise Rejected("REFERENCE_INVALID")
            if role_current["ref"] != tax_ref:
                raise Rejected("REFERENCE_INVALID")
            check_tax_scope(role, charge.get("fee_type_ref"))
    if expected_roles != set(resolved_by_role):
        raise Rejected("REFERENCE_INVALID")
    return resolved_by_role


def _render_configured_quote(
    payload: dict,
    calculation: dict,
    template_record: dict,
    number: str,
    quote_id: str,
    revision: int,
    business_hash: str,
) -> bytes:
    template = template_record["data"]
    currency = payload.get("currency_ref", {})
    line_amounts = {item["id"]: item for item in calculation.get("lines", [])}
    charge_amounts = {item["obligation_key"]: item for item in calculation.get("charges", [])}
    lines = []
    for line in payload.get("lines", []):
        amount = line_amounts.get(line.get("line_id"), {})
        lines.append(
            " | ".join(
                (
                    str(line.get("line_id", "")),
                    f"quantity={line.get('quantity', '')}",
                    f"unit_price={line.get('unit_price', '')}",
                    f"net_minor={amount.get('net_minor', '')}",
                    f"tax_minor={amount.get('tax_minor', '')}",
                    f"payable_minor={amount.get('payable_minor', '')}",
                )
            )
        )
    charges = []
    for charge in payload.get("charges", []):
        key = charge.get("obligation_key") or charge.get("obligation_id") or charge.get(
            "charge_id", ""
        )
        amount = charge_amounts.get(key, {})
        charges.append(
            " | ".join(
                (
                    f"charge={charge.get('charge_id', key)}",
                    f"obligation={key}",
                    f"amount={charge.get('amount', '')}",
                    f"net_minor={amount.get('net_minor', '')}",
                    f"tax_minor={amount.get('tax_minor', '')}",
                    f"payable_minor={amount.get('payable_minor', '')}",
                )
            )
        )
    payments = [
        " | ".join(
            f"{key}={stage.get(key, '')}"
            for key in ("stage_id", "percent", "amount_minor", "trigger", "days", "day_basis")
        )
        for stage in calculation.get("payments", [])
    ]
    def refs(name: str) -> str:
        return canonical(payload[name]) if payload.get(name) is not None else "not supplied"

    parties = calculation.get("trade_party_binding")
    issuer_text = "Issuer: " + refs("issuer_ref")
    recipient_text = "Customer: " + refs("customer_ref") + "\nContact: " + refs("contact_ref")
    if isinstance(parties, dict) and parties.get("contract") == "brant.quote-trade-parties/0.1.0":
        issuer = parties["issuer"]
        customer = parties["customer"]
        contact = parties["contact"]
        issuer_text += (
            f"\nLegal name: {issuer['legal_name']}\nRegistration: {issuer['registration_no']}"
            f"\nCountry: {issuer['country']}\nIssuer address: {issuer['address']}"
        )
        recipient_text += (
            f"\nCustomer legal name: {customer['legal_name']}\nCountry: {customer['country']}"
            f"\nCustomer address ({customer['address_role']}): {customer['address']}"
            f"\nContact name: {contact['name']}"
        )
    blocks = {
        "issuer": issuer_text,
        "recipient": recipient_text,
        "identity": f"Number: {number}\nQuote: {quote_id} r{revision}\nBusiness SHA-256: {business_hash}",
        "lines": "Lines (amounts in currency minor units):\n"
        + ("\n".join(lines) if lines else "no lines")
        + ("\n" + "\n".join(charges) if charges else ""),
        "totals": f"Currency: {currency.get('id', 'not supplied')}\nNet minor: {calculation.get('net_minor', '')}\nTax minor: {calculation.get('tax_minor', '')}\nPayable minor: {calculation.get('payable_minor', '')}",
        "terms": "Trade terms: "
        + refs("trade_terms_ref")
        + "\nPayment terms: "
        + refs("payment_terms_ref")
        + "\nTrade scope: "
        + refs("trade_scope_ref"),
        "delivery": "Delivery: " + refs("delivery"),
        "payments": "Payment plan (minor units; not receipts):\n"
        + ("\n".join(payments) if payments else "not supplied"),
        "validity": f"Commercial issue: {payload.get('issued_at', 'not supplied')}\nExpires exclusively: {payload.get('expires_at', 'not supplied')}",
        "notes": str(payload.get("customer_notes", "")) + "\n" + template["footer_note"],
    }
    metadata = (
        "INTERNAL RENDER ONLY; NOT SENT\n"
        f"template_ref={canonical(template_record['ref'])}\n"
        f"template_data_sha256={template_record['data_hash']}\n"
        f"template_record_sha256={template_record['record_hash']}\n"
        f"template_publication_sha256={template_record['publication_hash']}\n"
        f"renderer_version={template['renderer_version']}\n"
    )
    text = (
        metadata
        + template["title"]
        + "\n\n"
        + "\n\n".join(blocks[section] for section in template["sections"])
        + "\n"
    )
    content = text.encode("utf-8")
    if len(content) > 1024 * 1024:
        raise Rejected("CALCULATION_LIMIT_EXCEEDED")
    return content


def activate(
    core,
    db: sqlite3.Connection,
    who: Principal,
    quote_id: str,
    *,
    expected_root_version: int,
    approval_id: str,
    number_id: str,
    document_id: str,
    file_id: str,
    task_id: str | None = None,
    expected_old_active_revision: int | None = None,
) -> dict:
    root = quote_row(db, who.scope, quote_id)
    replacing = expected_old_active_revision is not None
    if root["root_version"] != expected_root_version:
        raise Rejected("VERSION_CONFLICT")
    if replacing:
        if (
            root["status"] != "pending_approval"
            or root["active_revision"] != expected_old_active_revision
        ):
            raise Rejected("QUOTE_NOT_CURRENT")
    elif root["status"] != "pending_approval" or root["active_revision"] is not None:
        raise Rejected("QUOTE_NOT_CURRENT")
    control = _guard_quote(db, who, quote_id, task_id)
    approval = db.execute(
        "SELECT * FROM t03_approval WHERE tenant=? AND company=? AND approval_id=?",
        (*who.scope, approval_id),
    ).fetchone()
    if approval is None or approval["quote_id"] != quote_id:
        raise Rejected("APPROVAL_REQUIRED")
    if approval["effectivity"] != "valid":
        raise Rejected("APPROVAL_REVOKED")
    if approval["command"] != ("quote.replace" if replacing else "quote.activate"):
        raise Rejected("APPROVAL_REQUIRED")
    if not _unexpired(approval["expires_at"], core.clock().astimezone(UTC)):
        raise Rejected("APPROVAL_EXPIRED")
    revision = db.execute(
        "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, quote_id, approval["business_revision"]),
    ).fetchone()
    if (
        revision is None
        or revision["status"] != "pending_approval"
        or revision["business_hash"] != approval["business_hash"]
    ):
        raise Rejected("REFERENCE_INVALID")
    current_reviewer(core, db, who.scope, quote_id, approval, revision)
    if db.execute(
        "SELECT 1 FROM t03_document_binding WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, quote_id, approval["business_revision"]),
    ).fetchone():
        raise Rejected("BUSINESS_KEY_CONFLICT")
    if db.execute(
        "SELECT 1 FROM document_number WHERE tenant=? AND company=? AND id=?",
        (*who.scope, number_id),
    ).fetchone():
        raise Rejected("BUSINESS_KEY_CONFLICT")
    if db.execute(
        "SELECT 1 FROM business_file WHERE tenant=? AND company=? AND id=?", (*who.scope, file_id)
    ).fetchone():
        raise Rejected("BUSINESS_KEY_CONFLICT")
    payload = json.loads(revision["data_json"])
    calculation = (
        json.loads(revision["calculation_json"])
        if revision["calculation_json"] is not None
        else None
    )
    if "lines" in payload:
        if calculation is None:
            raise Rejected("REFERENCE_INVALID")
        if not _quote_expiration(payload, core.clock().astimezone(UTC)):
            raise Rejected("QUOTE_EXPIRED")
        if calculation is not None and calculation.get("margin_rule") != "pass":
            raise Rejected("MARGIN_POLICY_REQUIRES_APPROVAL")
    # This is deliberately inside the same write transaction as approval,
    # numbering, file creation, state change, evidence and outbox.  A current
    # false result therefore aborts the whole formalization and cannot leave a
    # number or document behind.
    cost_qualification = _cost_qualification(core, db, who, payload, calculation)
    configuration_records = _formalization_configurations(
        core, db, who, payload, calculation
    )
    if "lines" in payload:
        _current_sales_fx(core, db, who, payload)
    configuration_bindings = calculation.get("configuration_bindings", []) if calculation else []
    event_id = f"formal.{quote_id}.{approval['business_revision']}"
    recipient_snapshot = _recipient_snapshot(
        db,
        who,
        payload,
        quote_id=quote_id,
        business_revision=approval["business_revision"],
        business_hash=approval["business_hash"],
        event_id=event_id,
    )
    number = f"Q-{quote_id}-{approval['business_revision']}"
    template_record = configuration_records.get("document_template")
    if template_record is not None:
        if calculation is None:
            raise Rejected("REFERENCE_INVALID")
        content = _render_configured_quote(
            payload,
            calculation,
            template_record,
            number,
            quote_id,
            approval["business_revision"],
            approval["business_hash"],
        )
    else:
        content = (
            "INTERNAL FORMAL QUOTATION; NOT SENT\n"
            f"quote_id={quote_id}\n"
            f"business_revision={approval['business_revision']}\n"
            f"business_hash={approval['business_hash']}\n"
            + (
                f"cost_snapshot_id={cost_qualification['snapshot_id']}\n"
                f"cost_snapshot_result_hash={cost_qualification['snapshot_result_hash']}\n"
                if cost_qualification
                else ""
            )
            + (
                f"dispatch_target_snapshot_id={recipient_snapshot['snapshot_id']}\n"
                f"dispatch_target_snapshot_hash={recipient_snapshot['snapshot_hash']}\n"
                if recipient_snapshot
                else ""
            )
            + f"configuration_bindings={canonical(configuration_bindings)}\n"
            + f"data={canonical(payload)}\n"
        ).encode("utf-8")
    file_hash = hashlib.sha256(content).hexdigest()
    now_value = now()
    db.execute(
        "INSERT INTO document_number VALUES(?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            number_id,
            "quote",
            f"{quote_id}:{approval['business_revision']}",
            number,
            "t03.internal",
            1,
            now_value,
        ),
    )
    db.execute(
        "INSERT INTO business_file VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            file_id,
            f"{number}.txt",
            "text/plain",
            content,
            file_hash,
            None,
            template_record["ref"]["id"] if template_record is not None else "t03.internal",
            template_record["ref"]["revision"] if template_record is not None else 1,
            number_id,
            now_value,
        ),
    )
    db.execute(
        "INSERT INTO t03_document_binding VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            document_id,
            quote_id,
            approval["business_revision"],
            approval["business_hash"],
            number_id,
            number,
            file_id,
            file_hash,
            "text/plain",
            len(content),
            now_value,
        ),
    )
    for binding in configuration_bindings:
        ref = binding["ref"]
        db.execute(
            "INSERT INTO t03_document_config_binding VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (
                *who.scope,
                document_id,
                binding["role"],
                ref["kind"],
                ref["id"],
                ref["revision"],
                binding["data_hash"],
                binding["record_hash"],
                binding["publication_hash"],
                now_value,
            ),
        )
    new_version = root["root_version"] + 1
    if replacing:
        db.execute(
            "UPDATE t03_quote_revision SET status='superseded' WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
            (*who.scope, quote_id, root["active_revision"]),
        )
    db.execute(
        "UPDATE t03_quote_revision SET status='active' WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, quote_id, approval["business_revision"]),
    )
    db.execute(
        "UPDATE t03_quote_root SET root_version=?,working_revision=NULL,active_revision=?,status='active',control_epoch=?,updated_at=? WHERE tenant=? AND company=? AND quote_id=?",
        (
            new_version,
            approval["business_revision"],
            control["control_epoch"],
            now_value,
            *who.scope,
            quote_id,
        ),
    )
    commit_id = f"commit.{quote_id}.{approval['business_revision']}"
    db.execute(
        "INSERT INTO t03_commit_evidence VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            commit_id,
            quote_id,
            approval["business_revision"],
            approval["business_hash"],
            now_value,
            authority_epoch(db, who.scope),
            control["control_epoch"],
            approval_id,
            cost_qualification["snapshot_id"] if cost_qualification else None,
            canonical(
                {
                    "number": number,
                    "file_sha256": file_hash,
                    "cost_qualification": cost_qualification,
                    "dispatch_target_snapshot": recipient_snapshot,
                    "configuration_bindings": configuration_bindings,
                }
            ),
            now_value,
        ),
    )
    db.execute(
        "INSERT INTO t03_quote_outbox VALUES(?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            event_id,
            quote_id,
            approval["business_revision"],
            "quote.replaced" if replacing else "quote.activated",
            canonical(
                {
                    "quote_id": quote_id,
                    "business_revision": approval["business_revision"],
                    "number": number,
                    "file_id": file_id,
                    "cost_qualification": cost_qualification,
                    "dispatch_target_snapshot": recipient_snapshot,
                    "configuration_bindings": configuration_bindings,
                }
            ),
            now_value,
        ),
    )
    _event(
        db,
        who,
        quote_id,
        approval["business_revision"],
        "quote.replaced" if replacing else "quote.activated",
        {
            "number": number,
            "file_id": file_id,
            "cost_qualification": cost_qualification,
            "configuration_bindings": configuration_bindings,
        },
        control["control_epoch"],
    )
    return {
        "object_id": quote_id,
        "root_version": new_version,
        "business_revision": approval["business_revision"],
        "approval_id": approval_id,
        "document_id": document_id,
        "number": number,
        "file_id": file_id,
            "dispatch_target_snapshot": recipient_snapshot,
        "status": "active",
    }


def quote_get(
    core,
    db: sqlite3.Connection,
    who: Principal,
    quote_id: str,
    revision_number: int | None = None,
) -> dict:
    """Read a quote root and immutable revision facts under current access.

    Historical commercial payloads are never rewritten when current cost or
    configuration eligibility changes.  The optional current qualification is
    therefore reported as a separate fact and business ineligibility does not
    make an otherwise authorized historical read disappear.
    """
    root = quote_row(db, who.scope, quote_id)
    params: tuple = (*who.scope, quote_id)
    if revision_number is None:
        revisions = db.execute(
            "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? ORDER BY business_revision",
            params,
        ).fetchall()
    else:
        revisions = db.execute(
            "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
            (*params, revision_number),
        ).fetchall()
    if not revisions:
        raise Rejected("NOT_FOUND")

    revision_values = []
    for revision in revisions:
        value = {
            "business_revision": revision["business_revision"],
            "business_hash": revision["business_hash"],
            "data": json.loads(revision["data_json"]),
            "calculation": (
                json.loads(revision["calculation_json"])
                if revision["calculation_json"] is not None
                else None
            ),
            "contributors": json.loads(revision["contributors_json"]),
            "status": revision["status"],
            "created_by": revision["created_by"],
            "created_at": revision["created_at"],
        }
        ref = _snapshot_ref(value["data"], value["calculation"])
        if ref is not None:
            try:
                qualification = core.costing_snapshot_in_transaction(db, who, ref["id"])
                snapshot = qualification.get("snapshot", {})
                value["current_cost_qualification"] = {
                    "snapshot_id": ref["id"],
                    "currently_eligible_for_quote": bool(
                        qualification.get("currently_eligible_for_quote", False)
                    ),
                    "result_hash": snapshot.get("result_hash"),
                    "eligibility_checked_at": qualification.get("eligibility_checked_at"),
                }
            except Rejected as exc:
                if exc.code in (
                    "COST_INPUT_NOT_READY",
                    "COST_SNAPSHOT_INELIGIBLE",
                    "REFERENCE_STALE",
                    "COMPARISON_BASIS_MISMATCH",
                ):
                    value["current_cost_qualification"] = {
                        "snapshot_id": ref["id"],
                        "currently_eligible_for_quote": False,
                        "reason": exc.code,
                    }
                else:
                    raise
        revision_values.append(value)

    events = [
        dict(row)
        for row in db.execute(
            "SELECT seq,business_revision,event_type,payload_json,actor,authority_epoch,control_epoch,recorded_at "
            "FROM t03_quote_event WHERE tenant=? AND company=? AND quote_id=? ORDER BY seq",
            params,
        ).fetchall()
    ]
    for event in events:
        event["payload"] = json.loads(event.pop("payload_json"))
    return {
        "object_id": quote_id,
        "root": dict(root),
        "revisions": revision_values,
        "events": events,
        "control": (
            dict(control_row(db, who.scope, "quote_root", quote_id))
            if control_row(db, who.scope, "quote_root", quote_id) is not None
            else None
        ),
    }


def _quote_revision_for_acceptance(db, scope: tuple[str, str], quote_id: str, revision: int):
    root = quote_row(db, scope, quote_id)
    if root["status"] != "active" or root["active_revision"] != revision:
        raise Rejected("QUOTE_NOT_EFFECTIVE")
    row = db.execute(
        "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*scope, quote_id, revision),
    ).fetchone()
    if row is None or row["status"] != "active":
        raise Rejected("QUOTE_NOT_EFFECTIVE")
    return root, row, json.loads(row["data_json"])


def record_customer_response(
    core, db: sqlite3.Connection, who: Principal, response: dict[str, Any],
    *, task_id: str | None = None,
) -> dict[str, Any]:
    """Record an operator's classification without asserting acceptance."""
    fields = {"response_id", "quote_id", "source_id", "locator", "classification", "summary"}
    if not isinstance(response, dict) or set(response) != fields:
        raise Rejected("SCHEMA_INVALID")
    for key, limit in (("response_id", 64), ("quote_id", 64), ("source_id", 64),
                       ("locator", 500), ("summary", 4000)):
        value = response[key]
        if not isinstance(value, str) or not value.strip() or len(value) > limit:
            raise Rejected("SCHEMA_INVALID")
    if response["classification"] not in (
        "full_unconditional", "conditional", "partial", "reject", "ambiguous"
    ):
        raise Rejected("SCHEMA_INVALID")
    _guard_quote(db, who, response["quote_id"], task_id)
    core._source_ref(db, who, response["source_id"], "/response/source_id")
    body = canonical(response)
    existing = db.execute(
        "SELECT quote_id,source_id,body_json,recorded_by,recorded_at FROM t04_customer_response "
        "WHERE tenant=? AND company=? AND response_id=?",
        (*who.scope, response["response_id"]),
    ).fetchone()
    if existing:
        from . import t04_response

        t04_response.get(core, db, who, response["response_id"])
        if existing["body_json"] != body:
            raise Rejected("RESPONSE_IMMUTABLE")
        return {**response, "recorded_by": existing["recorded_by"],
                "recorded_at": existing["recorded_at"], "replayed": True}
    recorded_at = core.clock().astimezone(UTC).isoformat()
    db.execute(
        "INSERT INTO t04_customer_response VALUES(?,?,?,?,?,?,?,?)",
        (*who.scope, response["response_id"], response["quote_id"], response["source_id"],
         body, who.actor, recorded_at),
    )
    return {**response, "recorded_by": who.actor, "recorded_at": recorded_at, "replayed": False}


def verify_customer_response(
    core, db: sqlite3.Connection, who: Principal, response_id: str,
    verification: dict[str, Any], *, task_id: str | None = None,
) -> dict[str, Any]:
    """Atomically verify an existing classified response and link the acceptance."""
    from .t03_write import REQUEST_VALIDATOR

    row = db.execute(
        "SELECT * FROM t04_customer_response WHERE tenant=? AND company=? AND response_id=?",
        (*who.scope, response_id),
    ).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    from . import t04_response

    response = t04_response.get(core, db, who, response_id)
    _guard_quote(db, who, row["quote_id"], task_id)
    if response["classification"] != "full_unconditional":
        raise Rejected("ACCEPTANCE_NOT_UNCONDITIONAL")
    expected = {"acceptance_id", "quote_business_revision", "quote_business_hash", "customer_ref",
                "contact_ref", "source_message_id", "source_author", "forward_chain_ref",
                "recorded_at", "line_ids"}
    if not isinstance(verification, dict) or set(verification) != expected:
        raise Rejected("SCHEMA_INVALID")
    try:
        request_body = canonical(verification)
        request_size = len(request_body.encode("utf-8"))
    except (TypeError, ValueError, UnicodeEncodeError, RecursionError):
        raise Rejected("SCHEMA_INVALID") from None
    if request_size > 1024 * 1024:
        raise Rejected("SCHEMA_INVALID")
    existing = db.execute(
        "SELECT * FROM t04_response_verification WHERE tenant=? AND company=? AND response_id=?",
        (*who.scope, response_id),
    ).fetchone()
    if existing:
        if existing["body_json"] != request_body:
            raise Rejected("RESPONSE_VERIFICATION_IMMUTABLE")
        return {"response_id": response_id, "acceptance_id": existing["acceptance_id"],
                "quote_id": row["quote_id"], "status": "verified", "replayed": True}
    verified_at = core.clock().astimezone(UTC).isoformat().replace("+00:00", "Z")
    acceptance = {**verification, "quote_id": row["quote_id"], "kind": "full_unconditional",
                  "source_ref": {"source_id": row["source_id"], "locator": response["locator"]},
                  "verified_at": verified_at, "verified_by": who.actor}
    request = {"contract": "brant.quotation/0.1.0", "command": "quote.acceptance.verify",
               "idempotency_key": "response.verify", "args": acceptance}
    if not REQUEST_VALIDATOR.is_valid(request):
        raise Rejected("SCHEMA_INVALID")
    if db.execute("SELECT 1 FROM t03_acceptance WHERE tenant=? AND company=? AND acceptance_id=?",
                  (*who.scope, acceptance["acceptance_id"])).fetchone():
        raise Rejected("ACCEPTANCE_ALREADY_EXISTS")
    result = register_acceptance(core, db, who, acceptance, task_id=task_id)
    db.execute("INSERT INTO t04_response_verification VALUES(?,?,?,?,?,?,?)",
               (*who.scope, response_id, result["acceptance_id"], request_body, who.actor, verified_at))
    return {"response_id": response_id, "acceptance_id": result["acceptance_id"],
            "quote_id": row["quote_id"], "status": "verified", "replayed": False}


def register_acceptance(
    core,
    db: sqlite3.Connection,
    who: Principal,
    acceptance: dict[str, Any],
    *,
    task_id: str | None = None,
) -> dict[str, Any]:
    """Record a human-verified, complete and unconditional customer acceptance."""
    required = (
        "acceptance_id", "quote_id", "quote_business_revision", "quote_business_hash",
        "customer_ref", "contact_ref", "kind", "source_ref", "source_message_id",
        "source_author", "forward_chain_ref", "recorded_at", "verified_at", "verified_by",
        "line_ids",
    )
    if any(key not in acceptance for key in required):
        raise Rejected("SCHEMA_INVALID")
    _guard_quote(db, who, acceptance["quote_id"], task_id)
    if acceptance["kind"] != "full_unconditional" or acceptance["verified_by"] != who.actor:
        raise Rejected("VERIFIER_IDENTITY_MISMATCH")
    if not isinstance(acceptance["line_ids"], list) or not acceptance["line_ids"]:
        raise Rejected("ACCEPTANCE_LINES_MISMATCH")
    root, revision, payload = _quote_revision_for_acceptance(
        db, who.scope, acceptance["quote_id"], acceptance["quote_business_revision"]
    )
    if revision["business_hash"] != acceptance["quote_business_hash"]:
        raise Rejected("ACCEPTANCE_SCOPE_MISMATCH")
    customer = payload.get("customer_ref")
    contact = payload.get("contact_ref")
    if customer != acceptance["customer_ref"] or contact != acceptance["contact_ref"]:
        raise Rejected("ACCEPTANCE_SCOPE_MISMATCH")
    line_ids = [line.get("line_id") for line in payload.get("lines", [])]
    if len(set(line_ids)) != len(line_ids) or set(acceptance["line_ids"]) != set(line_ids):
        raise Rejected("ACCEPTANCE_LINES_MISMATCH")
    try:
        recorded = foundation.stamp(acceptance["recorded_at"])
        verified = foundation.stamp(acceptance["verified_at"])
        expires = foundation.stamp(payload["expires_at"])
    except (KeyError, TypeError, ValueError):
        raise Rejected("ACCEPTANCE_TIME_CONFLICT") from None
    current = core.clock().astimezone(UTC)
    if recorded > verified or verified > current:
        raise Rejected("ACCEPTANCE_TIME_CONFLICT")
    if verified >= expires:
        raise Rejected("QUOTE_EXPIRED")
    source = acceptance["source_ref"]
    if not isinstance(source, dict) or not isinstance(source.get("source_id"), str):
        raise Rejected("REFERENCE_INVALID")
    core._source_ref(db, who, source["source_id"], "/acceptance/source_ref")
    body = dict(acceptance)
    body["scope"] = {"tenant": who.scope[0], "company": who.scope[1]}
    body_json = canonical(body)
    existing = db.execute(
        "SELECT body_json FROM t03_acceptance WHERE tenant=? AND company=? AND acceptance_id=?",
        (*who.scope, acceptance["acceptance_id"]),
    ).fetchone()
    if existing is not None:
        if existing["body_json"] != body_json:
            raise Rejected("ACCEPTANCE_IMMUTABLE")
        return {"acceptance_id": acceptance["acceptance_id"], "quote_id": acceptance["quote_id"], "business_revision": acceptance["quote_business_revision"], "business_hash": acceptance["quote_business_hash"], "status": "verified", "replayed": True}
    duplicate = db.execute(
        "SELECT acceptance_id FROM t03_acceptance WHERE tenant=? AND company=? AND source_message_id=?",
        (*who.scope, acceptance["source_message_id"]),
    ).fetchone()
    if duplicate is not None:
        raise Rejected("SOURCE_MESSAGE_DUPLICATE")
    created = now()
    db.execute(
        "INSERT INTO t03_acceptance VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (*who.scope, acceptance["acceptance_id"], acceptance["quote_id"], acceptance["quote_business_revision"],
         acceptance["quote_business_hash"], canonical(acceptance["customer_ref"]), canonical(acceptance["contact_ref"]),
         acceptance["kind"], canonical(source), acceptance["source_message_id"], acceptance["source_author"],
         acceptance["forward_chain_ref"], acceptance["recorded_at"], acceptance["verified_at"], acceptance["verified_by"],
         canonical(acceptance["line_ids"]), body_json, created),
    )
    db.execute(
        "INSERT INTO t03_acceptance_event VALUES(NULL,?,?,?,?,?,?,?)",
        (*who.scope, acceptance["acceptance_id"], "verified", who.actor,
         canonical({"quote_id": acceptance["quote_id"], "business_revision": acceptance["quote_business_revision"]}), created),
    )
    return {"acceptance_id": acceptance["acceptance_id"], "quote_id": acceptance["quote_id"], "business_revision": acceptance["quote_business_revision"], "business_hash": acceptance["quote_business_hash"], "status": "verified", "replayed": False}


def validate_order_snapshot(
    db: sqlite3.Connection, scope: tuple[str, str], order_id: str
) -> dict[str, Any]:
    """Verify persisted order identity and exact frozen source before write/replay.

    Historical queries/reconciliation continue to observe original facts. They
    do not certify a legacy body under this newer snapshot contract.
    """
    order = db.execute(
        "SELECT * FROM t03_order WHERE tenant=? AND company=? AND order_id=?",
        (*scope, order_id),
    ).fetchone()
    if order is None:
        raise Rejected("REFERENCE_INVALID")
    revision = db.execute(
        "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? "
        "AND business_revision=?",
        (*scope, order["source_quote_id"], order["source_quote_revision"]),
    ).fetchone()
    acceptance = db.execute(
        "SELECT * FROM t03_acceptance WHERE tenant=? AND company=? AND acceptance_id=?",
        (*scope, order["acceptance_id"]),
    ).fetchone()
    if revision is None or acceptance is None:
        raise Rejected("REFERENCE_INVALID")
    try:
        payload = json.loads(revision["data_json"])
        calculation = json.loads(revision["calculation_json"]) if revision["calculation_json"] else None
        body = json.loads(order["body_json"])
        expected = t03_order_snapshot.build(
            scope, order_id, order["source_quote_id"], order["source_quote_revision"],
            order["source_quote_hash"], order["acceptance_id"], order["conversion_slot"],
            payload, calculation,
        )
        if (
            canonical(body) != canonical(expected)
            or order["root_quote_id"] != order["source_quote_id"]
            or revision["business_hash"] != order["source_quote_hash"]
            or canonical(json.loads(order["customer_ref_json"])) != canonical(payload["customer_ref"])
            or hashlib.sha256(canonical(body).encode()).hexdigest() != order["order_hash"]
            or acceptance["quote_id"] != order["source_quote_id"]
            or acceptance["business_revision"] != order["source_quote_revision"]
            or acceptance["business_hash"] != order["source_quote_hash"]
            or canonical(json.loads(acceptance["customer_ref_json"])) != canonical(payload["customer_ref"])
            or canonical(json.loads(acceptance["contact_ref_json"])) != canonical(payload["contact_ref"])
            or sorted(json.loads(acceptance["line_ids_json"])) != sorted(
                row["line_id"] for row in payload["lines"]
            )
        ):
            raise Rejected("REFERENCE_INVALID")
    except (KeyError, TypeError, ValueError, AttributeError, Rejected):
        raise Rejected("REFERENCE_INVALID") from None
    return dict(order)


def prepare_order(
    core,
    db: sqlite3.Connection,
    who: Principal,
    quote_id: str,
    business_revision: int,
    business_hash: str,
    acceptance_id: str,
    conversion_slot: str = "full_v1",
    allow_existing: bool = True,
    *,
    task_id: str | None = None,
) -> dict[str, Any]:
    _guard_quote(db, who, quote_id, task_id)
    if conversion_slot != "full_v1":
        raise Rejected("CONVERSION_SLOT_UNSUPPORTED")
    root, revision, payload = _quote_revision_for_acceptance(db, who.scope, quote_id, business_revision)
    if revision["business_hash"] != business_hash:
        raise Rejected("BUSINESS_HASH_MISMATCH")
    acceptance = db.execute(
        "SELECT * FROM t03_acceptance WHERE tenant=? AND company=? AND acceptance_id=?",
        (*who.scope, acceptance_id),
    ).fetchone()
    if acceptance is None or acceptance["quote_id"] != quote_id or acceptance["business_revision"] != business_revision or acceptance["business_hash"] != business_hash:
        raise Rejected("ACCEPTANCE_SCOPE_MISMATCH")
    existing = db.execute(
        "SELECT * FROM t03_order WHERE tenant=? AND company=? AND root_quote_id=? AND conversion_slot=?",
        (*who.scope, quote_id, conversion_slot),
    ).fetchone()
    if existing is not None:
        if existing["source_quote_revision"] != business_revision or existing["source_quote_hash"] != business_hash or existing["acceptance_id"] != acceptance_id:
            raise Rejected("CONVERSION_SLOT_CONFLICT")
        if not allow_existing:
            raise Rejected("CONVERSION_SLOT_CONFLICT")
        validate_order_snapshot(db, who.scope, existing["order_id"])
        return {"order_id": existing["order_id"], "status": existing["status"], "row_version": existing["row_version"], "source_quote_id": quote_id, "source_quote_revision": business_revision, "source_quote_hash": business_hash, "acceptance_id": acceptance_id, "conversion_slot": conversion_slot, "replayed": True}
    order_id = "order." + hashlib.sha256(canonical({"scope": who.scope, "root": root["quote_id"], "slot": conversion_slot}).encode()).hexdigest()[:24]
    body = t03_order_snapshot.build(
        who.scope, order_id, quote_id, business_revision, business_hash, acceptance_id,
        conversion_slot, payload,
        json.loads(revision["calculation_json"]) if revision["calculation_json"] else None,
    )
    order_hash = hashlib.sha256(canonical(body).encode()).hexdigest()
    created = now()
    db.execute(
        "INSERT INTO t03_order VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (*who.scope, order_id, quote_id, conversion_slot, canonical(payload["customer_ref"]), quote_id, business_revision, business_hash, acceptance_id, "draft", 1, canonical(body), order_hash, None, created, created),
    )
    validate_order_snapshot(db, who.scope, order_id)
    db.execute("INSERT INTO t03_order_event VALUES(NULL,?,?,?,?,?,?,?)", (*who.scope, order_id, "prepared", who.actor, canonical({"quote_id": quote_id, "business_revision": business_revision, "order_hash": order_hash}), created))
    return {"order_id": order_id, "status": "draft", "row_version": 1, "source_quote_id": quote_id, "source_quote_revision": business_revision, "source_quote_hash": business_hash, "acceptance_id": acceptance_id, "conversion_slot": conversion_slot, "replayed": False}


def activate_order(
    core,
    db: sqlite3.Connection,
    who: Principal,
    order_id: str,
    expected_row_version: int,
    approval_id: str,
    *,
    task_id: str | None = None,
    order_review_id: str | None = None,
) -> dict[str, Any]:
    from . import t04_order_review

    t04_order_review._human(core, db, who, ("order.activate", "quote.read", "read"))
    order = db.execute("SELECT * FROM t03_order WHERE tenant=? AND company=? AND order_id=?", (*who.scope, order_id)).fetchone()
    if order is None:
        raise Rejected("NOT_FOUND")
    core._access(db, who, "quote", order["source_quote_id"])
    _guard_quote(db, who, order["source_quote_id"], task_id)
    validate_order_snapshot(db, who.scope, order_id)
    if order["status"] != "draft":
        if order["status"] == "active":
            link = db.execute("SELECT * FROM t04_order_review_activation WHERE tenant=? AND company=? AND order_id=?",
                              (*who.scope, order_id)).fetchone()
            if (approval_id != order["approval_id"] or
                    (link is not None and link["review_id"] != order_review_id) or
                    (link is None and order_review_id is not None)):
                raise Rejected("ORDER_REVIEW_IMMUTABLE")
            return {"order_id": order_id, "status": "active", "row_version": order["row_version"], "approval_id": order["approval_id"], "replayed": True}
        raise Rejected("ORDER_NOT_DRAFT")
    if order["row_version"] != expected_row_version:
        raise Rejected("VERSION_CONFLICT")
    from .t03_order_qualification import qualify

    source_qualification = qualify(core, db, who, order, approval_id)
    order_approval = t04_order_review.qualify(core, db, who, order, order_review_id)
    version = order["row_version"] + 1
    updated = now()
    db.execute("UPDATE t03_order SET status='active',row_version=?,approval_id=?,updated_at=? WHERE tenant=? AND company=? AND order_id=?", (version, approval_id, updated, *who.scope, order_id))
    db.execute("INSERT INTO t03_order_event VALUES(NULL,?,?,?,?,?,?,?)", (*who.scope, order_id, "activated", who.actor, canonical({"approval_id": approval_id, "order_hash": order["order_hash"], "source_qualification": source_qualification, "order_approval": order_approval}), updated))
    activated_at = core.clock().astimezone(UTC)
    if activated_at >= t04_order_review._stamp(order_approval["expires_at"]):
        raise Rejected("ORDER_APPROVAL_EXPIRED")
    db.execute("INSERT INTO t04_order_review_activation VALUES(?,?,?,?,?,?,?)",
               (*who.scope, order_id, order_review_id, approval_id, who.actor, activated_at.isoformat()))
    return {"order_id": order_id, "status": "active", "row_version": version, "approval_id": approval_id, "replayed": False}


def acceptance_history(db: sqlite3.Connection, scope: tuple[str, str], acceptance_id: str) -> dict[str, Any]:
    row = db.execute(
        "SELECT * FROM t03_acceptance WHERE tenant=? AND company=? AND acceptance_id=?",
        (*scope, acceptance_id),
    ).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    events = [dict(event) for event in db.execute(
        "SELECT seq,event_type,actor,payload_json,recorded_at FROM t03_acceptance_event WHERE tenant=? AND company=? AND acceptance_id=? ORDER BY seq",
        (*scope, acceptance_id),
    ).fetchall()]
    for event in events:
        event["payload"] = json.loads(event.pop("payload_json"))
    return {
        "acceptance_id": row["acceptance_id"], "quote_id": row["quote_id"],
        "business_revision": row["business_revision"], "business_hash": row["business_hash"],
        "customer_ref": json.loads(row["customer_ref_json"]), "contact_ref": json.loads(row["contact_ref_json"]),
        "kind": row["kind"], "source_ref": json.loads(row["source_ref_json"]),
        "source_message_id": row["source_message_id"], "source_author": row["source_author"],
        "forward_chain_ref": row["forward_chain_ref"], "recorded_at": row["recorded_at"],
        "verified_at": row["verified_at"], "verified_by": row["verified_by"],
        "line_ids": json.loads(row["line_ids_json"]), "events": events,
    }


def order_history(db: sqlite3.Connection, scope: tuple[str, str], order_id: str) -> dict[str, Any]:
    row = db.execute("SELECT * FROM t03_order WHERE tenant=? AND company=? AND order_id=?", (*scope, order_id)).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    events = [dict(event) for event in db.execute(
        "SELECT seq,event_type,actor,payload_json,recorded_at FROM t03_order_event WHERE tenant=? AND company=? AND order_id=? ORDER BY seq",
        (*scope, order_id),
    ).fetchall()]
    for event in events:
        event["payload"] = json.loads(event.pop("payload_json"))
    return {
        "order_id": row["order_id"], "root_quote_id": row["root_quote_id"],
        "conversion_slot": row["conversion_slot"], "customer_ref": json.loads(row["customer_ref_json"]),
        "source_quote_id": row["source_quote_id"], "source_quote_revision": row["source_quote_revision"],
        "source_quote_hash": row["source_quote_hash"], "acceptance_id": row["acceptance_id"],
        "status": row["status"], "row_version": row["row_version"], "order_hash": row["order_hash"],
        "approval_id": row["approval_id"], "body": json.loads(row["body_json"]), "events": events,
    }


def approval_history(
    db: sqlite3.Connection,
    scope: tuple[str, str],
    approval_id: str,
) -> dict:
    """Return an approval fact with a payload-free immutable event summary.

    The candidate ``approval`` view contains fields that are not persisted by
    this runtime (for example a policy reference).  This adapter therefore
    exposes a separate, deliberately smaller history view and keeps the
    approval row (the original decision/effectivity fact) separate from its
    append-only event trail.
    """
    row = db.execute(
        "SELECT a.*, r.status AS review_status, r.requested_by, r.requested_at "
        "FROM t03_approval a "
        "JOIN t03_review_request r ON r.tenant=a.tenant AND r.company=a.company "
        "AND r.review_request_id=a.review_request_id "
        "WHERE a.tenant=? AND a.company=? AND a.approval_id=?",
        (*scope, approval_id),
    ).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    events = [
        {
            "event_type": event["event_type"],
            "actor": event["actor"],
            "effectivity_version": event["effectivity_version"],
            "recorded_at": event["recorded_at"],
        }
        for event in db.execute(
            "SELECT event_type,actor,effectivity_version,recorded_at "
            "FROM t03_approval_event WHERE tenant=? AND company=? AND approval_id=? "
            "ORDER BY seq",
            (*scope, approval_id),
        ).fetchall()
    ]
    return {
        "approval_id": row["approval_id"],
        "review_request_id": row["review_request_id"],
        "quote_id": row["quote_id"],
        "business_revision": row["business_revision"],
        "business_hash": row["business_hash"],
        "target_command": row["command"],
        "reviewer": row["reviewer"],
        "decision": row["decision"],
        "decided_at": row["decided_at"],
        "expires_at": row["expires_at"],
        "effectivity": row["effectivity"],
        "effectivity_version": row["effectivity_version"],
        "review_request_status": row["review_status"],
        "requested_by": row["requested_by"],
        "requested_at": row["requested_at"],
        "event_count": len(events),
        "events": events,
    }


def document_history(
    db: sqlite3.Connection,
    scope: tuple[str, str],
    document_id: str,
) -> dict:
    """Return formal quote-document metadata and verify its immutable bindings.

    File content is intentionally never selected.  The binding, number and
    file rows are checked independently so a caller can distinguish an intact
    formalization from a missing or inconsistent underlying artifact.
    """
    binding = db.execute(
        "SELECT * FROM t03_document_binding WHERE tenant=? AND company=? AND document_id=?",
        (*scope, document_id),
    ).fetchone()
    if binding is None:
        raise Rejected("NOT_FOUND")
    number = db.execute(
        "SELECT id,number,document_type,business_ref FROM document_number "
        "WHERE tenant=? AND company=? AND id=?",
        (*scope, binding["number_id"]),
    ).fetchone()
    file_row = db.execute(
        "SELECT id,file_name,mime_type,content_hash,length(content) AS content_size,created_at "
        "FROM business_file WHERE tenant=? AND company=? AND id=?",
        (*scope, binding["file_id"]),
    ).fetchone()
    number_ok = (
        number is not None
        and number["number"] == binding["number"]
        and number["document_type"] == "quote"
        and number["business_ref"] == f"{binding['quote_id']}:{binding['business_revision']}"
    )
    file_ok = (
        file_row is not None
        and file_row["mime_type"] == binding["mime_type"]
        and file_row["content_hash"] == binding["file_sha256"]
        and file_row["content_size"] == binding["byte_size"]
    )
    if number_ok and file_ok:
        integrity_status = "intact"
    elif number is None or file_row is None:
        integrity_status = "missing"
    else:
        integrity_status = "mismatch"
    configurations = [
        dict(row)
        for row in db.execute(
            "SELECT role,kind,id,revision,data_hash,record_hash,publication_hash,created_at "
            "FROM t03_document_config_binding WHERE tenant=? AND company=? AND document_id=? ORDER BY role",
            (*scope, document_id),
        ).fetchall()
    ]
    return {
        "document_id": binding["document_id"],
        "quote_id": binding["quote_id"],
        "business_revision": binding["business_revision"],
        "business_hash": binding["business_hash"],
        "number_id": binding["number_id"],
        "document_number": binding["number"],
        "file_id": binding["file_id"],
        "file_name": file_row["file_name"] if file_row is not None else None,
        "file_sha256": binding["file_sha256"],
        "mime_type": binding["mime_type"],
        "byte_size": binding["byte_size"],
        "created_at": binding["created_at"],
        "number_integrity": "intact" if number_ok else "invalid",
        "file_integrity": "intact" if file_ok else "invalid",
        "integrity_status": integrity_status,
        "configuration_bindings": configurations,
    }


def outbox_history(
    db: sqlite3.Connection,
    scope: tuple[str, str],
    event_id: str,
) -> dict:
    """Return immutable internal outbox metadata without dispatch semantics.

    The current runtime persists the event atomically with formalization but
    has no external dispatcher or delivery receipt.  The public view therefore
    reports the event as queued and exposes only a hash of the stored payload.
    """
    row = db.execute(
        "SELECT event_id,quote_id,business_revision,event_type,payload_json,created_at "
        "FROM t03_quote_outbox WHERE tenant=? AND company=? AND event_id=?",
        (*scope, event_id),
    ).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    return {
        "event_id": row["event_id"],
        "quote_id": row["quote_id"],
        "business_revision": row["business_revision"],
        "event_type": row["event_type"],
        "created_at": row["created_at"],
        "payload_sha256": hashlib.sha256(row["payload_json"].encode("utf-8")).hexdigest(),
        "dispatch_state": "queued",
        "external_delivery_status": "not_started",
    }


def commit_history(
    db: sqlite3.Connection,
    scope: tuple[str, str],
    commit_id: str,
) -> dict:
    """Return the immutable server commit evidence as a compact fact view."""
    row = db.execute(
        "SELECT commit_id,quote_id,business_revision,business_hash,server_commit_at,"
        "authority_epoch,control_epoch,approval_id,cost_snapshot_id,result_json,created_at "
        "FROM t03_commit_evidence WHERE tenant=? AND company=? AND commit_id=?",
        (*scope, commit_id),
    ).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    try:
        result = json.loads(row["result_json"])
    except (TypeError, ValueError):
        raise Rejected("REFERENCE_INVALID") from None
    if not isinstance(result, dict):
        raise Rejected("REFERENCE_INVALID")
    cost_qualification = result.get("cost_qualification")
    return {
        "commit_id": row["commit_id"],
        "quote_id": row["quote_id"],
        "business_revision": row["business_revision"],
        "business_hash": row["business_hash"],
        "server_commit_at": row["server_commit_at"],
        "authority_epoch": row["authority_epoch"],
        "control_epoch": row["control_epoch"],
        "approval_id": row["approval_id"],
        "cost_snapshot_id": row["cost_snapshot_id"],
        "created_at": row["created_at"],
        "result_sha256": hashlib.sha256(row["result_json"].encode("utf-8")).hexdigest(),
        "formal_number": result.get("number"),
        "file_sha256": result.get("file_sha256"),
        "has_cost_qualification": isinstance(cost_qualification, dict),
    }


def dispatch_preflight(
    core,
    db: sqlite3.Connection,
    scope: tuple[str, str],
    event_id: str,
) -> dict:
    """Check local prerequisites before an external dispatcher may run.

    This is a read-only consistency check.  It never marks an event sent and
    never creates a delivery or customer-acceptance fact.
    """
    outbox = db.execute(
        "SELECT event_id,quote_id,business_revision,event_type,created_at "
        "FROM t03_quote_outbox WHERE tenant=? AND company=? AND event_id=?",
        (*scope, event_id),
    ).fetchone()
    if outbox is None:
        raise Rejected("NOT_FOUND")
    quote_id = outbox["quote_id"]
    revision = outbox["business_revision"]
    commit = db.execute(
        "SELECT * FROM t03_commit_evidence WHERE tenant=? AND company=? AND quote_id=? "
        "AND business_revision=? ORDER BY created_at DESC LIMIT 1",
        (*scope, quote_id, revision),
    ).fetchone()
    binding = db.execute(
        "SELECT document_id,business_hash,number,file_sha256 FROM t03_document_binding "
        "WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*scope, quote_id, revision),
    ).fetchone()
    root = db.execute(
        "SELECT status,active_revision FROM t03_quote_root WHERE tenant=? AND company=? AND quote_id=?",
        (*scope, quote_id),
    ).fetchone()
    reasons: list[str] = ["OUTBOX_QUEUED"]
    approval_id = commit["approval_id"] if commit is not None else None
    commit_id = commit["commit_id"] if commit is not None else None
    document_id = binding["document_id"] if binding is not None else None

    if commit is None:
        reasons.append("COMMIT_EVIDENCE_MISSING")
    else:
        reasons.append("COMMIT_EVIDENCE_PRESENT")
    if root is None or root["status"] != "active" or root["active_revision"] != revision:
        reasons.append("QUOTE_NOT_ACTIVE")
    else:
        reasons.append("QUOTE_ACTIVE")

    if binding is None:
        reasons.append("DOCUMENT_BINDING_MISSING")
    else:
        document = document_history(db, scope, str(document_id))
        if document["integrity_status"] == "intact":
            reasons.append("DOCUMENT_INTACT")
        else:
            reasons.append("DOCUMENT_INTEGRITY_FAILURE")

    approval = None
    if approval_id is None:
        reasons.append("APPROVAL_MISSING")
    else:
        approval = db.execute(
            "SELECT approval_id,business_revision,business_hash,effectivity,expires_at "
            "FROM t03_approval WHERE tenant=? AND company=? AND approval_id=?",
            (*scope, approval_id),
        ).fetchone()
        if approval is None:
            reasons.append("APPROVAL_MISSING")
        elif approval["effectivity"] != "valid":
            reasons.append("APPROVAL_REVOKED")
        else:
            checked_at = core.clock().astimezone(UTC)
            try:
                expired = checked_at >= foundation.stamp(approval["expires_at"])
            except (TypeError, ValueError, OverflowError):
                expired = True
            if expired:
                reasons.append("APPROVAL_EXPIRED")
            elif commit is not None and (
                approval["business_revision"] != revision
                or approval["business_hash"] != commit["business_hash"]
            ):
                reasons.append("APPROVAL_REFERENCE_MISMATCH")
            else:
                reasons.append("APPROVAL_CURRENT")

    if commit is not None and binding is not None:
        if commit["business_hash"] != binding["business_hash"]:
            reasons.append("BUSINESS_HASH_MISMATCH")

    positive = {
        "OUTBOX_QUEUED",
        "COMMIT_EVIDENCE_PRESENT",
        "QUOTE_ACTIVE",
        "DOCUMENT_INTACT",
        "APPROVAL_CURRENT",
    }
    ready = all(reason in reasons for reason in positive) and not any(
        reason.endswith(("MISSING", "FAILURE", "EXPIRED", "REVOKED", "MISMATCH"))
        or reason in {"QUOTE_NOT_ACTIVE"}
        for reason in reasons
    )
    return {
        "event_id": outbox["event_id"],
        "quote_id": quote_id,
        "business_revision": revision,
        "event_type": outbox["event_type"],
        "commit_id": commit_id,
        "approval_id": approval_id,
        "document_id": document_id,
        "checked_at": core.clock().astimezone(UTC).isoformat().replace("+00:00", "Z"),
        "ready_for_dispatch": ready,
        "reason_codes": reasons,
        "external_delivery_status": "not_started",
    }


def dispatch_target(
    core,
    db: sqlite3.Connection,
    scope: tuple[str, str],
    event_id: str,
) -> dict:
    """Summarize persisted recipient references before external dispatch.

    The customer/contact references come from the immutable snapshot created
    during formalization when Foundation master rows are available.  External
    channel configuration and sending remain outside this runtime.
    """
    outbox = db.execute(
        "SELECT event_id,quote_id,business_revision,event_type "
        "FROM t03_quote_outbox WHERE tenant=? AND company=? AND event_id=?",
        (*scope, event_id),
    ).fetchone()
    if outbox is None:
        raise Rejected("NOT_FOUND")
    revision = db.execute(
        "SELECT data_json,business_hash FROM t03_quote_revision WHERE tenant=? AND company=? "
        "AND quote_id=? AND business_revision=?",
        (*scope, outbox["quote_id"], outbox["business_revision"]),
    ).fetchone()
    if revision is None:
        raise Rejected("REFERENCE_INVALID")
    try:
        data = json.loads(revision["data_json"])
    except (TypeError, ValueError):
        raise Rejected("REFERENCE_INVALID") from None
    if not isinstance(data, dict):
        raise Rejected("REFERENCE_INVALID")

    snapshot = db.execute(
        "SELECT snapshot_id,business_hash,customer_ref_json,contact_ref_json,snapshot_hash "
        "FROM t03_dispatch_target_snapshot WHERE tenant=? AND company=? AND event_id=?",
        (*scope, event_id),
    ).fetchone()
    snapshot_valid = False
    snapshot_id = None
    snapshot_hash = None
    customer_ref = _typed_party_ref(data.get("customer_ref"), "customer")
    contact_ref = _typed_party_ref(data.get("contact_ref"), "contact")
    if snapshot is not None:
        snapshot_id = snapshot["snapshot_id"]
        snapshot_hash = snapshot["snapshot_hash"]
        try:
            stored_customer = json.loads(snapshot["customer_ref_json"])
            stored_contact = json.loads(snapshot["contact_ref_json"])
            calculated_hash = hashlib.sha256(
                canonical(
                    {
                        "business_hash": snapshot["business_hash"],
                        "customer_ref": stored_customer,
                        "contact_ref": stored_contact,
                        "customer": json.loads(
                            db.execute(
                                "SELECT customer_snapshot_json FROM t03_dispatch_target_snapshot "
                                "WHERE tenant=? AND company=? AND snapshot_id=?",
                                (*scope, snapshot_id),
                            ).fetchone()[0]
                        ),
                        "contact": json.loads(
                            db.execute(
                                "SELECT contact_snapshot_json FROM t03_dispatch_target_snapshot "
                                "WHERE tenant=? AND company=? AND snapshot_id=?",
                                (*scope, snapshot_id),
                            ).fetchone()[0]
                        ),
                    }
                ).encode()
            ).hexdigest()
            snapshot_valid = (
                calculated_hash == snapshot_hash
                and snapshot["business_hash"] == revision["business_hash"]
                and _typed_party_ref(stored_customer, "customer") == stored_customer
                and _typed_party_ref(stored_contact, "contact") == stored_contact
            )
            if snapshot_valid:
                customer_ref, contact_ref = stored_customer, stored_contact
        except (TypeError, ValueError, KeyError, IndexError):
            snapshot_valid = False
    preflight = dispatch_preflight(core, db, scope, event_id)
    reasons: list[str] = []
    if customer_ref is None:
        reasons.append("CUSTOMER_REFERENCE_MISSING")
    if contact_ref is None:
        reasons.append("CONTACT_REFERENCE_MISSING")
    if snapshot is None:
        reasons.append("RECIPIENT_SNAPSHOT_MISSING")
    elif not snapshot_valid:
        reasons.append("RECIPIENT_SNAPSHOT_INTEGRITY_FAILURE")
    if not preflight["ready_for_dispatch"]:
        reasons.append("DISPATCH_PREFLIGHT_NOT_READY")
    reasons.append("EXTERNAL_CHANNEL_NOT_CONFIGURED")
    local_target_ready = not any(
        code in reasons
        for code in (
            "CUSTOMER_REFERENCE_MISSING",
            "CONTACT_REFERENCE_MISSING",
            "RECIPIENT_SNAPSHOT_MISSING",
            "RECIPIENT_SNAPSHOT_INTEGRITY_FAILURE",
            "DISPATCH_PREFLIGHT_NOT_READY",
        )
    )
    return {
        "event_id": outbox["event_id"],
        "quote_id": outbox["quote_id"],
        "business_revision": outbox["business_revision"],
        "event_type": outbox["event_type"],
        "customer_ref": customer_ref,
        "contact_ref": contact_ref,
        "document_id": preflight["document_id"],
        "dispatch_preflight_ready": preflight["ready_for_dispatch"],
        "recipient_snapshot_id": snapshot_id,
        "recipient_snapshot_hash": snapshot_hash,
        "recipient_snapshot_available": snapshot_valid,
        "local_target_ready": local_target_ready,
        "target_ready": False,
        "channel_status": "not_configured",
        "reason_codes": reasons,
        "external_delivery_status": "not_started",
    }


def quote_ready(core, db: sqlite3.Connection, who: Principal, quote_id: str) -> dict:
    """Read the current adoption facts for the active historical revision.

    The result is informational and is intentionally not accepted by activate
    or replace as an authorization token; those methods repeat every check in
    their own write transaction.
    """
    root = quote_row(db, who.scope, quote_id)
    instant = core.clock().astimezone(UTC)
    checked_at = instant.isoformat().replace("+00:00", "Z")
    reasons: list[str] = []
    details: dict = {}
    revision = None
    if root["active_revision"] is None or root["status"] == "cancelled":
        reasons.append("NO_ACTIVE_REVISION")
    else:
        revision = db.execute(
            "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
            (*who.scope, quote_id, root["active_revision"]),
        ).fetchone()
        if revision is None or revision["status"] != "active":
            reasons.append("ACTIVE_REVISION_MISSING")

    control = control_row(db, who.scope, "quote_root", quote_id)
    if control is not None and control["state"] != "unbound":
        reasons.append("OBJECT_CONTROL_CONFLICT")

    if revision is not None:
        payload = json.loads(revision["data_json"])
        binding = db.execute(
            "SELECT * FROM t03_document_binding WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
            (*who.scope, quote_id, revision["business_revision"]),
        ).fetchone()
        if binding is None or binding["business_hash"] != revision["business_hash"]:
            reasons.append("FORMAL_DOCUMENT_MISSING")
        elif (
            db.execute(
                "SELECT 1 FROM document_number WHERE tenant=? AND company=? AND id=? AND number=?",
                (*who.scope, binding["number_id"], binding["number"]),
            ).fetchone()
            is None
            or db.execute(
                "SELECT 1 FROM business_file WHERE tenant=? AND company=? AND id=? AND content_hash=? AND length(content)=?",
                (*who.scope, binding["file_id"], binding["file_sha256"], binding["byte_size"]),
            ).fetchone()
            is None
        ):
            reasons.append("FORMAL_DOCUMENT_INTEGRITY_FAILURE")
        if not _quote_expiration(payload, instant):
            reasons.append("QUOTE_EXPIRED")
        commits = db.execute(
            "SELECT * FROM t03_commit_evidence WHERE tenant=? AND company=? AND quote_id=? "
            "AND business_revision=?", (*who.scope, quote_id, revision["business_revision"]),
        ).fetchall()
        approval = None
        valid_commit = len(commits) == 1 and commits[0]["business_hash"] == revision["business_hash"]
        if not valid_commit:
            reasons.append("REFERENCE_INVALID")
        else:
            approval = db.execute(
                "SELECT * FROM t03_approval WHERE tenant=? AND company=? AND approval_id=?",
                (*who.scope, commits[0]["approval_id"]),
            ).fetchone()
        if valid_commit and approval is None:
            reasons.append("APPROVAL_REQUIRED")
        elif approval is None:
            pass
        elif (approval["quote_id"] != quote_id
              or approval["business_revision"] != revision["business_revision"]
              or approval["business_hash"] != revision["business_hash"]
              or approval["command"] not in ("quote.activate", "quote.replace")
              or approval["decision"] != "approved"):
            reasons.append("APPROVAL_REQUIRED")
        elif approval["effectivity"] != "valid":
            reasons.append("APPROVAL_REVOKED")
        elif not _unexpired(approval["expires_at"], instant):
            reasons.append("APPROVAL_EXPIRED")
        else:
            try:
                current_reviewer(core, db, who.scope, quote_id, approval, revision)
            except Rejected as exc:
                if exc.code not in ("APPROVAL_STALE", "INDEPENDENT_REVIEW_REQUIRED"):
                    raise
                reasons.append(exc.code)
        ref = _snapshot_ref(payload, json.loads(revision["calculation_json"]) if revision["calculation_json"] else None)
        if ref is None:
            reasons.append("COST_SNAPSHOT_MISSING")
        else:
            try:
                query = core.costing_snapshot_in_transaction(db, who, ref["id"])
                snap = query.get("snapshot", {})
                details["cost_snapshot"] = {
                    "id": ref["id"],
                    "result_hash": snap.get("result_hash"),
                    "evidence_hash": snap.get("evidence_hash"),
                    "currently_eligible_for_quote": bool(
                        query.get("currently_eligible_for_quote", False)
                    ),
                    "eligibility_checked_at": query.get("eligibility_checked_at"),
                }
                if ref["result_hash"] is not None and ref["result_hash"] != snap.get("result_hash"):
                    reasons.append("REFERENCE_INVALID")
                elif not query.get("currently_eligible_for_quote", False):
                    reasons.append("COST_SNAPSHOT_INELIGIBLE")
                elif "lines" in payload:
                    from . import t03_cost_scope

                    calculation = json.loads(revision["calculation_json"]) if revision["calculation_json"] else {}
                    t03_cost_scope.bind(core, db, who, payload, snap, calculation)
                    from . import t03_sales_terms

                    t03_sales_terms.bind(core, db, who, payload, calculation)
                    from . import t03_trade_parties

                    t03_trade_parties.bind(core, db, who, payload, calculation)
                    _current_sales_fx(core, db, who, payload)
            except Rejected as exc:
                # Authorization and storage failures remain visible to the
                # caller; only a business qualification false is a reason.
                if exc.code in ("COST_INPUT_NOT_READY", "REFERENCE_STALE", "COMPARISON_BASIS_MISMATCH",
                                "REFERENCE_INVALID", "DRAFT_NOT_READY", "INVALID_KNOWN_VALUE",
                                "DEPENDENCY_NOT_SUPPORTED", "OBJECT_CONTROL_CONFLICT",
                                "TAX_POLICY_UNCONFIRMED", "CHARGE_SCOPE_UNRESOLVED",
                                "CONFIG_NOT_ACTIVE", "CONFIG_EXPIRED", "FX_STALE"):
                    reasons.append(exc.code)
                else:
                    raise
    return {
        "object_id": quote_id,
        "status": root["status"],
        "business_revision": root["active_revision"],
        "business_hash": revision["business_hash"] if revision is not None else None,
        "quote_ready": not reasons,
        "checked_at": checked_at,
        "reasons": reasons,
        **details,
    }


def _migrate_a2(db: sqlite3.Connection) -> None:
    db.execute(
        """CREATE TABLE t03_authority_scope(
            tenant TEXT NOT NULL, company TEXT NOT NULL,
            authority_epoch INTEGER NOT NULL CHECK(authority_epoch > 0),
            PRIMARY KEY(tenant,company), FOREIGN KEY(tenant,company) REFERENCES scope
        )"""
    )
    db.execute(
        """CREATE TABLE t03_object_control(
            tenant TEXT NOT NULL, company TEXT NOT NULL,
            object_kind TEXT NOT NULL, object_id TEXT NOT NULL,
            state TEXT NOT NULL CHECK(state IN ('unbound','bound','stopping')),
            task_id TEXT, delegate_epoch INTEGER,
            control_epoch INTEGER NOT NULL CHECK(control_epoch > 0),
            bound_actor TEXT, updated_at TEXT NOT NULL,
            PRIMARY KEY(tenant,company,object_kind,object_id),
            FOREIGN KEY(tenant,company) REFERENCES scope,
            CHECK((state='unbound' AND task_id IS NULL AND delegate_epoch IS NULL)
               OR (state IN ('bound','stopping') AND task_id IS NOT NULL AND delegate_epoch IS NOT NULL))
        )"""
    )
    db.execute("CREATE INDEX t03_object_control_task ON t03_object_control(tenant,company,task_id)")
    db.execute(
        "INSERT INTO t03_authority_scope(tenant,company,authority_epoch) SELECT tenant,company,1 FROM scope"
    )


def enabled(db: sqlite3.Connection) -> bool:
    return (
        db.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='t03_authority_scope'"
        ).fetchone()
        is not None
    )


def ensure_scope(db: sqlite3.Connection, scope: tuple[str, str]) -> None:
    db.execute(
        "INSERT OR IGNORE INTO t03_authority_scope VALUES(?,?,1)",
        (*scope,),
    )


def authority_epoch(db: sqlite3.Connection, scope: tuple[str, str]) -> int:
    ensure_scope(db, scope)
    row = db.execute(
        "SELECT authority_epoch FROM t03_authority_scope WHERE tenant=? AND company=?",
        (*scope,),
    ).fetchone()
    if row is None:
        raise RuntimeError("Missing T03 authority scope")
    return int(row[0])


def bump_authority_epoch(db: sqlite3.Connection, scope: tuple[str, str]) -> int:
    ensure_scope(db, scope)
    db.execute(
        "UPDATE t03_authority_scope SET authority_epoch=authority_epoch+1 WHERE tenant=? AND company=?",
        (*scope,),
    )
    return authority_epoch(db, scope)


def actor_snapshot(db: sqlite3.Connection, who: Principal) -> dict:
    epoch = authority_epoch(db, who.scope)
    authorization = db.execute(
        "SELECT grants_json,actor_kind FROM authorization WHERE tenant=? AND company=? AND actor=?",
        (*who.scope, who.actor),
    ).fetchone()
    access = db.execute(
        "SELECT team_id,data_scope FROM actor_access WHERE tenant=? AND company=? AND actor=?",
        (*who.scope, who.actor),
    ).fetchone()
    return {
        "authority_epoch": epoch,
        "actor": who.actor,
        "actor_kind": authorization["actor_kind"] if authorization else None,
        "grants": []
        if authorization is None
        else __import__("json").loads(authorization["grants_json"]),
        "team_id": access["team_id"] if access else None,
        "data_scope": access["data_scope"] if access else None,
    }


def control_row(db: sqlite3.Connection, scope: tuple[str, str], kind: str, object_id: str):
    return db.execute(
        "SELECT * FROM t03_object_control WHERE tenant=? AND company=? AND object_kind=? AND object_id=?",
        (*scope, kind, object_id),
    ).fetchone()


def guard(
    db: sqlite3.Connection,
    who: Principal,
    kind: str | None,
    object_id: str | None,
    *,
    task_id: str | None = None,
    expected_control_epoch: int | None = None,
) -> dict:
    """Check server-owned control before a mutating operation.

    An absent row is an explicitly verified unbound object.  A bound object
    cannot be operated on by the public request path because task identity is
    resolved by the trusted adapter, never accepted from client JSON.
    """
    if not kind or not object_id:
        return {"state": "unbound_verified", "control_epoch": None}
    row = control_row(db, who.scope, kind, object_id)
    if row is None:
        return {"state": "unbound_verified", "control_epoch": None}
    if expected_control_epoch is not None and row["control_epoch"] != expected_control_epoch:
        raise Rejected("OBJECT_CONTROL_CONFLICT")
    if row["state"] == "unbound":
        return {"state": "unbound_verified", "control_epoch": row["control_epoch"]}
    if row["state"] == "stopping":
        raise Rejected("OBJECT_CONTROL_CONFLICT")
    if task_id is None or task_id != row["task_id"]:
        raise Rejected("OBJECT_CONTROL_CONFLICT")
    if row["delegate_epoch"] != authority_epoch(db, who.scope):
        raise Rejected("OBJECT_CONTROL_CONFLICT")
    return {"state": "bound_verified", "control_epoch": row["control_epoch"]}


def bind(
    db: sqlite3.Connection,
    who: Principal,
    kind: str,
    object_id: str,
    task_id: str,
    *,
    expected_control_epoch: int | None = None,
) -> dict:
    if not task_id:
        raise Rejected("INVALID_KNOWN_VALUE")
    epoch = authority_epoch(db, who.scope)
    old = control_row(db, who.scope, kind, object_id)
    if old is not None:
        if expected_control_epoch is not None and old["control_epoch"] != expected_control_epoch:
            raise Rejected("VERSION_CONFLICT")
        if old["state"] in ("bound", "stopping"):
            raise Rejected("OBJECT_CONTROL_CONFLICT")
        control_epoch = old["control_epoch"] + 1
        db.execute(
            "UPDATE t03_object_control SET state='bound',task_id=?,delegate_epoch=?,control_epoch=?,bound_actor=?,updated_at=? "
            "WHERE tenant=? AND company=? AND object_kind=? AND object_id=?",
            (task_id, epoch, control_epoch, who.actor, now(), *who.scope, kind, object_id),
        )
    else:
        if expected_control_epoch not in (None, 0):
            raise Rejected("VERSION_CONFLICT")
        control_epoch = 1
        db.execute(
            "INSERT INTO t03_object_control VALUES(?,?,?,?,?,?,?,?,?,?)",
            (*who.scope, kind, object_id, "bound", task_id, epoch, control_epoch, who.actor, now()),
        )
    return {
        "object_kind": kind,
        "object_id": object_id,
        "state": "bound",
        "task_id": task_id,
        "delegate_epoch": epoch,
        "control_epoch": control_epoch,
    }


def stop(
    db: sqlite3.Connection,
    who: Principal,
    kind: str,
    object_id: str,
    *,
    expected_control_epoch: int,
) -> dict:
    row = control_row(db, who.scope, kind, object_id)
    if row is None or row["control_epoch"] != expected_control_epoch:
        raise Rejected("VERSION_CONFLICT")
    if row["state"] != "bound":
        raise Rejected("INVALID_STATE")
    control_epoch = row["control_epoch"] + 1
    db.execute(
        "UPDATE t03_object_control SET state='stopping',control_epoch=?,updated_at=? "
        "WHERE tenant=? AND company=? AND object_kind=? AND object_id=?",
        (control_epoch, now(), *who.scope, kind, object_id),
    )
    return {
        "object_kind": kind,
        "object_id": object_id,
        "state": "stopping",
        "control_epoch": control_epoch,
    }


def unbind(
    db: sqlite3.Connection,
    who: Principal,
    kind: str,
    object_id: str,
    *,
    expected_control_epoch: int,
) -> dict:
    row = control_row(db, who.scope, kind, object_id)
    if row is None or row["control_epoch"] != expected_control_epoch:
        raise Rejected("VERSION_CONFLICT")
    control_epoch = row["control_epoch"] + 1
    db.execute(
        "UPDATE t03_object_control SET state='unbound',task_id=NULL,delegate_epoch=NULL,control_epoch=?,bound_actor=NULL,updated_at=? "
        "WHERE tenant=? AND company=? AND object_kind=? AND object_id=?",
        (control_epoch, now(), *who.scope, kind, object_id),
    )
    return {
        "object_kind": kind,
        "object_id": object_id,
        "state": "unbound",
        "control_epoch": control_epoch,
    }


def utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")
