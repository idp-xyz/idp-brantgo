"""Reviewable local purchase drafts for active export orders.

A draft binds selected order lines to exact, currently effective supply
conditions and stores the server calculation. It is not a supplier commitment.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from datetime import UTC, date
from fractions import Fraction
from math import lcm
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from . import costing, foundation, t03_storage, t04_order_review
from .common import Rejected, canonical
from .costing_engine.rules import purchase_groups, split_tax
from .costing_engine.validator import Invalid, allocate
from .t04_response import public_time

CONTRACT = "brant.purchase-draft/0.1.0"
READ = ("quote.read", "read", "costing.read", "foundation.read")
IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,63}")
SOURCES = {"offer": "supplier_offer", "purchase_terms": "purchase_terms"}
HEADER = ("currency_ref", "payment_terms_ref", "trade_terms_ref", "purchase_trade_scope_ref")
CONFIGS = {
    "sku_profile_ref": "sku_profile", "purchase_unit_ref": "unit", "currency_ref": "currency",
    "tax_profile_ref": "tax_profile", "trade_terms_ref": "trade_terms",
    "payment_terms_ref": "payment_terms", "purchase_trade_scope_ref": "trade_scope",
    "tax_application_ref": "tax_application",
}
DOCUMENT_STALE = {"/business_revision": "SUPPLY_CONDITION_NOT_CURRENT",
                  "/interval": "SUPPLY_CONDITION_EXPIRED"}


def _costing(call, *args, stale: dict[str, str] | None = None, **kwargs):
    try:
        return call(*args, **kwargs)
    except Invalid as exc:
        if exc.code in ("PERMISSION_DENIED", "NOT_FOUND"):
            raise Rejected("REFERENCE_INVALID") from None
        if exc.code == "REFERENCE_STALE" and stale:
            raise Rejected(stale.get(exc.path, exc.code)) from None
        raise Rejected(exc.code) from None


def _identifier(value: Any) -> str:
    if not isinstance(value, str) or IDENTIFIER.fullmatch(value) is None:
        raise Rejected("SCHEMA_INVALID")
    return value


def _request(order_id: Any, draft_id: Any, lines: Any, selection_reason: Any) -> dict[str, Any]:
    _identifier(order_id)
    _identifier(draft_id)
    if (not isinstance(selection_reason, str) or not selection_reason.strip()
            or len(selection_reason) > 1000
            or any(unicodedata.category(char).startswith("C") for char in selection_reason)):
        raise Rejected("SCHEMA_INVALID")
    if not isinstance(lines, list) or not 0 < len(lines) <= 200:
        raise Rejected("SCHEMA_INVALID")
    normalized: list[dict[str, Any]] = []
    for item in lines:
        if not isinstance(item, dict) or set(item) != {"order_line_id", "source"}:
            raise Rejected("SCHEMA_INVALID")
        source = item["source"]
        if (not isinstance(source, dict) or set(source) != {"kind", "id", "revision", "condition_line_id"}
                or source["kind"] not in SOURCES or type(source["revision"]) is not int
                or not 0 < source["revision"] <= 2147483647):
            raise Rejected("SCHEMA_INVALID")
        for value in (item["order_line_id"], source["id"], source["condition_line_id"]):
            _identifier(value)
        normalized.append({"order_line_id": item["order_line_id"], "source": dict(source)})
    if len({item["order_line_id"] for item in normalized}) != len(normalized):
        raise Rejected("DUPLICATE_LINE_ID")
    return {"order_id": order_id, "lines": normalized, "selection_reason": selection_reason}


def _instant(core) -> str:
    return core.clock().astimezone(UTC).isoformat().replace("+00:00", "Z")


def _text(value: Fraction) -> str:
    scaled = value * 10**6
    if scaled.denominator != 1 or scaled < 0:
        raise Rejected("INVALID_KNOWN_VALUE")
    whole, fraction = divmod(scaled.numerator, 10**6)
    return str(whole) if fraction == 0 else f"{whole}.{fraction:06d}".rstrip("0")


def _applied(quantity: Fraction, condition: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for tier in condition["tiers"]:
        low = Fraction(tier["lower_inclusive"])
        high = Fraction(tier["upper_exclusive"]) if "upper_exclusive" in tier else None
        if condition["pricing_mode"] == "graduated":
            used = (quantity if high is None else min(quantity, high)) - low
            if used > 0:
                rows.append({**tier, "quantity": _text(used)})
        elif low <= quantity and (high is None or quantity < high):
            rows.append({**tier, "quantity": _text(quantity)})
    return rows


def _document(model, manifest: dict, source: dict[str, Any], rfq_ref: Any):
    kind = SOURCES[source["kind"]]
    ref = {"kind": kind, "id": source["id"], "revision": source["revision"]}
    data = _costing(model._business, ref, manifest, kind, stale=DOCUMENT_STALE)
    _costing(model._master, data["supplier_ref"], manifest, "supplier")
    record = model.roots[kind, source["id"]].revisions[source["revision"]]
    if not record.get("verified_by") or not record.get("verified_at"):
        raise Rejected("REFERENCE_INVALID")
    entry = {**ref, "data_hash": foundation.digest(data), "verified_by": record["verified_by"],
             "verified_at": record["verified_at"], "interval": data["interval"], "origin": None}
    if kind == "purchase_terms":
        origin_ref = data["source_offer_ref"]
        origin = _costing(model._business, origin_ref, manifest, "supplier_offer",
                          check_effect=data["validity_mode"] == "dependent_validity",
                          stale=DOCUMENT_STALE)
        if origin["supplier_ref"] != data["supplier_ref"]:
            raise Rejected("REFERENCE_INVALID")
        entry["origin"] = {**origin_ref, "validity_mode": data["validity_mode"],
                           "interval": origin["interval"]}
    elif data["rfq_ref"] != rfq_ref:
        raise Rejected("SUPPLY_SCOPE_MISMATCH")
    return data, entry


def _header(conditions: list[tuple[dict[str, Any], dict[str, Any]]]) -> dict[str, Any]:
    supplier, first = conditions[0]
    for other, condition in conditions[1:]:
        if other != supplier:
            raise Rejected("SUPPLIER_MISMATCH")
        if any(condition[key] != first[key] for key in HEADER):
            raise Rejected("PURCHASE_TERMS_INCONSISTENT")
    return {"supplier_ref": supplier, **{key: first[key] for key in HEADER}}


def _delivery(core, supply: dict[str, Any], required: dict[str, Any]) -> dict[str, Any]:
    if supply.get("kind") != "fixed":
        raise Rejected("DELIVERY_UNRESOLVED")
    if any(supply[key] != required[key] for key in ("milestone", "place_ref", "time_zone")):
        raise Rejected("DELIVERY_NOT_COMPARABLE")
    try:
        supplied = date.fromisoformat(supply["date"])
        deadline = date.fromisoformat(required["date"])
        today = core.clock().astimezone(ZoneInfo(required["time_zone"])).date()
    except (KeyError, TypeError, ValueError, ZoneInfoNotFoundError):
        raise Rejected("REFERENCE_INVALID") from None
    if supplied < today:
        raise Rejected("DELIVERY_DATE_PASSED")
    if supplied > deadline:
        raise Rejected("DELIVERY_LATE")
    return {"milestone": supply["milestone"], "place_ref": supply["place_ref"],
            "time_zone": supply["time_zone"], "supplier_date": supply["date"],
            "required_date": required["date"], "slack_days": (deadline - supplied).days}


def _costing_basis(model, actor, quote: dict[str, Any]):
    reference = quote.get("snapshot_ref")
    if not isinstance(reference, dict):
        raise Rejected("COST_SNAPSHOT_MISSING")
    snapshot = _costing(model.history, actor, reference["id"])
    scenario = model.scenarios.get(snapshot["scenario_id"])
    if (snapshot["kind"] != "snapshot" or snapshot["result_hash"] != reference.get("result_hash")
            or scenario is None or scenario["status"] != "frozen"
            or scenario["version"] != snapshot["frozen_scenario_version"]):
        raise Rejected("REFERENCE_INVALID")
    return snapshot, scenario["data"]["allocations"]


def _reference(snapshot, allocations, rfq_line_id: str, source: dict[str, Any],
               currency: str, cost_minor: int) -> dict[str, Any]:
    sources = [{**item["source"], "purchase_quantity": item["purchase_quantity"]}
               for item in allocations if item["rfq_line_id"] == rfq_line_id]
    costed = sum(int(item["amount_minor"]) for component in snapshot["components"]
                 if component["id"].startswith("purchase.")
                 for item in component["allocations"] if item["line_id"] == rfq_line_id)
    same = len(sources) == 1 and {key: sources[0][key] for key in source} == source
    return {"sources": sources, "currency": snapshot["currency"], "purchase_cost_minor": str(costed),
            "same_source": same,
            "cost_variance_minor": str(cost_minor - costed) if currency == snapshot["currency"] else None}


def _calculate(core, db, who, order, review_id: str, request: dict[str, Any], draft_id: str):
    snapshot_body = json.loads(order["body_json"])
    quote = snapshot_body["source_quote_snapshot"]["data"]
    required = snapshot_body["terms"].get("delivery")
    if not isinstance(required, dict) or required.get("kind") != "fixed":
        raise Rejected("DELIVERY_NOT_COMPARABLE")
    order_lines = {line["line_id"]: line for line in snapshot_body["lines"]}
    requested = []
    for item in request["lines"]:
        line = order_lines.get(item["order_line_id"])
        if line is None:
            raise Rejected("ORDER_LINE_NOT_FOUND")
        if not isinstance(line.get("rfq_line_id"), str):
            raise Rejected("REFERENCE_INVALID")
        requested.append((line, item["source"]))
    model, _ = costing.models(core, db, who)
    actor = costing.actor(core, db, who)
    model._actor = actor
    manifest: dict = {}
    configs: dict[str, Any] = {}

    def config(ref, kind):
        key = canonical(ref)
        if key not in configs:
            configs[key] = _costing(model._cfg, ref, manifest, kind)
        return configs[key]

    documents: dict[tuple, Any] = {}
    selected: list[tuple[Any, Any, Any, Any, Any]] = []
    for line, source in requested:
        key = (source["kind"], source["id"], source["revision"])
        if key not in documents:
            documents[key] = _document(model, manifest, source, quote.get("rfq_ref"))
        data = documents[key][0]
        condition = next((row for row in data["lines"] if row["id"] == source["condition_line_id"]), None)
        if condition is None:
            raise Rejected("REFERENCE_INVALID")
        if condition["sku_profile_ref"] != line["sku_profile_ref"]:
            raise Rejected("SPECIFICATION_MISMATCH")
        if "rfq_line_ids" in data and line["rfq_line_id"] not in data["rfq_line_ids"]:
            raise Rejected("SUPPLY_SCOPE_MISMATCH")
        config(line["sku_profile_ref"], "sku_profile")
        config(line["unit_ref"], "unit")
        for field, kind in CONFIGS.items():
            config(condition[field], kind)
        config(condition["delivery"]["place_ref"], "location")
        selected.append((line, source, data["supplier_ref"], condition,
                         _delivery(core, condition["delivery"], required)))
    header = _header([(supplier, condition) for _, _, supplier, condition, _ in selected])
    minor_units = int(config(header["currency_ref"], "currency")["minor_units"])
    context = {"lines": [{"line_id": line["rfq_line_id"], "sku_profile_ref": line["sku_profile_ref"],
                          "quantity": line["quantity"], "unit_ref": line["unit_ref"]}
                         for line, *_ in selected]}
    allocations = {"allocations": [{"rfq_line_id": line["rfq_line_id"], "purchase_quantity": line["quantity"],
                                    "purchase_unit_ref": line["unit_ref"], "source": source}
                                   for line, source, *_ in selected]}
    groups = sorted(_costing(purchase_groups, allocations, context,
                             lambda src: documents[src["kind"], src["id"], src["revision"]][0]),
                    key=lambda group: group["source_identity"])
    by_rfq = {line["rfq_line_id"]: line["line_id"] for line, *_ in selected}
    price_groups: list[dict[str, Any]] = []
    amounts: dict[str, tuple[str, int, int, str]] = {}
    for number, group in enumerate(groups, 1):
        condition, members = group["condition"], sorted(group["members"])
        tax = config(condition["tax_profile_ref"], "tax_profile")
        parts = _costing(split_tax, group["raw_amount"], tax, minor_units)
        scale = lcm(*(group["members"][member].denominator for member in members))
        weights = [int(group["members"][member] * scale) for member in members]
        net = _costing(allocate, parts["net_minor"], weights)
        taxed = _costing(allocate, parts["tax_minor"], weights)
        group_id = f"group.{number}"
        for index, member in enumerate(members):
            amounts[member] = (group_id, net[index], taxed[index], tax["recovery_treatment"])
        kind, identifier, revision, condition_line_id = group["source_identity"]
        price_groups.append({
            "group_id": group_id,
            "source": {"kind": kind, "id": identifier, "revision": revision,
                       "condition_line_id": condition_line_id},
            "order_line_ids": sorted(by_rfq[member] for member in members),
            "quantity": _text(group["quantity"]), "unit_ref": condition["purchase_unit_ref"],
            "pricing_mode": condition["pricing_mode"],
            "price_basis_quantity": condition["price_basis_quantity"],
            "applied_tiers": _applied(group["quantity"], condition),
            "tax_profile_ref": condition["tax_profile_ref"], "tax_price_basis": tax["price_basis"],
            "tax_rate": tax["rate"], "tax_recovery_treatment": tax["recovery_treatment"],
            **{key: str(parts[key]) for key in ("net_minor", "tax_minor", "gross_minor")},
        })
    snapshot, costed = _costing_basis(model, actor, quote)
    currency_code = config(header["currency_ref"], "currency")["code"]
    lines: list[dict[str, Any]] = []
    for line, source, _, condition, delivery in sorted(selected, key=lambda row: row[0]["line_id"]):
        group_id, net_minor, tax_minor, recovery = amounts[line["rfq_line_id"]]
        cost_minor = net_minor if recovery == "recoverable" else net_minor + tax_minor
        lines.append({
            "order_line_id": line["line_id"], "rfq_line_id": line["rfq_line_id"],
            "sku_profile_ref": line["sku_profile_ref"], "unit_ref": line["unit_ref"],
            "order_quantity": line["quantity"], "purchase_quantity": line["quantity"],
            "source": source, "supplier_item_code": condition.get("supplier_item_code"),
            "price_group_id": group_id, "net_minor": str(net_minor), "tax_minor": str(tax_minor),
            "gross_minor": str(net_minor + tax_minor),
            "tax_profile_ref": condition["tax_profile_ref"],
            "tax_application_ref": condition["tax_application_ref"],
            "moq": condition["moq"], "order_multiple": condition.get("order_multiple"),
            "delivery": delivery,
            "costing_reference": _reference(snapshot, costed, line["rfq_line_id"], source,
                                            currency_code, cost_minor),
        })
    sources = sorted((entry for _, entry in documents.values()),
                     key=lambda entry: (entry["kind"], entry["id"], entry["revision"]))
    ends = [entry["interval"]["valid_until"] for entry in sources] + [
        entry["origin"]["interval"]["valid_until"] for entry in sources
        if entry["origin"] and entry["origin"]["validity_mode"] == "dependent_validity"]
    return {
        "contract": CONTRACT, "scope": {"tenant": who.tenant, "company": who.company},
        "draft_id": draft_id, "commitment_state": "not_committed",
        "order": {
            "order_id": order["order_id"], "order_hash": order["order_hash"],
            "order_version": order["row_version"], "order_review_id": review_id,
            "source_quote_id": order["source_quote_id"],
            "source_quote_revision": order["source_quote_revision"],
            "source_quote_hash": order["source_quote_hash"],
            "customer_ref": snapshot_body["customer_ref"], "required_delivery": required,
        },
        **header, "minor_units": minor_units, "rounding": "HALF_UP",
        "sources": sources, "price_groups": price_groups, "lines": lines,
        "totals": {key: str(sum(int(line[key]) for line in lines))
                   for key in ("net_minor", "tax_minor", "gross_minor")},
        "costing_snapshot": {"id": snapshot["id"], "result_hash": snapshot["result_hash"],
                             "currency": snapshot["currency"]},
        "supply_valid_until": min(foundation.stamp(end) for end in ends).isoformat().replace("+00:00", "Z"),
        "selection_reason": request["selection_reason"], "checked_at": _instant(core),
    }


def _load(core, db, who, draft_id: str):
    """Return an integrity-checked draft under current quote and supply-condition access."""
    row = db.execute("SELECT * FROM t04_purchase_draft WHERE tenant=? AND company=? AND draft_id=?",
                     (*who.scope, draft_id)).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    order = db.execute("SELECT * FROM t03_order WHERE tenant=? AND company=? AND order_id=?",
                       (*who.scope, row["order_id"])).fetchone()
    if order is None:
        raise Rejected("REFERENCE_INVALID")
    core._access(db, who, "quote", order["source_quote_id"])
    try:
        body = json.loads(row["body_json"])
        stored = json.loads(row["request_json"])
        try:
            request = _request(stored["order_id"], row["draft_id"], stored["lines"],
                               stored["selection_reason"])
        except Rejected:
            raise Rejected("REFERENCE_INVALID") from None
        claimed = db.execute(
            "SELECT order_id,order_line_id FROM t04_purchase_draft_line "
            "WHERE tenant=? AND company=? AND draft_id=? ORDER BY order_line_id",
            (*who.scope, draft_id)).fetchall()
        requested = sorted(((item["order_line_id"], item["source"]) for item in request["lines"]),
                           key=lambda pair: pair[0])
        if (hashlib.sha256(canonical(body).encode("utf-8")).hexdigest() != row["draft_hash"]
                or stored != request or body["contract"] != CONTRACT
                or body["draft_id"] != row["draft_id"]
                or body["scope"] != {"tenant": who.tenant, "company": who.company}
                or body["selection_reason"] != request["selection_reason"]
                or not body["order"]["order_id"] == row["order_id"] == request["order_id"]
                or body["order"]["order_hash"] != order["order_hash"]
                or body["supplier_ref"]["id"] != row["supplier_id"]
                or [(line["order_line_id"], line["source"]) for line in body["lines"]] != requested
                or [(item["order_id"], item["order_line_id"]) for item in claimed]
                != [(row["order_id"], line["order_line_id"]) for line in body["lines"]]
                or public_time(body["checked_at"]) != row["prepared_at"]):
            raise Rejected("REFERENCE_INVALID")
        public_time(body["supply_valid_until"])
        for entry in body["sources"]:
            roots = [(entry["kind"], entry["id"])]
            if entry["origin"] is not None:
                roots.append(("supplier_offer", entry["origin"]["id"]))
            for kind, identifier in roots:
                try:
                    core._access(db, who, "t02.costing." + kind, identifier)
                except Rejected:
                    raise Rejected("REFERENCE_INVALID") from None
    except (KeyError, TypeError, ValueError, AttributeError, RecursionError):
        raise Rejected("REFERENCE_INVALID") from None
    t03_storage.validate_order_snapshot(db, who.scope, row["order_id"])
    return row, body, request


def _view(core, row, body: dict[str, Any]) -> dict[str, Any]:
    expired = core.clock().astimezone(UTC) >= foundation.stamp(body["supply_valid_until"])
    return {"draft_id": row["draft_id"], "order_id": row["order_id"], "supplier_id": row["supplier_id"],
            "draft_hash": row["draft_hash"], "prepared_by": row["prepared_by"],
            "prepared_at": row["prepared_at"], "state": "supply_expired" if expired else "draft",
            "body": body}


def get(core, db, who, draft_id: str) -> dict[str, Any]:
    for permission in READ:
        core._authorize(db, who, permission)
    _identifier(draft_id)
    row, body, _ = _load(core, db, who, draft_id)
    return _view(core, row, body)


def prepare(core, db, who, order_id: str, draft_id: str, lines: Any, selection_reason: str,
            task_id: str | None = None) -> dict[str, Any]:
    t04_order_review._human(core, db, who, ("purchase.draft.prepare", *READ))
    request = _request(order_id, draft_id, lines, selection_reason)
    if db.execute("SELECT 1 FROM t04_purchase_draft WHERE tenant=? AND company=? AND draft_id=?",
                  (*who.scope, draft_id)).fetchone():
        row, body, stored = _load(core, db, who, draft_id)
        t03_storage._guard_quote(db, who, body["order"]["source_quote_id"], task_id)
        if stored != request or row["prepared_by"] != who.actor:
            raise Rejected("PURCHASE_DRAFT_IMMUTABLE")
        return {**_view(core, row, body), "replayed": True}
    order = db.execute("SELECT * FROM t03_order WHERE tenant=? AND company=? AND order_id=?",
                       (*who.scope, order_id)).fetchone()
    if order is None:
        raise Rejected("NOT_FOUND")
    core._access(db, who, "quote", order["source_quote_id"])
    t03_storage._guard_quote(db, who, order["source_quote_id"], task_id)
    t03_storage.validate_order_snapshot(db, who.scope, order_id)
    if order["status"] != "active":
        raise Rejected("ORDER_NOT_ACTIVE")
    link = db.execute("SELECT review_id FROM t04_order_review_activation "
                      "WHERE tenant=? AND company=? AND order_id=?", (*who.scope, order_id)).fetchone()
    if link is None:
        raise Rejected("ORDER_APPROVAL_REQUIRED")
    if db.execute("SELECT 1 FROM t04_order_review_revocation WHERE tenant=? AND company=? AND review_id=?",
                  (*who.scope, link["review_id"])).fetchone():
        raise Rejected("ORDER_APPROVAL_REVOKED")
    line_ids = [item["order_line_id"] for item in request["lines"]]
    if db.execute("SELECT 1 FROM t04_purchase_draft_line WHERE tenant=? AND company=? AND order_id=? "
                  f"AND order_line_id IN ({','.join('?' * len(line_ids))})",
                  (*who.scope, order_id, *line_ids)).fetchone():
        raise Rejected("PURCHASE_LINE_ALREADY_DRAFTED")
    try:
        body = _calculate(core, db, who, order, link["review_id"], request, draft_id)
    except (KeyError, TypeError, ValueError, AttributeError):
        raise Rejected("REFERENCE_INVALID") from None
    encoded = canonical(body)
    db.execute("INSERT INTO t04_purchase_draft VALUES(?,?,?,?,?,?,?,?,?,?)",
               (*who.scope, draft_id, order_id, body["supplier_ref"]["id"], canonical(request), encoded,
                hashlib.sha256(encoded.encode("utf-8")).hexdigest(), who.actor, body["checked_at"]))
    for line in body["lines"]:
        db.execute("INSERT INTO t04_purchase_draft_line VALUES(?,?,?,?,?)",
                   (*who.scope, order_id, line["order_line_id"], draft_id))
    row = db.execute("SELECT * FROM t04_purchase_draft WHERE tenant=? AND company=? AND draft_id=?",
                     (*who.scope, draft_id)).fetchone()
    return {**_view(core, row, body), "replayed": False}
