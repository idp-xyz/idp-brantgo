"""Additive T02 SQLite migration. Every migration statement shares one lock."""

import sqlite3
from pathlib import Path


def migrate(db: sqlite3.Connection) -> None:
    db.execute("BEGIN IMMEDIATE")
    try:
        versions = [
            r[0] for r in db.execute("SELECT version FROM schema_migration ORDER BY version")
        ]
        if versions in (
            [1, 2, 3],
            [1, 2, 3, 4],
            [1, 2, 3, 4, 5],
            [1, 2, 3, 4, 5, 6],
            [1, 2, 3, 4, 5, 6, 7],
            [1, 2, 3, 4, 5, 6, 7, 8],
            [1, 2, 3, 4, 5, 6, 7, 8, 9],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
        ):
            db.commit()
            return
        if versions != [1, 2]:
            raise RuntimeError("Unsupported T02 migration history")
        statement = ""
        for line in (
            (Path(__file__).parent / "contracts/T02_migration.sql").read_text().splitlines()
        ):
            statement += line + "\n"
            if sqlite3.complete_statement(statement):
                db.execute(statement)
                statement = ""
        if statement.strip():
            raise RuntimeError("Incomplete T02 migration")
        db.execute("INSERT INTO schema_migration VALUES(3,strftime('%Y-%m-%dT%H:%M:%fZ','now'))")
        db.commit()
    except BaseException:
        db.rollback()
        raise
