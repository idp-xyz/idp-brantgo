"""Atomic JSON command adapter for the persisted T03 quotation state machine."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from . import t03_storage, t04_response
from .common import Rejected, canonical

CONTRACT = "brant.quotation/0.1.0"
SCHEMAS = Path(__file__).parent / "contracts"
REQUEST_VALIDATOR = Draft202012Validator(
    json.loads((SCHEMAS / "T03_write-commands.schema.json").read_text(encoding="utf-8")),
    format_checker=FormatChecker(),
)
RESPONSE_SCHEMA = json.loads(
    (SCHEMAS / "T03_write-responses.schema.json").read_text(encoding="utf-8")
)
RESPONSE_VALIDATOR = Draft202012Validator(RESPONSE_SCHEMA, format_checker=FormatChecker())
_PUBLIC_CODES = {
    value
    for branch in RESPONSE_SCHEMA["oneOf"]
    for value in branch.get("properties", {}).get("code", {}).get("enum", [])
}
_PUBLIC_CODE_ALIASES = {
    "COST_SNAPSHOT_INELIGIBLE": "COST_SNAPSHOT_NOT_ELIGIBLE",
    "SOURCE_IDENTITY_CONFLICT": "REFERENCE_INVALID",
    "CONVERSION_SLOT_CONFLICT": "ROOT_CONVERSION_LOCKED",
}

_PERMISSIONS: dict[str, tuple[str, ...]] = {
    "quote.save_draft": ("quote.write",),
    "quote.revise": ("quote.revise", "quote.read"),
    "quote.discard_draft": ("quote.discard_draft", "quote.read", "read"),
    "quote.freeze": ("quote.freeze", "quote.read", "costing.read", "read", "foundation.read"),
    "quote.submit_review": ("quote.review.request", "quote.read"),
    "quote.review.approve": ("quote.review.decide", "quote.read", "read"),
    "quote.review.return": ("quote.review.decide", "quote.read", "read"),
    "quote.review.reject": ("quote.review.decide", "quote.read", "read"),
    "quote.approval.revoke": ("quote.approval.revoke", "quote.read", "read"),
    "quote.activate": ("quote.activate", "quote.read", "costing.read", "read", "foundation.read"),
    "quote.replace": ("quote.replace", "quote.read", "costing.read", "read", "foundation.read"),
    "quote.withdraw": ("quote.withdraw", "quote.read", "read"),
    "quote.cancel": ("quote.cancel", "quote.read", "read"),
    "quote.acceptance.verify": ("quote.acceptance.verify", "quote.read", "read"),
    "quote.response.record": ("quote.response.record", "quote.read", "read"),
    "quote.response.verify": ("quote.response.verify", "quote.read", "read"),
    "order.prepare": ("order.prepare", "quote.read", "read"),
    "order.activate": ("order.activate", "quote.read", "read"),
    "order.approval.revoke": ("order.approval.revoke", "quote.read", "read"),
    "order.review.request": ("order.review.request", "quote.read", "read"),
    "order.review.decide": ("order.review.decide", "quote.read", "read"),
}
_HUMAN_ONLY = set(_PERMISSIONS) - {"quote.save_draft", "quote.revise"}


def _command(request: Any) -> str:
    value = request.get("command") if isinstance(request, dict) else None
    if isinstance(value, str) and value.startswith(("quote.", "order.")):
        return value[:100]
    return "quote.invalid"


def _object_id(request: Any) -> str | None:
    if not isinstance(request, dict):
        return None
    args = request.get("args")
    value = (args.get("quote_id") or args.get("order_id") or args.get("review_id") or args.get("response_id")) if isinstance(args, dict) else None
    return value if isinstance(value, str) and len(value) <= 64 else None


def _bounded_json(request: Any) -> bytes:
    """Reject Python-only values and pathological trees before schema traversal."""
    pending = [(request, 0)]
    visited = 0
    while pending:
        item, depth = pending.pop()
        visited += 1
        if depth > 64 or visited > 100_000:
            raise Rejected("CALCULATION_LIMIT_EXCEEDED")
        if isinstance(item, float):
            raise Rejected("SCHEMA_INVALID")
        if isinstance(item, dict):
            pending.extend((child, depth + 1) for child in item.values())
        elif isinstance(item, list):
            pending.extend((child, depth + 1) for child in item)
    try:
        encoded = canonical(request).encode("utf-8")
    except (TypeError, ValueError, UnicodeError, RecursionError):
        raise Rejected("SCHEMA_INVALID") from None
    if len(encoded) > 1024 * 1024:
        raise Rejected("CALCULATION_LIMIT_EXCEEDED")
    return encoded


def _root(db, who, quote_id: str, expected_root_version: int):
    root = t03_storage.quote_row(db, who.scope, quote_id)
    if root["root_version"] != expected_root_version:
        raise Rejected("VERSION_CONFLICT")
    return root


def _revision(db, who, quote_id: str, revision: int):
    row = db.execute(
        "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? AND business_revision=?",
        (*who.scope, quote_id, revision),
    ).fetchone()
    if row is None:
        raise Rejected("REFERENCE_INVALID")
    return row


def _review_request(db, who, quote_id: str, args: dict):
    row = db.execute(
        "SELECT * FROM t03_review_request WHERE tenant=? AND company=? AND review_request_id=?",
        (*who.scope, args["review_request_id"]),
    ).fetchone()
    if (
        row is None
        or row["quote_id"] != quote_id
        or row["business_revision"] != args["business_revision"]
    ):
        raise Rejected("REFERENCE_INVALID")
    return row


def _validate_evidence(core, db, who, values: list[dict[str, str]]) -> None:
    for item in values:
        core._source_ref(db, who, item["source_id"], "/args/evidence")


def _validate_quote_evidence(core, db, who, data: dict) -> None:
    pending: list[Any] = [data]
    while pending:
        value = pending.pop()
        if isinstance(value, dict):
            evidence = value.get("evidence")
            if isinstance(evidence, list):
                _validate_evidence(core, db, who, evidence)
            pending.extend(value.values())
        elif isinstance(value, list):
            pending.extend(value)


def _server_result(core, db, who, command: str, args: dict, generated: dict[str, str]) -> dict:
    if command == "order.review.request":
        from . import t04_order_review

        return t04_order_review.request(core, db, who, args["order_id"], args["review_id"], None)
    if command == "order.review.decide":
        from . import t04_order_review

        return t04_order_review.decide(core, db, who, args["review_id"], args["decision"], args["expires_at"], None)
    if command == "order.approval.revoke":
        from . import t04_order_review

        return t04_order_review.revoke(core, db, who, args["review_id"], args["reason"], None)
    if command == "quote.response.verify":
        return t03_storage.verify_customer_response(
            core, db, who, args["response_id"], args["verification"]
        )
    quote_id = args.get("quote_id") or args.get("order_id")
    if not isinstance(quote_id, str):
        raise Rejected("SCHEMA_INVALID")
    if command == "quote.save_draft":
        _validate_quote_evidence(core, db, who, args["data"])
        return t03_storage.save_draft(
            db,
            who,
            quote_id,
            args["data"],
            expected_root_version=args["expected_root_version"],
        )

    if command == "quote.acceptance.verify":
        return t03_storage.register_acceptance(core, db, who, args)
    if command == "quote.response.record":
        return t03_storage.record_customer_response(core, db, who, args)
    if command == "order.prepare":
        return t03_storage.prepare_order(core, db, who, quote_id, args["business_revision"], args["business_hash"], args["acceptance_id"], args["conversion_slot"], allow_existing=False)
    if command == "order.activate":
        return t03_storage.activate_order(core, db, who, args["order_id"], args["expected_row_version"],
                                         args["approval_id"], order_review_id=args.get("order_review_id"))

    root = _root(db, who, quote_id, args["expected_root_version"])
    if command == "quote.revise":
        return t03_storage.revise(
            db,
            who,
            quote_id,
            expected_root_version=args["expected_root_version"],
            base_revision=args["base_revision"],
        )
    if command in ("quote.discard_draft", "quote.freeze"):
        if root["working_revision"] != args["draft_generation"]:
            raise Rejected("VERSION_CONFLICT")
        if command == "quote.discard_draft":
            _validate_evidence(core, db, who, args["evidence"])
            return t03_storage.discard_draft(
                db,
                who,
                quote_id,
                expected_root_version=args["expected_root_version"],
                reason=args["reason"],
                evidence=args["evidence"],
            )
        return t03_storage.freeze(
            core, db, who, quote_id, expected_root_version=args["expected_root_version"]
        )
    if command == "quote.submit_review":
        if root["status"] not in ("frozen", "pending_approval"):
            raise Rejected("INVALID_STATE")
        target = args["target"]
        if target["command"] == "quote.activate":
            if root["active_revision"] is not None:
                raise Rejected("QUOTE_NOT_CURRENT")
            expected_revision = max(root["working_revision"] or 0, root["active_revision"] or 0, 1)
        else:
            if target["expected_old_active_revision"] != root["active_revision"]:
                raise Rejected("QUOTE_NOT_CURRENT")
            active_revision = root["active_revision"]
            if active_revision is None:
                raise Rejected("QUOTE_NOT_CURRENT")
            row = db.execute(
                "SELECT business_revision FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? "
                "AND business_revision<>? AND status IN ('frozen','pending_approval') "
                "ORDER BY business_revision DESC LIMIT 1",
                (*who.scope, quote_id, active_revision),
            ).fetchone()
            expected_revision = row[0] if row else None
        if expected_revision != args["business_revision"]:
            raise Rejected("REFERENCE_INVALID")
        return t03_storage.submit_review(
            db,
            who,
            quote_id,
            expected_root_version=args["expected_root_version"],
            review_request_id=generated["review_request_id"],
            target_command=target["command"],
            expected_old_active_revision=target.get("expected_old_active_revision"),
        )
    if command.startswith("quote.review."):
        request = _review_request(db, who, quote_id, args)
        if command == "quote.review.approve":
            _validate_evidence(core, db, who, args["evidence"])
            decision, reason = "approved", args["reason"]
            expires_at = args["expires_at"]
            business_hash = args["business_hash"]
        elif command == "quote.review.return":
            _validate_evidence(core, db, who, args["evidence"])
            decision, reason, expires_at = "returned", args["reason"], None
            business_hash = request["business_hash"]
        else:
            _validate_evidence(core, db, who, args["evidence"])
            decision, reason, expires_at = "rejected", args["reason"], None
            business_hash = request["business_hash"]
        result = t03_storage.decide_review(
            db,
            who,
            args["review_request_id"],
            decision=decision,
            approval_id=generated["approval_id"],
            business_hash=business_hash,
            expires_at=expires_at,
            reason=reason,
            evidence=args["evidence"],
        )
        result["business_revision"] = request["business_revision"]
        result["business_hash"] = request["business_hash"]
        result["root_version"] = t03_storage.quote_row(db, who.scope, quote_id)["root_version"]
        result["status"] = t03_storage.quote_row(db, who.scope, quote_id)["status"]
        return result
    if command == "quote.approval.revoke":
        _validate_evidence(core, db, who, args["evidence"])
        approval = db.execute(
            "SELECT * FROM t03_approval WHERE tenant=? AND company=? AND approval_id=?",
            (*who.scope, args["approval_id"]),
        ).fetchone()
        if (
            approval is None
            or approval["quote_id"] != quote_id
            or approval["business_revision"] != args["business_revision"]
        ):
            raise Rejected("REFERENCE_INVALID")
        if approval["effectivity_version"] != args["expected_effectivity_version"]:
            raise Rejected("VERSION_CONFLICT")
        result = t03_storage.revoke_approval(
            db,
            who,
            args["approval_id"],
            expected_effectivity_version=args["expected_effectivity_version"],
            reason=args["reason"],
            evidence=args["evidence"],
        )
        revision = _revision(db, who, quote_id, args["business_revision"])
        result["business_revision"] = args["business_revision"]
        result["business_hash"] = revision["business_hash"]
        result["root_version"] = root["root_version"]
        result["status"] = root["status"]
        return result
    if command in ("quote.activate", "quote.replace"):
        revision = _revision(db, who, quote_id, args["business_revision"])
        approval = db.execute(
            "SELECT * FROM t03_approval WHERE tenant=? AND company=? AND approval_id=?",
            (*who.scope, args["approval_id"]),
        ).fetchone()
        if (
            approval is None
            or approval["quote_id"] != quote_id
            or approval["business_revision"] != args["business_revision"]
            or approval["business_hash"] != revision["business_hash"]
            or approval["command"] != command
        ):
            raise Rejected("APPROVAL_REQUIRED")
        if approval["effectivity_version"] != args["expected_approval_effectivity_version"]:
            raise Rejected("VERSION_CONFLICT")
        if command == "quote.replace" and (
            root["active_revision"] != args["expected_old_active_revision"]
        ):
            raise Rejected("QUOTE_NOT_CURRENT")
        result = t03_storage.activate(
            core,
            db,
            who,
            quote_id,
            expected_root_version=args["expected_root_version"],
            approval_id=args["approval_id"],
            number_id=generated["number_id"],
            document_id=generated["document_id"],
            file_id=generated["file_id"],
            expected_old_active_revision=(
                args["expected_old_active_revision"] if command == "quote.replace" else None
            ),
        )
        result["business_hash"] = revision["business_hash"]
        return result
    if command in ("quote.withdraw", "quote.cancel"):
        revision = _revision(db, who, quote_id, args["business_revision"])
        _validate_evidence(core, db, who, args["evidence"])
        operation = t03_storage.withdraw if command == "quote.withdraw" else t03_storage.cancel
        result = operation(
            db,
            who,
            quote_id,
            expected_root_version=args["expected_root_version"],
            business_revision=args["business_revision"],
            reason=args["reason"],
            evidence=args["evidence"],
        )
        result["business_hash"] = revision["business_hash"]
        return result
    raise Rejected("UNSUPPORTED_CONTRACT")


def _public_result(command: str, result: dict, generated: dict[str, str]) -> dict:
    if command == "quote.acceptance.verify":
        return {key: result[key] for key in ("acceptance_id", "quote_id", "business_revision", "business_hash", "status")}
    if command == "quote.response.record":
        return {key: (result[key].replace("+00:00", "Z") if key == "recorded_at" else result[key])
                for key in ("response_id", "quote_id", "classification", "recorded_at")} | {"status": "recorded"}
    if command == "quote.response.verify":
        return {key: result[key] for key in ("response_id", "acceptance_id", "quote_id")} | {"status": "verified"}
    if command == "order.prepare":
        return {key: result[key] for key in ("order_id", "status", "row_version", "source_quote_id", "source_quote_revision", "source_quote_hash", "acceptance_id", "conversion_slot")}
    if command == "order.activate":
        return {key: result[key] for key in ("order_id", "status", "row_version", "approval_id")}
    if command == "order.approval.revoke":
        return {"review_id": result["review_id"], "revoked": result["revoked"]}
    if command == "order.review.request":
        return {"review_id": result["review_id"], "order_id": result["order_id"]}
    if command == "order.review.decide":
        return {"review_id": result["review_id"], "decision": result["decision"]}
    current_status = "draft" if result.get("status") == "working" else result.get("status")
    status = {
        "quote.save_draft": "draft",
        "quote.revise": "draft",
        "quote.discard_draft": "discarded",
        "quote.freeze": "frozen",
        "quote.submit_review": "pending_approval",
        "quote.review.approve": "pending_approval",
        "quote.review.return": "frozen",
        "quote.review.reject": "frozen",
        "quote.activate": "active",
        "quote.replace": "active",
        "quote.withdraw": "withdrawn",
        "quote.cancel": "cancelled",
        "quote.acceptance.verify": "verified",
        "order.prepare": "draft",
        "order.activate": "active",
        "order.approval.revoke": "revoked",
        "order.review.request": "pending",
        "order.review.decide": "decided",
    }.get(command, current_status)
    value: dict[str, Any] = {
        "object_id": result["object_id"],
        "root_version": result["root_version"],
        "status": status,
    }
    for key in ("business_revision", "business_hash", "review_request_id"):
        if key in result and result[key] is not None:
            value[key] = result[key]
    if command == "quote.review.approve":
        value["approval_id"] = generated["approval_id"]
    elif command in ("quote.activate", "quote.replace"):
        value["approval_id"] = result["approval_id"]
        value["document_id"] = result["document_id"]
    elif command == "quote.approval.revoke":
        value["approval_id"] = result["approval_id"]
    return value


def _error(command: str, code: str) -> dict[str, Any]:
    public_command = command if command.startswith(("quote.", "order.")) else "quote.invalid"
    public_code = _PUBLIC_CODE_ALIASES.get(code, code)
    if public_code not in _PUBLIC_CODES:
        public_code = "INVALID_STATE"
    result = {"ok": False, "command": public_command, "code": public_code, "retriable": False}
    RESPONSE_VALIDATOR.validate(result)
    return result


def execute(core, who, request: Any) -> dict[str, Any]:
    """Run a closed quotation command with action result, event, and audit atomicity."""
    command = _command(request)
    quote_id = _object_id(request)
    correlation = uuid.uuid4().hex
    try:
        if not core._t03_enabled:
            raise Rejected("UNSUPPORTED_CONTRACT")
        encoded = _bounded_json(request)
        if not REQUEST_VALIDATOR.is_valid(request):
            if command not in _PERMISSIONS:
                raise Rejected("UNSUPPORTED_CONTRACT")
            raise Rejected("SCHEMA_INVALID")
        command = request["command"]
        args = request["args"]
        quote_id = args.get("quote_id") or args.get("order_id") or args.get("review_id") or args.get("response_id")
        if not isinstance(quote_id, str):
            raise Rejected("SCHEMA_INVALID")
        request_hash = hashlib.sha256(encoded).hexdigest()
        generated = {
            "approval_id": uuid.uuid4().hex,
            "document_id": uuid.uuid4().hex,
            "file_id": uuid.uuid4().hex,
            "number_id": uuid.uuid4().hex,
            "review_request_id": uuid.uuid4().hex,
        }
        with core._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                for permission in _PERMISSIONS[command]:
                    core._authorize(db, who, permission)
                if command in _HUMAN_ONLY:
                    actor = t03_storage.actor_snapshot(db, who)
                    if actor["actor_kind"] != "human":
                        raise Rejected("PERMISSION_DENIED")
                if command == "order.activate":
                    order = db.execute(
                        "SELECT source_quote_id FROM t03_order WHERE tenant=? AND company=? AND order_id=?",
                        (*who.scope, args["order_id"]),
                    ).fetchone()
                    if order is None:
                        raise Rejected("NOT_FOUND")
                    quote_id = order["source_quote_id"]
                elif command in ("order.approval.revoke", "order.review.request", "order.review.decide"):
                    review_id = args.get("review_id")
                    if command == "order.review.request":
                        order = db.execute(
                            "SELECT source_quote_id FROM t03_order WHERE tenant=? AND company=? AND order_id=?",
                            (*who.scope, args["order_id"]),
                        ).fetchone()
                    else:
                        order = db.execute(
                            "SELECT o.source_quote_id FROM t04_order_review_request r "
                            "JOIN t03_order o ON o.tenant=r.tenant AND o.company=r.company AND o.order_id=r.order_id "
                            "WHERE r.tenant=? AND r.company=? AND r.review_id=?",
                            (*who.scope, review_id),
                        ).fetchone()
                    if order is None:
                        raise Rejected("NOT_FOUND")
                    quote_id = order["source_quote_id"]
                elif command == "quote.response.verify":
                    response = db.execute(
                        "SELECT quote_id FROM t04_customer_response WHERE tenant=? AND company=? AND response_id=?",
                        (*who.scope, args["response_id"]),
                    ).fetchone()
                    if response is None:
                        raise Rejected("NOT_FOUND")
                    quote_id = response["quote_id"]
                root_exists = db.execute(
                    "SELECT 1 FROM t03_quote_root WHERE tenant=? AND company=? AND quote_id=?",
                    (*who.scope, quote_id),
                ).fetchone() is not None
                if root_exists:
                    core._access(db, who, "quote", quote_id)
                elif command not in ("order.activate", "order.approval.revoke", "order.review.request", "order.review.decide", "quote.response.record", "quote.response.verify") and (command != "quote.save_draft" or args.get("expected_root_version") != 0):
                    raise Rejected("NOT_FOUND")
                t03_storage.guard(db, who, "quote_root", quote_id)
                old = db.execute(
                    "SELECT request_hash,action_id,result_json FROM action_result WHERE tenant=? AND company=? AND command=? AND idempotency_key=?",
                    (*who.scope, command, request["idempotency_key"]),
                ).fetchone()
                if old is not None:
                    if old["request_hash"] != request_hash:
                        raise Rejected("IDEMPOTENCY_PAYLOAD_CONFLICT")
                    core._authorize(db, who, "quote.read")
                    try:
                        result = json.loads(old["result_json"])
                    except (TypeError, ValueError):
                        raise Rejected("REFERENCE_INVALID") from None
                    if command.startswith("quote.response."):
                        if (not RESPONSE_VALIDATOR.is_valid(result)
                                or result.get("ok") is not True
                                or result.get("command") != command
                                or result.get("action_id") != old["action_id"]):
                            raise Rejected("REFERENCE_INVALID")
                        response = t04_response.validate_receipt(core, db, who, command, result["result"])
                        if (response["response_id"] != args["response_id"]
                                or response["quote_id"] != quote_id):
                            raise Rejected("REFERENCE_INVALID")
                        if command == "quote.response.record":
                            if any(response[key] != value for key, value in args.items()):
                                raise Rejected("REFERENCE_INVALID")
                        else:
                            link = db.execute(
                                "SELECT body_json FROM t04_response_verification "
                                "WHERE tenant=? AND company=? AND response_id=?",
                                (*who.scope, args["response_id"]),
                            ).fetchone()
                            if link is None or json.loads(link["body_json"]) != args["verification"]:
                                raise Rejected("REFERENCE_INVALID")
                    if command.startswith("order."):
                        if (
                            not RESPONSE_VALIDATOR.is_valid(result)
                            or result.get("ok") is not True
                            or result.get("command") != command
                            or result.get("action_id") != old["action_id"]
                        ):
                            raise Rejected("REFERENCE_INVALID")
                        if command in ("order.approval.revoke", "order.review.request", "order.review.decide"):
                            review = db.execute(
                                "SELECT r.order_id,o.source_quote_id FROM t04_order_review_request r "
                                "JOIN t03_order o ON o.tenant=r.tenant AND o.company=r.company AND o.order_id=r.order_id "
                                "WHERE r.tenant=? AND r.company=? AND r.review_id=?",
                                (*who.scope, args["review_id"]),
                            ).fetchone()
                            if command == "order.review.request":
                                review = db.execute(
                                    "SELECT o.source_quote_id FROM t03_order o WHERE o.tenant=? AND o.company=? AND o.order_id=?",
                                    (*who.scope, args["order_id"]),
                                ).fetchone()
                                valid = (review is not None and review["source_quote_id"] == quote_id and
                                         result["result"]["review_id"] == args["review_id"] and
                                         result["result"]["order_id"] == args["order_id"])
                            else:
                                valid = (review is not None and review["source_quote_id"] == quote_id and
                                         result["result"]["review_id"] == args["review_id"])
                            if not valid:
                                raise Rejected("REFERENCE_INVALID")
                            if command != "order.review.request":
                                t03_storage.validate_order_snapshot(db, who.scope, review["order_id"])
                        else:
                            stored_order = t03_storage.validate_order_snapshot(
                                db, who.scope, result["result"]["order_id"]
                            )
                            if stored_order["source_quote_id"] != quote_id:
                                raise Rejected("REFERENCE_INVALID")
                        if command == "order.prepare" and any(
                            result["result"][field] != args[argument]
                            or result["result"][field] != stored_order[field]
                            for field, argument in (
                                ("source_quote_id", "quote_id"),
                                ("source_quote_revision", "business_revision"),
                                ("source_quote_hash", "business_hash"),
                                ("acceptance_id", "acceptance_id"),
                                ("conversion_slot", "conversion_slot"),
                            )
                        ):
                            raise Rejected("REFERENCE_INVALID")
                        if command == "order.activate" and result["result"]["order_id"] != args["order_id"]:
                            raise Rejected("REFERENCE_INVALID")
                    result["replayed"] = True
                    core._audit(
                        db, who, command, quote_id, "replayed", None, correlation
                    )
                else:
                    if not root_exists:
                        core._claim(db, who, "quote", quote_id)
                    internal = _server_result(core, db, who, command, args, generated)
                    result = {
                        "ok": True,
                        "command": command,
                        "action_id": uuid.uuid4().hex,
                        "replayed": False,
                        "result": _public_result(command, internal, generated),
                    }
                    RESPONSE_VALIDATOR.validate(result)
                    db.execute(
                        "INSERT INTO action_result VALUES(?,?,?,?,?,?,?)",
                        (
                            *who.scope,
                            command,
                            request["idempotency_key"],
                            request_hash,
                            result["action_id"],
                            canonical(result),
                        ),
                    )
                    core._audit(db, who, command, quote_id, "succeeded", None, correlation)
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise
    except Rejected as exc:
        public_code = _PUBLIC_CODE_ALIASES.get(exc.code, exc.code)
        if public_code not in _PUBLIC_CODES:
            public_code = "INVALID_STATE"
        with core._connection() as db:
            try:
                core._audit(
                    db, who, command, quote_id, "rejected", public_code, correlation
                )
                db.commit()
            except sqlite3.Error:
                db.rollback()
        return _error(command, public_code)
