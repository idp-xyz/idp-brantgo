"""BC-T01 local application service. Principal and provision require a trusted adapter."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from . import foundation, t03_config, t03_query, t03_storage, t03_write
from .common import Principal, Rejected, canonical, now
from .costing_storage import migrate as migrate_costing
from .foundation_storage import migrate
from .storage import initialize

CONTRACT = "brant.trade-core/0.1.0"
SCHEMAS = Path(__file__).parent / "contracts"
REQUEST_SCHEMA = json.loads((SCHEMAS / "BC_T01_commands.schema.json").read_text())
RESPONSE_SCHEMA = json.loads((SCHEMAS / "BC_T01_response.schema.json").read_text())
Draft202012Validator.check_schema(REQUEST_SCHEMA)
Draft202012Validator.check_schema(RESPONSE_SCHEMA)
REQUEST_VALIDATOR = Draft202012Validator(REQUEST_SCHEMA)
RESPONSE_VALIDATOR = Draft202012Validator(RESPONSE_SCHEMA)


class Core:
    def __init__(self, path: str | Path, *, clock=None, enable_t03: bool = False):
        self.path = Path(path)
        self.clock = clock or (lambda: datetime.now(UTC))
        self._t03_enabled = enable_t03
        with self._connection() as db:
            initialize(db, SCHEMAS / "BC_T01_reference.sql")
            migrate(db)
            migrate_costing(db)
            if enable_t03:
                t03_storage.migrate(db)

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        db = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            yield db
        finally:
            db.close()

    def provision(
        self,
        who: Principal,
        grants: list[str],
        *,
        actor_kind: str = "human",
        team_id: str | None = None,
        data_scope: str = "own",
    ) -> None:
        """Out-of-band local bootstrap/revocation; never expose as a user command."""
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                db.execute("INSERT OR IGNORE INTO scope VALUES(?,?)", who.scope)
                t03_changed = False
                if t03_storage.enabled(db):
                    t03_storage.ensure_scope(db, who.scope)
                    old_authorization = db.execute(
                        "SELECT grants_json,actor_kind FROM authorization WHERE tenant=? AND company=? AND actor=?",
                        (*who.scope, who.actor),
                    ).fetchone()
                    old_access = db.execute(
                        "SELECT team_id,data_scope FROM actor_access WHERE tenant=? AND company=? AND actor=?",
                        (*who.scope, who.actor),
                    ).fetchone()
                    t03_changed = (
                        old_authorization is None
                        or old_authorization["grants_json"] != canonical(grants)
                        or old_authorization["actor_kind"] != actor_kind
                        or old_access is None
                        or old_access["team_id"] != team_id
                        or old_access["data_scope"] != data_scope
                    )
                db.execute(
                    "INSERT INTO authorization VALUES(?,?,?,?,?) "
                    "ON CONFLICT(tenant,company,actor) DO UPDATE SET grants_json=excluded.grants_json,actor_kind=excluded.actor_kind",
                    (*who.scope, who.actor, canonical(grants), actor_kind),
                )
                db.execute(
                    "INSERT INTO actor_access VALUES(?,?,?,?,?) ON CONFLICT(tenant,company,actor) DO UPDATE SET team_id=excluded.team_id,data_scope=excluded.data_scope",
                    (*who.scope, who.actor, team_id, data_scope),
                )
                if t03_changed:
                    t03_storage.bump_authority_epoch(db, who.scope)
                self._audit(
                    db,
                    who,
                    "authorization.provision",
                    None,
                    "succeeded",
                    None,
                    uuid.uuid4().hex,
                )
                db.commit()
            except BaseException:
                db.rollback()
                raise

    def t03_authority_snapshot(self, who: Principal) -> dict[str, Any]:
        """Return current server-resolved authority; trusted local adapter only."""
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        with self._connection() as db:
            db.execute("BEGIN")
            try:
                result = t03_storage.actor_snapshot(db, who)
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def t03_config_verify_source(
        self,
        who: Principal,
        source_id: str,
        *,
        verified: bool,
        denied: bool = False,
        reason: str,
    ) -> dict[str, Any]:
        """Trusted local adapter assertion; this is not a public JSON command."""
        return t03_config.set_source_verification(
            self, who, source_id, verified=verified, denied=denied, reason=reason
        )

    def t03_config_select_pricing_policy(
        self, who: Principal, reference: dict[str, Any], *, reason: str
    ) -> dict[str, Any]:
        """Select the server-owned policy used for configuration publication."""
        return t03_config.set_policy_ref(self, who, reference, reason=reason)

    def t03_bind_object_control(
        self,
        who: Principal,
        kind: str,
        object_id: str,
        task_id: str,
        *,
        expected_control_epoch: int | None = None,
    ) -> dict[str, Any]:
        """Bind a server-owned object to a task; never expose as a JSON command."""
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                self._authorize(db, who, "quote.control")
                if kind == "quote_root":
                    exists = db.execute(
                        "SELECT 1 FROM t03_quote_root WHERE tenant=? AND company=? AND quote_id=?",
                        (*who.scope, object_id),
                    ).fetchone() is not None
                    if exists:
                        self._access(db, who, "quote", object_id)
                    else:
                        self._claim(db, who, "quote", object_id)
                result = t03_storage.bind(
                    db,
                    who,
                    kind,
                    object_id,
                    task_id,
                    expected_control_epoch=expected_control_epoch,
                )
                self._audit(
                    db,
                    who,
                    "t03.object_control.bind",
                    object_id,
                    "succeeded",
                    None,
                    uuid.uuid4().hex,
                )
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def t03_stop_object_control(
        self, who: Principal, kind: str, object_id: str, *, expected_control_epoch: int
    ) -> dict[str, Any]:
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                self._authorize(db, who, "quote.control")
                result = t03_storage.stop(
                    db, who, kind, object_id, expected_control_epoch=expected_control_epoch
                )
                self._audit(
                    db,
                    who,
                    "t03.object_control.stop",
                    object_id,
                    "succeeded",
                    None,
                    uuid.uuid4().hex,
                )
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def t03_unbind_object_control(
        self, who: Principal, kind: str, object_id: str, *, expected_control_epoch: int
    ) -> dict[str, Any]:
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                self._authorize(db, who, "quote.control")
                result = t03_storage.unbind(
                    db, who, kind, object_id, expected_control_epoch=expected_control_epoch
                )
                self._audit(
                    db,
                    who,
                    "t03.object_control.unbind",
                    object_id,
                    "succeeded",
                    None,
                    uuid.uuid4().hex,
                )
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def t03_check_object_control(
        self,
        who: Principal,
        kind: str,
        object_id: str,
        *,
        task_id: str | None = None,
        expected_control_epoch: int | None = None,
    ) -> dict[str, Any]:
        """Check control in a short trusted transaction; quote writes use the same db."""
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                result = t03_storage.guard(
                    db,
                    who,
                    kind,
                    object_id,
                    task_id=task_id,
                    expected_control_epoch=expected_control_epoch,
                )
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def _t03_write(
        self,
        who: Principal,
        permission: str | tuple[str, ...],
        command: str,
        object_id: str,
        operation,
        *,
        human_only: bool = False,
    ):
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                permissions = (permission,) if isinstance(permission, str) else permission
                for required in permissions:
                    self._authorize(db, who, required)
                if human_only:
                    actor = db.execute(
                        "SELECT actor_kind FROM authorization WHERE tenant=? AND company=? AND actor=?",
                        (*who.scope, who.actor),
                    ).fetchone()
                    if actor is None or actor["actor_kind"] != "human":
                        raise Rejected("PERMISSION_DENIED")
                quote_id: str | None = object_id
                if command == "quote.review.decide":
                    row = db.execute(
                        "SELECT quote_id FROM t03_review_request WHERE tenant=? AND company=? AND review_request_id=?",
                        (*who.scope, object_id),
                    ).fetchone()
                    quote_id = row["quote_id"] if row is not None else None
                elif command == "quote.approval.revoke":
                    row = db.execute(
                        "SELECT quote_id FROM t03_approval WHERE tenant=? AND company=? AND approval_id=?",
                        (*who.scope, object_id),
                    ).fetchone()
                    quote_id = row["quote_id"] if row is not None else None
                if quote_id is None:
                    raise Rejected("NOT_FOUND")
                root_exists = db.execute(
                    "SELECT 1 FROM t03_quote_root WHERE tenant=? AND company=? AND quote_id=?",
                    (*who.scope, quote_id),
                ).fetchone() is not None
                if command == "quote.save_draft" and not root_exists:
                    self._claim(db, who, "quote", object_id)
                else:
                    self._access(db, who, "quote", quote_id)
                result = operation(db)
                self._audit(db, who, command, object_id, "succeeded", None, uuid.uuid4().hex)
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def t03_quote_save_draft(
        self,
        who: Principal,
        quote_id: str,
        data: dict,
        *,
        expected_root_version: int = 0,
        calculation: dict | None = None,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            "quote.write",
            "quote.save_draft",
            quote_id,
            lambda db: t03_storage.save_draft(
                db,
                who,
                quote_id,
                data,
                expected_root_version=expected_root_version,
                calculation=calculation,
                task_id=task_id,
            ),
        )

    def t03_quote_freeze(
        self,
        who: Principal,
        quote_id: str,
        *,
        expected_root_version: int,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            ("quote.freeze", "quote.read", "costing.read", "read", "foundation.read"),
            "quote.freeze",
            quote_id,
            lambda db: t03_storage.freeze(
                self,
                db,
                who,
                quote_id,
                expected_root_version=expected_root_version,
                task_id=task_id,
            ),
            human_only=True,
        )

    def t03_quote_revise(
        self,
        who: Principal,
        quote_id: str,
        *,
        expected_root_version: int,
        base_revision: int,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            ("quote.revise", "quote.read"),
            "quote.revise",
            quote_id,
            lambda db: t03_storage.revise(
                db,
                who,
                quote_id,
                expected_root_version=expected_root_version,
                base_revision=base_revision,
                task_id=task_id,
            ),
        )

    def t03_quote_discard_draft(
        self,
        who: Principal,
        quote_id: str,
        *,
        expected_root_version: int,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            ("quote.discard_draft", "quote.read"),
            "quote.discard_draft",
            quote_id,
            lambda db: t03_storage.discard_draft(
                db, who, quote_id, expected_root_version=expected_root_version, task_id=task_id
            ),
            human_only=True,
        )

    def t03_quote_withdraw(
        self,
        who: Principal,
        quote_id: str,
        *,
        expected_root_version: int,
        business_revision: int,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            ("quote.withdraw", "quote.read"),
            "quote.withdraw",
            quote_id,
            lambda db: t03_storage.withdraw(
                db,
                who,
                quote_id,
                expected_root_version=expected_root_version,
                business_revision=business_revision,
                task_id=task_id,
            ),
            human_only=True,
        )

    def t03_quote_cancel(
        self,
        who: Principal,
        quote_id: str,
        *,
        expected_root_version: int,
        business_revision: int,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            ("quote.cancel", "quote.read"),
            "quote.cancel",
            quote_id,
            lambda db: t03_storage.cancel(
                db,
                who,
                quote_id,
                expected_root_version=expected_root_version,
                business_revision=business_revision,
                task_id=task_id,
            ),
            human_only=True,
        )

    def t03_quote_submit_review(
        self,
        who: Principal,
        quote_id: str,
        *,
        expected_root_version: int,
        review_request_id: str,
        target_command: str,
        expected_old_active_revision: int | None = None,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            ("quote.review.request", "quote.read"),
            "quote.submit_review",
            quote_id,
            lambda db: t03_storage.submit_review(
                db,
                who,
                quote_id,
                expected_root_version=expected_root_version,
                review_request_id=review_request_id,
                target_command=target_command,
                expected_old_active_revision=expected_old_active_revision,
                task_id=task_id,
            ),
            human_only=True,
        )

    def t03_quote_decide_review(
        self,
        who: Principal,
        review_request_id: str,
        *,
        decision: str,
        approval_id: str,
        business_hash: str,
        expires_at: str | None = None,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            ("quote.review.decide", "quote.read"),
            "quote.review.decide",
            review_request_id,
            lambda db: t03_storage.decide_review(
                db,
                who,
                review_request_id,
                decision=decision,
                approval_id=approval_id,
                business_hash=business_hash,
                expires_at=expires_at,
                task_id=task_id,
            ),
            human_only=True,
        )

    def t03_quote_revoke_approval(
        self,
        who: Principal,
        approval_id: str,
        *,
        expected_effectivity_version: int,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            ("quote.approval.revoke", "quote.read"),
            "quote.approval.revoke",
            approval_id,
            lambda db: t03_storage.revoke_approval(
                db,
                who,
                approval_id,
                expected_effectivity_version=expected_effectivity_version,
                task_id=task_id,
            ),
            human_only=True,
        )

    def t03_quote_activate(
        self,
        who: Principal,
        quote_id: str,
        *,
        expected_root_version: int,
        approval_id: str,
        number_id: str,
        document_id: str,
        file_id: str,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            ("quote.activate", "quote.read", "costing.read", "read", "foundation.read"),
            "quote.activate",
            quote_id,
            lambda db: t03_storage.activate(
                self,
                db,
                who,
                quote_id,
                expected_root_version=expected_root_version,
                approval_id=approval_id,
                number_id=number_id,
                document_id=document_id,
                file_id=file_id,
                task_id=task_id,
            ),
            human_only=True,
        )

    def t03_quote_replace(
        self,
        who: Principal,
        quote_id: str,
        *,
        expected_root_version: int,
        expected_old_active_revision: int,
        approval_id: str,
        number_id: str,
        document_id: str,
        file_id: str,
        task_id: str | None = None,
    ) -> dict:
        return self._t03_write(
            who,
            ("quote.replace", "quote.read", "costing.read", "read", "foundation.read"),
            "quote.replace",
            quote_id,
            lambda db: t03_storage.activate(
                self,
                db,
                who,
                quote_id,
                expected_root_version=expected_root_version,
                expected_old_active_revision=expected_old_active_revision,
                approval_id=approval_id,
                number_id=number_id,
                document_id=document_id,
                file_id=file_id,
                task_id=task_id,
            ),
            human_only=True,
        )

    def t04_record_customer_response(
        self, who: Principal, response: dict[str, Any], *, task_id: str | None = None
    ) -> dict:
        """Record a human-classified response; this does not verify acceptance."""
        if not isinstance(response, dict) or not isinstance(response.get("quote_id"), str):
            raise Rejected("SCHEMA_INVALID")
        return self._t03_write(
            who, ("quote.response.record", "quote.read", "read"),
            "quote.response.record", response["quote_id"],
            lambda db: t03_storage.record_customer_response(self, db, who, response, task_id=task_id),
            human_only=True,
        )

    def t04_get_customer_response(self, who: Principal, response_id: str) -> dict:
        """Read a response subject to current quote and source access."""
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        if not isinstance(response_id, str) or not response_id or len(response_id) > 64:
            raise Rejected("SCHEMA_INVALID")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                self._authorize(db, who, "quote.read")
                self._authorize(db, who, "read")
                from . import t04_response

                result = t04_response.get(self, db, who, response_id)
                self._audit(db, who, "quote.response.get", response_id, "read", None, uuid.uuid4().hex)
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def t04_verify_customer_response(
        self, who: Principal, response_id: str, verification: dict[str, Any],
        *, task_id: str | None = None,
    ) -> dict:
        """Verify a response and create its acceptance in one local transaction."""
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        if not isinstance(response_id, str) or not response_id or len(response_id) > 64:
            raise Rejected("SCHEMA_INVALID")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                for permission in ("quote.acceptance.verify", "quote.read", "read"):
                    self._authorize(db, who, permission)
                actor = db.execute("SELECT actor_kind FROM authorization WHERE tenant=? AND company=? AND actor=?",
                                   (*who.scope, who.actor)).fetchone()
                if actor is None or actor["actor_kind"] != "human":
                    raise Rejected("PERMISSION_DENIED")
                result = t03_storage.verify_customer_response(
                    self, db, who, response_id, verification, task_id=task_id)
                self._audit(db, who, "quote.response.verify", response_id, "succeeded", None, uuid.uuid4().hex)
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def t03_quote_record_acceptance(
        self, who: Principal, acceptance: dict[str, Any], *, task_id: str | None = None
    ) -> dict:
        """Record a complete, human-verified customer acceptance in one transaction."""
        quote_id = acceptance.get("quote_id")
        if not isinstance(quote_id, str):
            raise Rejected("SCHEMA_INVALID")
        return self._t03_write(
            who,
            ("quote.acceptance.verify", "quote.read", "read"),
            "quote.acceptance.verify",
            quote_id,
            lambda db: t03_storage.register_acceptance(self, db, who, acceptance, task_id=task_id),
            human_only=True,
        )

    def t03_order_prepare(
        self,
        who: Principal,
        quote_id: str,
        *,
        business_revision: int,
        business_hash: str,
        acceptance_id: str,
        conversion_slot: str = "full_v1",
        task_id: str | None = None,
    ) -> dict:
        """Create the one local full_v1 order draft for a verified acceptance."""
        return self._t03_write(
            who,
            ("order.prepare", "quote.read", "read"),
            "order.prepare",
            quote_id,
            lambda db: t03_storage.prepare_order(
                self, db, who, quote_id, business_revision, business_hash, acceptance_id,
                conversion_slot, task_id=task_id,
            ),
            human_only=True,
        )

    def t03_order_activate(
        self,
        who: Principal,
        order_id: str,
        *,
        expected_row_version: int,
        approval_id: str,
        task_id: str | None = None,
        order_review_id: str | None = None,
    ) -> dict:
        """Activate a prepared order after rechecking its quote approval and acceptance."""
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                for permission in ("order.activate", "quote.read", "read"):
                    self._authorize(db, who, permission)
                actor = db.execute(
                    "SELECT actor_kind FROM authorization WHERE tenant=? AND company=? AND actor=?",
                    (*who.scope, who.actor),
                ).fetchone()
                if actor is None or actor["actor_kind"] != "human":
                    raise Rejected("PERMISSION_DENIED")
                order = db.execute(
                    "SELECT source_quote_id FROM t03_order WHERE tenant=? AND company=? AND order_id=?",
                    (*who.scope, order_id),
                ).fetchone()
                if order is None:
                    raise Rejected("NOT_FOUND")
                self._access(db, who, "quote", order["source_quote_id"])
                result = t03_storage.activate_order(
                    self, db, who, order_id, expected_row_version, approval_id,
                    task_id=task_id, order_review_id=order_review_id
                )
                self._audit(db, who, "order.activate", order_id, "succeeded", None, uuid.uuid4().hex)
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def _t04_transaction(self, who, command, object_id, outcome, operation):
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                result = operation(db)
                self._audit(db, who, command, object_id, outcome, None, uuid.uuid4().hex)
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def _t04_order_review_write(self, who, command, object_id, operation):
        return self._t04_transaction(who, command, object_id, "succeeded", operation)

    def t04_order_request_review(self, who: Principal, order_id: str, review_id: str,
                                 *, task_id: str | None = None) -> dict:
        from . import t04_order_review

        return self._t04_order_review_write(who, "order.review.request", order_id,
            lambda db: t04_order_review.request(self, db, who, order_id, review_id, task_id))

    def t04_order_get_review(self, who: Principal, review_id: str,
                             *, task_id: str | None = None) -> dict:
        from . import t04_order_review

        return self._t04_order_review_write(who, "order.review.get", review_id,
            lambda db: t04_order_review.get(self, db, who, review_id, task_id))

    def t04_order_decide_review(self, who: Principal, review_id: str, decision: str,
                                expires_at: str, *, task_id: str | None = None) -> dict:
        from . import t04_order_review

        return self._t04_order_review_write(who, "order.review.decide", review_id,
            lambda db: t04_order_review.decide(self, db, who, review_id, decision, expires_at, task_id))

    def t04_order_activate_reviewed(self, who: Principal, order_id: str, review_id: str,
                                    quote_approval_id: str, *, task_id: str | None = None) -> dict:
        from . import t04_order_review

        return self._t04_order_review_write(who, "order.activate.reviewed", order_id,
            lambda db: t04_order_review.activate(self, db, who, order_id, review_id,
                                                quote_approval_id, task_id))

    def t04_order_revoke_approval(self, who: Principal, review_id: str, reason: str,
                                  *, task_id: str | None = None) -> dict:
        from . import t04_order_review

        return self._t04_order_review_write(who, "order.approval.revoke", review_id,
            lambda db: t04_order_review.revoke(self, db, who, review_id, reason, task_id))

    def t04_purchase_prepare_draft(self, who: Principal, order_id: str, draft_id: str,
                                   lines: list[dict[str, Any]], selection_reason: str,
                                   *, task_id: str | None = None) -> dict:
        """Bind active order lines to effective supply conditions; never a supplier commitment."""
        from . import t04_purchase

        return self._t04_transaction(who, "purchase.draft.prepare", draft_id, "succeeded",
            lambda db: t04_purchase.prepare(self, db, who, order_id, draft_id, lines,
                                            selection_reason, task_id))

    def t04_purchase_get_draft(self, who: Principal, draft_id: str) -> dict:
        """Read an immutable purchase draft under current quote and supply-condition access."""
        from . import t04_purchase

        return self._t04_transaction(who, "purchase.draft.get", draft_id, "read",
            lambda db: t04_purchase.get(self, db, who, draft_id))

    def t03_quote_ready(self, who: Principal, quote_id: str) -> dict:
        """Return current active-quote qualification facts.

        This trusted read is advisory only.  Formalization repeats the
        checks inside its own caller-owned SQLite write transaction.
        """
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                self._authorize(db, who, "quote.read")
                self._access(db, who, "quote", quote_id)
                result = t03_storage.quote_ready(self, db, who, quote_id)
                self._audit(db, who, "quote.ready", quote_id, "read", None, uuid.uuid4().hex)
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def t03_quote_get(
        self, who: Principal, quote_id: str, revision: int | None = None
    ) -> dict:
        """Read current or historical quote facts without changing them."""
        if not self._t03_enabled:
            raise RuntimeError("T03 persistence is not enabled for this Core")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                self._authorize(db, who, "quote.read")
                self._access(db, who, "quote", quote_id)
                result = t03_storage.quote_get(self, db, who, quote_id, revision)
                self._audit(db, who, "quote.get", quote_id, "read", None, uuid.uuid4().hex)
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise

    def _authorize(self, db, who, permission):
        row = db.execute(
            "SELECT grants_json,actor_kind FROM authorization WHERE tenant=? AND company=? AND actor=?",
            (*who.scope, who.actor),
        ).fetchone()
        grants = json.loads(row["grants_json"]) if row else []
        if (
            permission
            in ("master.confirm", "rfq.confirm_scope", "foundation.publish", "foundation.retire")
            and row
            and row["actor_kind"] != "human"
        ):
            raise Rejected("PERMISSION_DENIED")
        if (
            permission in ("master.confirm", "rfq.confirm_scope")
            and "read" not in grants
            and "*" not in grants
        ):
            raise Rejected("PERMISSION_DENIED")
        if permission not in grants and "*" not in grants:
            raise Rejected("PERMISSION_DENIED")

    def _audit(self, db, who, command, object_id, outcome, code, correlation, reason=None):
        db.execute(
            "INSERT INTO audit_event(tenant,company,actor,event_id,command,object_id,outcome,code,correlation_id,recorded_at,reason) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (
                *who.scope,
                who.actor,
                uuid.uuid4().hex,
                command,
                object_id,
                outcome,
                code,
                correlation,
                now(),
                reason,
            ),
        )

    def execute(self, who: Principal, request: Any) -> dict[str, Any]:
        if isinstance(request, dict) and request.get("contract") in (
            "brant.costing/0.1.0",
            "brant.foundation-extension/0.1.0",
        ):
            from .costing import execute

            return execute(self, who, request)
        if isinstance(request, dict) and request.get("contract") == t03_query.CONTRACT:
            if "command" in request:
                return t03_write.execute(self, who, request)
            return t03_query.execute(self, who, request)
        if isinstance(request, dict) and request.get("contract") == t03_config.CONTRACT:
            return t03_config.execute(self, who, request)
        correlation = uuid.uuid4().hex
        command = request.get("command", "invalid") if isinstance(request, dict) else "invalid"
        if not isinstance(command, str) or len(command) > 100:
            command = "invalid"
        object_id = None
        try:
            contract = request.get("contract") if isinstance(request, dict) else None
            if isinstance(request, dict) and contract not in (CONTRACT, foundation.CONTRACT):
                raise Rejected("UNSUPPORTED_CONTRACT", "/contract")
            validator = (
                foundation.REQUEST_VALIDATOR
                if contract == foundation.CONTRACT
                else REQUEST_VALIDATOR
            )
            response_validator = (
                foundation.RESPONSE_VALIDATOR
                if contract == foundation.CONTRACT
                else RESPONSE_VALIDATOR
            )
            try:
                encoded = canonical(request).encode("utf-8")
            except (TypeError, ValueError, UnicodeError, RecursionError):
                raise Rejected("SCHEMA_INVALID") from None
            if len(encoded) > (
                15 * 1024 * 1024 if contract == foundation.CONTRACT else 1024 * 1024
            ) or not validator.is_valid(request):
                raise Rejected(
                    "SCHEMA_INVALID",
                    "/",
                    "Request does not match bounded closed schema",
                )
            args = request["args"]
            object_id = args["id"]
            payload = {k: v for k, v in args.items() if k != "expected_version"}
            digest = hashlib.sha256(canonical(payload).encode("utf-8")).hexdigest()
            with self._connection() as db:
                db.execute("BEGIN IMMEDIATE")
                try:
                    self._authorize(db, who, command)
                    if self._t03_enabled:
                        t03_storage.guard(db, who, args.get("kind"), args.get("id"))
                    old = db.execute(
                        "SELECT request_hash,result_json FROM action_result WHERE "
                        "tenant=? AND company=? AND command=? AND idempotency_key=?",
                        (*who.scope, command, request["idempotency_key"]),
                    ).fetchone()
                    if old:
                        if old["request_hash"] != digest:
                            raise Rejected("IDEMPOTENCY_PAYLOAD_CONFLICT")
                        self._authorize(db, who, "read")
                        replay_result = json.loads(old["result_json"])
                        if not command.startswith("foundation."):
                            self._access(
                                db,
                                who,
                                "source"
                                if command == "source.register"
                                else "master"
                                if command.startswith("master.")
                                else "rfq",
                                replay_result["object_id"],
                            )
                        else:
                            foundation.replay_access(self, db, who, command, args, replay_result)
                        result = json.loads(old["result_json"])
                        result["replayed"] = True
                        self._audit(
                            db,
                            who,
                            command,
                            result["object_id"],
                            "replayed",
                            None,
                            correlation,
                        )
                    else:
                        result = (
                            foundation.handle(self, db, who, command, args)
                            if contract == foundation.CONTRACT
                            else self._dispatch(db, who, command, args)
                        )
                        result.update(ok=True, action_id=uuid.uuid4().hex, replayed=False)
                        response_validator.validate(result)
                        db.execute(
                            "INSERT INTO action_result VALUES(?,?,?,?,?,?,?)",
                            (
                                *who.scope,
                                command,
                                request["idempotency_key"],
                                digest,
                                result["action_id"],
                                canonical(result),
                            ),
                        )
                        db.execute(
                            "INSERT INTO outbox VALUES(?,?,?,?,?)",
                            (
                                *who.scope,
                                uuid.uuid4().hex,
                                result["action_id"],
                                canonical(
                                    {
                                        "command": command,
                                        "object_id": result["object_id"],
                                        "row_version": result["row_version"],
                                    }
                                ),
                            ),
                        )
                        self._audit(
                            db,
                            who,
                            command,
                            result["object_id"],
                            "succeeded",
                            None,
                            correlation,
                            args.get("reason"),
                        )
                    db.commit()
                    return result
                except BaseException:
                    db.rollback()
                    raise
        except Rejected as exc:
            with self._connection() as db:
                self._audit(db, who, command, object_id, "rejected", exc.code, correlation)
            result = {
                "ok": False,
                "code": exc.code,
                "field_errors": exc.fields,
                "correlation_id": correlation,
                "retryable": False,
            }
            (
                foundation.RESPONSE_VALIDATOR
                if isinstance(request, dict) and request.get("contract") == foundation.CONTRACT
                else RESPONSE_VALIDATOR
            ).validate(result)
            return result

    def _dispatch(self, db, who, command, args):
        if command == "source.register":
            return self._register_source(db, who, args)
        if command == "master.upsert_draft":
            return self._save_master(db, who, args)
        if command == "rfq.save_draft":
            return self._save_rfq(db, who, args)
        table = "master" if command.startswith("master.") else "rfq"
        record = self._load(db, who, table, args["id"])
        self._version(record, args["expected_version"])
        if command == "master.confirm":
            self._state(record, ["draft"])
            self._sources(db, who, args["evidence_ids"])
            self._confirm_master(db, who, record)
            for sid in args["evidence_ids"]:
                db.execute(
                    "INSERT OR IGNORE INTO master_evidence VALUES(?,?,?,?)",
                    (*who.scope, record["id"], sid),
                )
            status = "confirmed"
        elif command == "master.deactivate":
            self._state(record, ["confirmed"])
            status = "inactive"
        elif command == "rfq.confirm_scope":
            self._state(record, ["draft"])
            self._sources(db, who, args["evidence_ids"])
            self._confirm_rfq(db, who, record, args["evidence_ids"])
            for sid in args["evidence_ids"]:
                db.execute(
                    "INSERT OR IGNORE INTO source_use VALUES(?,?,?,?)",
                    (*who.scope, record["id"], sid),
                )
            status = "ready"
        elif command == "rfq.cancel":
            self._state(record, ["draft", "ready"])
            status = "cancelled"
        elif command == "rfq.close":
            self._state(record, ["ready"])
            status = "closed"
        else:
            raise Rejected("SCHEMA_INVALID")
        db.execute(
            f"UPDATE {table} SET status=?,row_version=row_version+1 WHERE tenant=? AND company=? AND id=?",
            (status, *who.scope, record["id"]),
        )
        return {
            "object_id": record["id"],
            "row_version": record["row_version"] + 1,
            "status": status,
        }

    def _claim(self, db, who, kind, object_id):
        row = db.execute(
            "SELECT team_id FROM actor_access WHERE tenant=? AND company=? AND actor=?",
            (*who.scope, who.actor),
        ).fetchone()
        inserted = db.execute(
            "INSERT OR IGNORE INTO record_access VALUES(?,?,?,?,?,?)",
            (*who.scope, kind, object_id, who.actor, row["team_id"] if row else None),
        )
        if self._t03_enabled and inserted.rowcount:
            t03_storage.bump_authority_epoch(db, who.scope)

    def _access(self, db, who, kind, object_id):
        access = db.execute(
            "SELECT * FROM actor_access WHERE tenant=? AND company=? AND actor=?",
            (*who.scope, who.actor),
        ).fetchone()
        record = db.execute(
            "SELECT * FROM record_access WHERE tenant=? AND company=? AND kind=? AND object_id=?",
            (*who.scope, kind, object_id),
        ).fetchone()
        if not access or not record:
            raise Rejected("NOT_FOUND", "/args/id")
        if record["owner_id"] == who.actor or access["data_scope"] == "company":
            return
        if (
            access["data_scope"] == "team"
            and access["team_id"]
            and access["team_id"] == record["team_id"]
        ):
            return
        raise Rejected("NOT_FOUND", "/args/id")

    def _load(self, db, who, table, object_id):
        row = db.execute(
            f"SELECT * FROM {table} WHERE tenant=? AND company=? AND id=?",
            (*who.scope, object_id),
        ).fetchone()
        if not row:
            raise Rejected("NOT_FOUND", "/args/id")
        if table in ("master", "rfq", "source_origin"):
            self._access(
                db,
                who,
                {"master": "master", "rfq": "rfq", "source_origin": "source"}[table],
                object_id,
            )
        return dict(row)

    @staticmethod
    def _version(record, expected):
        if record["row_version"] != expected:
            raise Rejected("VERSION_CONFLICT", "/args/expected_version")

    @staticmethod
    def _state(record, allowed):
        if record["status"] not in allowed:
            raise Rejected("INVALID_STATE", "/args/id")

    def _master_ref(self, db, who, object_id, kind, path, confirmed=False):
        row = db.execute(
            "SELECT * FROM master WHERE tenant=? AND company=? AND id=? AND kind=?",
            (*who.scope, object_id, kind),
        ).fetchone()
        if not row or (confirmed and row["status"] != "confirmed"):
            raise Rejected("REFERENCE_INVALID", path)
        try:
            self._access(db, who, "master", object_id)
        except Rejected:
            raise Rejected("REFERENCE_INVALID", path) from None
        return dict(row)

    def _sources(self, db, who, ids, path="/args/evidence_ids"):
        for i, sid in enumerate(ids):
            self._source_ref(db, who, sid, f"{path}/{i}")

    def _source_ref(self, db, who, sid, path):
        self._authorize(db, who, "read")
        if not db.execute(
            "SELECT 1 FROM source_origin WHERE tenant=? AND company=? AND id=?", (*who.scope, sid)
        ).fetchone():
            raise Rejected("REFERENCE_INVALID", path, "Source is not accessible")
        try:
            self._access(db, who, "source", sid)
        except Rejected:
            raise Rejected("REFERENCE_INVALID", path, "Source is not accessible") from None

    def _register_source(self, db, who, args):
        digest = hashlib.sha256(args["content_text"].encode("utf-8")).hexdigest()
        by_id = db.execute(
            "SELECT * FROM source_origin WHERE tenant=? AND company=? AND id=?",
            (*who.scope, args["id"]),
        ).fetchone()
        existing = None
        if args["source_kind"] == "email_text":
            existing = db.execute(
                "SELECT * FROM source_origin WHERE tenant=? AND company=? AND provider=? AND account_ref=? AND message_id=?",
                (
                    *who.scope,
                    args["provider"],
                    args["account_ref"],
                    args["external_message_id"],
                ),
            ).fetchone()
        for accessible_origin in (by_id, existing):
            if accessible_origin:
                self._access(db, who, "source", accessible_origin["id"])
        if by_id and existing and by_id["id"] != existing["id"]:
            raise Rejected("SOURCE_IDENTITY_CONFLICT", "/args/id")
        existing = existing or by_id
        if existing:
            content = self._load(db, who, "source_content", existing["content_id"])
            identity = tuple(
                existing[k]
                for k in (
                    "kind",
                    "provider",
                    "account_ref",
                    "message_id",
                    "author_claim",
                )
            )
            incoming = (
                args["source_kind"],
                args.get("provider"),
                args.get("account_ref"),
                args.get("external_message_id"),
                args.get("author_claim"),
            )
            if content["sha256"] != digest or identity != incoming:
                raise Rejected("SOURCE_IDENTITY_CONFLICT", "/args/id")
            origin_id = existing["id"]
        else:
            content = db.execute(
                "SELECT id FROM source_content WHERE tenant=? AND company=? AND sha256=?",
                (*who.scope, digest),
            ).fetchone()
            content_id = content["id"] if content else uuid.uuid4().hex
            if not content:
                db.execute(
                    "INSERT INTO source_content VALUES(?,?,?,?,?)",
                    (*who.scope, content_id, digest, args["content_text"]),
                )
            origin_id = args["id"]
            db.execute(
                "INSERT INTO source_origin VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    *who.scope,
                    origin_id,
                    content_id,
                    args["source_kind"],
                    args.get("provider"),
                    args.get("account_ref"),
                    args.get("external_message_id"),
                    args.get("author_claim"),
                ),
            )
        db.execute(
            "INSERT INTO source_import VALUES(?,?,?,?,?,?)",
            (*who.scope, uuid.uuid4().hex, origin_id, who.actor, now()),
        )
        if existing:
            self._access(db, who, "source", origin_id)
        self._claim(db, who, "source", origin_id)
        return {"object_id": origin_id, "row_version": 1, "status": "registered"}

    def _save_master(self, db, who, args):
        current = db.execute(
            "SELECT * FROM master WHERE tenant=? AND company=? AND id=?",
            (*who.scope, args["id"]),
        ).fetchone()
        if current:
            self._access(db, who, "master", args["id"])
            self._version(current, args["expected_version"])
            self._state(current, ["draft"])
            if args["kind"] != current["kind"]:
                raise Rejected("INVALID_STATE", "/args/kind")
        elif args["expected_version"] != 0:
            raise Rejected("NOT_FOUND", "/args/id")
        if args.get("parent_customer_id"):
            if args["kind"] != "contact":
                raise Rejected("INVALID_KNOWN_VALUE", "/args/parent_customer_id")
            self._master_ref(
                db,
                who,
                args["parent_customer_id"],
                "customer",
                "/args/parent_customer_id",
            )
        if args.get("base_uom") and args["kind"] != "sku":
            raise Rejected("INVALID_KNOWN_VALUE", "/args/base_uom")
        version = args["expected_version"] + 1
        db.execute(
            "INSERT INTO master VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant,company,id) DO UPDATE SET "
            "name=excluded.name,parent_customer_id=excluded.parent_customer_id,base_uom=excluded.base_uom,row_version=excluded.row_version",
            (
                *who.scope,
                args["id"],
                args["kind"],
                args.get("name"),
                args.get("parent_customer_id"),
                args.get("base_uom"),
                "draft",
                version,
            ),
        )
        self._claim(db, who, "master", args["id"])
        return {"object_id": args["id"], "row_version": version, "status": "draft"}

    def _confirm_master(self, db, who, record):
        if not record["name"] or not record["name"].strip():
            raise Rejected("DRAFT_NOT_READY", "/args/name")
        if record["kind"] == "contact":
            if not record["parent_customer_id"]:
                raise Rejected("DRAFT_NOT_READY", "/args/parent_customer_id")
            self._master_ref(
                db,
                who,
                record["parent_customer_id"],
                "customer",
                "/args/parent_customer_id",
                True,
            )
        if record["kind"] == "sku" and record["base_uom"] != "PCS":
            raise Rejected("DRAFT_NOT_READY", "/args/base_uom")

    def _save_rfq(self, db, who, args):
        current = db.execute(
            "SELECT * FROM rfq WHERE tenant=? AND company=? AND id=?",
            (*who.scope, args["id"]),
        ).fetchone()
        if current:
            self._access(db, who, "rfq", args["id"])
            self._version(current, args["expected_version"])
            self._state(current, ["draft"])
        elif args["expected_version"] != 0:
            raise Rejected("NOT_FOUND", "/args/id")
        lines = args.get("lines", [])
        if len({line["line_id"] for line in lines}) != len(lines):
            raise Rejected("DUPLICATE_LINE_ID", "/args/lines")
        for i, line in enumerate(lines):
            if "quantity" in line and Decimal(line["quantity"]) <= 0:
                raise Rejected("INVALID_KNOWN_VALUE", f"/args/lines/{i}/quantity")
        customer, contact = args.get("customer_id"), args.get("contact_id")
        if customer:
            self._master_ref(db, who, customer, "customer", "/args/customer_id")
        if contact:
            c = self._master_ref(db, who, contact, "contact", "/args/contact_id")
            if customer and c["parent_customer_id"] != customer:
                raise Rejected("REFERENCE_INVALID", "/args/contact_id")
        self._sources(db, who, args.get("source_ids", []), "/args/source_ids")
        for i, line in enumerate(lines):
            if "sku_id" in line:
                self._master_ref(db, who, line["sku_id"], "sku", f"/args/lines/{i}/sku_id")
            if "source_id" in line:
                self._source_ref(db, who, line["source_id"], f"/args/lines/{i}/source_id")
        version = args["expected_version"] + 1
        db.execute(
            "INSERT INTO rfq VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(tenant,company,id) DO UPDATE SET "
            "customer_id=excluded.customer_id,contact_id=excluded.contact_id,row_version=excluded.row_version,unresolved_json=excluded.unresolved_json",
            (
                *who.scope,
                args["id"],
                customer,
                contact,
                "draft",
                version,
                canonical(args.get("unresolved_fields", [])),
            ),
        )
        db.execute(
            "DELETE FROM rfq_line WHERE tenant=? AND company=? AND rfq_id=?",
            (*who.scope, args["id"]),
        )
        db.execute(
            "DELETE FROM source_use WHERE tenant=? AND company=? AND rfq_id=?",
            (*who.scope, args["id"]),
        )
        uses = set(args.get("source_ids", []))
        for line in lines:
            db.execute(
                "INSERT INTO rfq_line VALUES(?,?,?,?,?,?,?,?,?,?)",
                (
                    *who.scope,
                    args["id"],
                    line["line_id"],
                    line.get("sku_id"),
                    line.get("quantity"),
                    line.get("uom"),
                    line.get("requested_item"),
                    line.get("source_id"),
                    line.get("locator"),
                ),
            )
            if line.get("source_id"):
                uses.add(line["source_id"])
        for sid in uses:
            db.execute("INSERT INTO source_use VALUES(?,?,?,?)", (*who.scope, args["id"], sid))
        self._claim(db, who, "rfq", args["id"])
        return {"object_id": args["id"], "row_version": version, "status": "draft"}

    def _confirm_rfq(self, db, who, record, evidence):
        if not record["customer_id"] or not record["contact_id"]:
            raise Rejected("DRAFT_NOT_READY", "/args/customer_id", "Customer and contact required")
        self._master_ref(db, who, record["customer_id"], "customer", "/args/customer_id", True)
        contact = self._master_ref(
            db, who, record["contact_id"], "contact", "/args/contact_id", True
        )
        if contact["parent_customer_id"] != record["customer_id"]:
            raise Rejected("REFERENCE_INVALID", "/args/contact_id")
        if json.loads(record["unresolved_json"]):
            raise Rejected("DRAFT_NOT_READY", "/args/unresolved_fields")
        lines = db.execute(
            "SELECT * FROM rfq_line WHERE tenant=? AND company=? AND rfq_id=? ORDER BY line_id",
            (*who.scope, record["id"]),
        ).fetchall()
        if not lines:
            raise Rejected("DRAFT_NOT_READY", "/args/lines")
        for i, line in enumerate(lines):
            for field in ("sku_id", "quantity", "uom", "source_id", "locator"):
                if not line[field] or not str(line[field]).strip():
                    raise Rejected("DRAFT_NOT_READY", f"/args/lines/{i}/{field}")
            self._master_ref(db, who, line["sku_id"], "sku", f"/args/lines/{i}/sku_id", True)
        referenced = {
            row[0]
            for row in db.execute(
                "SELECT source_id FROM source_use WHERE tenant=? AND company=? AND rfq_id=?",
                (*who.scope, record["id"]),
            )
        }
        if not referenced.issubset(set(evidence)):
            raise Rejected(
                "DRAFT_NOT_READY",
                "/args/evidence_ids",
                "Human confirmation must cover all referenced sources",
            )

    def get(self, who: Principal, kind: str, object_id: str) -> dict:
        correlation = uuid.uuid4().hex
        try:
            return self._get(who, kind, object_id, correlation)
        except Rejected as exc:
            with self._connection() as db:
                self._audit(db, who, "get", object_id, "rejected", exc.code, correlation)
            raise

    def _get(self, who: Principal, kind: str, object_id: str, correlation: str) -> dict:
        if kind not in ("master", "rfq", "source"):
            raise Rejected("NOT_FOUND")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            self._authorize(db, who, "read")
            record = self._load(db, who, "source_origin" if kind == "source" else kind, object_id)
            if kind == "rfq":
                record["unresolved_fields"] = json.loads(record.pop("unresolved_json"))
                record["lines"] = [
                    dict(row)
                    for row in db.execute(
                        "SELECT * FROM rfq_line WHERE tenant=? AND company=? AND rfq_id=? ORDER BY line_id",
                        (*who.scope, object_id),
                    )
                ]
                record["source_ids"] = [
                    row[0]
                    for row in db.execute(
                        "SELECT source_id FROM source_use WHERE tenant=? AND company=? AND rfq_id=? ORDER BY source_id",
                        (*who.scope, object_id),
                    )
                ]
            elif kind == "source":
                record["content"] = self._load(db, who, "source_content", record["content_id"])
                record["imports"] = [
                    dict(row)
                    for row in db.execute(
                        "SELECT * FROM source_import WHERE tenant=? AND company=? AND origin_id=? ORDER BY imported_at,id",
                        (*who.scope, object_id),
                    )
                ]
            self._audit(db, who, "get", object_id, "read", None, correlation)
            db.commit()
            return record

    def audit(self, who: Principal) -> list[dict]:
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            self._authorize(db, who, "audit.read")
            records = [
                dict(row)
                for row in db.execute(
                    "SELECT * FROM audit_event WHERE tenant=? AND company=? ORDER BY seq", who.scope
                )
            ]
            db.commit()
            return records

    def costing_get(self, who: Principal, kind: str, object_id: str, revision=None) -> dict:
        from .costing import get

        return get(self, who, kind, object_id, revision)

    def costing_snapshot_in_transaction(
        self, db: sqlite3.Connection, who: Principal, snapshot_id: str
    ) -> dict:
        """Trusted backend boundary; caller owns transaction and action audit."""
        from .costing import snapshot_in_transaction

        return snapshot_in_transaction(self, db, who, snapshot_id)

    def costing_execute_json(self, who: Principal, raw: str | bytes) -> dict:
        from .costing import execute_json

        return execute_json(self, who, raw)

    def attest_costing_source(self, who: Principal, source_id: str, reason: str) -> str:
        """Authorized local human attestation, separate from registering raw text."""
        from .costing import attest_source

        return attest_source(self, who, source_id, reason)

    def configure_costing(self, who: Principal, policy_ref: dict) -> None:
        """Trusted local administration; never infer a verification policy."""
        from .costing import configure

        configure(self, who, policy_ref)

    def foundation_get(
        self, who: Principal, kind: str, object_id: str, revision: int | None = None
    ) -> dict:
        correlation = uuid.uuid4().hex
        try:
            with self._connection() as db:
                db.execute("BEGIN IMMEDIATE")
                output = foundation.get(self, db, who, kind, object_id, revision)
                self._audit(db, who, "foundation.get", object_id, "read", None, correlation)
                db.commit()
                return output
        except Rejected as exc:
            with self._connection() as db:
                self._audit(db, who, "foundation.get", object_id, "rejected", exc.code, correlation)
            raise
