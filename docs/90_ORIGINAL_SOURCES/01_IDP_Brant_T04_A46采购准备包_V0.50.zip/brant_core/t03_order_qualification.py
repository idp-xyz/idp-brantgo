"""Current, local source checks for a new order activation, never replay tokens."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from . import foundation, t03_storage
from .common import Principal, Rejected, canonical

CONTRACT = "brant.order-source-qualification/0.1.0"
FOUNDATION_KINDS = {
    "company", "currency", "pricing_policy", "payment_terms", "trade_terms",
    "trade_scope", "location", "sku_profile", "unit", "calendar", "fx",
    "sequence", "party_profile", "conversion",
}


def _instant(value: Any) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            raise ValueError("Timezone required")
        return parsed.astimezone(UTC)
    except (AttributeError, TypeError, ValueError, OverflowError):
        raise Rejected("REFERENCE_INVALID") from None


def _time_bounds(core, payload: dict, approval) -> datetime:
    instant = core.clock().astimezone(UTC)
    quote_expires = _instant(payload["expires_at"])
    approval_expires = _instant(approval["expires_at"])
    if instant >= quote_expires:
        raise Rejected("QUOTE_EXPIRED")
    if instant >= approval_expires:
        raise Rejected("APPROVAL_STALE")
    if approval_expires > quote_expires:
        raise Rejected("REFERENCE_INVALID")
    return instant


def qualify(core, db, who: Principal, order: Any, approval_id: str) -> dict[str, Any]:
    """Run on the order writer connection, without committing or repricing.

    This bounded gate covers persisted formalization identity, revocation
    evidence, current reviewer authority, cost adoption and supported current
    configuration bindings. It is not complete T04 or production admission.
    """
    if not db.in_transaction:
        raise RuntimeError("Order qualification requires the caller transaction")
    scope = who.scope
    quote_id, revision_number = order["source_quote_id"], order["source_quote_revision"]
    root = t03_storage.quote_row(db, scope, quote_id)
    if root["status"] != "active" or root["active_revision"] != revision_number:
        raise Rejected("QUOTE_NOT_CURRENT")
    revision = db.execute(
        "SELECT * FROM t03_quote_revision WHERE tenant=? AND company=? AND quote_id=? "
        "AND business_revision=?", (*scope, quote_id, revision_number),
    ).fetchone()
    if revision is None or revision["status"] != "active" or revision["business_hash"] != order["source_quote_hash"]:
        raise Rejected("QUOTE_NOT_CURRENT")
    payload = json.loads(revision["data_json"])
    calculation = json.loads(revision["calculation_json"]) if revision["calculation_json"] else None
    if "lines" in payload and calculation is None:
        raise Rejected("REFERENCE_INVALID")
    commits = db.execute(
        "SELECT * FROM t03_commit_evidence WHERE tenant=? AND company=? AND quote_id=? "
        "AND business_revision=?", (*scope, quote_id, revision_number),
    ).fetchall()
    if len(commits) != 1 or commits[0]["business_hash"] != order["source_quote_hash"]:
        raise Rejected("REFERENCE_INVALID")
    commit = commits[0]
    if commit["approval_id"] != approval_id:
        raise Rejected("APPROVAL_REQUIRED")
    approval = db.execute(
        "SELECT * FROM t03_approval WHERE tenant=? AND company=? AND approval_id=?",
        (*scope, approval_id),
    ).fetchone()
    if (
        approval is None or approval["quote_id"] != quote_id
        or approval["business_revision"] != revision_number
        or approval["business_hash"] != order["source_quote_hash"]
        or approval["command"] not in ("quote.activate", "quote.replace")
        or approval["decision"] != "approved"
    ):
        raise Rejected("APPROVAL_REQUIRED")
    # Immutable revocation evidence is also a durable hold on this exact
    # formalized revision. An arbitrary replacement approval cannot clear it.
    revoked = db.execute(
        "SELECT 1 FROM t03_approval_event WHERE tenant=? AND company=? AND approval_id=? "
        "AND event_type='revoked' LIMIT 1", (*scope, approval_id),
    ).fetchone()
    if approval["effectivity"] != "valid" or revoked is not None:
        raise Rejected("APPROVAL_REVOKED")
    review = db.execute(
        "SELECT * FROM t03_review_request WHERE tenant=? AND company=? AND review_request_id=?",
        (*scope, approval["review_request_id"]),
    ).fetchone()
    if (
        review is None or review["status"] != "approved"
        or review["quote_id"] != quote_id or review["business_revision"] != revision_number
        or review["business_hash"] != order["source_quote_hash"]
        or review["target_command"] != approval["command"]
    ):
        raise Rejected("APPROVAL_REQUIRED")
    _time_bounds(core, payload, approval)
    reviewer = t03_storage.current_reviewer(core, db, scope, quote_id, approval, revision)

    binding = db.execute(
        "SELECT * FROM t03_document_binding WHERE tenant=? AND company=? AND quote_id=? "
        "AND business_revision=?", (*scope, quote_id, revision_number),
    ).fetchone()
    if binding is None or binding["business_hash"] != order["source_quote_hash"]:
        raise Rejected("FILE_INVALID")
    number = db.execute(
        "SELECT * FROM document_number WHERE tenant=? AND company=? AND id=?",
        (*scope, binding["number_id"]),
    ).fetchone()
    file = db.execute(
        "SELECT * FROM business_file WHERE tenant=? AND company=? AND id=?",
        (*scope, binding["file_id"]),
    ).fetchone()
    if (
        number is None or file is None or number["number"] != binding["number"]
        or number["business_ref"] != f"{quote_id}:{revision_number}" or number["document_type"] != "quote"
        or file["number_id"] != binding["number_id"] or file["mime_type"] != binding["mime_type"]
        or file["content_hash"] != binding["file_sha256"]
        or not isinstance(file["content"], bytes)
        or len(file["content"]) != binding["byte_size"]
        or hashlib.sha256(file["content"]).hexdigest() != binding["file_sha256"]
    ):
        raise Rejected("FILE_INVALID")
    try:
        committed = json.loads(commit["result_json"])
        if committed["file_sha256"] != binding["file_sha256"] or committed["number"] != binding["number"]:
            raise Rejected("REFERENCE_INVALID")
    except (KeyError, TypeError, ValueError):
        raise Rejected("REFERENCE_INVALID") from None

    qualification = t03_storage._cost_qualification(core, db, who, payload, calculation)
    if qualification is None:
        raise Rejected("COST_SNAPSHOT_MISSING")
    if commit["cost_snapshot_id"] != qualification["snapshot_id"]:
        raise Rejected("REFERENCE_INVALID")
    current_foundation = []
    resolved = {}
    for ref in sorted(foundation.refs(payload), key=canonical):
        if ref["kind"] not in FOUNDATION_KINDS:
            continue
        key = canonical(ref)
        if key in resolved:
            continue
        # The T02 extension projection owns the legacy location/trade-scope
        # references; A27 validates their exact bindings and current sources.
        scoped = qualification.get("scope_binding", {}).get("configuration_bindings", [])
        if ref["kind"] in {"location", "trade_scope"} and any(
            item["ref"] == ref for item in scoped
        ) and db.execute(
            "SELECT 1 FROM foundation_root WHERE tenant=? AND company=? AND kind=? AND id=?",
            (*scope, ref["kind"], ref["id"]),
        ).fetchone() is None:
            current_foundation.append(next(item for item in scoped if item["ref"] == ref))
            continue
        t03_storage.guard(db, who, ref["kind"], ref["id"])
        data = foundation.active(core, db, who, ref, purpose="quotation" if ref["kind"] == "fx" else None)
        resolved[key] = data
        current_foundation.append({"ref": ref, "data_hash": foundation.digest(data)})
    policy_ref = payload.get("pricing_policy_ref")
    if not isinstance(policy_ref, dict) or canonical(policy_ref) not in resolved:
        raise Rejected("REFERENCE_INVALID")
    policy = resolved[canonical(policy_ref)]
    fx_ref = payload.get("sales_fx_ref")
    fx_deadline = None
    if fx_ref is not None:
        if not isinstance(fx_ref, dict) or canonical(fx_ref) not in resolved:
            raise Rejected("REFERENCE_INVALID")
        try:
            fx = resolved[canonical(fx_ref)]
            max_age = int(policy["max_fx_age_seconds"])
            age = (core.clock().astimezone(UTC) - _instant(fx["observed_at"])).total_seconds()
            if max_age < 0 or age > max_age or Decimal(str(fx["rate"])) <= 0:
                raise Rejected("FX_STALE")
            fx_deadline = (_instant(fx["observed_at"]), max_age)
        except (KeyError, TypeError, ValueError, ArithmeticError):
            raise Rejected("REFERENCE_INVALID") from None
    records = t03_storage._formalization_configurations(core, db, who, payload, calculation)
    checked_at = _time_bounds(core, payload, approval)
    if fx_deadline is not None and (checked_at - fx_deadline[0]).total_seconds() > fx_deadline[1]:
        raise Rejected("FX_STALE")
    control = t03_storage.control_row(db, scope, "quote_root", quote_id)
    return {
        "contract": CONTRACT,
        "checked_at": checked_at.isoformat().replace("+00:00", "Z"),
        "source_quote_id": quote_id,
        "source_quote_revision": revision_number,
        "source_quote_hash": order["source_quote_hash"],
        "formalization_commit_id": commit["commit_id"],
        "document_id": binding["document_id"],
        "file_sha256": binding["file_sha256"],
        "approval_id": approval_id,
        "approval_effectivity_version": approval["effectivity_version"],
        "reviewer": reviewer.actor,
        "approval_revocation_hold": False,
        "authority_epoch": t03_storage.authority_epoch(db, scope),
        "control_epoch": control["control_epoch"] if control is not None else None,
        "cost_qualification": qualification,
        "foundation_bindings": current_foundation,
        "configuration_bindings": [
            {"role": role, **{key: value[key] for key in (
                "ref", "data_hash", "record_hash", "publication_hash"
            )}}
            for role, value in sorted(records.items())
        ],
    }
