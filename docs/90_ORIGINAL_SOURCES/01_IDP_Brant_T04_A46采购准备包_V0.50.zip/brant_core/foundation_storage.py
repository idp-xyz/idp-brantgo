"""Additive, transactional migration from the BC-T01 local store."""

import sqlite3


def migrate(db: sqlite3.Connection) -> None:
    db.execute("BEGIN IMMEDIATE")
    try:
        versions = [
            r[0] for r in db.execute("SELECT version FROM schema_migration ORDER BY version")
        ]
        if versions in (
            [1, 2],
            [1, 2, 3],
            [1, 2, 3, 4],
            [1, 2, 3, 4, 5],
            [1, 2, 3, 4, 5, 6],
            [1, 2, 3, 4, 5, 6, 7],
            [1, 2, 3, 4, 5, 6, 7, 8],
            [1, 2, 3, 4, 5, 6, 7, 8, 9],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
        ):
            db.commit()
            return
        if versions != [1]:
            raise RuntimeError("Unsupported foundation migration history")
        ddl = [
            """CREATE TABLE actor_access(tenant TEXT NOT NULL,company TEXT NOT NULL,actor TEXT NOT NULL,
                team_id TEXT,data_scope TEXT NOT NULL CHECK(data_scope IN ('own','team','company')),
                PRIMARY KEY(tenant,company,actor),FOREIGN KEY(tenant,company,actor) REFERENCES authorization)""",
            """CREATE TABLE record_access(tenant TEXT NOT NULL,company TEXT NOT NULL,kind TEXT NOT NULL,
                object_id TEXT NOT NULL,owner_id TEXT NOT NULL,team_id TEXT,
                PRIMARY KEY(tenant,company,kind,object_id),FOREIGN KEY(tenant,company) REFERENCES scope)""",
            """CREATE TABLE foundation_root(tenant TEXT NOT NULL,company TEXT NOT NULL,kind TEXT NOT NULL,
                id TEXT NOT NULL,row_version INTEGER NOT NULL,last_revision INTEGER NOT NULL,
                active_revision INTEGER,PRIMARY KEY(tenant,company,kind,id),FOREIGN KEY(tenant,company) REFERENCES scope)""",
            """CREATE TABLE foundation_revision(tenant TEXT NOT NULL,company TEXT NOT NULL,kind TEXT NOT NULL,
                id TEXT NOT NULL,revision INTEGER NOT NULL,data_json TEXT NOT NULL CHECK(json_valid(data_json)),
                content_hash TEXT NOT NULL,evidence_json TEXT NOT NULL CHECK(json_valid(evidence_json)),
                created_by TEXT NOT NULL,created_at TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('draft','active','superseded','retired')),
                reviewed_by TEXT,reviewed_at TEXT,PRIMARY KEY(tenant,company,kind,id,revision),
                FOREIGN KEY(tenant,company,kind,id) REFERENCES foundation_root)""",
            """CREATE TABLE foundation_snapshot(tenant TEXT NOT NULL,company TEXT NOT NULL,id TEXT NOT NULL,
                data_json TEXT NOT NULL,content_hash TEXT NOT NULL,created_at TEXT NOT NULL,
                PRIMARY KEY(tenant,company,id),FOREIGN KEY(tenant,company) REFERENCES scope)""",
            """CREATE TABLE master_history(tenant TEXT NOT NULL,company TEXT NOT NULL,id TEXT NOT NULL,
                row_version INTEGER NOT NULL,data_json TEXT NOT NULL,created_at TEXT NOT NULL,
                PRIMARY KEY(tenant,company,id,row_version),FOREIGN KEY(tenant,company,id) REFERENCES master)""",
            """CREATE TABLE document_counter(tenant TEXT NOT NULL,company TEXT NOT NULL,document_type TEXT NOT NULL,
                year INTEGER NOT NULL,last_value INTEGER NOT NULL,PRIMARY KEY(tenant,company,document_type,year),
                FOREIGN KEY(tenant,company) REFERENCES scope)""",
            """CREATE TABLE document_number(tenant TEXT NOT NULL,company TEXT NOT NULL,id TEXT NOT NULL,
                document_type TEXT NOT NULL,business_ref TEXT NOT NULL,number TEXT NOT NULL,sequence_id TEXT NOT NULL,
                sequence_revision INTEGER NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(tenant,company,id),
                UNIQUE(tenant,company,document_type,business_ref),UNIQUE(tenant,company,number),
                FOREIGN KEY(tenant,company) REFERENCES scope)""",
            """CREATE TABLE business_file(tenant TEXT NOT NULL,company TEXT NOT NULL,id TEXT NOT NULL,
                file_name TEXT NOT NULL,mime_type TEXT NOT NULL,content BLOB NOT NULL,
                content_hash TEXT NOT NULL,supersedes_file_id TEXT,template_id TEXT,template_revision INTEGER,
                number_id TEXT,created_at TEXT NOT NULL,PRIMARY KEY(tenant,company,id),
                FOREIGN KEY(tenant,company,supersedes_file_id) REFERENCES business_file(tenant,company,id),
                FOREIGN KEY(tenant,company,number_id) REFERENCES document_number(tenant,company,id),
                FOREIGN KEY(tenant,company) REFERENCES scope)""",
        ]
        for statement in ddl:
            db.execute(statement)
        # Legacy grants were company-scoped. Preserve them rather than silently narrowing/expanding.
        db.execute(
            "INSERT INTO actor_access SELECT tenant,company,actor,NULL,'company' FROM authorization"
        )
        for kind, table in [("master", "master"), ("rfq", "rfq"), ("source", "source_origin")]:
            for row in db.execute(f"SELECT tenant,company,id FROM {table}").fetchall():
                audit = db.execute(
                    "SELECT actor FROM audit_event WHERE tenant=? AND company=? AND object_id=? AND outcome='succeeded' AND command=? ORDER BY seq LIMIT 1",
                    (
                        *row,
                        {
                            "master": "master.upsert_draft",
                            "rfq": "rfq.save_draft",
                            "source": "source.register",
                        }[kind],
                    ),
                ).fetchone()
                if not audit:
                    raise RuntimeError(
                        "Legacy record has no verifiable creator audit; migration requires explicit repair"
                    )
                db.execute(
                    "INSERT INTO record_access VALUES(?,?,?,?,?,NULL)",
                    (row[0], row[1], kind, row[2], audit[0]),
                )
        db.execute("""CREATE TRIGGER immutable_foundation_payload BEFORE UPDATE ON foundation_revision
            WHEN NEW.data_json != OLD.data_json OR NEW.content_hash != OLD.content_hash
              OR NEW.evidence_json != OLD.evidence_json OR NEW.created_by != OLD.created_by
            BEGIN SELECT RAISE(ABORT,'immutable foundation revision'); END""")
        for table in ["foundation_snapshot", "master_history", "business_file", "document_number"]:
            for op in ["UPDATE", "DELETE"]:
                db.execute(
                    f"CREATE TRIGGER immutable_{table}_{op.lower()} BEFORE {op} ON {table} BEGIN SELECT RAISE(ABORT,'immutable history'); END"
                )
        db.execute("INSERT INTO schema_migration VALUES(2,strftime('%Y-%m-%dT%H:%M:%fZ','now'))")
        db.commit()
    except BaseException:
        db.rollback()
        raise
