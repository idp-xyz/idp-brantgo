"""Current issuer, customer address, contact, and account-term bindings."""

from __future__ import annotations

from typing import Any

from . import foundation, t03_storage
from .common import Rejected

CONTRACT = "brant.quote-trade-parties/0.1.0"
FOUNDATION_PARTY_ADDRESS_ROLES = frozenset(
    {"buyer", "seller", "payer", "payee", "consignee", "shipper", "billing"}
)
QUOTE_CUSTOMER_ADDRESS_ROLES = frozenset({"buyer", "billing"})


def bind(core, db, who, data: dict, calculation: dict | None = None) -> dict:
    """Resolve selected parties on the caller's write transaction."""
    if not db.in_transaction:
        raise RuntimeError("Trade-party bindings require the caller writer transaction")
    try:
        result = _bind(core, db, who, data)
    except (KeyError, TypeError, ValueError, AttributeError):
        raise Rejected("REFERENCE_INVALID") from None
    if calculation is not None and calculation.get("trade_party_binding") != result:
        raise Rejected("REFERENCE_INVALID")
    return result


def _bind(core, db, who, data: dict) -> dict:
    issuer = data.get("issuer_ref")
    if not isinstance(issuer, dict) or issuer != {
        "kind": "company", "id": who.company, "revision": issuer.get("revision")
    } or type(issuer.get("revision")) is not int or issuer["revision"] < 1:
        raise Rejected("REFERENCE_INVALID")
    t03_storage.guard(db, who, "company", issuer["id"])
    company = foundation.active(core, db, who, issuer)
    for key in ("legal_name", "registration_no", "country", "address"):
        value = company.get(key)
        if not isinstance(value, str) or not value.strip():
            raise Rejected("DRAFT_NOT_READY")

    customer_ref = data.get("customer_ref")
    contact_ref = data.get("contact_ref")
    if not isinstance(customer_ref, dict) or customer_ref.get("kind") != "customer":
        raise Rejected("REFERENCE_INVALID")
    if not isinstance(contact_ref, dict) or contact_ref.get("kind") != "contact":
        raise Rejected("REFERENCE_INVALID")
    customer = core._master_ref(db, who, customer_ref["id"], "customer", "/args/data/customer_ref", True)
    contact = core._master_ref(db, who, contact_ref["id"], "contact", "/args/data/contact_ref", True)
    if (
        customer_ref.get("row_version") != customer["row_version"]
        or contact_ref.get("row_version") != contact["row_version"]
        or contact.get("parent_customer_id") != customer["id"]
    ):
        raise Rejected("REFERENCE_STALE")

    profile_ref = data.get("customer_profile_ref")
    if not isinstance(profile_ref, dict) or set(profile_ref) != {"kind", "id", "revision"}:
        raise Rejected("DRAFT_NOT_READY")
    if (profile_ref.get("kind") != "party_profile"
        or not isinstance(profile_ref.get("id"), str)
        or not profile_ref["id"].strip()
        or type(profile_ref.get("revision")) is not int
        or profile_ref["revision"] < 1):
        raise Rejected("REFERENCE_INVALID")
    t03_storage.guard(db, who, "party_profile", profile_ref["id"])
    profile = foundation.active(core, db, who, profile_ref)
    for key in ("legal_name", "country"):
        if not isinstance(profile.get(key), str) or not profile[key].strip():
            raise Rejected("DRAFT_NOT_READY")
    if profile.get("party_id") != customer["id"] or profile.get("party_row_version") != customer["row_version"]:
        raise Rejected("REFERENCE_STALE")

    addresses = profile.get("addresses")
    address_id = data.get("customer_address_id")
    if not isinstance(addresses, list) or not isinstance(address_id, str) or not address_id:
        raise Rejected("DRAFT_NOT_READY")
    selected = [item for item in addresses if isinstance(item, dict) and item.get("address_id") == address_id]
    if len(selected) != 1:
        raise Rejected("REFERENCE_INVALID")
    address = selected[0]
    if address.get("role") not in QUOTE_CUSTOMER_ADDRESS_ROLES:
        raise Rejected("REFERENCE_INVALID")
    if not isinstance(address.get("address"), str) or not address["address"].strip():
        raise Rejected("DRAFT_NOT_READY")

    contacts = profile.get("contact_refs")
    direct_contact = isinstance(contacts, list) and any(
        isinstance(item, dict)
        and item.get("id") == contact["id"]
        and item.get("row_version") == contact["row_version"]
        for item in contacts
    )
    contact_profile_binding = None
    if not direct_contact:
        matches = []
        for ref in profile.get("contacts", []):
            contact_profile = foundation.active(core, db, who, ref)
            if (
                contact_profile.get("party_id") == customer["id"]
                and contact_profile.get("party_role") == "customer"
                and contact_profile.get("party_row_version") == customer["row_version"]
                and contact_profile.get("legacy_contact_ref")
                == {"id": contact["id"], "row_version": contact["row_version"]}
            ):
                matches.append((ref, contact_profile))
        if len(matches) != 1:
            raise Rejected("REFERENCE_INVALID")
        selected_ref, selected_profile = matches[0]
        t03_storage.guard(db, who, "contact_profile", selected_ref["id"])
        contact_profile_binding = {
            "profile_ref": selected_ref,
            "profile_hash": foundation.digest(selected_profile),
        }

    for profile_field, quote_field in (
        ("trade_terms", "trade_terms_ref"), ("payment_terms", "payment_terms_ref")
    ):
        if profile.get(profile_field) != data.get(quote_field):
            raise Rejected("COMPARISON_BASIS_MISMATCH")

    result: dict[str, Any] = {
        "contract": CONTRACT,
        "issuer": {
            "ref": issuer,
            "profile_hash": foundation.digest(company),
            **{key: company[key] for key in ("legal_name", "registration_no", "country", "address")},
        },
        "customer": {
            "ref": customer_ref,
            "profile_ref": profile_ref,
            "profile_hash": foundation.digest(profile),
            "legal_name": profile["legal_name"],
            "country": profile["country"],
            "address_id": address_id,
            "address_role": address["role"],
            "address": address["address"],
        },
        "contact": {
            "ref": contact_ref,
            "name": contact["name"],
            "parent_customer_id": contact["parent_customer_id"],
            **(contact_profile_binding or {}),
        },
        "trade_terms_ref": data["trade_terms_ref"],
        "payment_terms_ref": data["payment_terms_ref"],
    }
    result["binding_hash"] = foundation.digest(result)
    return result
