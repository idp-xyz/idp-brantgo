"""Registry-bound sequential costing reference. Not a persistent enterprise service."""

from copy import deepcopy
from typing import Any

from jsonschema import Draft202012Validator

from .assumption_rules import bind_assumptions
from .command_model import ROOT_TYPES, CommandModel
from .commercial_rules import (
    payment,
    payment_signature,
    tax_application,
    trade_scope,
    validate_config,
)
from .delivery_rules import resolve_delivery
from .normalization import VERSION as NORMALIZATION_VERSION
from .normalization import normalize
from .resource_budget import LIMITS, Budget, Fraction, admit
from .rules import (
    active_interval,
    bill,
    chargeable,
    check_output,
    fee_graph,
    fx_cost,
    purchase_groups,
    split_tax,
    verified_estimate_allowed,
)
from .strict_formats import FormatChecker
from .validator import REG, ROOT, SCHEMA, Invalid, V, allocate, canonical, digest, fail, minor
from .write_admission import HUMAN_ACTIONS, WriteAdmission


class IntegratedModel(WriteAdmission, CommandModel):
    FREEZE_BINDING_FIELDS = (
        "input_hash",
        "components",
        "excluded_components",
        "delivery_checks",
        "assumptions",
        "engine_version",
        "cost_basis",
        "excluded_cost_categories",
        "commercial_checks",
    )

    def __init__(self, registry=None):
        super().__init__()
        self.registry = deepcopy(REG if registry is None else registry)
        self.clock = self.registry["as_of"]
        self.complete_results = {}
        self.complete_snapshots = {}
        self.bindings = {}
        self.command_dependencies = {}
        self.actions = []

    def _history_access(self, actor, result):
        if not actor.get("readable", False):
            fail("PERMISSION_DENIED", "/")
        if actor.get("tenant") != self.registry["server_scope"].get("tenant") or actor.get(
            "company"
        ) != self.registry["server_scope"].get("company"):
            fail("NOT_FOUND", "/")
        self._read_row(self.scenarios.get(result["scenario_id"]))
        for entry in result["input_manifest"]:
            self._read_dependency(entry["kind"], entry["id"], entry["version"])

    def execute(self, actor, req):
        admit(req)
        if not V.is_valid(req):
            fail("SCHEMA_INVALID", "/")
        cmd = req["command"]
        if cmd not in actor["grants"] or not actor.get("readable", False):
            fail("PERMISSION_DENIED", "/")
        if actor.get("tenant") != self.registry["server_scope"].get("tenant") or actor.get(
            "company"
        ) != self.registry["server_scope"].get("company"):
            fail("NOT_FOUND", "/")
        if cmd.split(".")[1] in HUMAN_ACTIONS and actor["kind"] != "human":
            fail("PERMISSION_DENIED", "/")
        key = (actor["tenant"], actor["company"], cmd, req["idempotency_key"])
        before = deepcopy(self.__dict__)
        try:
            self._actor = actor
            if key in self.replays:
                if self.replays[key][0] != digest(req):
                    fail("IDEMPOTENCY_PAYLOAD_CONFLICT", "/")
                saved = self.replays[key][1]
                for entry in self.command_dependencies[key]:
                    self._read_dependency(entry["kind"], entry["id"], entry["version"])
                if "result" in saved:
                    self._history_access(actor, saved["result"])
                return super().execute(actor, req)
            self._write_manifest = {}
            self._budget = Budget()
            value = super().execute(actor, req)
            kind = cmd.split(".")[0]
            id_ = req["args"].get("id", req["args"].get("scenario_id"))
            scope = {
                "tenant": actor["tenant"],
                "company": actor["company"],
                "owner_id": actor["id"],
            }
            if actor.get("team_ids"):
                scope["team_id"] = actor["team_ids"][0]
            if (kind, id_) in self.roots:
                root = self.roots[kind, id_]
                if not hasattr(root, "access"):
                    root.access = {"scope": scope}
                if cmd.endswith((".verify", ".publish")):
                    record = root.revisions[root.active]
                    record.update(
                        verification_evidence=deepcopy(req["args"]["evidence"]),
                        verification_policy_ref=deepcopy(self._admission_policy_ref),
                        verified_by=actor["id"],
                        verified_at=self.clock,
                    )
            obj: Any = (
                self.rfqs.get(id_)
                if kind == "supplier_rfq"
                else self.measurements.get(id_)
                if kind == "measurement"
                else self.scenarios.get(id_)
                if kind == "cost_scenario"
                else None
            )
            if obj is not None:
                obj.setdefault("scope", scope)
            if kind == "measurement" and cmd.endswith((".record_verified", ".supersede")):
                obj.setdefault("verification", {})[obj["active"]] = {
                    "verified_by": actor["id"],
                    "verified_at": self.clock,
                    "verification_policy_ref": deepcopy(self._admission_policy_ref),
                    "evidence": deepcopy(req["args"]["data"]["evidence"]),
                }
            if kind == "source_denial":
                self.denials[id_].update(
                    recorded_by=actor["id"], recorded_at=self.clock, scope=scope
                )
            value["object_id"] = value["result"]["id"] if "result" in value else id_
            value["action_id"] = "action." + str(len(self.actions) + 1)
            self.replays[key] = (
                digest(req),
                deepcopy({k: v for k, v in value.items() if k != "replayed"}),
            )
            entries = list(self._write_manifest.values())
            entries.append(
                {
                    "kind": "target." + ("cost_scenario" if kind == "cost_snapshot" else kind),
                    "id": id_,
                    "version": value["version"],
                    "content_hash": digest({"id": id_, "version": value["version"]}),
                }
            )
            if "result" in value:
                entries += value["result"]["input_manifest"]
            dedup = {(e["kind"], e["id"], e["version"]): e for e in entries}
            self.command_dependencies[key] = list(dedup.values())
            self.actions.append(
                {
                    "command": cmd,
                    "object_id": id_,
                    "actor_id": actor["id"],
                    "occurred_at": self.clock,
                    "request_hash": digest(req),
                    "dependencies": deepcopy(self.command_dependencies[key]),
                }
            )
            return value
        except Exception:
            self.__dict__ = before
            raise
        finally:
            for field in ("_actor", "_write_manifest", "_budget", "_admission_policy_ref"):
                self.__dict__.pop(field, None)

    def _source(self, id_):
        if hasattr(self, "_budget"):
            self._budget.tick()
        row = next((x for x in self.registry["sources"] if x["id"] == id_), None)
        if row is None:
            fail("REFERENCE_INVALID", "/source")
        self._read_row(row)
        if row.get("denied") or any(x["source_id"] == id_ for x in self.denials.values()):
            fail("REFERENCE_STALE", "/source_denial")
        if row["status"] != "verified":
            fail("COST_INPUT_NOT_READY", "/source")
        return row

    def _remember(self, manifest, kind, id_, version, data, historical=False):
        if hasattr(self, "_budget"):
            self._budget.observe(kind, id_, version, data, historical)
        key = (kind, id_, version)
        manifest[key] = {"kind": kind, "id": id_, "version": version, "content_hash": digest(data)}

    def _cfg(self, ref, manifest, expected=None, trail=()):
        if hasattr(self, "_budget"):
            self._budget.tick()
        key = (ref["kind"], ref["id"], ref["revision"])
        if key in trail or len(trail) > 8:
            fail("REFERENCE_INVALID", "/config_dependency_cycle")
        if expected is not None and ref["kind"] != expected:
            fail("REFERENCE_INVALID", "/config_kind")
        rows = [
            x
            for x in self.registry["configs"]
            if x["ref"]["kind"] == ref["kind"] and x["ref"]["id"] == ref["id"]
        ]
        exact = next((x for x in rows if x["ref"]["revision"] == ref["revision"]), None)
        if exact is None:
            fail("REFERENCE_INVALID", "/config")
        self._read_row(exact)
        active = max((x["ref"]["revision"] for x in rows if x.get("active", True)), default=None)
        if not exact.get("active", True) or active != ref["revision"]:
            fail("REFERENCE_STALE", "/config")
        d = exact["data"]
        if ref["kind"] in (
            "trade_scope",
            "tax_application",
            "trade_terms",
            "payment_terms",
            "tax_profile",
            "calendar",
        ):
            validate_config(ref["kind"], d)
        if "valid_from" in d:
            active_interval(d, self.clock)
        for evidence in exact.get("publication_evidence", []):
            self._remember(
                manifest, "source", evidence["source_id"], 1, self._source(evidence["source_id"])
            )
        for dep in exact.get("reference_dependencies", []):
            self._cfg(dep, manifest, trail=trail + (key,))
        if "publication" in exact:
            self._remember(
                manifest,
                "foundation_publication." + ref["kind"],
                ref["id"],
                ref["revision"],
                {
                    k: exact[k]
                    for k in ("publication", "publication_evidence", "reference_dependencies")
                },
            )
        self._remember(manifest, ref["kind"], ref["id"], ref["revision"], d)
        return d

    def _business(self, ref, manifest, expected, check_effect=True):
        if hasattr(self, "_budget"):
            self._budget.tick()
        if ref["kind"] != expected:
            fail("REFERENCE_INVALID", "/business_kind")
        if expected == "delivery_anchor":
            self._anchor_capability(ref["id"])
        root = self.roots.get((expected, ref["id"]))
        if root is not None:
            self._read_row(getattr(root, "access", {}))
            if check_effect and root.active != ref["revision"]:
                fail("REFERENCE_STALE", "/business_revision")
            if ref["revision"] not in root.revisions:
                fail("REFERENCE_INVALID", "/business_revision")
            if not root.revisions[ref["revision"]]["sealed"]:
                fail("REFERENCE_INVALID", "/unverified_business_revision")
            record = root.revisions[ref["revision"]]
            d = record["data"]
            for e in record.get("verification_evidence", []):
                self._remember(manifest, "source", e["source_id"], 1, self._source(e["source_id"]))
            if "verified_by" in record:
                self._remember(
                    manifest,
                    "business_verification." + expected,
                    ref["id"],
                    ref["revision"],
                    {
                        k: record[k]
                        for k in (
                            "contributors",
                            "verification_evidence",
                            "verification_policy_ref",
                            "verified_by",
                            "verified_at",
                        )
                    },
                )
                self._access_document(record["verification_policy_ref"], manifest, historical=True)
        elif expected == "measurement" and ref["id"] in self.measurements:
            model = self.measurements[ref["id"]]
            self._read_row(model)
            if ref["revision"] not in model["revisions"]:
                fail("REFERENCE_INVALID", "/measurement_revision")
            if check_effect and model["active"] != ref["revision"]:
                fail("REFERENCE_STALE", "/measurement_revision")
            d = model["revisions"][ref["revision"]]
            if ref["revision"] in model.get("verification", {}):
                record = model["verification"][ref["revision"]]
                self._remember(
                    manifest,
                    "business_verification.measurement",
                    ref["id"],
                    ref["revision"],
                    record,
                )
                self._access_document(record["verification_policy_ref"], manifest, historical=True)
        else:
            rows = [
                x
                for x in self.registry["verified_business"]
                if x["ref"]["kind"] == expected and x["ref"]["id"] == ref["id"]
            ]
            row = next((x for x in rows if x["ref"]["revision"] == ref["revision"]), None)
            if row is None:
                fail("REFERENCE_INVALID", "/business")
            self._read_row(row)
            if check_effect and (
                not row.get("active", True)
                or max((x["ref"]["revision"] for x in rows if x.get("active", True)), default=None)
                != ref["revision"]
            ):
                fail("REFERENCE_STALE", "/business_revision")
            d = row["data"]
            if expected == "delivery_anchor":
                for evidence in row.get("origin_evidence", []):
                    self._remember(
                        manifest,
                        "source",
                        evidence["source_id"],
                        1,
                        self._source(evidence["source_id"]),
                    )
                for dependency in row.get("reference_dependencies", []):
                    self._access_document(dependency, manifest, historical=True)
                # Event provenance retains historical commercial versions, but
                # every source actually used by that provenance must still be
                # trustworthy for a new calculation/adoption.
                for entry in list(manifest.values()):
                    if entry["kind"] == "source":
                        self._source(entry["id"])
                if "projection" in row:
                    self._remember(
                        manifest,
                        "business_verification.delivery_anchor",
                        ref["id"],
                        ref["revision"],
                        row["projection"],
                    )
        definition = ROOT_TYPES.get(expected, "measurement" if expected == "measurement" else None)
        shape = (
            {"$defs": SCHEMA["$defs"], "$ref": "#/$defs/" + definition}
            if definition
            else __import__("json").loads(
                (ROOT / "contracts/delivery-anchor.data.schema.json").read_text()
            )
            if expected == "delivery_anchor"
            else None
        )
        if shape is not None and not Draft202012Validator(
            shape, format_checker=FormatChecker()
        ).is_valid(d):
            fail("COST_INPUT_NOT_READY", "/business/data")
        if check_effect and "interval" in d:
            active_interval(d["interval"], self.clock)
        self._remember(
            manifest, expected, ref["id"], ref["revision"], d, historical=not check_effect
        )
        for e in d.get("evidence", []):
            self._remember(manifest, "source", e["source_id"], 1, self._source(e["source_id"]))
        return d

    def _master(self, ref, manifest, expected):
        if hasattr(self, "_budget"):
            self._budget.tick()
        if ref["kind"] != expected or ref not in self.registry["masters"]:
            fail("REFERENCE_INVALID", "/master")
        metadata: dict[str, Any] = next(
            (x for x in self.registry.get("master_metadata", []) if x["ref"] == ref), {}
        )
        self._read_row(metadata)
        if not metadata.get("confirmed", False):
            fail("REFERENCE_STALE", "/master")
        if ref["row_version"] != max(
            x["row_version"]
            for x in self.registry["masters"]
            if x["kind"] == ref["kind"] and x["id"] == ref["id"]
        ):
            fail("REFERENCE_STALE", "/master")
        self._remember(manifest, "master." + expected, ref["id"], ref["row_version"], ref)

    def _cost(self, scenario_id, result_id):
        scenario = self.scenarios[scenario_id]
        data = scenario["data"]
        manifest: dict[Any, Any] = {}
        self._budget = Budget()
        self._budget.observe("cost_scenario", scenario_id, scenario["version"], data)
        if (
            len(
                {
                    (a["source"]["kind"], a["source"]["id"], a["source"]["revision"])
                    for a in data["allocations"]
                }
            )
            > LIMITS["candidate_sources"]
        ):
            fail("CALCULATION_LIMIT_EXCEEDED", "/candidate_sources")
        context = self._business(data["context_ref"], manifest, "costing_context")
        differences = []
        delivery_checks = []
        commercial_checks = []
        provisional = context["context_kind"] == "what_if"
        comparable = True

        def resolve(ref, kind):
            return self._cfg(ref, manifest, kind)

        def commercial(path, category, status, reason, refs):
            commercial_checks.append(
                {
                    "path": path,
                    "category": category,
                    "status": status,
                    "reason": reason,
                    "refs": deepcopy(refs),
                }
            )

        def mismatch(path, category, reason, refs):
            nonlocal comparable
            comparable = False
            differences.append({"path": path, "reason": reason})
            commercial(path, category, "mismatch", reason, refs)

        documents = {
            "context": context,
            "scenario": data,
            "supplier_offer": {},
            "purchase_terms": {},
            "logistics_offer": {},
        }
        rfq = self._rfq(context["rfq_ref"], manifest)
        a = sorted(context["lines"], key=lambda x: x["line_id"])
        b = sorted(rfq["lines"], key=lambda x: x["line_id"])
        if canonical(a) != canonical(b):
            if context["context_kind"] == "actual":
                fail("COMPARISON_BASIS_MISMATCH", "/context_lines")
            if [x["line_id"] for x in a] != [x["line_id"] for x in b] or any(
                x["sku_profile_ref"] != y["sku_profile_ref"] or x["unit_ref"] != y["unit_ref"]
                for x, y in zip(a, b)
            ):
                fail("COMPARISON_BASIS_MISMATCH", "/what_if_line_identity")
            comparable = False
            differences.append(
                {
                    "path": "/context/lines",
                    "reason": "What-if quantities differ from the original customer RFQ; not eligible for its formal quote",
                }
            )
        self._remember(manifest, "rfq", rfq["id"], rfq["row_version"], rfq)
        currency = self._cfg(context["calculation_currency_ref"], manifest, "currency")
        precision = currency["minor_units"]
        target = currency["code"]
        policy = self._cfg(context["pricing_policy_ref"], manifest, "pricing_policy")
        if "requested_currency_ref" in context:
            self._cfg(context["requested_currency_ref"], manifest, "currency")
        commercial_basis = context["comparison_basis"]
        sale = trade_scope(commercial_basis["sales_trade_scope_ref"], "export_sale", resolve)
        sale_payment = payment(commercial_basis["sales_payment_terms_ref"], resolve)
        commercial(
            "/context/comparison_basis/sales_payment_terms_ref",
            "payment_terms",
            "matched",
            "Customer receipts and supplier payments are separate obligations; nominal direct cost excludes imputed financing, expected credit loss and unrealized hedging",
            [commercial_basis["sales_payment_terms_ref"]],
        )
        if sale["named_place_ref"] != commercial_basis["named_place_ref"]:
            mismatch(
                "/context/comparison_basis/sales_trade_scope_ref",
                "trade_terms",
                "Reviewed sales scope and comparison location differ",
                [commercial_basis["sales_trade_scope_ref"]],
            )
        for field, actual, kind in [
            ("requested_trade_terms_ref", sale["trade_terms_ref"], "trade_terms"),
            (
                "requested_payment_terms_ref",
                commercial_basis["sales_payment_terms_ref"],
                "payment_terms",
            ),
        ]:
            if field in context:
                resolve(context[field], kind)
                if context[field] != actual:
                    mismatch(
                        "/context/" + field,
                        kind,
                        "Customer requirement differs from the explicit sales basis; no equivalence was assumed",
                        [context[field], actual],
                    )
                else:
                    commercial(
                        "/context/" + field,
                        kind,
                        "matched",
                        "Customer requirement is bound to the same sales revision",
                        [actual],
                    )
        pc = policy["calculation_currency"]
        if (pc["id"] if isinstance(pc, dict) else pc) != context["calculation_currency_ref"]["id"]:
            fail("REFERENCE_INVALID", "/policy_currency")
        self._cfg(context["comparison_basis"]["named_place_ref"], manifest, "location")

        def delivery(rule, path, role):
            nonlocal provisional, comparable
            anchor = calendar = None
            self._cfg(rule["place_ref"], manifest, "location")
            if rule["kind"] == "lead_time":
                anchor = self._business(rule["anchor_ref"], manifest, "delivery_anchor")
                calendar = self._cfg(rule["calendar_ref"], manifest, "delivery_calendar")
            resolved_delivery = resolve_delivery(rule, anchor, calendar, self.clock)
            row = {
                "path": path,
                "role": role,
                "milestone": rule["milestone"],
                "place_ref": deepcopy(rule["place_ref"]),
                "time_zone": rule["time_zone"],
                **resolved_delivery,
            }
            delivery_checks.append(row)
            if row["status"] == "unresolved":
                provisional = True
                comparable = False
                differences.append({"path": path, "reason": row["reason"]})
            return row.get("date")

        required_date = delivery(
            context["comparison_basis"]["delivery"],
            "/context/comparison_basis/delivery",
            "requirement",
        )
        required_delivery = context["comparison_basis"]["delivery"]
        if required_delivery["place_ref"] != context["comparison_basis"]["named_place_ref"]:
            comparable = False
            differences.append(
                {
                    "path": "/context/comparison_basis/delivery/place_ref",
                    "reason": "Delivery requirement and comparison place do not refer to the same verified location",
                }
            )
        for line in context["lines"]:
            sku = self._cfg(line["sku_profile_ref"], manifest, "sku_profile")
            u = self._cfg(line["unit_ref"], manifest, "unit")
            if Fraction(line["quantity"]) <= 0 or len(
                line["quantity"].split(".")[1] if "." in line["quantity"] else ""
            ) > min(6, u["precision"]):
                fail("INVALID_KNOWN_VALUE", "/quantity")
            self._master(
                {"kind": "sku", "id": sku["sku_id"], "row_version": sku.get("sku_row_version", 1)},
                manifest,
                "sku",
            )
        resolved = {}

        def supplier(src):
            kind = "supplier_offer" if src["kind"] == "offer" else "purchase_terms"
            ref = {"kind": kind, "id": src["id"], "revision": src["revision"]}
            o = self._business(ref, manifest, kind)
            documents[kind][src["id"]] = o
            self._master(o["supplier_ref"], manifest, "supplier")
            if kind == "purchase_terms":
                origin_ref = o["source_offer_ref"]
                origin = self._business(
                    origin_ref,
                    manifest,
                    "supplier_offer",
                    check_effect=o["validity_mode"] == "dependent_validity",
                )
                if origin["supplier_ref"] != o["supplier_ref"]:
                    fail("REFERENCE_INVALID", "/purchase_terms/supplier_ref")
            else:
                if o["rfq_ref"] != context["rfq_ref"]:
                    fail("REFERENCE_INVALID", "/offer/rfq_ref")
                if o["origin"]["kind"] == "in_response_to_rfq":
                    request = o["origin"]["supplier_rfq_ref"]
                    sent = self.rfqs.get(request["id"])
                    if (
                        sent is None
                        or sent.get("issued_version", sent["version"]) != request["row_version"]
                        or sent["status"] not in ("issued", "closed")
                    ):
                        fail("REFERENCE_STALE", "/supplier_rfq")
                    if (
                        sent["data"]["supplier_ref"] != o["supplier_ref"]
                        or sent["data"]["rfq_ref"] != context["rfq_ref"]
                    ):
                        fail("REFERENCE_INVALID", "/supplier_rfq")
                    if not set(o["rfq_line_ids"]) <= set(sent["data"]["rfq_line_ids"]):
                        fail("REFERENCE_INVALID", "/supplier_rfq/line_ids")
                    self._remember(
                        manifest, "supplier_rfq", request["id"], request["row_version"], sent
                    )

            resolved[(src["kind"], src["id"], src["revision"])] = o
            return o

        def convert_quantity(q, from_ref, to_ref, sku_ref, condition):
            original = self._cfg(from_ref, manifest, "unit")
            target_unit = self._cfg(to_ref, manifest, "unit")
            if (q * 10 ** min(6, original["precision"])).denominator != 1:
                fail("INVALID_KNOWN_VALUE", "/purchase_unit_precision")
            if from_ref == to_ref:
                value = q
            else:
                possibilities = []
                for conversion_ref in condition.get("conversion_refs", []):
                    c = self._cfg(conversion_ref, manifest, "conversion")
                    if c["sku_profile"] != sku_ref:
                        fail("REFERENCE_INVALID", "/conversion/sku_profile")
                    if c["from_unit"] == from_ref and c["to_unit"] == to_ref:
                        possibilities.append(c)
                if len(possibilities) != 1:
                    fail("REFERENCE_INVALID", "/conversion/direction")
                if original["dimension"] != target_unit["dimension"]:
                    fail("REFERENCE_INVALID", "/conversion/dimension")
                factor = Fraction(possibilities[0]["factor"])
                if factor <= 0:
                    fail("INVALID_KNOWN_VALUE", "/conversion/factor")
                value = q * factor
            if value > 1000000 or (value * 10 ** min(6, target_unit["precision"])).denominator != 1:
                fail("INVALID_KNOWN_VALUE", "/converted_quantity")
            return value

        groups = sorted(
            purchase_groups(data, context, supplier, convert_quantity),
            key=lambda g: g["source_identity"],
        )
        components = []
        graphs = []

        fx = []
        for ref in data.get("fx_refs", []):
            fx.append(self._cfg(ref, manifest, "fx"))

        def convert(value, cur):
            if cur["code"] == target:
                return minor(value, precision)
            options = [
                x
                for x in fx
                if x["from_currency"] == cur["code"]
                and x["to_currency"] == target
                and x["purpose"] == "cost_estimate"
            ]
            if len(options) != 1:
                fail("FX_NOT_APPLICABLE", "/fx_refs")
            if "max_fx_age_seconds" not in policy:
                fail("COST_INPUT_NOT_READY", "/policy/max_fx_age_seconds")
            return fx_cost(
                value,
                cur["code"],
                target,
                options[0],
                self.clock,
                policy["max_fx_age_seconds"],
                precision,
            )

        def amount(value, curref, taxref):
            cur = self._cfg(curref, manifest, "currency")
            tax = self._cfg(taxref, manifest, "tax_profile")
            parts = split_tax(value, tax, cur["minor_units"])
            return convert(Fraction(parts["cost_minor"], 10 ** cur["minor_units"]), cur)

        def distribute(total, members, basis, weights):
            ids = sorted(members)
            values = allocate(total, [weights[x] for x in ids])
            return [
                {
                    "line_id": i,
                    "amount_minor": str(v),
                    "basis": basis,
                    "base_integer": str(weights[i]),
                }
                for i, v in zip(ids, values)
            ]

        purchase_base = {line["line_id"]: 0 for line in context["lines"]}
        included = {}
        self._budget.claim_components(len(groups))
        purchase_scopes = []
        for i, g in enumerate(groups):
            c = g["condition"]
            self._cfg(c["trade_terms_ref"], manifest, "trade_terms")
            self._cfg(c["payment_terms_ref"], manifest, "payment_terms")
            src_kind, src_id, src_revision, _ = g["source_identity"]
            source = resolved[src_kind, src_id, src_revision]
            path = (
                "/"
                + ("supplier_offer" if src_kind == "offer" else "purchase_terms")
                + "/"
                + src_id
                + "/lines/"
                + c["id"]
            )
            purchase_scope = trade_scope(
                c["purchase_trade_scope_ref"], "supplier_purchase", resolve
            )
            purchase_scopes.append(purchase_scope)
            for obligation in purchase_scope["obligations"]:
                if (
                    obligation["bearer"] == "seller"
                    and obligation["obligation_id"] not in c["included_obligation_ids"]
                ):
                    fail("COST_INPUT_NOT_READY", "/supplier_price_inclusion")
            if (
                purchase_scope["trade_terms_ref"] != c["trade_terms_ref"]
                or purchase_scope["named_place_ref"] != c["delivery"]["place_ref"]
            ):
                mismatch(
                    path + "/purchase_trade_scope_ref",
                    "trade_terms",
                    "Supplier terms or named place differs from the reviewed purchase mapping",
                    [c["purchase_trade_scope_ref"], c["trade_terms_ref"]],
                )
            else:
                commercial(
                    path + "/purchase_trade_scope_ref",
                    "trade_terms",
                    "normalized",
                    "Supplier contract and export sales contract retain their own parties; explicit price inclusions and exporter charges define the cost bridge",
                    [c["purchase_trade_scope_ref"], commercial_basis["sales_trade_scope_ref"]],
                )
            supplier_payment = payment(c["payment_terms_ref"], resolve)
            same = payment_signature(supplier_payment) == payment_signature(sale_payment)
            commercial(
                path + "/payment_terms_ref",
                "payment_terms",
                "matched" if same else "different_cashflow",
                "Separate receipt/payment schedules retained; no automatic financing adjustment to nominal direct cost",
                [commercial_basis["sales_payment_terms_ref"], c["payment_terms_ref"]],
            )
            tax_application(
                c["tax_application_ref"],
                c["tax_profile_ref"],
                source["supplier_ref"],
                c["sku_profile_ref"],
                "goods",
                resolve,
            )
            commercial(
                path + "/tax_application_ref",
                "tax_application",
                "matched",
                "Reviewed CN-M01 goods application matches counterparty, SKU and tax revision; no tax entitlement inferred",
                [c["tax_application_ref"], c["tax_profile_ref"]],
            )
            delivery_path = (
                "/"
                + ("supplier_offer" if g["source_identity"][0] == "offer" else "purchase_terms")
                + "/"
                + str(g["source_identity"][1])
                + "/lines/"
                + c["id"]
                + "/delivery"
            )
            supplied_date = delivery(c["delivery"], delivery_path, "supply")
            if any(
                c["delivery"][key] != required_delivery[key]
                for key in ("milestone", "place_ref", "time_zone")
            ):
                comparable = False
                differences.append(
                    {
                        "path": delivery_path,
                        "reason": "Delivery milestone, location or time zone differs; no transport time or event equivalence was assumed",
                    }
                )
            if (
                required_date is not None
                and supplied_date is not None
                and supplied_date > required_date
            ):
                comparable = False
                differences.append(
                    {
                        "path": delivery_path,
                        "reason": "Supplier delivery date exceeds the verified comparison deadline",
                    }
                )
            value = amount(g["raw_amount"], c["currency_ref"], c["tax_profile_ref"])
            members = g["members"]
            # Exact common denominator maps rational quantities to integer relative weights.
            from math import lcm

            den = lcm(*(x.denominator for x in members.values()))
            weights = {k: int(v * den) for k, v in members.items()}
            component = {
                "id": "purchase." + str(i + 1),
                "obligation_id": "goods." + str(i + 1),
                "amount_minor": str(value),
                "allocations": distribute(value, members, "quantity", weights),
            }
            components.append(component)
            graphs.append({"id": component["id"], "obligation_id": component["obligation_id"]})
            for alloc in component["allocations"]:
                purchase_base[alloc["line_id"]] += int(alloc["amount_minor"])
            for obligation in c["included_obligation_ids"]:
                if obligation in included:
                    fail("CHARGE_SCOPE_UNRESOLVED", "/included_obligation")
                included[obligation] = component["id"]
        seen_fee_obligations = set()
        fee_type_ids = set()
        fee_rows: list[Any] = []
        local_ids = {}
        excluded = []
        fee_parties = {}
        sale_obligations = {o["obligation_id"]: o for o in sale["obligations"]}
        for obligation in sale["obligations"]:
            if obligation["obligation_id"] in included or obligation["bearer"] == "buyer":
                fee_type_ids.add(canonical(obligation["fee_type_ref"]))
            if obligation["bearer"] == "buyer" and obligation["obligation_id"] in included:
                mismatch(
                    "/included_obligation_ids",
                    "obligation",
                    "Customer-borne obligation is embedded in purchase price; no unproved deduction was made",
                    [commercial_basis["sales_trade_scope_ref"]],
                )

        def measurement(ref):
            if ref["kind"] != "measurement":
                fail("REFERENCE_INVALID", "/measurement_kind")
            d = self._business(ref, manifest, "measurement")
            verified_estimate_allowed(d["kind"], policy)
            from .rules import moment

            if moment(d["observed_at"]) > moment(self.clock):
                fail("INVALID_KNOWN_VALUE", "/measurement/observed_at")
            packages = d["packages"]
            seen = set()
            volume = Fraction(0)
            for package in packages:
                if package["id"] in seen:
                    fail("DUPLICATE_LINE_ID", "/measurement/packages")
                seen.add(package["id"])
                if Fraction(package["net_kg"]) > Fraction(package["gross_kg"]):
                    fail("INVALID_KNOWN_VALUE", "/measurement/gross_kg")
                if any(x not in purchase_base for x in package["line_ids"]):
                    fail("REFERENCE_INVALID", "/measurement/line_ids")
                volume += (
                    package["count"]
                    * Fraction(package["length_m"])
                    * Fraction(package["width_m"])
                    * Fraction(package["height_m"])
                )
            if "declared_volume_m3" in d and minor(volume, 6) != minor(d["declared_volume_m3"], 6):
                fail("MEASUREMENT_CONFLICT", "/measurement/volume")
            return packages

        for ref in sorted(
            data.get("logistics_offer_refs", []), key=lambda r: (r["kind"], r["id"], r["revision"])
        ):
            log = self._business(ref, manifest, "logistics_offer")
            role = self._business(log["service_role_ref"], manifest, "service_party_role")
            self._master(role["party_ref"], manifest, "supplier")
            documents["logistics_offer"][ref["id"]] = log
            fee_parties[ref["id"], ref["revision"]] = role["party_ref"]
            if log["mode"] not in sale["allowed_modes"] or any(
                log["mode"] not in scope["allowed_modes"] for scope in purchase_scopes
            ):
                mismatch(
                    "/logistics_offer/" + ref["id"] + "/mode",
                    "trade_terms",
                    "Transport mode is outside the reviewed commercial scope",
                    [commercial_basis["sales_trade_scope_ref"]],
                )
            if any(log[k] != role[k] for k in ["service_code", "origin_ref", "destination_ref"]):
                fail("REFERENCE_INVALID", "/service_role")
            if log["destination_ref"] != context["comparison_basis"]["named_place_ref"]:
                fail("COMPARISON_BASIS_MISMATCH", "/destination")
            self._cfg(log["origin_ref"], manifest, "location")
            self._cfg(log["destination_ref"], manifest, "location")
            for f in sorted(log["fees"], key=lambda f: f["id"]):
                self._budget.claim_components(1)
                if f["obligation_id"] in seen_fee_obligations:
                    fail("CHARGE_DOUBLE_COUNT", "/fee_obligation")
                seen_fee_obligations.add(f["obligation_id"])
                fee_type_ids.add(canonical(f["fee_type_ref"]))
                self._cfg(f["fee_type_ref"], manifest, "fee_type")
                required = sale_obligations.get(f["obligation_id"])
                if required and (
                    f["responsible_party"] != required["bearer"]
                    or f["fee_type_ref"] != required["fee_type_ref"]
                ):
                    mismatch(
                        "/logistics_offer/" + ref["id"] + "/fees/" + f["id"],
                        "obligation",
                        "Fee party or fee type contradicts the reviewed sales responsibility",
                        [commercial_basis["sales_trade_scope_ref"]],
                    )
                identifier = "fee." + str(len(fee_rows) + 1)
                scope = (ref["id"], ref["revision"])
                local_key = scope + (f["id"],)
                if local_key in local_ids:
                    fail("DUPLICATE_LINE_ID", "/fees")
                local_ids[local_key] = identifier
                fee_rows.append((scope, identifier, f))
        purchase_ids = {c["id"] for c in components}
        for scope, identifier, f in fee_rows:
            graph = {"id": identifier, "obligation_id": f["obligation_id"]}
            parent = included.get(f["obligation_id"])
            explicit = f.get("included_in_component_ref")
            if explicit:
                candidates = []
                if explicit in purchase_ids:
                    candidates.append(explicit)
                if scope + (explicit,) in local_ids:
                    candidates.append(local_ids[scope + (explicit,)])
                if len(candidates) != 1:
                    fail("CHARGE_SCOPE_UNRESOLVED", "/included_in_component_ref")
                if parent is not None and parent != candidates[0]:
                    fail("CHARGE_SCOPE_UNRESOLVED", "/included_in_component_ref")
                parent = candidates[0]
            if parent is not None:
                graph["included_in_component_ref"] = parent
                self._budget.inclusion()
            if parent is not None and parent.startswith("fee."):
                parent_fee = next(item for _, parent_id, item in fee_rows if parent_id == parent)
                if parent_fee["responsible_party"] != f["responsible_party"]:
                    fail("CHARGE_SCOPE_UNRESOLVED", "/included_in_component_ref/responsibility")
            graphs.append(graph)
        payable = {x["id"] for x in fee_graph(graphs)}
        for scope, identifier, f in fee_rows:
            self._cfg(f["currency_ref"], manifest, "currency")
            self._cfg(f["tax_profile_ref"], manifest, "tax_profile")
            tax_application(
                f["tax_application_ref"],
                f["tax_profile_ref"],
                fee_parties[scope],
                f["fee_type_ref"],
                "service",
                resolve,
            )
            commercial(
                "/components/" + identifier + "/tax_application_ref",
                "tax_application",
                "matched",
                "Reviewed CN-M01 service application matches provider, fee type and tax revision",
                [f["tax_application_ref"], f["tax_profile_ref"]],
            )
            if f["responsible_party"] == "buyer":
                if identifier not in payable:
                    mismatch(
                        "/components/" + identifier,
                        "obligation",
                        "Customer-borne charge is bundled into another price; its amount cannot be silently deducted",
                        [commercial_basis["sales_trade_scope_ref"]],
                    )
                excluded.append(
                    {
                        "id": identifier,
                        "obligation_id": f["obligation_id"],
                        "reason_code": "customer_borne",
                        "reason": "Customer-borne obligation is excluded from exporter nominal direct cost; no zero-priced service was fabricated",
                    }
                )
                commercial(
                    "/components/" + identifier,
                    "obligation",
                    "customer_borne",
                    "Exporter cost excludes the explicitly customer-borne obligation",
                    [commercial_basis["sales_trade_scope_ref"]],
                )
                continue
            if identifier not in payable:
                parent = next(
                    g["included_in_component_ref"] for g in graphs if g["id"] == identifier
                )
                excluded.append(
                    {
                        "id": identifier,
                        "obligation_id": f["obligation_id"],
                        "included_in_component_ref": parent,
                        "reason_code": "included",
                        "reason": "Included in referenced payable component; not counted again",
                    }
                )
                continue
            rule = f["chargeable"]
            billing = f["billing"]
            if rule["kind"] == "fixed" and billing["kind"] != "fixed":
                fail("UNSUPPORTED_PRICING_MODE", "/billing/chargeable_basis")
            if rule["kind"] == "fixed":
                quantity = Fraction(1)
            else:
                packages = measurement(rule["measurement_ref"])
                quantity = chargeable(packages, rule)
                if billing["kind"] != "fixed":
                    unit = self._cfg(billing["unit_ref"], manifest, "unit")
                    expected = "M3" if rule["kind"] == "volume" else "KG"
                    if unit["code"] != expected:
                        fail("REFERENCE_INVALID", "/billing/unit")
            if (
                billing["kind"] == "fixed"
                and Fraction(billing["amount"]) == 0
                and not f.get("zero_price_reason")
            ):
                fail("COST_INPUT_NOT_READY", "/fee_zero_price_reason")
            raw = bill(quantity, billing)
            value = amount(raw, f["currency_ref"], f["tax_profile_ref"])
            allocation = f["allocation"]
            basis = allocation["basis"]
            if basis == "explicit":
                weights = {x["line_id"]: int(x["weight"]) for x in allocation["weights"]}
                if len(weights) != len(allocation["weights"]):
                    fail("DUPLICATE_LINE_ID", "/weights")
            else:
                ids = allocation["target_line_ids"]
                if len(ids) != len(set(ids)):
                    fail("DUPLICATE_LINE_ID", "/target_line_ids")
                if basis == "amount":
                    weights = {x: purchase_base.get(x, 0) for x in ids}
                elif basis == "quantity":
                    quantities = {
                        line["line_id"]: Fraction(line["quantity"]) for line in context["lines"]
                    }
                    den = lcm(*(quantities[x].denominator for x in ids if x in quantities))
                    weights = {x: int(quantities.get(x, 0) * den) for x in ids}
                elif basis in ("weight", "volume"):
                    if "measurement_ref" not in allocation:
                        fail("COST_INPUT_NOT_READY", "/allocation/measurement_ref")
                    packages = measurement(allocation["measurement_ref"])
                    values = {x: Fraction(0) for x in ids}
                    for package in packages:
                        if len(package["line_ids"]) != 1:
                            fail("DEPENDENCY_NOT_SUPPORTED", "/allocation/mixed_package")
                        line_id = package["line_ids"][0]
                        if line_id not in values:
                            continue
                        per = (
                            Fraction(package["net_kg"])
                            if basis == "weight"
                            else Fraction(package["length_m"])
                            * Fraction(package["width_m"])
                            * Fraction(package["height_m"])
                        )
                        values[line_id] += package["count"] * per
                    if any(x <= 0 for x in values.values()):
                        fail("COST_INPUT_NOT_READY", "/allocation/measurement_coverage")
                    den = lcm(*(x.denominator for x in values.values()))
                    weights = {k: int(v * den) for k, v in values.items()}
                else:
                    fail("DEPENDENCY_NOT_SUPPORTED", "/allocation_basis_integration")
            if any(x not in purchase_base for x in weights):
                fail("REFERENCE_INVALID", "/allocation_target")
            components.append(
                {
                    "id": identifier,
                    "obligation_id": f["obligation_id"],
                    "amount_minor": str(value),
                    "allocations": distribute(value, weights, basis, weights),
                }
            )
        for obligation in sale["obligations"]:
            covered = obligation["obligation_id"] in included or any(
                f["obligation_id"] == obligation["obligation_id"]
                and f["responsible_party"] == "seller"
                for _, _, f in fee_rows
            )
            if obligation["bearer"] == "seller" and not covered:
                fail("COST_INPUT_NOT_READY", "/required_obligations")
            commercial(
                "/obligations/" + obligation["obligation_id"],
                "obligation",
                "normalized" if obligation["bearer"] == "seller" else "customer_borne",
                "Responsibility, price inclusion and explicit charges reconciled without guessing from an Incoterms label",
                [commercial_basis["sales_trade_scope_ref"]],
            )
        if any(
            canonical(x) not in fee_type_ids
            for x in context["comparison_basis"]["required_fee_type_refs"]
        ):
            fail("COST_INPUT_NOT_READY", "/required_fees")
        root = self.roots.get(("costing_context", data["context_ref"]["id"]))
        provenance = (
            {}
            if root is None
            else root.revisions[data["context_ref"]["revision"]].get("assumption_provenance", {})
        )
        assumptions = bind_assumptions(
            context.get("assumptions", []),
            documents,
            provenance,
            lambda id_: self._remember(manifest, "source", id_, 1, self._source(id_)),
        )
        if assumptions:
            provisional = True
            self._remember(
                manifest,
                "context_provenance",
                data["context_ref"]["id"],
                data["context_ref"]["revision"],
                provenance,
            )
            for assumption in assumptions:
                differences.append(
                    {
                        "path": assumption["path"],
                        "reason": "Unverified assumption: " + assumption["reason"],
                    }
                )
        total = sum(int(c["amount_minor"]) for c in components)
        if total > 10**12 * 10**precision:
            fail("CALCULATION_LIMIT_EXCEEDED", "/total_cost")
        self.last_budget_report = self._budget.finish()
        input_manifest = sorted(manifest.values(), key=lambda x: (x["kind"], x["id"], x["version"]))
        binding = {
            "normalization_version": NORMALIZATION_VERSION,
            "scenario": normalize(
                {
                    "contract": "brant.costing/0.1.0",
                    "command": "cost_scenario.save_draft",
                    "idempotency_key": "binding",
                    "args": {
                        "id": scenario_id,
                        "expected_version": scenario["version"],
                        "data": data,
                    },
                }
            ),
            "input_manifest": input_manifest,
        }
        components.sort(key=lambda c: c["id"])
        result = {
            "kind": "evaluation",
            "id": result_id,
            "scenario_id": scenario_id,
            "input_scenario_version": scenario["version"],
            "context_ref": deepcopy(data["context_ref"]),
            "rfq_ref": deepcopy(context["rfq_ref"]),
            "engine_version": "reference.integrated.0.6",
            "calculation_time": self.clock,
            "input_manifest": input_manifest,
            "input_hash": digest(binding),
            "comparison_status": "comparable" if comparable else "not_comparable",
            "verification_status": "provisional" if provisional else "verified",
            "currency": target,
            "minor_units": precision,
            "components": components,
            "excluded_components": sorted(excluded, key=lambda x: x["id"]),
            "total_minor": str(total),
            "differences": sorted(differences, key=lambda d: (d["path"], d["reason"])),
            "assumptions": assumptions,
            "delivery_checks": sorted(delivery_checks, key=lambda d: (d["path"], d["role"])),
        }
        result.update(
            {
                "cost_basis": commercial_basis["cost_basis"],
                "excluded_cost_categories": [
                    "imputed_financing_cost",
                    "expected_credit_loss",
                    "unrealized_fx_hedge",
                ],
                "commercial_checks": sorted(
                    commercial_checks,
                    key=lambda c: (c["path"], c["category"], canonical(c["refs"])),
                ),
            }
        )
        result["engine_version"] = "reference.integrated.0.8"
        result["result_hash"] = digest(result)
        check_output(result)
        return result, binding

    def _apply(self, actor, cmd, a):
        scenario: Any
        previous: Any
        self._admit_write(actor, cmd, a)
        if cmd == "costing_context.save_draft":
            root = self.roots.get(("costing_context", a["id"]))
            prior = (
                {}
                if root is None or root.working is None
                else deepcopy(root.revisions[root.working])
            )
            value = super()._apply(actor, cmd, a)
            root = self.roots["costing_context", a["id"]]
            revision = root.revisions[root.working]
            previous = {x["id"]: x for x in prior.get("data", {}).get("assumptions", [])}
            provenance = {}
            for assumption in a["data"].get("assumptions", []):
                id_ = assumption["id"]
                provenance[id_] = (
                    deepcopy(prior.get("assumption_provenance", {}).get(id_))
                    if previous.get(id_) == assumption
                    else None
                )
                if provenance[id_] is None:
                    provenance[id_] = {"proposed_by": actor["id"], "proposed_at": self.clock}
            revision["assumption_provenance"] = provenance
            return value
        if cmd == "costing_context.revise":
            value = super()._apply(actor, cmd, a)
            root = self.roots["costing_context", a["id"]]
            root.revisions[root.working]["assumption_provenance"] = deepcopy(
                root.revisions[a["base_revision"]].get("assumption_provenance", {})
            )
            return value
        if cmd == "cost_scenario.evaluate":
            value = super()._apply(actor, cmd, a)
            result, binding = self._cost(a["id"], value["result_id"])
            self.complete_results[result["id"]] = result
            self.bindings[result["id"]] = binding
            self.results[result["id"]]["result_hash"] = result["result_hash"]
            self.results[result["id"]]["complete_input_hash"] = result["input_hash"]
            return {**value, "result_hash": result["result_hash"], "result": deepcopy(result)}
        if cmd == "cost_snapshot.freeze":
            scenario = self.scenarios.get(a["scenario_id"])
            if scenario is None:
                fail("NOT_FOUND", "/")
            if scenario["version"] != a["expected_version"]:
                fail("VERSION_CONFLICT", "/expected_version")
            if scenario["status"] != "draft":
                fail("INVALID_STATE", "/status")
            previous = self.complete_results.get(a["result_id"])
            if previous is None:
                fail("REFERENCE_INVALID", "/result_id")
            if previous["verification_status"] != "verified":
                fail("COST_INPUT_NOT_READY", "/verification_status")
            if previous["comparison_status"] != "comparable":
                fail("COMPARISON_BASIS_MISMATCH", "/comparison_status")
            current, binding = self._cost(a["scenario_id"], a["result_id"])
            if current["verification_status"] != "verified":
                fail("COST_INPUT_NOT_READY", "/verification_status")
            if current["comparison_status"] != "comparable":
                fail("COMPARISON_BASIS_MISMATCH", "/comparison_status")
            if (
                any(current[key] != previous[key] for key in self.FREEZE_BINDING_FIELDS)
                or a["result_hash"] != previous["result_hash"]
            ):
                fail("REFERENCE_STALE", "/result_input")
            # New current-time checks are from _cost; freeze keeps original calculation_time/hash.
            value = super()._apply(actor, cmd, a)
            snap = {
                **deepcopy(previous),
                "kind": "snapshot",
                "id": "snapshot." + str(len(self.complete_snapshots) + 1),
                "evaluation_id": previous["id"],
                "frozen_scenario_version": value["version"],
                "selection_reason": a["selection_reason"],
            }
            snap["evidence_hash"] = digest(snap)
            self.complete_snapshots[snap["id"]] = snap
            check_output(snap)
            return {**value, "result": deepcopy(snap)}
        return super()._apply(actor, cmd, a)

    def response(self, command, model_result, action_id=None):
        status: str | None
        if command == "cost_scenario.evaluate":
            status = "evaluated"
            result = model_result["result"]
        elif command == "cost_snapshot.freeze":
            status = "frozen"
            result = model_result["result"]
        else:
            action = command.split(".")[1]
            status = {
                "save_draft": "draft",
                "revise": "draft",
                "discard_draft": "verified" if model_result.get("active") else "empty",
                "verify": "verified",
                "publish": "active",
                "withdraw": "withdrawn",
                "retire": "retired",
                "record_issued": "issued",
                "close": "closed",
                "record_verified": "verified",
                "supersede": "verified",
                "record": "denied",
            }.get(action)
            if status is None:
                fail("DEPENDENCY_NOT_SUPPORTED", "/response_mapping")
            result = {"kind": "ack", "root_version": model_result["version"]}
            for source, target in [("active", "active_revision"), ("working", "working_revision")]:
                if model_result.get(source) is not None:
                    result[target] = model_result[source]
        payload = {
            "ok": True,
            "action_id": action_id or model_result.get("action_id", "reference.action"),
            "object_id": model_result.get("object_id", result.get("id")),
            "status": status,
            "replayed": model_result["replayed"],
            "row_version": model_result["version"],
            "result": result,
        }
        if "result_hash" in result:
            payload["result_hash"] = result["result_hash"]
        schema = __import__("json").loads((ROOT / "contracts/response.schema.json").read_text())
        Draft202012Validator(schema, format_checker=FormatChecker()).validate(payload)
        by_command = __import__("json").loads(
            (ROOT / "contracts/command-responses.schema.json").read_text()
        )
        Draft202012Validator(by_command[command], format_checker=FormatChecker()).validate(payload)
        from .output_evidence import check_transport

        check_transport(payload)
        return payload

    def snapshot_query(self, actor, id_):
        snapshot = self.history(actor, id_)
        if snapshot["kind"] != "snapshot":
            fail("NOT_FOUND", "/")
        scenario_id = snapshot["scenario_id"]
        scenario = self.scenarios[scenario_id]
        eligible = False
        self._actor = actor
        try:
            if (
                scenario["status"] == "frozen"
                and scenario["version"] == snapshot["frozen_scenario_version"]
            ):
                # Re-evaluate the original input version at today's clock. This
                # transient copy never changes the persisted frozen scenario.
                self.scenarios[scenario_id] = {
                    **scenario,
                    "version": snapshot["input_scenario_version"],
                }
                try:
                    current, _ = self._cost(scenario_id, snapshot["evaluation_id"])
                    eligible = (
                        current["verification_status"] == "verified"
                        and current["comparison_status"] == "comparable"
                        and all(current[k] == snapshot[k] for k in self.FREEZE_BINDING_FIELDS)
                    )
                except Invalid as exc:
                    if exc.code not in (
                        "REFERENCE_STALE",
                        "COST_INPUT_NOT_READY",
                        "COMPARISON_BASIS_MISMATCH",
                    ):
                        raise
        finally:
            self.scenarios[scenario_id] = scenario
            for field in ("_actor", "_budget"):
                self.__dict__.pop(field, None)
        output = {
            "kind": "snapshot_query",
            "snapshot": snapshot,
            "currently_eligible_for_quote": eligible,
            "eligibility_checked_at": self.clock,
        }
        schema = __import__("json").loads((ROOT / "contracts/query.schema.json").read_text())
        Draft202012Validator(schema, format_checker=FormatChecker()).validate(output)
        return output

    def history(self, actor, id_):
        if "costing.read" not in actor.get("grants", []):
            fail("PERMISSION_DENIED", "/")
        if not actor.get("readable", False):
            fail("PERMISSION_DENIED", "/")
        if actor.get("tenant") != self.registry["server_scope"].get("tenant") or actor.get(
            "company"
        ) != self.registry["server_scope"].get("company"):
            fail("NOT_FOUND", "/")
        result = self.complete_results.get(id_, self.complete_snapshots.get(id_))
        if result is None:
            fail("NOT_FOUND", "/")
        self._actor = actor
        try:
            self._history_access(actor, result)
            return deepcopy(result)
        finally:
            self.__dict__.pop("_actor", None)
