"""Explicit delivery dates and versioned working calendars. No implicit today or holiday data."""

from datetime import date, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .rules import moment
from .validator import fail


def validate_calendar(data):
    try:
        ZoneInfo(data["time_zone"])
        start = date.fromisoformat(data["coverage_from"])
        end = date.fromisoformat(data["coverage_until"])
        holidays = {date.fromisoformat(x) for x in data["holidays"]}
        overrides = {date.fromisoformat(x) for x in data["working_overrides"]}
    except (ValueError, ZoneInfoNotFoundError, KeyError):
        fail("INVALID_KNOWN_VALUE", "/delivery_calendar")
    if (
        start > end
        or holidays & overrides
        or any(x < start or x > end for x in holidays | overrides)
    ):
        fail("INVALID_KNOWN_VALUE", "/delivery_calendar")
    weekdays = data["working_weekdays"]
    if (
        not weekdays
        or len(set(weekdays)) != len(weekdays)
        or any(type(x) is not int or not 1 <= x <= 7 for x in weekdays)
    ):
        fail("INVALID_KNOWN_VALUE", "/working_weekdays")
    return start, end, holidays, overrides


def resolve_delivery(rule, anchor=None, calendar=None, now=None):
    try:
        ZoneInfo(rule["time_zone"])
    except (KeyError, ValueError, ZoneInfoNotFoundError):
        fail("INVALID_KNOWN_VALUE", "/delivery/time_zone")
    if rule["kind"] == "fixed":
        return {"status": "resolved", "date": date.fromisoformat(rule["date"]).isoformat()}
    if calendar is None:
        fail("COST_INPUT_NOT_READY", "/delivery_calendar")
    start, end, holidays, overrides = validate_calendar(calendar)
    if calendar["time_zone"] != rule["time_zone"]:
        fail("INVALID_KNOWN_VALUE", "/calendar_time_zone")
    if anchor is None or anchor.get("status") != "verified" or "occurred_at" not in anchor:
        return {
            "status": "unresolved",
            "reason": "Anchor has no verified occurrence time; no date was assumed",
        }
    occurred = moment(anchor["occurred_at"])
    if now is not None and occurred > moment(now):
        fail("INVALID_KNOWN_VALUE", "/delivery_anchor/occurred_at")
    current = occurred.astimezone(ZoneInfo(calendar["time_zone"])).date()
    if not start <= current <= end:
        fail("COST_INPUT_NOT_READY", "/calendar_coverage")
    remaining = rule["days"]
    if type(remaining) is not int or not 0 <= remaining <= 3650:
        fail("INVALID_KNOWN_VALUE", "/delivery/days")
    if rule["day_basis"] not in ("calendar", "working"):
        fail("INVALID_KNOWN_VALUE", "/delivery/day_basis")
    # Anchor day is excluded; zero days resolves to anchor's local date.
    for _ in range(36601):
        if remaining == 0:
            return {"status": "resolved", "date": current.isoformat()}
        if current >= end:
            fail("COST_INPUT_NOT_READY", "/calendar_coverage")
        current += timedelta(days=1)
        if (
            rule["day_basis"] == "calendar"
            or current in overrides
            or (current.isoweekday() in calendar["working_weekdays"] and current not in holidays)
        ):
            remaining -= 1
    fail("CALCULATION_LIMIT_EXCEEDED", "/delivery_calendar")
