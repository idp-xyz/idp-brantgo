"""Reviewed commercial mappings for nominal direct cost; no legal or financing inference."""

import json
from functools import lru_cache
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from jsonschema import Draft202012Validator

from .resource_budget import Fraction
from .strict_formats import FormatChecker
from .validator import ROOT, canonical, fail


@lru_cache
def schemas():
    baseline = json.loads((ROOT / "contracts/baseline-foundation.commands.schema.json").read_text())
    result = {}
    for branch in baseline["oneOf"]:
        args = branch.get("properties", {}).get("args", {}).get("properties", {})
        kind = args.get("kind", {}).get("const")
        if kind and "data" in args:
            result[kind] = args["data"]
    extension = json.loads((ROOT / "contracts/foundation-extension.data.schema.json").read_text())
    for branch in extension["oneOf"]:
        result[branch["properties"]["kind"]["const"]] = branch["properties"]["data"]
    return result


def validate_config(kind, data):
    shape = schemas().get(kind)
    if shape is None or not Draft202012Validator(shape, format_checker=FormatChecker()).is_valid(
        data
    ):
        fail("COST_INPUT_NOT_READY", "/" + kind + "/data")
    if kind == "trade_scope":
        ids = [x["obligation_id"] for x in data["obligations"]]
        if len(ids) != len(set(ids)):
            fail("CHARGE_DOUBLE_COUNT", "/trade_scope/obligations")
    if kind == "payment_terms":
        if len({x["stage_id"] for x in data["stages"]}) != len(data["stages"]):
            fail("DUPLICATE_LINE_ID", "/payment_terms/stages")
        if (
            any(not 0 < Fraction(x["percent"]) <= 100 for x in data["stages"])
            or sum(Fraction(x["percent"]) for x in data["stages"]) != 100
        ):
            fail("INVALID_KNOWN_VALUE", "/payment_terms/percent")
    if kind == "tax_profile":
        rate = Fraction(data["rate"])
        if not 0 <= rate <= 1 or (data["price_basis"] == "not_applicable" and rate != 0):
            fail("INVALID_KNOWN_VALUE", "/tax_profile/rate")
    if kind == "calendar":
        try:
            ZoneInfo(data["timezone"])
        except (ValueError, ZoneInfoNotFoundError):
            fail("INVALID_KNOWN_VALUE", "/calendar/timezone")
        if len(set(data["working_weekdays"])) != len(data["working_weekdays"]):
            fail("INVALID_KNOWN_VALUE", "/calendar/working_weekdays")
    return data


def payment(ref, resolve):
    data = validate_config("payment_terms", resolve(ref, "payment_terms"))
    for stage in data["stages"]:
        validate_config("calendar", resolve(stage["calendar"], "calendar"))
    return data


def payment_signature(data):
    return sorted(
        (
            str(Fraction(x["percent"])),
            x["trigger"],
            x["days"],
            x["day_basis"],
            canonical(x["calendar"]),
        )
        for x in data["stages"]
    )


def trade_scope(ref, role, resolve):
    data = validate_config("trade_scope", resolve(ref, "trade_scope"))
    if data["role"] != role:
        fail("REFERENCE_INVALID", "/trade_scope/role")
    terms = validate_config("trade_terms", resolve(data["trade_terms_ref"], "trade_terms"))
    resolve(data["named_place_ref"], "location")
    check_transport(terms, data["allowed_modes"])
    for obligation in data["obligations"]:
        resolve(obligation["fee_type_ref"], "fee_type")
    return data


def check_transport(terms, modes):
    if terms["incoterm"] in ("FAS", "FOB", "CFR", "CIF") and any(mode != "sea" for mode in modes):
        fail("INVALID_KNOWN_VALUE", "/trade_scope/incoterm_transport")


def tax_application(ref, tax_ref, party_ref, subject_ref, kind, resolve):
    data = validate_config("tax_application", resolve(ref, "tax_application"))
    if (
        data["business_model"] != "CN-M01"
        or data["cost_kind"] != kind
        or data["counterparty_ref"] != party_ref
        or data["subject_ref"] != subject_ref
        or data["tax_profile_ref"] != tax_ref
    ):
        fail("REFERENCE_INVALID", "/tax_application/binding")
    validate_config("tax_profile", resolve(tax_ref, "tax_profile"))
    resolve(subject_ref, subject_ref["kind"])
    return data


def publication_dependencies(kind, data):
    if kind == "pricing_policy":
        return [data["calculation_currency"], data["tax_profile"]]
    if kind == "trade_scope":
        return [data["trade_terms_ref"], data["named_place_ref"]] + [
            x["fee_type_ref"] for x in data["obligations"]
        ]
    if kind == "tax_application":
        return [data["tax_profile_ref"], data["subject_ref"]]
    return []
