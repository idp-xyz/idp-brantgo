"""Executable contract rules/model. No business database or external actions."""

from copy import deepcopy
from datetime import datetime
from typing import Any

from .resource_budget import Fraction
from .validator import canonical, digest, fail, minor


def moment(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def active_interval(data, now):
    if not moment(data["valid_from"]) <= moment(now) < moment(data["valid_until"]):
        fail("REFERENCE_STALE", "/interval")


def tiers_cost(quantity, condition):
    q = Fraction(quantity)
    ts = condition["tiers"]
    mode = condition["pricing_mode"]
    basis = Fraction(condition["price_basis_quantity"])
    if condition.get("price_tier_scope", "sku") != "sku":
        fail("UNSUPPORTED_PRICING_MODE", "/price_tier_scope")
    if q <= 0 or basis <= 0:
        fail("INVALID_KNOWN_VALUE", "/quantity")
    if not ts or (mode == "flat" and len(ts) != 1):
        fail("PRICE_TIER_AMBIGUOUS", "/tiers")
    for i, t in enumerate(ts):
        lo = Fraction(t["lower_inclusive"])
        hi = Fraction(t["upper_exclusive"]) if "upper_exclusive" in t else None
        if lo < 0 or (i == 0 and lo != 0) or (hi is not None and hi <= lo):
            fail("PRICE_TIER_AMBIGUOUS", "/tiers")
        if i and (
            "upper_exclusive" not in ts[i - 1] or Fraction(ts[i - 1]["upper_exclusive"]) != lo
        ):
            fail("PRICE_TIER_AMBIGUOUS", "/tiers")
        if Fraction(t["unit_price"]) < 0:
            fail("INVALID_KNOWN_VALUE", "/tiers/unit_price")
        if Fraction(t["unit_price"]) == 0 and not t.get("zero_price_reason"):
            fail("COST_INPUT_NOT_READY", "/tiers/zero_price_reason")
    if "upper_exclusive" in ts[-1] and q >= Fraction(ts[-1]["upper_exclusive"]):
        fail("PRICE_TIER_AMBIGUOUS", "/quantity")
    if mode in ("flat", "all_units"):
        t = next(
            (
                t
                for t in ts
                if Fraction(t["lower_inclusive"]) <= q
                and ("upper_exclusive" not in t or q < Fraction(t["upper_exclusive"]))
            ),
            None,
        )
        if t is None:
            fail("PRICE_TIER_AMBIGUOUS", "/tiers")
        return q / basis * Fraction(t["unit_price"])
    if mode != "graduated":
        fail("UNSUPPORTED_PRICING_MODE", "/pricing_mode")
    total = Fraction(0)
    for t in ts:
        lo = Fraction(t["lower_inclusive"])
        hi = min(q, Fraction(t["upper_exclusive"])) if "upper_exclusive" in t else q
        total = Fraction(total + max(Fraction(0), hi - lo) / basis * Fraction(t["unit_price"]))
    return total


def purchase_groups(scenario, context, resolve, convert_quantity=None):
    """First path requires exact matching purchase/tier/price units; unsupported conversions reject."""
    demand = {x["line_id"]: x for x in context["lines"]}
    given: dict[str, Any] = {}
    prices: dict[Any, Any] = {}
    moqs: dict[Any, Any] = {}
    for a in scenario["allocations"]:
        line = demand.get(a["rfq_line_id"])
        if line is None:
            fail("REFERENCE_INVALID", "/allocations/rfq_line_id")
        src = a["source"]
        offer = resolve(src)
        if "rfq_line_ids" in offer and a["rfq_line_id"] not in offer["rfq_line_ids"]:
            fail("REFERENCE_INVALID", "/allocations/offer_line_scope")
        cond = next((x for x in offer["lines"] if x["id"] == src["condition_line_id"]), None)
        if cond is None or cond["sku_profile_ref"] != line["sku_profile_ref"]:
            fail("REFERENCE_INVALID", "/allocations/source")
        units = [
            a["purchase_unit_ref"],
            cond["purchase_unit_ref"],
            cond["price_unit_ref"],
            cond["tier_unit_ref"],
            cond["moq"]["unit_ref"],
            line["unit_ref"],
        ]
        if any(x != units[0] for x in units[:-1]):
            fail("DEPENDENCY_NOT_SUPPORTED", "/allocations/unit_conversion")
        if units[-1] != units[0] and convert_quantity is None:
            fail("DEPENDENCY_NOT_SUPPORTED", "/allocations/unit_conversion")
        q = Fraction(a["purchase_quantity"])
        if q <= 0 or q > 1000000:
            fail("INVALID_KNOWN_VALUE", "/allocations/purchase_quantity")
        base_q = (
            convert_quantity(q, units[0], units[-1], cond["sku_profile_ref"], cond)
            if convert_quantity
            else q
        )
        given[line["line_id"]] = given.get(line["line_id"], 0) + base_q
        source_key = (src["kind"], src["id"], src["revision"])
        key = source_key + (src["condition_line_id"],)
        group = prices.setdefault(
            key, {"quantity": Fraction(0), "condition": cond, "members": {}, "source_identity": key}
        )
        group["quantity"] += q
        group["members"][line["line_id"]] = group["members"].get(line["line_id"], 0) + q
        moq = cond["moq"]
        if moq["scope"] == "explicit_group":
            if line["line_id"] not in moq["member_line_ids"]:
                fail("REFERENCE_INVALID", "/moq/member_line_ids")
            mk = source_key + ("group", moq["group_id"])
        else:
            mk = source_key + ("sku", canonical(cond["sku_profile_ref"]))
        mg = moqs.setdefault(mk, {"quantity": Fraction(0), "rule": moq})

        def moq_signature(rule):
            return canonical(
                {
                    **rule,
                    "quantity": str(Fraction(rule["quantity"])),
                    **(
                        {"member_line_ids": sorted(rule["member_line_ids"])}
                        if "member_line_ids" in rule
                        else {}
                    ),
                }
            )

        if moq_signature(mg["rule"]) != moq_signature(moq):
            fail("REFERENCE_INVALID", "/moq/conflicting_group_rules")
        mg["quantity"] += q
    for group in moqs.values():
        if group["quantity"] < Fraction(group["rule"]["quantity"]):
            fail("MOQ_NOT_MET", "/allocations")
    if given != {k: Fraction(v["quantity"]) for k, v in demand.items()}:
        fail("COMPARISON_BASIS_MISMATCH", "/allocations")
    for group in prices.values():
        cond = group["condition"]
        multiple = Fraction(cond.get("order_multiple", "1"))
        if "order_multiple" in cond and (group["quantity"] / multiple).denominator != 1:
            fail("ORDER_MULTIPLE_INVALID", "/allocations")
        group["raw_amount"] = tiers_cost(group["quantity"], cond)
    return list(prices.values())


def fee_graph(components):
    by = {c["id"]: c for c in components}
    if len(by) != len(components):
        fail("DUPLICATE_LINE_ID", "/components")
    obligations = {}
    for c in components:
        if c["obligation_id"] in obligations:
            fail("CHARGE_DOUBLE_COUNT", "/components")
        obligations[c["obligation_id"]] = c["id"]
        target = c.get("included_in_component_ref")
        if target and target not in by:
            fail("REFERENCE_INVALID", "/components/included_in_component_ref")
    for c in components:
        seen = set()
        node = c
        while node.get("included_in_component_ref"):
            if node["id"] in seen:
                fail("CHARGE_DOUBLE_COUNT", "/components/inclusion_cycle")
            seen.add(node["id"])
            if len(seen) > 8:
                fail("CALCULATION_LIMIT_EXCEEDED", "/components/inclusion_depth")
            node = by[node["included_in_component_ref"]]
    return [c for c in components if "included_in_component_ref" not in c]


def split_tax(value, tax, precision=2):
    if tax["recovery_treatment"] == "unknown":
        fail("TAX_TREATMENT_UNKNOWN", "/tax")
    if tax["recovery_treatment"] not in ("recoverable", "nonrecoverable"):
        fail("DEPENDENCY_NOT_SUPPORTED", "/tax")
    scale = 10**precision
    rate = Fraction(tax["rate"])
    v = Fraction(value)
    if v < 0 or not 0 <= rate <= 1:
        fail("INVALID_KNOWN_VALUE", "/tax")
    if tax["price_basis"] == "inclusive":
        gross = minor(v, precision)
        net = minor(Fraction(gross, scale) / (1 + rate), precision)
        tax_minor = gross - net
    elif tax["price_basis"] == "exclusive":
        net = minor(v, precision)
        tax_minor = minor(Fraction(net, scale) * rate, precision)
        gross = net + tax_minor
    elif tax["price_basis"] == "not_applicable":
        if rate != 0:
            fail("INVALID_KNOWN_VALUE", "/tax/rate")
        net = minor(v, precision)
        tax_minor = 0
        gross = net
    else:
        fail("SCHEMA_INVALID", "/tax/price_basis")
    return {
        "net_minor": net,
        "tax_minor": tax_minor,
        "gross_minor": gross,
        "cost_minor": net if tax["recovery_treatment"] == "recoverable" else gross,
    }


def fx_cost(value, from_code, to_code, fx, now, max_age, precision=2):
    if from_code == to_code:
        if fx is not None:
            fail("FX_NOT_APPLICABLE", "/fx")
        return minor(value, precision)
    if fx is None or (fx["from_currency"], fx["to_currency"], fx["purpose"]) != (
        from_code,
        to_code,
        "cost_estimate",
    ):
        fail("FX_NOT_APPLICABLE", "/fx")
    active_interval(fx, now)
    age = (moment(now) - moment(fx["observed_at"])).total_seconds()
    if age < 0 or age > max_age or not 0 < Fraction(fx["rate"]) <= 1000:
        fail("FX_NOT_APPLICABLE", "/fx")
    return minor(Fraction(value) * Fraction(fx["rate"]), precision)


def chargeable(packages, rule):
    increment = Fraction(rule["billing_increment"])
    if increment <= 0:
        fail("INVALID_KNOWN_VALUE", "/billing_increment")
    if rule["kind"] == "max_actual_volumetric" and rule["max_scope"] != rule["rounding_scope"]:
        fail("UNSUPPORTED_PRICING_MODE", "/scope")

    def round_q(q):
        v = q / increment
        if rule["rounding_mode"] == "ceil":
            return (-(-v.numerator // v.denominator)) * increment
        if rule["rounding_mode"] == "half_up":
            return minor(v, 0) * increment
        fail("SCHEMA_INVALID", "/rounding_mode")

    def values(p):
        weight = Fraction(p["gross_kg"])
        volume = Fraction(p["length_m"]) * Fraction(p["width_m"]) * Fraction(p["height_m"])
        if rule["kind"] == "actual_weight":
            return weight, weight
        if rule["kind"] == "volume":
            return volume, volume
        divisor = Fraction(rule["divisor_m3_per_kg"])
        if divisor <= 0:
            fail("INVALID_KNOWN_VALUE", "/divisor")
        # Declared divisor unit is M3/KG; volumetric KG = M3 / (M3/KG).
        return weight, volume / divisor

    pairs = [(p["count"], values(p)) for p in packages]
    if rule["rounding_scope"] == "per_package":
        return sum(n * round_q(max(w, v)) for n, (w, v) in pairs)
    if rule["rounding_scope"] == "shipment":
        return round_q(max(sum(n * w for n, (w, v) in pairs), sum(n * v for n, (w, v) in pairs)))
    fail("SCHEMA_INVALID", "/rounding_scope")


def bill(quantity, billing):
    if billing["kind"] == "fixed":
        return Fraction(billing["amount"])
    if billing["kind"] == "per_basis":
        raw = Fraction(quantity) / Fraction(billing["basis_quantity"]) * Fraction(billing["rate"])
    elif billing["kind"] == "tiered":
        raw = tiers_cost(
            quantity,
            {
                **billing,
                "price_basis_quantity": billing["basis_quantity"],
                "price_tier_scope": "sku",
            },
        )
    else:
        fail("UNSUPPORTED_PRICING_MODE", "/billing")
    return max(raw, Fraction(billing["minimum_amount"]))


def source_effect(terms, origin, now):
    if origin.get("denied"):
        fail("REFERENCE_STALE", "/source_denial")
    if not origin.get("readable"):
        fail("PERMISSION_DENIED", "/")
    active_interval(terms["interval"], now)
    if not terms.get("active", True):
        fail("REFERENCE_STALE", "/terms")
    if terms["validity_mode"] == "dependent_validity":
        active_interval(origin["interval"], now)
        if not origin.get("active", True):
            fail("REFERENCE_STALE", "/source_offer")


def dependency_access(root, resolve, max_nodes=5000):
    visiting = set()
    done = set()
    budget = [0]

    def walk(key, depth):
        if depth > 8 or budget[0] > 10000:
            fail("CALCULATION_LIMIT_EXCEEDED", "/dependencies")
        budget[0] += 1
        if key in visiting:
            fail("REFERENCE_INVALID", "/dependency_cycle")
        if key in done:
            return
        node = resolve(key)
        if not node["readable"]:
            fail("PERMISSION_DENIED", "/")
        if node.get("denied"):
            fail("REFERENCE_STALE", "/source_denial")
        visiting.add(key)
        for child in node.get("dependencies", []):
            walk(child, depth + 1)
        visiting.remove(key)
        done.add(key)
        if len(done) > max_nodes:
            fail("CALCULATION_LIMIT_EXCEEDED", "/dependencies")

    walk(root, 0)
    return done


class RevisionModel:
    """Sequential contract state model: not SSO, database CAS or concurrency proof."""

    def __init__(self, kind="offer", independent=True):
        self.kind = kind
        self.version = 0
        self.last = 0
        self.working = None
        self.active = None
        self.revisions = {}
        self.events = []
        self.independent = independent
        self.replays = {}
        self.access: dict[str, Any] = {}

    def apply(self, actor, command, key, args):
        if command not in actor["grants"]:
            fail("PERMISSION_DENIED", "/")
        signature = digest(args)
        replay_key = (command, key)
        if not actor.get("readable", True):
            fail("PERMISSION_DENIED", "/")
        if replay_key in self.replays:
            old, answer = self.replays[replay_key]
            if old != signature:
                fail("IDEMPOTENCY_PAYLOAD_CONFLICT", "/")
            if not actor.get("readable", True):
                fail("PERMISSION_DENIED", "/")
            return {**deepcopy(answer), "replayed": True}
        if args["expected_version"] != self.version:
            fail("VERSION_CONFLICT", "/expected_version")
        before = deepcopy(self.__dict__)
        try:
            if command in ("verify", "publish", "withdraw", "retire") and actor["kind"] != "human":
                fail("PERMISSION_DENIED", "/")
            if command == "save_draft":
                if self.working is None:
                    if self.active is not None or any(r["sealed"] for r in self.revisions.values()):
                        fail("INVALID_STATE", "/working_revision")
                    self.last += 1
                    self.working = self.last
                    self.revisions[self.last] = {
                        "creator": actor["id"],
                        "sealed": False,
                        "data": {},
                    }
                self.revisions[self.working]["data"] = deepcopy(args["data"])
                draft = self.revisions[self.working]
                draft["contributors"] = sorted(set(draft.get("contributors", []) + [actor["id"]]))
            elif command == "revise":
                base = self.revisions.get(args["base_revision"])
                if self.working is not None or base is None or not base["sealed"]:
                    fail("INVALID_STATE", "/base_revision")
                self.last += 1
                self.working = self.last
                self.revisions[self.last] = {
                    "creator": actor["id"],
                    "contributors": [actor["id"]],
                    "sealed": False,
                    "data": deepcopy(base["data"]),
                }
            elif command == "discard_draft":
                if self.working is None or args["working_revision"] != self.working:
                    fail("INVALID_STATE", "/working_revision")
                self.events.append(("discard", self.working))
                self.working = None
            elif command in ("verify", "publish"):
                if self.working is None or args["working_revision"] != self.working:
                    fail("INVALID_STATE", "/working_revision")
                if self.active != args.get("supersedes_revision"):
                    fail("REFERENCE_STALE", "/supersedes_revision")
                draft = self.revisions[self.working]
                if (self.kind == "purchase_terms" or self.independent) and actor["id"] in draft.get(
                    "contributors", [draft["creator"]]
                ):
                    fail("PERMISSION_DENIED", "/")
                if not args.get("evidence"):
                    fail("COST_INPUT_NOT_READY", "/evidence")
                draft["sealed"] = True
                if self.active:
                    self.events.append(("superseded", self.active))
                self.active = self.working
                self.working = None
                self.events.append((command, self.active))
            elif command in ("withdraw", "retire"):
                target = args["target_revision"]
                if target not in self.revisions or not self.revisions[target]["sealed"]:
                    fail("INVALID_STATE", "/target_revision")
                if target == self.active:
                    self.active = None
                self.events.append((command, target))
            else:
                fail("UNSUPPORTED_CONTRACT", "/command")
            self.version += 1
            answer = {
                "version": self.version,
                "active": self.active,
                "working": self.working,
                "replayed": False,
            }
            self.replays[replay_key] = (signature, deepcopy(answer))
            return answer
        except Exception:
            self.__dict__ = before
            raise


def verified_estimate_allowed(kind, policy):
    if kind == "estimated" and not policy.get("allow_verified_estimates", False):
        fail("COST_INPUT_NOT_READY", "/estimate_policy")


def check_output(result):
    ids = [c["id"] for c in result["components"]]
    if len(set(ids)) != len(ids):
        fail("DUPLICATE_LINE_ID", "/result/components")
    if sum(int(c["amount_minor"]) for c in result["components"]) != int(result["total_minor"]):
        fail("ALLOCATION_INVALID", "/result/total_minor")
    for c in result["components"]:
        if sum(int(x["amount_minor"]) for x in c["allocations"]) != int(c["amount_minor"]):
            fail("ALLOCATION_INVALID", "/result/components/allocations")
        ls = [x["line_id"] for x in c["allocations"]]
        if len(ls) != len(set(ls)):
            fail("DUPLICATE_LINE_ID", "/result/components/allocations")
    if (
        result["kind"] == "snapshot"
        and result["frozen_scenario_version"] != result["input_scenario_version"] + 1
    ):
        fail("VERSION_CONFLICT", "/result/frozen_scenario_version")
