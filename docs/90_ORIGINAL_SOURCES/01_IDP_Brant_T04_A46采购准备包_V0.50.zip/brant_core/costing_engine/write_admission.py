"""Command-time dependency admission for the bounded sequential T02 reference.

Drafts may be incomplete. Supplied references must exist and be readable;
sealing additionally requires current effect and cross-field readiness. Historical
actions and successful replays check access without reactivating expired data.
"""

from copy import deepcopy
from typing import TYPE_CHECKING, Any

from jsonschema import Draft202012Validator

from .access_rules import read_row
from .commercial_rules import payment, tax_application, trade_scope
from .delivery_rules import resolve_delivery
from .resource_budget import Budget, Fraction
from .rules import moment
from .strict_formats import FormatChecker
from .validator import SCHEMA, canonical, fail, minor, tiers, unique

ROOT_KINDS = {
    "costing_context",
    "supplier_offer",
    "purchase_terms",
    "logistics_offer",
    "service_party_role",
}
BUSINESS_KINDS = ROOT_KINDS | {"measurement", "delivery_anchor"}
FIELD_KINDS = {
    "sku_profile_ref": "sku_profile",
    "unit_ref": "unit",
    "purchase_unit_ref": "unit",
    "price_unit_ref": "unit",
    "tier_unit_ref": "unit",
    "currency_ref": "currency",
    "calculation_currency_ref": "currency",
    "requested_currency_ref": "currency",
    "pricing_policy_ref": "pricing_policy",
    "tax_profile_ref": "tax_profile",
    "trade_terms_ref": "trade_terms",
    "requested_trade_terms_ref": "trade_terms",
    "payment_terms_ref": "payment_terms",
    "requested_payment_terms_ref": "payment_terms",
    "sales_payment_terms_ref": "payment_terms",
    "sales_trade_scope_ref": "trade_scope",
    "purchase_trade_scope_ref": "trade_scope",
    "tax_application_ref": "tax_application",
    "named_place_ref": "location",
    "origin_ref": "location",
    "destination_ref": "location",
    "place_ref": "location",
    "fee_type_ref": "fee_type",
    "context_ref": "costing_context",
    "source_offer_ref": "supplier_offer",
    "service_role_ref": "service_party_role",
    "measurement_ref": "measurement",
    "anchor_ref": "delivery_anchor",
    "conversion_refs": "conversion",
    "fx_refs": "fx",
    "logistics_offer_refs": "logistics_offer",
    "required_fee_type_refs": "fee_type",
    "from_unit": "unit",
    "to_unit": "unit",
    "sku_profile": "sku_profile",
    "calendar": "calendar",
    "calendar_ref": "delivery_calendar",
}
HUMAN_ACTIONS = {
    "verify",
    "publish",
    "withdraw",
    "retire",
    "record_verified",
    "supersede",
    "record_issued",
    "close",
    "record",
    "freeze",
}


class WriteAdmission:
    if TYPE_CHECKING:
        registry: dict[str, Any]
        roots: dict[Any, Any]
        rfqs: dict[str, Any]
        measurements: dict[str, Any]
        denials: dict[str, Any]
        scenarios: dict[str, Any]
        clock: str
        _write_manifest: dict[Any, Any]
        _budget: Budget
        _remember: Any
        _cfg: Any
        _business: Any
        _master: Any
        _ready: Any
        _source: Any

    def _read_row(self, row):
        """Server projection of current access; never accepts identity from a request."""
        read_row(getattr(self, "_actor", None), row)

    def _rfq(self, ref, manifest, current=True):
        rows = [x for x in self.registry["rfqs"] if x["id"] == ref["id"]]
        row = next((x for x in rows if x["row_version"] == ref["row_version"]), None)
        if row is None:
            fail("REFERENCE_STALE" if current else "PERMISSION_DENIED", "/rfq")
        self._read_row(row)
        if current and (
            row["status"] != "ready" or row["row_version"] != max(x["row_version"] for x in rows)
        ):
            fail("REFERENCE_STALE", "/rfq")
        self._remember(manifest, "rfq", row["id"], row["row_version"], row)
        return row

    def _anchor_capability(self, id_):
        supported = self.registry.get("delivery_anchor_event_kinds")
        if supported is not None and id_.split(":", 1)[0] not in supported:
            fail("DEPENDENCY_NOT_SUPPORTED", "/delivery_anchor/event_mapping")

    def _read_dependency(self, kind, id_, version):
        """Resolve only current read rights to an exact historical dependency."""
        if kind.startswith("target."):
            kind = kind.split(".", 1)[1]
            if kind in ROOT_KINDS:
                row = getattr(self.roots.get((kind, id_)), "access", None)
            else:
                row = (
                    self.rfqs
                    if kind == "supplier_rfq"
                    else self.measurements
                    if kind == "measurement"
                    else self.denials
                    if kind == "source_denial"
                    else self.scenarios
                ).get(id_)
            self._read_row(row)
            return
        if kind.startswith("foundation_publication."):
            kind = kind.split(".", 1)[1]
        if kind.startswith("business_verification."):
            kind = kind.split(".", 1)[1]
        if kind == "context_provenance":
            kind = "costing_context"
        if kind == "delivery_anchor":
            self._anchor_capability(id_)
        row = None
        if kind == "source":
            row = next((x for x in self.registry["sources"] if x["id"] == id_), None)
        elif kind == "rfq":
            row = next(
                (
                    x
                    for x in self.registry["rfqs"]
                    if x["id"] == id_ and x["row_version"] == version
                ),
                None,
            )
        elif kind.startswith("master."):
            ref = {"kind": kind.split(".", 1)[1], "id": id_, "row_version": version}
            if ref in self.registry["masters"]:
                row = next(
                    (x for x in self.registry.get("master_metadata", []) if x["ref"] == ref), {}
                )
        elif kind == "supplier_rfq":
            row = self.rfqs.get(id_)
            if row is not None and version not in (row["version"], row.get("issued_version")):
                row = None
        elif kind == "measurement" and id_ in self.measurements:
            row = self.measurements[id_]
            if version not in row["revisions"]:
                row = None
        elif (kind, id_) in self.roots:
            root = self.roots[kind, id_]
            row = getattr(root, "access", {}) if version in root.revisions else None
        elif kind == "cost_scenario":
            row = self.scenarios.get(id_)
        else:
            row = next(
                (
                    x
                    for x in self.registry["configs"] + self.registry["verified_business"]
                    if x["ref"] == {"kind": kind, "id": id_, "revision": version}
                ),
                None,
            )
        self._read_row(row)

    def _access_document(self, data, manifest, field="", trail=(), historical=False):
        """Resolve every typed reference, including transitive configuration sources."""
        if isinstance(data, list):
            for item in data:
                self._access_document(item, manifest, field, trail, historical)
            return
        if not isinstance(data, dict):
            return
        if {"kind", "id", "revision"} <= data.keys():
            kind = {"offer": "supplier_offer"}.get(data["kind"], data["kind"])
            ref = {"kind": kind, "id": data["id"], "revision": data["revision"]}
            expected = FIELD_KINDS.get(field)
            if expected and kind != expected:
                fail("REFERENCE_INVALID", "/" + field)
            key = (kind, ref["id"], ref["revision"])
            if key in trail:
                fail("REFERENCE_INVALID", "/dependency_cycle")
            if len(trail) >= 8:
                fail("CALCULATION_LIMIT_EXCEEDED", "/dependency_depth")
            if historical:
                self._read_dependency(*key)
                if kind == "measurement" and ref["id"] in self.measurements:
                    resolved = self.measurements[ref["id"]]["revisions"][ref["revision"]]
                    verification = (
                        self.measurements[ref["id"]]
                        .get("verification", {})
                        .get(ref["revision"], {})
                    )
                    self._access_document(
                        verification, manifest, trail=trail + (key,), historical=True
                    )
                elif key[:2] in self.roots:
                    record = self.roots[key[:2]].revisions[ref["revision"]]
                    resolved = record["data"]
                    for e in record.get("verification_evidence", []):
                        self._access_document(e, manifest, trail=trail + (key,), historical=True)
                    if "verification_policy_ref" in record:
                        self._access_document(
                            record["verification_policy_ref"],
                            manifest,
                            trail=trail + (key,),
                            historical=True,
                        )
                else:
                    row = next(
                        x
                        for x in self.registry["configs"] + self.registry["verified_business"]
                        if x["ref"] == ref
                    )
                    resolved = row["data"]
                    for e in row.get("publication_evidence", []):
                        self._access_document(e, manifest, trail=trail + (key,), historical=True)
                    for e in row.get("origin_evidence", []):
                        self._access_document(e, manifest, trail=trail + (key,), historical=True)
                    for dep in row.get("reference_dependencies", []):
                        self._access_document(dep, manifest, trail=trail + (key,), historical=True)
                self._remember(manifest, *key, resolved, historical=True)
            else:
                resolved = (
                    self._business(ref, manifest, kind)
                    if kind in BUSINESS_KINDS
                    else self._cfg(ref, manifest, kind)
                )
            # Independent conditions retain their original offer as provenance, not a
            # current calculation policy. Its source evidence still has current effect.
            if kind == "purchase_terms" and resolved.get("validity_mode") == "independent_validity":
                for k, v in resolved.items():
                    self._access_document(
                        v, manifest, k, trail + (key,), historical or k == "source_offer_ref"
                    )
                if not historical:
                    origin = self._business(
                        resolved["source_offer_ref"], manifest, "supplier_offer", check_effect=False
                    )
                    if origin["supplier_ref"] != resolved["supplier_ref"]:
                        fail("REFERENCE_INVALID", "/purchase_terms/supplier_ref")
            else:
                # historical=True checks the complete read-rights closure, not
                # whether old commercial revisions are currently effective.
                self._access_document(
                    resolved, manifest, trail=trail + (key,), historical=historical
                )
            return
        if {"kind", "id", "row_version"} <= data.keys():
            ref = {k: data[k] for k in ("kind", "id", "row_version")}
            if (
                field in ("supplier_ref", "party_ref", "counterparty_ref")
                and ref["kind"] != "supplier"
            ):
                fail("REFERENCE_INVALID", "/" + field)
            if historical:
                self._read_dependency("master." + ref["kind"], ref["id"], ref["row_version"])
                self._remember(
                    manifest, "master." + ref["kind"], ref["id"], ref["row_version"], ref
                )
            else:
                self._master(ref, manifest, ref["kind"])
            return
        if field == "rfq_ref":
            self._rfq(data, manifest, not historical)
            return
        if field == "supplier_rfq_ref":
            row = self.rfqs.get(data["id"])
            if row is None:
                fail("REFERENCE_STALE", "/supplier_rfq")
            self._read_row(row)
            if row.get("issued_version") != data["row_version"] or row["status"] not in (
                "issued",
                "closed",
            ):
                fail("REFERENCE_STALE", "/supplier_rfq")
            self._remember(manifest, "supplier_rfq", data["id"], data["row_version"], row)
            self._access_document(row["data"], manifest, trail=trail, historical=historical)
            return
        if "source_id" in data:
            if historical:
                self._read_dependency("source", data["source_id"], 1)
                source = next(x for x in self.registry["sources"] if x["id"] == data["source_id"])
            else:
                source = self._source(data["source_id"])
            self._remember(manifest, "source", data["source_id"], 1, source)
        for k, v in data.items():
            origin_history = (
                k == "source_offer_ref" and data.get("validity_mode") == "independent_validity"
            )
            self._access_document(v, manifest, k, trail, historical or origin_history)
            if origin_history and not historical:
                self._business(v, manifest, "supplier_offer", check_effect=False)

    def _verification_policy(self, kind, data, manifest):
        if kind == "costing_context":
            ref = data["pricing_policy_ref"]
        else:
            ref = self.registry.get("verification_policy_ref")
            if ref is None:
                fail("COST_INPUT_NOT_READY", "/verification_policy_ref")
        policy = self._cfg(ref, manifest, "pricing_policy")
        if type(policy.get("independent_review")) is not bool:
            fail("COST_INPUT_NOT_READY", "/policy/independent_review")
        self._admission_policy_ref = deepcopy(ref)
        return policy

    def _delivery_ready(self, data, manifest):
        anchor = calendar = None
        if data["kind"] == "lead_time":
            anchor = self._business(data["anchor_ref"], manifest, "delivery_anchor")
            calendar = self._cfg(data["calendar_ref"], manifest, "delivery_calendar")
        resolve_delivery(data, anchor, calendar, self.clock)

    def _quantity_ready(self, value, ref, manifest):
        unit = self._cfg(ref, manifest, "unit")
        q = Fraction(value)
        scale = len(value.split(".")[1]) if "." in value else 0
        if (
            q <= 0
            or q > 1000000
            or scale > min(6, unit["precision"])
            or (q * 10 ** min(6, unit["precision"])).denominator != 1
        ):
            fail("INVALID_KNOWN_VALUE", "/quantity")

    def _document_ready(self, kind, data, manifest):
        def resolve(r, k):
            return self._cfg(r, manifest, k)

        if kind == "costing_context":
            rfq = self._rfq(data["rfq_ref"], manifest)
            unique(data["lines"], "/lines", "line_id")
            left = sorted(data["lines"], key=lambda x: x["line_id"])
            right = sorted(rfq["lines"], key=lambda x: x["line_id"])
            if data["context_kind"] == "actual" and canonical(left) != canonical(right):
                fail("COMPARISON_BASIS_MISMATCH", "/context_lines")
            if data["context_kind"] == "what_if" and (
                [x["line_id"] for x in left] != [x["line_id"] for x in right]
                or any(
                    x["sku_profile_ref"] != y["sku_profile_ref"] or x["unit_ref"] != y["unit_ref"]
                    for x, y in zip(left, right)
                )
            ):
                fail("COMPARISON_BASIS_MISMATCH", "/what_if_line_identity")
            policy = self._verification_policy(kind, data, manifest)
            currency = policy.get("calculation_currency")
            if (currency["id"] if isinstance(currency, dict) else currency) != data[
                "calculation_currency_ref"
            ]["id"]:
                fail("REFERENCE_INVALID", "/policy_currency")
            for line in data["lines"]:
                self._quantity_ready(line["quantity"], line["unit_ref"], manifest)
                sku = resolve(line["sku_profile_ref"], "sku_profile")
                self._master(
                    {
                        "kind": "sku",
                        "id": sku["sku_id"],
                        "row_version": sku.get("sku_row_version", 1),
                    },
                    manifest,
                    "sku",
                )
            trade_scope(data["comparison_basis"]["sales_trade_scope_ref"], "export_sale", resolve)
            payment(data["comparison_basis"]["sales_payment_terms_ref"], resolve)
            self._delivery_ready(data["comparison_basis"]["delivery"], manifest)
        elif kind in ("supplier_offer", "purchase_terms"):
            unique(data["lines"], "/lines", "id")
            group_rules: dict[str, str] = {}
            if kind == "supplier_offer":
                rfq = self._rfq(data["rfq_ref"], manifest)
                ids = data["rfq_line_ids"]
                unique(ids, "/rfq_line_ids")
                if not set(ids) <= {x["line_id"] for x in rfq["lines"]}:
                    fail("REFERENCE_INVALID", "/rfq_line_ids")
                allowed_skus = {
                    canonical(x["sku_profile_ref"]) for x in rfq["lines"] if x["line_id"] in ids
                }
                if any(canonical(x["sku_profile_ref"]) not in allowed_skus for x in data["lines"]):
                    fail("REFERENCE_INVALID", "/offer/sku")
                if data["origin"]["kind"] == "in_response_to_rfq":
                    request = self.rfqs[data["origin"]["supplier_rfq_ref"]["id"]]["data"]
                    if (
                        request["supplier_ref"] != data["supplier_ref"]
                        or request["rfq_ref"] != data["rfq_ref"]
                        or not set(ids) <= set(request["rfq_line_ids"])
                    ):
                        fail("REFERENCE_INVALID", "/supplier_rfq/binding")
            else:
                origin = self._business(
                    data["source_offer_ref"],
                    manifest,
                    "supplier_offer",
                    check_effect=data["validity_mode"] == "dependent_validity",
                )
                if origin["supplier_ref"] != data["supplier_ref"]:
                    fail("REFERENCE_INVALID", "/purchase_terms/supplier_ref")
            for line in data["lines"]:
                tiers(line, "/lines/tiers")
                for t in line["tiers"]:
                    if Fraction(t["unit_price"]) == 0 and not t.get("zero_price_reason"):
                        fail("COST_INPUT_NOT_READY", "/zero_price_reason")
                for f in ("price_unit_ref", "tier_unit_ref"):
                    if line[f] != line["purchase_unit_ref"]:
                        fail("UNSUPPORTED_PRICING_MODE", "/condition_unit")
                if line["moq"]["unit_ref"] != line["purchase_unit_ref"]:
                    fail("REFERENCE_INVALID", "/moq/unit_ref")
                self._quantity_ready(line["price_basis_quantity"], line["price_unit_ref"], manifest)
                self._quantity_ready(line["moq"]["quantity"], line["moq"]["unit_ref"], manifest)
                if "order_multiple" in line:
                    self._quantity_ready(
                        line["order_multiple"], line["purchase_unit_ref"], manifest
                    )
                if line["moq"]["scope"] == "explicit_group":
                    members = line["moq"]["member_line_ids"]
                    unique(members, "/moq/member_line_ids")
                    demand_ref = data["rfq_ref"] if kind == "supplier_offer" else origin["rfq_ref"]
                    demand = self._rfq(demand_ref, manifest)
                    if not set(members) <= {x["line_id"] for x in demand["lines"]}:
                        fail("REFERENCE_INVALID", "/moq/member_line_ids")
                    rule = {
                        **line["moq"],
                        "member_line_ids": sorted(members),
                        "quantity": str(Fraction(line["moq"]["quantity"])),
                    }
                    signature = canonical(rule)
                    previous = group_rules.setdefault(line["moq"]["group_id"], signature)
                    if previous != signature:
                        fail("REFERENCE_INVALID", "/moq/conflicting_group_rules")
                unique(line["included_obligation_ids"], "/included_obligation_ids")
                trade_scope(line["purchase_trade_scope_ref"], "supplier_purchase", resolve)
                payment(line["payment_terms_ref"], resolve)
                tax_application(
                    line["tax_application_ref"],
                    line["tax_profile_ref"],
                    data["supplier_ref"],
                    line["sku_profile_ref"],
                    "goods",
                    resolve,
                )
                self._delivery_ready(line["delivery"], manifest)
        elif kind == "supplier_rfq":
            rfq = self._rfq(data["rfq_ref"], manifest)
            unique(data["rfq_line_ids"], "/rfq_line_ids")
            if not set(data["rfq_line_ids"]) <= {x["line_id"] for x in rfq["lines"]}:
                fail("REFERENCE_INVALID", "/rfq_line_ids")
        elif kind == "logistics_offer":
            role = self._business(data["service_role_ref"], manifest, "service_party_role")
            if any(data[k] != role[k] for k in ("service_code", "origin_ref", "destination_ref")):
                fail("REFERENCE_INVALID", "/service_role")
            unique(data["fees"], "/fees", "id")
            if len({x["obligation_id"] for x in data["fees"]}) != len(data["fees"]):
                fail("CHARGE_DOUBLE_COUNT", "/fee_obligation")
            for fee in data["fees"]:
                tax_application(
                    fee["tax_application_ref"],
                    fee["tax_profile_ref"],
                    role["party_ref"],
                    fee["fee_type_ref"],
                    "service",
                    resolve,
                )
                if (
                    fee["billing"]["kind"] == "fixed"
                    and Fraction(fee["billing"]["amount"]) == 0
                    and not fee.get("zero_price_reason")
                ):
                    fail("COST_INPUT_NOT_READY", "/fee_zero_price_reason")
                allocation = fee["allocation"]
                if allocation["basis"] == "explicit":
                    unique(allocation["weights"], "/weights", "line_id")
                    if sum(int(x["weight"]) for x in allocation["weights"]) == 0:
                        fail("ALLOCATION_INVALID", "/weights")
                else:
                    unique(allocation["target_line_ids"], "/target_line_ids")
                    if (
                        allocation["basis"] in ("weight", "volume")
                        and "measurement_ref" not in allocation
                    ):
                        fail("COST_INPUT_NOT_READY", "/measurement_ref")
                charge = fee["chargeable"]
                if charge["kind"] == "fixed" and fee["billing"]["kind"] != "fixed":
                    fail("UNSUPPORTED_PRICING_MODE", "/billing/chargeable_basis")
                if (
                    charge["kind"] == "max_actual_volumetric"
                    and charge["rounding_scope"] != charge["max_scope"]
                ):
                    fail("UNSUPPORTED_PRICING_MODE", "/max_scope")
                if fee["billing"]["kind"] == "tiered":
                    tiers(fee["billing"], "/billing/tiers")
        elif kind == "measurement":
            if moment(data["observed_at"]) > moment(self.clock):
                fail("INVALID_KNOWN_VALUE", "/measurement/observed_at")
            unique(data["packages"], "/packages", "id")
            volume = Fraction(0)
            for package in data["packages"]:
                unique(package["line_ids"], "/package/line_ids")
                if Fraction(package["gross_kg"]) < Fraction(package["net_kg"]):
                    fail("INVALID_KNOWN_VALUE", "/measurement/gross_kg")
                volume += (
                    package["count"]
                    * Fraction(package["length_m"])
                    * Fraction(package["width_m"])
                    * Fraction(package["height_m"])
                )
            if "declared_volume_m3" in data and minor(volume, 6) != minor(
                data["declared_volume_m3"], 6
            ):
                fail("MEASUREMENT_CONFLICT", "/measurement/volume")

    def _admit_write(self, actor, cmd, args):
        kind, action = cmd.split(".")
        id_ = args.get("id", args.get("scenario_id"))
        manifest = self._write_manifest
        # State/CAS precedes private dependency lookup. The dispatcher repeats these
        # checks when applying, as a second guard within this sequential model.
        root: Any = self.roots.get((kind, id_)) if kind in ROOT_KINDS else None
        obj: Any = (
            self.rfqs.get(id_)
            if kind == "supplier_rfq"
            else self.measurements.get(id_)
            if kind == "measurement"
            else self.scenarios.get(id_)
            if kind in ("cost_scenario", "cost_snapshot")
            else None
        )
        if root is not None:
            self._read_row(getattr(root, "access", {}))
            if root.version != args["expected_version"]:
                fail("VERSION_CONFLICT", "/expected_version")
        if obj is not None:
            self._read_row(obj)
            if obj["version"] != args["expected_version"]:
                fail("VERSION_CONFLICT", "/expected_version")
        if (
            kind in ROOT_KINDS
            and root is None
            and (action != "save_draft" or args["expected_version"] != 0)
        ):
            fail("NOT_FOUND", "/")
        if (
            kind in ("supplier_rfq", "cost_scenario")
            and obj is None
            and (action != "save_draft" or args["expected_version"] != 0)
        ):
            fail("NOT_FOUND", "/")
        if kind == "measurement" and action != "record_verified" and obj is None:
            fail("NOT_FOUND", "/")
        if kind == "measurement" and action == "record_verified" and obj is not None:
            fail("VERSION_CONFLICT", "/expected_version")
        if (
            kind == "measurement"
            and action == "supersede"
            and obj["active"] != args["active_revision"]
        ):
            fail("REFERENCE_STALE", "/active_revision")
        if (
            kind == "supplier_rfq"
            and action in ("record_issued", "close")
            and obj["status"] != ("draft" if action == "record_issued" else "issued")
        ):
            fail("INVALID_STATE", "/status")
        data = (
            args.get("data")
            if action in ("save_draft", "record_verified", "supersede")
            else root.revisions[root.working]["data"]
            if root is not None and root.working is not None
            else None
        )
        if data is not None:
            self._budget.observe(
                kind, id_, root.working if root is not None and root.working else 1, data
            )
        if action in ("verify", "publish"):
            if root.working is None or root.working != args["working_revision"]:
                fail("INVALID_STATE", "/working_revision")
            if root.active != args.get("supersedes_revision"):
                fail("REFERENCE_STALE", "/supersedes_revision")
            draft = root.revisions[root.working]
            self._ready(kind, draft["data"])
            policy = self._verification_policy(kind, draft["data"], manifest)
            if (kind == "purchase_terms" or policy["independent_review"]) and actor[
                "id"
            ] in draft.get("contributors", [draft["creator"]]):
                fail("PERMISSION_DENIED", "/")
            self._access_document(draft["data"], manifest)
            self._document_ready(kind, draft["data"], manifest)
        elif action == "save_draft":
            if (
                root is not None
                and root.working is None
                and (root.active is not None or any(x["sealed"] for x in root.revisions.values()))
            ):
                fail("INVALID_STATE", "/working_revision")
            if obj is not None and obj.get("status") != "draft":
                fail("INVALID_STATE", "/status")
            self._access_document(args["data"], manifest, historical=True)
        elif action in ("revise", "discard_draft", "withdraw", "retire") and root is not None:
            revision = args.get(
                "base_revision", args.get("working_revision", args.get("target_revision"))
            )
            record = root.revisions.get(revision)
            if record is None:
                fail("INVALID_STATE", "/revision")
            self._access_document(record["data"], manifest, historical=True)
        elif kind == "supplier_rfq":
            self._access_document(obj["data"], manifest, historical=action == "close")
            if action == "record_issued":
                if not Draft202012Validator(
                    {"$defs": SCHEMA["$defs"], "$ref": "#/$defs/supplier_rfq"},
                    format_checker=FormatChecker(),
                ).is_valid(obj["data"]):
                    fail("COST_INPUT_NOT_READY", "/data")
                self._document_ready(kind, obj["data"], manifest)
        elif kind == "measurement":
            if action in ("record_verified", "supersede"):
                self._access_document(args["data"], manifest)
                self._document_ready(kind, args["data"], manifest)
                policy = self._verification_policy(kind, args["data"], manifest)
                if policy["independent_review"]:
                    for e in args["data"]["evidence"]:
                        source = self._source(e["source_id"])
                        if not source.get("contributors"):
                            fail("COST_INPUT_NOT_READY", "/measurement/source_contributors")
                        if actor["id"] in source.get("contributors", []):
                            fail("PERMISSION_DENIED", "/")
            else:
                data = obj["revisions"].get(args["target_revision"])
                if data is None:
                    fail("REFERENCE_INVALID", "/target_revision")
                self._access_document(data, manifest, historical=True)
        elif kind == "source_denial":
            if id_ in self.denials:
                fail("VERSION_CONFLICT", "/id")
            source = next(
                (x for x in self.registry["sources"] if x["id"] == args["source_id"]), None
            )
            if source is None:
                fail("REFERENCE_INVALID", "/source_id")
            self._read_row(source)
            self._remember(manifest, "source", source["id"], 1, source)
        if "evidence" in args:
            for e in args["evidence"]:
                self._access_document(e, manifest)
        if root is not None and action in ("verify", "publish"):
            root.independent = kind == "purchase_terms" or policy["independent_review"]
        self._budget.finish()
