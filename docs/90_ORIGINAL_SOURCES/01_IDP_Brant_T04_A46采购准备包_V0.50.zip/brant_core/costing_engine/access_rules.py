"""Current server-projected read scope shared by the two reference models."""

from .validator import fail


def read_row(actor, row):
    if row is None or not row.get("readable", True):
        fail("PERMISSION_DENIED", "/")
    if actor is None:
        return
    scope = row.get("scope", {})
    if (
        scope.get("tenant", actor["tenant"]) != actor["tenant"]
        or scope.get("company", actor["company"]) != actor["company"]
    ):
        fail("NOT_FOUND", "/")
    owner = scope.get("owner_id")
    team = scope.get("team_id")
    level = actor.get("data_scope", "company")
    if level not in ("own", "team", "company"):
        fail("PERMISSION_DENIED", "/")
    # Shared dictionaries have no owner/team. Explicitly scoped business data are
    # filtered by own/team/company before any dependent private payload is read.
    if (owner is not None or team is not None) and level == "own" and owner != actor["id"]:
        fail("PERMISSION_DENIED", "/")
    if (
        (owner is not None or team is not None)
        and level == "team"
        and owner != actor["id"]
        and (team is None or team not in actor.get("team_ids", []))
    ):
        fail("PERMISSION_DENIED", "/")
    if scope.get("sensitive", False) and "foundation.sensitive.read" not in actor["grants"]:
        fail("PERMISSION_DENIED", "/")
