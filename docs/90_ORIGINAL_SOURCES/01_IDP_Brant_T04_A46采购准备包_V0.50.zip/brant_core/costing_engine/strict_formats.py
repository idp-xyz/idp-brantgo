"""Mandatory wire date/time checks without optional jsonschema format packages."""

import re
from datetime import date, datetime

from jsonschema import FormatChecker as BaseFormatChecker


def valid_date(value):
    if not isinstance(value, str):
        return True
    if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", value):
        return False
    try:
        date.fromisoformat(value)
        return True
    except ValueError:
        return False


def valid_date_time(value):
    if not isinstance(value, str):
        return True
    if not re.fullmatch(
        r"[0-9]{4}-[0-9]{2}-[0-9]{2}[Tt][0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]+)?(?:[Zz]|[+-][0-9]{2}:[0-9]{2})",
        value,
    ):
        return False
    if not valid_date(value[:10]):
        return False
    if int(value[11:13]) >= 24 or int(value[14:16]) >= 60 or int(value[17:19]) >= 60:
        return False
    if value[-1] not in "Zz" and (int(value[-5:-3]) >= 24 or int(value[-2:]) >= 60):
        return False
    try:
        datetime.fromisoformat(value.upper().replace("Z", "+00:00"))
        return True
    except ValueError:
        return False


class FormatChecker(BaseFormatChecker):
    def __init__(self):
        super().__init__()
        self.checks("date")(valid_date)
        self.checks("date-time")(valid_date_time)
