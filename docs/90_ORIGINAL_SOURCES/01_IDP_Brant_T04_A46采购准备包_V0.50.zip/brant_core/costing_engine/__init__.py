"""Private, namespaced rules adapted from the qualified candidate V0.8.

The SQLite adapter always supplies database projections; no synthetic seed is
loaded as runtime data. See docs/T02_IMPLEMENTATION.md for the adaptation seam.
"""
