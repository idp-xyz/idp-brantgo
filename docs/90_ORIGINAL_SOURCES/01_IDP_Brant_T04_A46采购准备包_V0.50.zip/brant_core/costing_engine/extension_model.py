"""Versioned foundation extension reference model; no persistent service or authentication."""

import json
from copy import deepcopy

from jsonschema import Draft202012Validator

from .access_rules import read_row
from .commercial_rules import check_transport, publication_dependencies, validate_config
from .delivery_rules import validate_calendar
from .resource_budget import admit, decode_request
from .rules import RevisionModel, active_interval
from .strict_formats import FormatChecker
from .validator import REG, ROOT, digest, fail


class ExtensionModel:
    def __init__(self, registry=None):
        self.registry = deepcopy(REG if registry is None else registry)
        self.roots = {}
        self.replays = {}
        self.clock = self.registry["as_of"]
        self.schema = json.loads(
            (ROOT / "contracts/foundation-extension.commands.schema.json").read_text()
        )
        self.data_schema = json.loads(
            (ROOT / "contracts/foundation-extension.data.schema.json").read_text()
        )

    def _source(self, id_, new_use=True):
        row = next((s for s in self.registry["sources"] if s["id"] == id_), None)
        if row is None:
            fail("REFERENCE_INVALID", "/evidence")
        read_row(getattr(self, "_actor", None), row)
        if new_use and (row.get("denied") or row.get("status") != "verified"):
            fail("REFERENCE_STALE", "/evidence")
        return row

    def _ref(self, ref, trail=()):
        key = (ref["kind"], ref["id"], ref["revision"])
        if key in trail or len(trail) > 8:
            fail("REFERENCE_INVALID", "/config_dependency_cycle")
        rows = self.export_configs()
        rows = [r for r in rows if r["ref"]["kind"] == ref["kind"] and r["ref"]["id"] == ref["id"]]
        exact = next((r for r in rows if r["ref"] == ref), None)
        if exact is None:
            fail("REFERENCE_INVALID", "/config")
        read_row(getattr(self, "_actor", None), exact)
        if (
            not exact.get("active", True)
            or max((r["ref"]["revision"] for r in rows if r.get("active", True)), default=0)
            != ref["revision"]
        ):
            fail("REFERENCE_STALE", "/config")
        if "valid_from" in exact["data"]:
            active_interval(exact["data"], self.clock)
        for evidence in exact.get("publication_evidence", []):
            self._source(evidence["source_id"])
        for dep in exact.get("reference_dependencies", []):
            self._ref(dep, trail + (key,))
        return exact

    def _history_ref_access(self, ref, trail=()):
        key = (ref["kind"], ref["id"], ref["revision"])
        if key in trail or len(trail) > 8:
            fail("REFERENCE_INVALID", "/config_dependency_cycle")
        row = next((r for r in self.export_configs() if r["ref"] == ref), None)
        if row is None:
            fail("PERMISSION_DENIED", "/")
        read_row(getattr(self, "_actor", None), row)
        for evidence in row.get("publication_evidence", []):
            self._source(evidence["source_id"], False)
        for dep in row.get("reference_dependencies", []):
            self._history_ref_access(dep, trail + (key,))

    def execute(self, actor, req):
        self._actor = actor
        try:
            return self._execute(actor, req)
        finally:
            self.__dict__.pop("_actor", None)

    def _execute(self, actor, req):
        admit(req)
        if not Draft202012Validator(self.schema, format_checker=FormatChecker()).is_valid(req):
            fail("SCHEMA_INVALID", "/")
        cmd = req["command"]
        a = req["args"]
        action = cmd.split(".")[1]
        if cmd not in actor.get("grants", []) or not actor.get("readable", False):
            fail("PERMISSION_DENIED", "/")
        if actor.get("tenant") != self.registry["server_scope"].get("tenant") or actor.get(
            "company"
        ) != self.registry["server_scope"].get("company"):
            fail("NOT_FOUND", "/")
        if action in ("publish", "retire") and actor.get("kind") != "human":
            fail("PERMISSION_DENIED", "/")
        key = (actor["tenant"], actor["company"], cmd, req["idempotency_key"])
        signature = digest(req)
        if key in self.replays:
            old, response, source_ids, dependencies = self.replays[key]
            if old != signature:
                fail("IDEMPOTENCY_PAYLOAD_CONFLICT", "/")
            for id_ in source_ids:
                self._source(id_, False)
            for dep in dependencies:
                self._history_ref_access(dep)
            return {**deepcopy(response), "replayed": True}
        before = deepcopy(self.__dict__)
        try:
            kind = a["kind"]
            id_ = a["id"]
            root = self.roots.get((kind, id_))
            if root is None:
                if action != "save_draft" or a["expected_version"] != 0:
                    fail("NOT_FOUND", "/")
                if any(
                    r["ref"]["kind"] == kind and r["ref"]["id"] == id_
                    for r in self.registry["configs"]
                ):
                    fail("REFERENCE_INVALID", "/existing_baseline_config")
                root = RevisionModel(kind=kind, independent=True)
                self.roots[kind, id_] = root
            read_row(actor, getattr(root, "access", {}))
            if root.version != a["expected_version"]:
                fail("VERSION_CONFLICT", "/expected_version")
            source_ids = []
            dependencies = []
            if action == "publish":
                draft = root.revisions.get(root.working)
                if draft is None or root.working != a["working_revision"]:
                    fail("INVALID_STATE", "/working_revision")
                if actor["id"] in draft.get("contributors", [draft["creator"]]):
                    fail("PERMISSION_DENIED", "/")
                payload = {
                    "contract": "brant.foundation-extension-data/0.1.0",
                    "kind": kind,
                    "data": draft["data"],
                }
                if not Draft202012Validator(
                    self.data_schema, format_checker=FormatChecker()
                ).is_valid(payload):
                    fail("COST_INPUT_NOT_READY", "/data")
                if kind == "delivery_calendar":
                    validate_calendar(draft["data"])
                if kind in ("trade_scope", "tax_application"):
                    validate_config(kind, draft["data"])
                    active_interval(draft["data"], self.clock)
                dependencies = publication_dependencies(kind, draft["data"])
                for ref in dependencies:
                    resolved = self._ref(ref)
                    if ref["kind"] in ("trade_terms", "tax_profile"):
                        validate_config(ref["kind"], resolved["data"])
                    if kind == "trade_scope" and ref["kind"] == "trade_terms":
                        check_transport(resolved["data"], draft["data"]["allowed_modes"])
                if kind == "tax_application":
                    ref = draft["data"]["counterparty_ref"]
                    if ref not in self.registry["masters"]:
                        fail("REFERENCE_INVALID", "/counterparty_ref")
                    metadata = next(
                        (m for m in self.registry.get("master_metadata", []) if m["ref"] == ref),
                        None,
                    )
                    if metadata is None or not metadata["confirmed"]:
                        fail("REFERENCE_STALE", "/counterparty_ref")
                    read_row(
                        actor,
                        next(
                            (
                                x
                                for x in self.registry.get("master_metadata", [])
                                if x["ref"] == ref
                            ),
                            {},
                        ),
                    )
                    if ref["row_version"] != max(
                        x["row_version"]
                        for x in self.registry["masters"]
                        if x["kind"] == ref["kind"] and x["id"] == ref["id"]
                    ):
                        fail("REFERENCE_STALE", "/counterparty_ref")
            if action in ("publish", "retire"):
                for e in a["evidence"]:
                    self._source(e["source_id"])
                    source_ids.append(e["source_id"])
            root.apply({**actor, "grants": [action]}, action, "outer." + str(root.version), a)
            if action == "revise":
                root.revisions[root.working]["contributors"] = [actor["id"]]
            if action == "save_draft":
                revision = root.revisions[root.working]
                revision["contributors"] = sorted(
                    set(revision.get("contributors", []) + [actor["id"]])
                )
            if action == "publish":
                revision = root.revisions[root.active]
                revision["publication_evidence"] = deepcopy(a["evidence"])
                revision["reference_dependencies"] = deepcopy(dependencies)
                revision["publisher"] = actor["id"]
                revision["published_at"] = self.clock
            status = (
                "active_with_draft"
                if root.active and root.working
                else "active"
                if root.active
                else "draft"
                if root.working
                else "retired"
                if any(r["sealed"] for r in root.revisions.values())
                else "empty"
            )
            response = {
                "ok": True,
                "kind": "foundation_extension_ack",
                "object_ref": {"kind": kind, "id": id_},
                "root_version": root.version,
                "status": status,
                "replayed": False,
            }
            if root.active is not None:
                response["active_revision"] = root.active
            if root.working is not None:
                response["working_revision"] = root.working
            schema = json.loads(
                (ROOT / "contracts/foundation-extension.response.schema.json").read_text()
            )
            Draft202012Validator(schema).validate(response)
            self.replays[key] = (signature, deepcopy(response), source_ids, deepcopy(dependencies))
            return response
        except Exception:
            self.__dict__ = before
            raise

    def execute_json(self, actor, raw):
        return self.execute(actor, decode_request(raw))

    def export_configs(self):
        rows = [
            deepcopy(r)
            for r in self.registry["configs"]
            if (r["ref"]["kind"], r["ref"]["id"]) not in self.roots
        ]
        for (kind, id_), root in self.roots.items():
            for revision, record in root.revisions.items():
                if not record["sealed"]:
                    continue
                rows.append(
                    {
                        "ref": {"kind": kind, "id": id_, "revision": revision},
                        "data": deepcopy(record["data"]),
                        "active": root.active == revision,
                        "publication_evidence": deepcopy(record["publication_evidence"]),
                        "reference_dependencies": deepcopy(record["reference_dependencies"]),
                        "publication": {
                            "publisher": record["publisher"],
                            "published_at": record["published_at"],
                            "contributors": deepcopy(record["contributors"]),
                        },
                    }
                )
        return rows

    def history(self, actor, ref):
        self._actor = actor
        try:
            return self._history(actor, ref)
        finally:
            self.__dict__.pop("_actor", None)

    def _history(self, actor, ref):
        if not actor.get("readable", False) or "foundation_extension.read" not in actor.get(
            "grants", []
        ):
            fail("PERMISSION_DENIED", "/")
        if actor.get("tenant") != self.registry["server_scope"].get("tenant") or actor.get(
            "company"
        ) != self.registry["server_scope"].get("company"):
            fail("NOT_FOUND", "/")
        root = self.roots.get((ref["kind"], ref["id"]))
        row = None if root is None else root.revisions.get(ref["revision"])
        if row is None or not row["sealed"]:
            fail("NOT_FOUND", "/")
        read_row(actor, getattr(root, "access", {}))
        for e in row["publication_evidence"]:
            self._source(e["source_id"], False)
        for dep in row["reference_dependencies"]:
            self._history_ref_access(dep)
        return deepcopy(row)
