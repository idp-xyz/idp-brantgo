"""Schema-driven candidate business normalization; raw request hashing is separate."""

from .resource_budget import Fraction
from .validator import SCHEMA, V, canonical, fail

VERSION = "brant.business-normalization/0.2.0"


def array_order(key, value):
    if key in ("lines", "packages", "fees", "assumptions", "weights"):
        id_field = "line_id" if key == "weights" or key == "lines" and "line_id" in value else "id"
        return (value[id_field], canonical(value))
    if key == "evidence":
        return (value["source_id"], value["locator"])
    if isinstance(value, dict) and {"kind", "id", "revision"} <= value.keys():
        return (value["kind"], value["id"], value["revision"], canonical(value))
    if key == "allocations":
        return (value["rfq_line_id"], canonical(value))
    if isinstance(value, str):
        return (value,)
    return (canonical(value),)


def array_rule(key):
    if key == "tiers":
        return "numeric lower_inclusive order"
    if key in ("lines", "packages", "fees", "assumptions", "weights"):
        return "stable id (line_id for demand lines and weights), canonical tie-break"
    if key == "evidence":
        return "source_id,locator"
    if key == "allocations":
        return "rfq_line_id,canonical normalized element"
    return "kind,id,numeric revision for references; code-point order for strings; otherwise canonical normalized element"


def deref(s):
    while "$ref" in s:
        s = SCHEMA["$defs"][s["$ref"].split("/")[-1]]
    return s


def branch(s, value):
    s = deref(s)
    if "oneOf" in s:
        from jsonschema import Draft202012Validator

        good = [
            x
            for x in s["oneOf"]
            if Draft202012Validator({"$defs": SCHEMA["$defs"], **x}).is_valid(value)
        ]
        if len(good) != 1:
            fail("SCHEMA_INVALID", "/normalization")
        return branch(good[0], value)
    return s


def normalize(req):
    if not V.is_valid(req):
        fail("SCHEMA_INVALID", "/")
    command_schema = next(
        x for x in SCHEMA["oneOf"] if x["properties"]["command"]["const"] == req["command"]
    )

    def visit(value, s, key=""):
        s = branch(s, value)
        if isinstance(value, dict):
            return {k: visit(v, s["properties"][k], k) for k, v in value.items()}
        if isinstance(value, list):
            values = [visit(v, s["items"]) for v in value]
            if key == "tiers":
                return sorted(values, key=lambda x: Fraction(x["lower_inclusive"]))
            return sorted(values, key=lambda v: array_order(key, v))
        if isinstance(value, str) and s.get("maxLength") == 40 and "pattern" in s:
            if "." not in value:
                return value
            return value.rstrip("0").rstrip(".")
        return value

    out = visit(req, command_schema)
    out.pop("idempotency_key", None)
    return out


def path_rules():
    out = {}

    def walk(s, path, rows):
        s = deref(s)
        if "oneOf" in s:
            for x in s["oneOf"]:
                walk(x, path, rows)
        elif s.get("type") == "object":
            for k, v in s["properties"].items():
                walk(v, path + "/" + k, rows)
        elif s.get("type") == "array":
            rows.add((path, array_rule(path.split("/")[-1])))
            walk(s["items"], path + "/*", rows)
        elif s.get("type") == "string":
            rows.add(
                (
                    path,
                    "decimal trim fractional zeros"
                    if s.get("maxLength") == 40
                    else "preserve Unicode code points",
                )
            )
        else:
            rows.add((path, "preserve typed scalar"))

    for s in SCHEMA["oneOf"]:
        name = s["properties"]["command"]["const"]
        rows: set[tuple[str, str]] = set()
        walk(s, "", rows)
        out[name] = [{"path": p, "rule": r} for p, r in sorted(rows)]
    return out
