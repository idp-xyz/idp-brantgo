"""Assumptions annotate typed inputs; neither JSON Pointer nor value_text is executable."""

import re

from .validator import canonical, fail

ALLOWED = re.compile(
    r"^/(?:context/(?:lines/[0-9]+/quantity|comparison_basis/delivery/(?:date|days))|(?:supplier_offer|purchase_terms)/[A-Za-z0-9._:-]+/lines/[0-9]+/(?:tiers/[0-9]+/unit_price|delivery/(?:date|days))|logistics_offer/[A-Za-z0-9._:-]+/fees/[0-9]+/billing/(?:amount|rate|minimum_amount))$"
)


def bind_assumptions(assumptions, documents, provenance, source):
    seen = set()
    paths = set()
    records = []
    for assumption in sorted(assumptions, key=lambda a: a["id"]):
        path = assumption["path"]
        if assumption["id"] in seen or path in paths:
            fail("DUPLICATE_LINE_ID", "/assumptions")
        seen.add(assumption["id"])
        paths.add(path)
        if not ALLOWED.fullmatch(path):
            fail("DEPENDENCY_NOT_SUPPORTED", "/assumptions/path")
        value = documents
        try:
            for part in path.split("/")[1:]:
                value = value[int(part)] if isinstance(value, list) else value[part]
        except (KeyError, IndexError, TypeError, ValueError):
            fail("REFERENCE_INVALID", "/assumptions/path")
        expected = str(value) if type(value) in (str, int) else canonical(value)
        if assumption["value_text"] != expected:
            fail("INVALID_KNOWN_VALUE", "/assumptions/value_text")
        author = provenance.get(assumption["id"])
        if author is None:
            fail("COST_INPUT_NOT_READY", "/assumptions/provenance")
        for evidence in assumption["evidence"]:
            source(evidence["source_id"])
        records.append({**assumption, **author, "verification_status": "unverified"})
    return records
