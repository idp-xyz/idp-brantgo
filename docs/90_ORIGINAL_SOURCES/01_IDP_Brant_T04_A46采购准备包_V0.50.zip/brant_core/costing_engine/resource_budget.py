"""Bounded JSON admission, observed dependency graphs and exact rational arithmetic."""

import json
from fractions import Fraction as StandardFraction
from typing import Any, NoReturn

LIMITS = {
    "request_bytes": 1048576,
    "json_depth": 64,
    "json_values": 100000,
    "direct_refs": 1000,
    "expanded_nodes": 5000,
    "dependency_depth": 8,
    "expand_operations": 10000,
    "inclusion_edges": 2000,
    "components": 500,
    "measurement_packages": 1000,
    "candidate_sources": 200,
    "rational_digits": 256,
    "loaded_bytes": 67108864,
}


def fail(code: str, path: str) -> NoReturn:
    from .validator import fail as reject

    reject(code, path)


def bounded_integer(value):
    if abs(value) >= 10 ** LIMITS["rational_digits"]:
        fail("CALCULATION_LIMIT_EXCEEDED", "/arithmetic/digits")
    return value


def _wrap_fraction(method):
    def wrapped(self, *args):
        value = method(self, *args)
        return Fraction(value) if isinstance(value, StandardFraction) else value

    return wrapped


class Fraction(StandardFraction):
    def __new__(cls, *args, **kwargs):
        result = super().__new__(cls, *args, **kwargs)
        bounded_integer(result.numerator)
        bounded_integer(result.denominator)
        return result

    for _name in (
        "__add__",
        "__radd__",
        "__sub__",
        "__rsub__",
        "__mul__",
        "__rmul__",
        "__truediv__",
        "__rtruediv__",
        "__neg__",
        "__abs__",
    ):
        locals()[_name] = _wrap_fraction(getattr(StandardFraction, _name))


def references(data):
    refs = set()
    stack = [(data, "", True)]
    while stack:
        value, field, root = stack.pop()
        if isinstance(value, dict):
            if (
                not root
                and {"kind", "id", "revision"} <= value.keys()
                and isinstance(value["kind"], str)
                and isinstance(value["id"], str)
                and type(value["revision"]) is int
            ):
                kind = {"offer": "supplier_offer"}.get(value["kind"], value["kind"])
                refs.add((kind, value["id"], value["revision"]))
            elif (
                not root
                and {"kind", "id", "row_version"} <= value.keys()
                and isinstance(value["kind"], str)
                and isinstance(value["id"], str)
                and type(value["row_version"]) is int
            ):
                refs.add(("master." + value["kind"], value["id"], value["row_version"]))
            elif (
                field in ("rfq_ref", "supplier_rfq_ref")
                and {"id", "row_version"} <= value.keys()
                and isinstance(value["id"], str)
                and type(value["row_version"]) is int
            ):
                refs.add(
                    (
                        "supplier_rfq" if field == "supplier_rfq_ref" else "rfq",
                        value["id"],
                        value["row_version"],
                    )
                )
            if isinstance(value.get("source_id"), str):
                refs.add(("source", value["source_id"], 1))
            stack.extend((v, k, False) for k, v in value.items())
        elif isinstance(value, list):
            stack.extend((v, field, False) for v in value)
    return refs


def check_tree(data):
    stack = [(data, 0)]
    count = 0
    while stack:
        value, depth = stack.pop()
        count += 1
        if depth > LIMITS["json_depth"] or count > LIMITS["json_values"]:
            fail("CALCULATION_LIMIT_EXCEEDED", "/json_structure")
        if isinstance(value, dict):
            stack.extend((v, depth + 1) for v in value.values())
        elif isinstance(value, list):
            stack.extend((v, depth + 1) for v in value)
        elif type(value) is float:
            fail("SCHEMA_INVALID", "/json_number")


def encoded_size(data):
    try:
        return sum(
            len(x.encode("utf-8"))
            for x in json.JSONEncoder(
                ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
            ).iterencode(data)
        )
    except (ValueError, UnicodeError, RecursionError, TypeError):
        fail("SCHEMA_INVALID", "/json")


def admit(data):
    check_tree(data)
    if encoded_size(data) > LIMITS["request_bytes"]:
        fail("CALCULATION_LIMIT_EXCEEDED", "/request_bytes")
    if len(references(data)) > LIMITS["direct_refs"]:
        fail("CALCULATION_LIMIT_EXCEEDED", "/direct_refs")
    return data


def decode_request(raw):
    try:
        raw = raw.encode("utf-8") if isinstance(raw, str) else raw
        if len(raw) > LIMITS["request_bytes"]:
            fail("CALCULATION_LIMIT_EXCEEDED", "/request_bytes")
        text = raw.decode("utf-8")
        depth = 0
        quoted = False
        escaped = False
        for c in text:
            if quoted:
                if escaped:
                    escaped = False
                elif c == "\\":
                    escaped = True
                elif c == '"':
                    quoted = False
            elif c == '"':
                quoted = True
            elif c in "[{":
                depth += 1
                if depth > LIMITS["json_depth"]:
                    fail("CALCULATION_LIMIT_EXCEEDED", "/json_structure")
            elif c in "]}":
                depth -= 1

        def pairs(rows):
            result = {}
            for k, v in rows:
                if k in result:
                    fail("SCHEMA_INVALID", "/duplicate_json_key")
                result[k] = v
            return result

        def integer(value):
            if len(value.lstrip("-")) > 10:
                fail("CALCULATION_LIMIT_EXCEEDED", "/json_integer")
            return int(value)

        def invalid(_):
            fail("SCHEMA_INVALID", "/json_number")

        return admit(
            json.loads(
                text,
                object_pairs_hook=pairs,
                parse_int=integer,
                parse_float=invalid,
                parse_constant=invalid,
            )
        )
    except (UnicodeError, ValueError, RecursionError, TypeError):
        fail("SCHEMA_INVALID", "/json")


class Budget:
    def __init__(self):
        self.nodes = {}
        self.graph = {}
        self.vertices = set()
        self.operations = 0
        self.components = 0
        self.packages = 0
        self.bytes = 0
        self.inclusion_edges = 0

    def tick(self):
        self.operations += 1
        if self.operations > LIMITS["expand_operations"]:
            fail("CALCULATION_LIMIT_EXCEEDED", "/expand_operations")

    def observe(self, kind, id_, version, data, historical=False):
        key = (kind, id_, version)
        if key in self.nodes:
            return
        check_tree(data)
        self.bytes += encoded_size(data)
        if self.bytes > LIMITS["loaded_bytes"]:
            fail("CALCULATION_LIMIT_EXCEEDED", "/loaded_bytes")
        self.nodes[key] = data
        edges = references(data)
        if kind == "source":
            edges.discard(key)
        if historical:
            edges = {x for x in edges if x[0] == "source"}
        self.graph[key] = edges
        self.vertices.add(key)
        self.vertices.update(edges)
        if len(self.vertices) > LIMITS["expanded_nodes"]:
            fail("CALCULATION_LIMIT_EXCEEDED", "/expanded_nodes")
        if kind == "measurement":
            self.packages += len(data["packages"])
            if self.packages > LIMITS["measurement_packages"]:
                fail("CALCULATION_LIMIT_EXCEEDED", "/measurement_packages")
        check_numeric_bounds(kind, data)

    def claim_components(self, count):
        self.components += count
        if self.components > LIMITS["components"]:
            fail("CALCULATION_LIMIT_EXCEEDED", "/components")

    def inclusion(self):
        self.inclusion_edges += 1
        if self.inclusion_edges > LIMITS["inclusion_edges"]:
            fail("CALCULATION_LIMIT_EXCEEDED", "/inclusion_edges")

    def finish(self):
        visiting = set()
        height: dict[Any, int] = {}

        def walk(key, depth):
            self.tick()
            if depth > LIMITS["dependency_depth"]:
                fail("CALCULATION_LIMIT_EXCEEDED", "/dependency_depth")
            if key in visiting:
                fail("REFERENCE_INVALID", "/dependency_cycle")
            if key in height:
                if depth + height[key] > LIMITS["dependency_depth"]:
                    fail("CALCULATION_LIMIT_EXCEEDED", "/dependency_depth")
                return height[key]
            visiting.add(key)
            result = 0
            for child in self.graph.get(key, ()):
                result = max(result, 1 + walk(child, depth + 1))
            visiting.remove(key)
            height[key] = result
            return result

        for key in self.graph:
            walk(key, 0)
        return {
            "expanded_nodes": len(self.vertices),
            "loaded_objects": len(self.nodes),
            "expand_operations": self.operations,
            "loaded_bytes": self.bytes,
            "components": self.components,
            "measurement_packages": self.packages,
            "inclusion_edges": self.inclusion_edges,
        }


def check_numeric_bounds(kind, data):
    stack = [data]
    money = {"unit_price", "amount", "rate", "minimum_amount"}
    quantity = {
        "quantity",
        "purchase_quantity",
        "price_basis_quantity",
        "basis_quantity",
        "lower_inclusive",
        "upper_exclusive",
        "order_multiple",
    }
    while stack:
        item = stack.pop()
        if isinstance(item, list):
            stack.extend(item)
            continue
        if not isinstance(item, dict):
            continue
        for key, value in item.items():
            if isinstance(value, (dict, list)):
                stack.append(value)
                continue
            if not isinstance(value, str):
                continue
            limit = (
                10**12
                if key in money
                else 1000000
                if key in quantity
                else 1000
                if key in ("length_m", "width_m", "height_m")
                else 10**9
                if key in ("net_kg", "gross_kg", "declared_volume_m3")
                else 10**9
                if key == "weight"
                else None
            )
            if limit is not None:
                try:
                    number = Fraction(value)
                except (ValueError, ZeroDivisionError):
                    fail("INVALID_KNOWN_VALUE", "/" + kind + "/" + key)
                if number < 0 or number > limit:
                    fail("CALCULATION_LIMIT_EXCEEDED", "/" + kind + "/" + key)
    if kind == "measurement":
        weight = sum(p["count"] * Fraction(p["gross_kg"]) for p in data["packages"])
        volume = sum(
            p["count"] * Fraction(p["length_m"]) * Fraction(p["width_m"]) * Fraction(p["height_m"])
            for p in data["packages"]
        )
        if weight > 10**9 or volume > 10**9:
            fail("CALCULATION_LIMIT_EXCEEDED", "/measurement_totals")
