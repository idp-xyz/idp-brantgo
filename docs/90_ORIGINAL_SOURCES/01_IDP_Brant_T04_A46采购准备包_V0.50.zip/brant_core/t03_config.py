"""Persistent quotation-foundation configuration lifecycle for local Core."""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import UTC
from decimal import Decimal
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from . import foundation, t03_storage
from .common import Principal, Rejected, canonical

CONTRACT = "brant.quotation-foundation/0.1.0"
SCHEMAS = Path(__file__).parent / "contracts"
REQUEST_SCHEMA = json.loads(
    (SCHEMAS / "T03_configuration.commands.schema.json").read_text(encoding="utf-8")
)
RESPONSE_SCHEMA = json.loads(
    (SCHEMAS / "T03_configuration.responses.schema.json").read_text(encoding="utf-8")
)
QUERY_SCHEMA = json.loads(
    (SCHEMAS / "T03_configuration.queries.schema.json").read_text(encoding="utf-8")
)
QUERY_RESPONSE_SCHEMA = json.loads(
    (SCHEMAS / "T03_configuration.query-responses.schema.json").read_text(encoding="utf-8")
)
REQUEST_VALIDATOR = Draft202012Validator(REQUEST_SCHEMA, format_checker=FormatChecker())
RESPONSE_VALIDATOR = Draft202012Validator(RESPONSE_SCHEMA, format_checker=FormatChecker())
QUERY_VALIDATOR = Draft202012Validator(QUERY_SCHEMA, format_checker=FormatChecker())
QUERY_RESPONSE_VALIDATOR = Draft202012Validator(
    QUERY_RESPONSE_SCHEMA, format_checker=FormatChecker()
)

_ACTIONS = {"save_draft", "revise", "discard_draft", "publish", "retire"}
_KINDS = {"quote_document_template", "sales_tax_application"}
_READ_PERMISSION = "quotation_foundation.read"
_HUMAN_ONLY = {"discard_draft", "publish", "retire"}
_FOUNDATION_KINDS = {
    "company",
    "currency",
    "unit",
    "conversion",
    "fx",
    "calendar",
    "trade_terms",
    "payment_terms",
    "tax_profile",
    "fee_type",
    "pricing_policy",
    "party_profile",
    "contact_profile",
    "sku_profile",
    "code_mapping",
    "bank_account",
    "sequence",
    "document_template",
}
_MASTER_KINDS = {"customer", "contact", "supplier", "sku"}
_TEMPLATE_SECTIONS = (
    "issuer",
    "recipient",
    "identity",
    "lines",
    "totals",
    "terms",
    "delivery",
    "payments",
    "validity",
    "notes",
)


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def _now(core) -> str:
    value = core.clock()
    if value.tzinfo is None:
        raise RuntimeError("Core clock must return an aware datetime")
    return value.astimezone(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")


def _bounded_json(request: Any) -> None:
    pending = [(request, 0)]
    visited = 0
    while pending:
        value, depth = pending.pop()
        visited += 1
        if depth > 64 or visited > 100_000:
            raise Rejected("CALCULATION_LIMIT_EXCEEDED")
        if isinstance(value, float):
            raise Rejected("SCHEMA_INVALID")
        if isinstance(value, dict):
            pending.extend((child, depth + 1) for child in value.values())
        elif isinstance(value, list):
            pending.extend((child, depth + 1) for child in value)
    try:
        encoded = canonical(request).encode("utf-8")
    except (TypeError, ValueError, UnicodeError, RecursionError):
        raise Rejected("SCHEMA_INVALID") from None
    if len(encoded) > 1024 * 1024:
        raise Rejected("CALCULATION_LIMIT_EXCEEDED")


def _command(request: Any) -> str:
    value = request.get("command") if isinstance(request, dict) else None
    if isinstance(value, str) and value.startswith("quotation_foundation.") and len(value) <= 100:
        return value
    return "quotation_foundation.invalid"


def _query_kind(request: Any) -> str:
    value = request.get("kind") if isinstance(request, dict) else None
    return value if value in _KINDS else "quote_document_template"


def _error_code(code: str) -> str:
    allowed = {
        item
        for branch in RESPONSE_SCHEMA["oneOf"]
        for item in branch.get("properties", {}).get("code", {}).get("enum", [])
    }
    return code if code in allowed else "REFERENCE_INVALID"


def _access_kind(kind: str) -> str:
    return f"quotation_foundation.{kind}"


def _root(core, db, who: Principal, kind: str, object_id: str):
    row = db.execute(
        "SELECT * FROM quotation_config_root WHERE tenant=? AND company=? AND kind=? AND id=?",
        (*who.scope, kind, object_id),
    ).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    core._access(db, who, _access_kind(kind), object_id)
    return row


def _revision(db, who: Principal, kind: str, object_id: str, number: int):
    row = db.execute(
        "SELECT * FROM quotation_config_revision WHERE tenant=? AND company=? AND kind=? AND id=? AND revision=?",
        (*who.scope, kind, object_id, number),
    ).fetchone()
    if row is None:
        raise Rejected("NOT_FOUND")
    return row


def _source(core, db, who: Principal, evidence: dict, *, current: bool) -> None:
    core._source_ref(db, who, evidence["source_id"], "/args/evidence")
    if not current:
        return
    row = db.execute(
        "SELECT verified,denied FROM quotation_config_source_state WHERE tenant=? AND company=? AND source_id=?",
        (*who.scope, evidence["source_id"]),
    ).fetchone()
    if row is None or row["verified"] != 1 or row["denied"] != 0:
        raise Rejected("REFERENCE_STALE", "/args/evidence")


def _master_reference(
    core,
    db,
    who: Principal,
    ref: dict,
    *,
    current: bool,
) -> dict:
    kind, object_id, version = ref["kind"], ref["id"], ref["row_version"]
    if kind not in _MASTER_KINDS:
        raise Rejected("DEPENDENCY_NOT_SUPPORTED")
    core._authorize(db, who, "read")
    try:
        core._access(db, who, "master", object_id)
    except Rejected:
        raise Rejected("PERMISSION_DENIED") from None
    row = db.execute(
        "SELECT id,kind,name,parent_customer_id,base_uom,status,row_version FROM master "
        "WHERE tenant=? AND company=? AND id=? AND kind=?",
        (*who.scope, object_id, kind),
    ).fetchone()
    if row is not None and row["row_version"] == version:
        value = dict(row)
    else:
        historical = db.execute(
            "SELECT data_json FROM master_history WHERE tenant=? AND company=? AND id=? AND row_version=?",
            (*who.scope, object_id, version),
        ).fetchone()
        if historical is None:
            raise Rejected("REFERENCE_INVALID")
        value = json.loads(historical["data_json"])
        if value.get("kind") != kind:
            raise Rejected("REFERENCE_INVALID")
    if current and value["status"] != "confirmed":
        raise Rejected("REFERENCE_STALE")
    return value


def _check_document(
    core,
    db,
    who: Principal,
    value: Any,
    *,
    current: bool,
    source_current: bool,
    trail: tuple[tuple[str, str, int], ...] = (),
    budget: dict[str, int] | None = None,
) -> None:
    if budget is None:
        budget = {"operations": 0, "direct": 0}
    if isinstance(value, dict):
        if {"kind", "id", "revision"} <= value.keys():
            budget["operations"] += 1
            budget["direct"] += 1
            if budget["operations"] > 10_000 or budget["direct"] > 1_000:
                raise Rejected("CALCULATION_LIMIT_EXCEEDED")
            ref = {key: value[key] for key in ("kind", "id", "revision")}
            key = (ref["kind"], ref["id"], ref["revision"])
            if key in trail or len(trail) >= 8:
                raise Rejected("REFERENCE_INVALID")
            if ref["kind"] not in _FOUNDATION_KINDS:
                raise Rejected("DEPENDENCY_NOT_SUPPORTED")
            core._authorize(db, who, "foundation.read")
            record = foundation.revision(db, who, ref)
            head = foundation.root(db, who, ref["kind"], ref["id"])
            data = json.loads(record["data_json"])
            if current:
                if head["active_revision"] != ref["revision"] or record["status"] != "active":
                    raise Rejected("REFERENCE_STALE")
                if "valid_from" in data:
                    instant = core.clock().astimezone(UTC)
                    if (
                        not foundation.stamp(data["valid_from"])
                        <= instant
                        < foundation.stamp(data["valid_until"])
                    ):
                        raise Rejected("REFERENCE_STALE")
            foundation.validate(core, db, who, ref["kind"], ref["id"], data)
            source_ids = json.loads(record["evidence_json"])
            for source_id in source_ids:
                _source(core, db, who, {"source_id": source_id}, current=source_current)
            _check_document(
                core,
                db,
                who,
                data,
                current=current,
                source_current=source_current,
                trail=(*trail, key),
                budget=budget,
            )
            return
        if {"kind", "id", "row_version"} <= value.keys():
            budget["operations"] += 1
            budget["direct"] += 1
            if budget["operations"] > 10_000 or budget["direct"] > 1_000:
                raise Rejected("CALCULATION_LIMIT_EXCEEDED")
            _master_reference(core, db, who, value, current=current)
            return
        if "source_id" in value:
            _source(core, db, who, value, current=source_current)
            return
        for child in value.values():
            _check_document(
                core,
                db,
                who,
                child,
                current=current,
                source_current=source_current,
                trail=trail,
                budget=budget,
            )
    elif isinstance(value, list):
        for child in value:
            _check_document(
                core,
                db,
                who,
                child,
                current=current,
                source_current=source_current,
                trail=trail,
                budget=budget,
            )


def _check_data(
    core, db, who: Principal, kind: str, data: dict, *, current: bool, source_current: bool
) -> None:
    _check_document(core, db, who, data, current=current, source_current=source_current)
    if kind == "quote_document_template":
        sections = set(_TEMPLATE_SECTIONS)
        if len(data["sections"]) != len(sections) or set(data["sections"]) != sections:
            raise Rejected("REFERENCE_INVALID")
        if current and (data["language"] != "en" or data["renderer_version"] != "quote-text/0.1.0"):
            raise Rejected("DEPENDENCY_NOT_SUPPORTED")
        return
    if data["customer_ref"]["kind"] != "customer":
        raise Rejected("REFERENCE_INVALID")
    if data["issuer_ref"]["id"] != who.company:
        raise Rejected("REFERENCE_INVALID")
    start = foundation.stamp(data["valid_from"])
    end = foundation.stamp(data["valid_until"])
    if start >= end:
        raise Rejected("INVALID_KNOWN_VALUE")
    tax = foundation.revision(db, who, data["tax_profile_ref"])
    tax_data = json.loads(tax["data_json"])
    rate = Decimal(tax_data["rate"])
    if not 0 <= rate <= 1 or (tax_data["price_basis"] == "not_applicable" and rate != 0):
        raise Rejected("REFERENCE_INVALID")
    if current:
        instant = core.clock().astimezone(UTC)
        if not start <= instant < end:
            raise Rejected("REFERENCE_STALE")
        _master_reference(core, db, who, data["customer_ref"], current=True)
        if data["subject_kind"] == "fee_type":
            subject = foundation.revision(db, who, data["subject_ref"])
            subject_data = json.loads(subject["data_json"])
            if subject_data["side"] != "sales_charge":
                raise Rejected("CHARGE_SCOPE_UNRESOLVED")


def _record_value(kind: str, object_id: str, number: int, row) -> dict:
    revision = {
        "data": json.loads(row["data_json"]),
        "contributors": json.loads(row["contributors_json"]),
        "publication": json.loads(row["publication_json"])
        if row["publication_json"] is not None
        else None,
        "base_ref": json.loads(row["base_ref_json"]) if row["base_ref_json"] else None,
    }
    value = {
        "kind": kind,
        "id": object_id,
        "revision": number,
        "data": revision["data"],
        "contributors": revision["contributors"],
    }
    if revision["publication"] is not None:
        value["publication"] = revision["publication"]
    if revision["base_ref"] is not None:
        value["base_ref"] = revision["base_ref"]
    return value


def _validate_revision_history(
    core,
    db,
    who: Principal,
    kind: str,
    object_id: str,
    number: int,
    *,
    source_current: bool = False,
    trail: tuple[int, ...] = (),
) -> None:
    if number in trail or len(trail) >= 8:
        raise Rejected("REFERENCE_INVALID")
    row = _revision(db, who, kind, object_id, number)
    data = json.loads(row["data_json"])
    contributors = json.loads(row["contributors_json"])
    if (
        canonical(data) != row["data_json"]
        or digest(data) != row["content_hash"]
        or not isinstance(contributors, list)
        or contributors != sorted(set(contributors))
        or bool(row["sealed"]) != (row["effectivity"] in ("active", "superseded", "retired"))
        or (bool(row["sealed"]) != (row["publication_json"] is not None))
    ):
        raise Rejected("REFERENCE_INVALID")
    _check_data(core, db, who, kind, data, current=False, source_current=source_current)
    publication = json.loads(row["publication_json"]) if row["publication_json"] else None
    if publication:
        _check_document(
            core,
            db,
            who,
            publication,
            current=False,
            source_current=source_current,
        )
    base_ref = json.loads(row["base_ref_json"]) if row["base_ref_json"] else None
    if base_ref:
        _validate_revision_history(
            core,
            db,
            who,
            base_ref["kind"],
            base_ref["id"],
            base_ref["revision"],
            source_current=source_current,
            trail=(*trail, number),
        )


def _resolve_policy(core, db, who: Principal) -> dict:
    row = db.execute(
        "SELECT policy_id,policy_revision FROM quotation_config_policy WHERE tenant=? AND company=?",
        who.scope,
    ).fetchone()
    if row is None:
        raise Rejected("REFERENCE_INVALID", reason="No server quotation policy is configured")
    ref = {"kind": "pricing_policy", "id": row["policy_id"], "revision": row["policy_revision"]}
    data = foundation.active(core, db, who, ref)
    if data["independent_review"] is not True:
        raise Rejected("REFERENCE_INVALID")
    return ref


def _insert_event(
    db,
    who: Principal,
    kind: str,
    object_id: str,
    revision: int,
    action_id: str,
    command: str,
    args: dict,
    root_version: int,
    recorded_at: str,
) -> None:
    db.execute(
        "INSERT INTO quotation_config_event(tenant,company,kind,id,revision,action_id,command,args_json,actor,root_version,recorded_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            kind,
            object_id,
            revision,
            action_id,
            command,
            canonical(args),
            who.actor,
            root_version,
            recorded_at,
        ),
    )


def _apply(core, db, who: Principal, command: str, args: dict) -> dict:
    action = command.rsplit(".", 1)[1]
    kind, object_id = args["kind"], args["id"]
    root = db.execute(
        "SELECT * FROM quotation_config_root WHERE tenant=? AND company=? AND kind=? AND id=?",
        (*who.scope, kind, object_id),
    ).fetchone()
    if root is None:
        if action != "save_draft" or args["expected_version"] != 0:
            raise Rejected("NOT_FOUND")
        timestamp = _now(core)
        db.execute(
            "INSERT INTO quotation_config_root VALUES(?,?,?,?,1,0,NULL,NULL,?,?)",
            (*who.scope, kind, object_id, timestamp, timestamp),
        )
        core._claim(db, who, _access_kind(kind), object_id)
        root = db.execute(
            "SELECT * FROM quotation_config_root WHERE tenant=? AND company=? AND kind=? AND id=?",
            (*who.scope, kind, object_id),
        ).fetchone()
        first_root = True
    else:
        core._access(db, who, _access_kind(kind), object_id)
        first_root = False
        if root["row_version"] != args["expected_version"]:
            raise Rejected("VERSION_CONFLICT")
    if first_root and action != "save_draft":
        raise Rejected("INVALID_STATE")

    recorded_at = _now(core)
    revision_number = 0
    new_version = root["row_version"] if first_root else root["row_version"] + 1
    if action == "save_draft":
        if root["working_revision"] is not None:
            revision_number = root["working_revision"]
            _validate_revision_history(core, db, who, kind, object_id, revision_number)
            _check_data(core, db, who, kind, args["data"], current=False, source_current=False)
            existing = _revision(db, who, kind, object_id, revision_number)
            contributors = sorted(set(json.loads(existing["contributors_json"])) | {who.actor})
            db.execute(
                "UPDATE quotation_config_revision SET data_json=?,content_hash=?,contributors_json=? WHERE tenant=? AND company=? AND kind=? AND id=? AND revision=? AND sealed=0",
                (
                    canonical(args["data"]),
                    digest(args["data"]),
                    canonical(contributors),
                    *who.scope,
                    kind,
                    object_id,
                    revision_number,
                ),
            )
        else:
            if not first_root:
                sealed = db.execute(
                    "SELECT 1 FROM quotation_config_revision WHERE tenant=? AND company=? AND kind=? AND id=? AND sealed=1 LIMIT 1",
                    (*who.scope, kind, object_id),
                ).fetchone()
                if sealed:
                    raise Rejected("INVALID_STATE")
            _check_data(core, db, who, kind, args["data"], current=False, source_current=False)
            revision_number = root["last_revision"] + 1
            db.execute(
                "INSERT INTO quotation_config_revision VALUES(?,?,?,?,?,?,?,?,0,'draft',NULL,NULL,?,?)",
                (
                    *who.scope,
                    kind,
                    object_id,
                    revision_number,
                    canonical(args["data"]),
                    digest(args["data"]),
                    canonical([who.actor]),
                    who.actor,
                    recorded_at,
                ),
            )
        db.execute(
            "UPDATE quotation_config_root SET row_version=?,last_revision=?,working_revision=?,updated_at=? WHERE tenant=? AND company=? AND kind=? AND id=?",
            (
                new_version,
                revision_number,
                revision_number,
                recorded_at,
                *who.scope,
                kind,
                object_id,
            ),
        )
    elif action == "revise":
        if root["working_revision"] is not None:
            raise Rejected("INVALID_STATE")
        base_number = args["base_revision"]
        base = _revision(db, who, kind, object_id, base_number)
        if base["sealed"] != 1:
            raise Rejected("INVALID_STATE")
        _validate_revision_history(core, db, who, kind, object_id, base_number)
        revision_number = root["last_revision"] + 1
        contributors = sorted(set(json.loads(base["contributors_json"])) | {who.actor})
        base_ref = {"kind": kind, "id": object_id, "revision": base_number}
        db.execute(
            "INSERT INTO quotation_config_revision VALUES(?,?,?,?,?,?,?,?,0,'draft',NULL,?,?,?)",
            (
                *who.scope,
                kind,
                object_id,
                revision_number,
                base["data_json"],
                base["content_hash"],
                canonical(contributors),
                canonical(base_ref),
                who.actor,
                recorded_at,
            ),
        )
        db.execute(
            "UPDATE quotation_config_root SET row_version=?,last_revision=?,working_revision=?,updated_at=? WHERE tenant=? AND company=? AND kind=? AND id=?",
            (
                new_version,
                revision_number,
                revision_number,
                recorded_at,
                *who.scope,
                kind,
                object_id,
            ),
        )
    elif action in ("publish", "discard_draft"):
        if root["working_revision"] != args["working_revision"]:
            raise Rejected("INVALID_STATE")
        revision_number = args["working_revision"]
        target = _revision(db, who, kind, object_id, revision_number)
        _validate_revision_history(core, db, who, kind, object_id, revision_number)
        for evidence in args["evidence"]:
            _source(core, db, who, evidence, current=True)
        if action == "publish":
            contributors = json.loads(target["contributors_json"])
            if who.actor in contributors:
                raise Rejected("INDEPENDENT_REVIEW_REQUIRED")
            policy_ref = _resolve_policy(core, db, who)
            data = json.loads(target["data_json"])
            _check_data(core, db, who, kind, data, current=True, source_current=True)
            stored_base_ref = (
                json.loads(target["base_ref_json"]) if target["base_ref_json"] else None
            )
            if stored_base_ref:
                _validate_revision_history(
                    core,
                    db,
                    who,
                    kind,
                    object_id,
                    stored_base_ref["revision"],
                    source_current=True,
                )
            publication = {
                "published_by": who.actor,
                "published_at": recorded_at,
                "policy_ref": policy_ref,
                "evidence": args["evidence"],
            }
            if root["active_revision"] is not None:
                db.execute(
                    "UPDATE quotation_config_revision SET effectivity='superseded' WHERE tenant=? AND company=? AND kind=? AND id=? AND revision=?",
                    (*who.scope, kind, object_id, root["active_revision"]),
                )
            db.execute(
                "UPDATE quotation_config_revision SET sealed=1,effectivity='active',publication_json=? WHERE tenant=? AND company=? AND kind=? AND id=? AND revision=?",
                (canonical(publication), *who.scope, kind, object_id, revision_number),
            )
            active_revision = revision_number
        else:
            db.execute(
                "UPDATE quotation_config_revision SET effectivity='discarded' WHERE tenant=? AND company=? AND kind=? AND id=? AND revision=?",
                (*who.scope, kind, object_id, revision_number),
            )
            active_revision = root["active_revision"]
        db.execute(
            "UPDATE quotation_config_root SET row_version=?,working_revision=NULL,active_revision=?,updated_at=? WHERE tenant=? AND company=? AND kind=? AND id=?",
            (new_version, active_revision, recorded_at, *who.scope, kind, object_id),
        )
    else:
        revision_number = args["target_revision"]
        target = _revision(db, who, kind, object_id, revision_number)
        if target["sealed"] != 1 or target["effectivity"] == "retired":
            raise Rejected("INVALID_STATE")
        _validate_revision_history(core, db, who, kind, object_id, revision_number)
        db.execute(
            "UPDATE quotation_config_revision SET effectivity='retired' WHERE tenant=? AND company=? AND kind=? AND id=? AND revision=?",
            (*who.scope, kind, object_id, revision_number),
        )
        active_revision = (
            None if root["active_revision"] == revision_number else root["active_revision"]
        )
        db.execute(
            "UPDATE quotation_config_root SET row_version=?,active_revision=?,updated_at=? WHERE tenant=? AND company=? AND kind=? AND id=?",
            (new_version, active_revision, recorded_at, *who.scope, kind, object_id),
        )

    response = {
        "ok": True,
        "command": command,
        "action_id": uuid.uuid4().hex,
        "replayed": False,
        "kind": kind,
        "id": object_id,
        "root_version": new_version,
        "last_revision": max(root["last_revision"], revision_number),
    }
    after = db.execute(
        "SELECT working_revision,active_revision,last_revision FROM quotation_config_root WHERE tenant=? AND company=? AND kind=? AND id=?",
        (*who.scope, kind, object_id),
    ).fetchone()
    if after["active_revision"] is not None:
        response["active_revision"] = after["active_revision"]
    if after["working_revision"] is not None:
        response["working_revision"] = after["working_revision"]
    _insert_event(
        db,
        who,
        kind,
        object_id,
        revision_number,
        response["action_id"],
        command,
        args,
        new_version,
        recorded_at,
    )
    return response


def _replay(core, db, who: Principal, request: dict, command: str, args: dict, old) -> dict:
    if old["request_hash"] != digest(request):
        raise Rejected("IDEMPOTENCY_PAYLOAD_CONFLICT")
    kind, object_id = args["kind"], args["id"]
    _root(core, db, who, kind, object_id)
    event = db.execute(
        "SELECT revision FROM quotation_config_event WHERE tenant=? AND company=? AND action_id=?",
        (*who.scope, old["action_id"]),
    ).fetchone()
    if event is None:
        raise RuntimeError("Quotation configuration action has no immutable event")
    _validate_revision_history(core, db, who, kind, object_id, event["revision"])
    stored = json.loads(old["result_json"])
    stored["replayed"] = True
    return stored


def _audit_rejection(
    core, who: Principal, command: str, object_id: str | None, code: str, correlation: str
) -> None:
    with core._connection() as db:
        core._audit(db, who, command, object_id, "rejected", code, correlation)


def _command_execute(core, who: Principal, request: Any) -> dict:
    command = _command(request)
    args = request.get("args") if isinstance(request, dict) else None
    object_id = args.get("id") if isinstance(args, dict) else None
    if not isinstance(object_id, str) or len(object_id) > 64:
        object_id = None
    correlation = uuid.uuid4().hex
    try:
        _bounded_json(request)
        if not REQUEST_VALIDATOR.is_valid(request):
            raise Rejected("SCHEMA_INVALID")
        if not core._t03_enabled:
            raise Rejected("UNSUPPORTED_CONTRACT")
        assert isinstance(args, dict)
        kind = args["kind"]
        assert isinstance(object_id, str)
        action = command.rsplit(".", 1)[1]
        with core._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                core._authorize(db, who, command)
                core._authorize(db, who, _READ_PERMISSION)
                if action in _HUMAN_ONLY:
                    actor = db.execute(
                        "SELECT actor_kind FROM authorization WHERE tenant=? AND company=? AND actor=?",
                        (*who.scope, who.actor),
                    ).fetchone()
                    if actor is None or actor["actor_kind"] != "human":
                        raise Rejected("PERMISSION_DENIED")
                t03_storage.guard(db, who, _access_kind(kind), object_id)
                payload_hash = digest(request)
                old = db.execute(
                    "SELECT request_hash,action_id,result_json FROM action_result WHERE tenant=? AND company=? AND command=? AND idempotency_key=?",
                    (*who.scope, command, request["idempotency_key"]),
                ).fetchone()
                if old:
                    _root(core, db, who, kind, object_id)
                    result = _replay(core, db, who, request, command, args, old)
                    core._audit(db, who, command, object_id, "replayed", None, correlation)
                else:
                    result = _apply(core, db, who, command, args)
                    RESPONSE_VALIDATOR.validate(result)
                    db.execute(
                        "INSERT INTO action_result VALUES(?,?,?,?,?,?,?)",
                        (
                            *who.scope,
                            command,
                            request["idempotency_key"],
                            payload_hash,
                            result["action_id"],
                            canonical(result),
                        ),
                    )
                    db.execute(
                        "INSERT INTO outbox VALUES(?,?,?,?,?)",
                        (
                            *who.scope,
                            uuid.uuid4().hex,
                            result["action_id"],
                            canonical(
                                {
                                    "command": command,
                                    "kind": kind,
                                    "object_id": object_id,
                                    "root_version": result["root_version"],
                                    "last_revision": result["last_revision"],
                                }
                            ),
                        ),
                    )
                    core._audit(
                        db,
                        who,
                        command,
                        object_id,
                        "succeeded",
                        None,
                        correlation,
                        args.get("reason"),
                    )
                db.commit()
                return result
            except BaseException:
                db.rollback()
                raise
    except Rejected as exc:
        code = _error_code(exc.code)
        _audit_rejection(core, who, command, object_id, code, correlation)
        result = {"ok": False, "command": command, "code": code, "retriable": False}
        RESPONSE_VALIDATOR.validate(result)
        return result


def _query_execute(core, who: Principal, request: Any) -> dict:
    kind = _query_kind(request)
    object_id = request.get("id") if isinstance(request, dict) else None
    if not isinstance(object_id, str) or len(object_id) > 64:
        object_id = None
    correlation = uuid.uuid4().hex
    try:
        _bounded_json(request)
        if not QUERY_VALIDATOR.is_valid(request):
            raise Rejected("SCHEMA_INVALID")
        if not core._t03_enabled:
            raise Rejected("UNSUPPORTED_CONTRACT")
        assert isinstance(request, dict)
        assert isinstance(object_id, str)
        with core._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                core._authorize(db, who, _READ_PERMISSION)
                root = _root(core, db, who, kind, object_id)
                number = request.get("revision")
                if number is None:
                    number = root["working_revision"] or root["active_revision"]
                if number is None:
                    raise Rejected("NOT_FOUND")
                row = _revision(db, who, kind, object_id, number)
                if row["effectivity"] == "active" and root["active_revision"] != number:
                    raise Rejected("REFERENCE_INVALID")
                if row["effectivity"] == "draft" and root["working_revision"] != number:
                    raise Rejected("REFERENCE_INVALID")
                if root["active_revision"] == number and row["effectivity"] != "active":
                    raise Rejected("REFERENCE_INVALID")
                if root["working_revision"] == number and row["effectivity"] != "draft":
                    raise Rejected("REFERENCE_INVALID")
                _validate_revision_history(core, db, who, kind, object_id, number)
                value = {
                    "ok": True,
                    "kind": kind,
                    "id": object_id,
                    "root_version": root["row_version"],
                    "revision": number,
                    "sealed": bool(row["sealed"]),
                    "effectivity": row["effectivity"],
                    "data": json.loads(row["data_json"]),
                    "data_hash": row["content_hash"],
                    "record_hash": digest(_record_value(kind, object_id, number, row)),
                    "contributors": sorted(json.loads(row["contributors_json"])),
                }
                if row["publication_json"] is not None:
                    value["publication"] = json.loads(row["publication_json"])
                QUERY_RESPONSE_VALIDATOR.validate(value)
                core._audit(
                    db, who, "quotation_foundation.get", object_id, "read", None, correlation
                )
                db.commit()
                return value
            except BaseException:
                db.rollback()
                raise
    except Rejected as exc:
        code = _error_code(exc.code)
        _audit_rejection(core, who, "quotation_foundation.get", object_id, code, correlation)
        result = {"ok": False, "kind": kind, "code": code}
        QUERY_RESPONSE_VALIDATOR.validate(result)
        return result


def execute(core, who: Principal, request: Any) -> dict:
    if isinstance(request, dict) and request.get("contract") != CONTRACT:
        return {"ok": False, "code": "UNSUPPORTED_CONTRACT"}
    if isinstance(request, dict) and "command" in request:
        return _command_execute(core, who, request)
    return _query_execute(core, who, request)


def active_in_transaction(core, db, who: Principal, ref: dict) -> dict:
    """Resolve a currently published quotation configuration on the caller's transaction.

    This is a trusted adapter boundary for quote calculation and formalization. It
    deliberately repeats authorization, object control, publication evidence,
    source verification, revision integrity, and current-reference checks while
    the caller holds its existing write transaction.
    """
    if not isinstance(ref, dict) or ref.get("kind") not in _KINDS:
        raise Rejected("REFERENCE_INVALID")
    kind, object_id, number = ref.get("kind"), ref.get("id"), ref.get("revision")
    if (
        not isinstance(kind, str)
        or not isinstance(object_id, str)
        or not object_id
        or not isinstance(number, int)
        or isinstance(number, bool)
        or number <= 0
    ):
        raise Rejected("REFERENCE_INVALID")
    assert isinstance(kind, str)
    assert isinstance(object_id, str)
    assert isinstance(number, int)
    core._authorize(db, who, _READ_PERMISSION)
    t03_storage.guard(db, who, _access_kind(kind), object_id)
    root = _root(core, db, who, kind, object_id)
    if root["active_revision"] != number:
        raise Rejected("REFERENCE_STALE")
    row = _revision(db, who, kind, object_id, number)
    if row["sealed"] != 1 or row["effectivity"] != "active":
        raise Rejected("REFERENCE_STALE")
    _validate_revision_history(core, db, who, kind, object_id, number)
    data = json.loads(row["data_json"])
    _check_data(core, db, who, kind, data, current=True, source_current=True)
    publication = json.loads(row["publication_json"] or "null")
    if not isinstance(publication, dict):
        raise Rejected("REFERENCE_INVALID")
    policy_ref = publication.get("policy_ref")
    if not isinstance(policy_ref, dict):
        raise Rejected("REFERENCE_INVALID")
    policy = foundation.active(core, db, who, policy_ref)
    if policy.get("independent_review") is not True:
        raise Rejected("REFERENCE_STALE")
    evidence = publication.get("evidence")
    if not isinstance(evidence, list) or not evidence:
        raise Rejected("REFERENCE_INVALID")
    for item in evidence:
        if not isinstance(item, dict) or not isinstance(item.get("source_id"), str):
            raise Rejected("REFERENCE_INVALID")
        _source(core, db, who, item, current=True)
    return {
        "ref": {"kind": kind, "id": object_id, "revision": number},
        "data": data,
        "data_hash": row["content_hash"],
        "record_hash": digest(_record_value(kind, object_id, number, row)),
        "publication_hash": digest(publication),
        "publication": publication,
    }


def set_source_verification(
    core, who: Principal, source_id: str, *, verified: bool, denied: bool, reason: str
) -> dict:
    if not core._t03_enabled:
        raise RuntimeError("T03 persistence is not enabled for this Core")
    if not isinstance(verified, bool) or not isinstance(denied, bool) or verified and denied:
        raise Rejected("INVALID_KNOWN_VALUE")
    with core._connection() as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            core._authorize(db, who, "foundation.publish")
            core._source_ref(db, who, source_id, "/source_id")
            timestamp = _now(core)
            db.execute(
                "INSERT INTO quotation_config_source_state VALUES(?,?,?,?,?,?,?) ON CONFLICT(tenant,company,source_id) DO UPDATE SET verified=excluded.verified,denied=excluded.denied,updated_by=excluded.updated_by,updated_at=excluded.updated_at",
                (*who.scope, source_id, int(verified), int(denied), who.actor, timestamp),
            )
            db.execute(
                "INSERT INTO quotation_config_source_event(tenant,company,source_id,verified,denied,actor,reason,recorded_at) VALUES(?,?,?,?,?,?,?,?)",
                (*who.scope, source_id, int(verified), int(denied), who.actor, reason, timestamp),
            )
            t03_storage.bump_authority_epoch(db, who.scope)
            core._audit(
                db,
                who,
                "quotation_foundation.source.verify",
                source_id,
                "succeeded",
                None,
                uuid.uuid4().hex,
                reason,
            )
            db.commit()
            return {"source_id": source_id, "verified": verified, "denied": denied}
        except BaseException:
            db.rollback()
            raise


def set_policy_ref(core, who: Principal, ref: dict, *, reason: str) -> dict:
    if not core._t03_enabled:
        raise RuntimeError("T03 persistence is not enabled for this Core")
    if ref.get("kind") != "pricing_policy":
        raise Rejected("REFERENCE_INVALID")
    with core._connection() as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            core._authorize(db, who, "foundation.publish")
            data = foundation.active(core, db, who, ref)
            if data["independent_review"] is not True:
                raise Rejected("REFERENCE_INVALID")
            timestamp = _now(core)
            db.execute(
                "INSERT INTO quotation_config_policy VALUES(?,?,?,?,?,?) ON CONFLICT(tenant,company) DO UPDATE SET policy_id=excluded.policy_id,policy_revision=excluded.policy_revision,updated_by=excluded.updated_by,updated_at=excluded.updated_at",
                (*who.scope, ref["id"], ref["revision"], who.actor, timestamp),
            )
            db.execute(
                "INSERT INTO quotation_config_policy_event(tenant,company,policy_id,policy_revision,actor,reason,recorded_at) VALUES(?,?,?,?,?,?,?)",
                (*who.scope, ref["id"], ref["revision"], who.actor, reason, timestamp),
            )
            t03_storage.bump_authority_epoch(db, who.scope)
            core._audit(
                db,
                who,
                "quotation_foundation.policy.select",
                ref["id"],
                "succeeded",
                None,
                uuid.uuid4().hex,
                reason,
            )
            db.commit()
            return {"policy_ref": ref, "updated_at": timestamp}
        except BaseException:
            db.rollback()
            raise
