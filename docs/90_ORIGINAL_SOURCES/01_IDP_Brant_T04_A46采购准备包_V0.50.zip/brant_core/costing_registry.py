"""Scope-bound projections. No fixture data are imported into the business store."""

import json
from datetime import UTC

from .common import Rejected
from .foundation import refs

CONFIG_KINDS = {
    "unit",
    "currency",
    "sku_profile",
    "tax_profile",
    "pricing_policy",
    "trade_terms",
    "payment_terms",
    "calendar",
    "conversion",
    "fx",
    "fee_type",
}


def can_access(core, db, who, kind, id_):
    try:
        core._access(db, who, kind, id_)
        return True
    except Rejected:
        return False


def bounded_rows(db, who, table):
    # Table names are from this module's constant calls, never request values.
    rows = db.execute(
        f"SELECT * FROM {table} WHERE tenant=? AND company=? LIMIT 5001", who.scope
    ).fetchall()
    if len(rows) > 5000:
        raise Rejected("CALCULATION_LIMIT_EXCEEDED")
    if (
        sum(len(v.encode("utf-8")) for r in rows for v in r if isinstance(v, str))
        > 64 * 1024 * 1024
    ):
        raise Rejected("CALCULATION_LIMIT_EXCEEDED")
    return rows


def registry(core, db, who):
    result = {
        "as_of": core.clock().astimezone(UTC).isoformat().replace("+00:00", "Z"),
        "server_scope": {"tenant": who.tenant, "company": who.company},
        "sources": [],
        "masters": [],
        "master_metadata": [],
        "configs": [],
        "verified_business": [],
        "rfqs": [],
    }
    policy = db.execute(
        "SELECT ref_json FROM t02_policy WHERE tenant=? AND company=?", who.scope
    ).fetchone()
    if policy:
        result["verification_policy_ref"] = json.loads(policy[0])
    for source in bounded_rows(db, who, "source_origin"):
        imports = db.execute(
            "SELECT DISTINCT actor_id FROM source_import WHERE tenant=? AND company=? AND origin_id=?",
            (*who.scope, source["id"]),
        ).fetchall()
        attestations = [
            dict(r)
            for r in db.execute(
                "SELECT id,actor_id,recorded_at,reason FROM t02_source_attestation WHERE tenant=? AND company=? AND source_id=? ORDER BY id",
                (*who.scope, source["id"]),
            )
        ]
        content = db.execute(
            "SELECT sha256 FROM source_content WHERE tenant=? AND company=? AND id=?",
            (*who.scope, source["content_id"]),
        ).fetchone()
        denied = (
            db.execute(
                "SELECT 1 FROM t02_denial WHERE tenant=? AND company=? AND source_id=?",
                (*who.scope, source["id"]),
            ).fetchone()
            is not None
        )
        result["sources"].append(
            {
                "id": source["id"],
                "status": "verified" if attestations else "unverified",
                "readable": can_access(core, db, who, "source", source["id"]),
                "denied": denied,
                "contributors": sorted(r[0] for r in imports),
                "content_hash": content[0],
                "attestations": attestations,
            }
        )
    master_rows = [dict(r) for r in bounded_rows(db, who, "master")]
    master_rows += [json.loads(r["data_json"]) for r in bounded_rows(db, who, "master_history")]
    for master in master_rows:
        ref = {"kind": master["kind"], "id": master["id"], "row_version": master["row_version"]}
        result["masters"].append(ref)
        result["master_metadata"].append(
            {
                "ref": ref,
                "confirmed": master["status"] == "confirmed",
                "readable": can_access(core, db, who, "master", master["id"]),
            }
        )
    heads = {(r["kind"], r["id"]): r for r in bounded_rows(db, who, "foundation_root")}
    for row in bounded_rows(db, who, "foundation_revision"):
        if row["kind"] not in CONFIG_KINDS or row["reviewed_by"] is None:
            continue
        ref = {"kind": row["kind"], "id": row["id"], "revision": row["revision"]}
        data = json.loads(row["data_json"])
        dependencies = list(refs(data))
        if ref["kind"] == "fx":
            data = {
                **data,
                "from_currency": data["from_currency"]["id"],
                "to_currency": data["to_currency"]["id"],
            }
        result["configs"].append(
            {
                "ref": ref,
                "data": data,
                "active": heads[row["kind"], row["id"]]["active_revision"] == row["revision"]
                and row["status"] == "active",
                "publication_evidence": [
                    {
                        "source_id": id_,
                        "locator": f"foundation:{row['kind']}:{row['id']}:{row['revision']}",
                    }
                    for id_ in json.loads(row["evidence_json"])
                ],
                "reference_dependencies": dependencies,
                "publication": {
                    "publisher": row["reviewed_by"],
                    "published_at": row["reviewed_at"],
                    "contributors": [row["created_by"]],
                    "source_content_hash": row["content_hash"],
                    "adapter_version": "t02.sqlite.v0.1",
                },
            }
        )
    for row in bounded_rows(db, who, "t02_rfq_binding"):
        result["rfqs"].append(
            {
                **json.loads(row["data_json"]),
                "readable": can_access(core, db, who, "rfq", row["id"]),
            }
        )
    for row in bounded_rows(db, who, "rfq"):
        previous = next(
            (
                r
                for r in result["rfqs"]
                if r["id"] == row["id"] and r["row_version"] == row["row_version"]
            ),
            None,
        )
        if previous:
            previous["status"] = row["status"]
            continue
        lines = []
        supported = True
        for line in db.execute(
            "SELECT * FROM rfq_line WHERE tenant=? AND company=? AND rfq_id=? ORDER BY line_id",
            (*who.scope, row["id"]),
        ):
            profiles = [
                c
                for c in result["configs"]
                if c["ref"]["kind"] == "sku_profile"
                and c["active"]
                and c["data"]["sku_id"] == line["sku_id"]
            ]
            units = [
                c
                for c in result["configs"]
                if c["ref"]["kind"] == "unit" and c["active"] and c["data"]["code"] == line["uom"]
            ]
            if len(profiles) != 1 or len(units) != 1 or line["quantity"] is None:
                supported = False
                break
            lines.append(
                {
                    "line_id": line["line_id"],
                    "sku_profile_ref": profiles[0]["ref"],
                    "unit_ref": units[0]["ref"],
                    "quantity": line["quantity"],
                }
            )
        result["rfqs"].append(
            {
                "id": row["id"],
                "row_version": row["row_version"],
                "status": row["status"] if supported else "mapping_unresolved",
                "lines": lines,
                "readable": can_access(core, db, who, "rfq", row["id"]),
            }
        )
    return result
