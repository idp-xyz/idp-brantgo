# T03 A17 报价写命令运行态报告 V0.1

日期：2026-10-24。承接 T03 A16 投递目标快照运行态 V0.22。

## 实现范围

- 在 `Core.execute` 为 `brant.quotation/0.1.0` 区分 `command` 写请求和 `kind` 查询请求，注册候选封闭 schema 定义的全部13个报价动作。
- 新增 `brant_core/t03_write.py` 作为统一公共命令适配器。它验证请求／响应 schema、1 MiB 上限、64层深度、100,000 节点和禁止浮点，再在一个 `BEGIN IMMEDIATE` 事务内核对当前命令权限、人工身份、报价根对象控制和状态 CAS，最后调用已有 `t03_storage` 领域写函数。
- 补齐公开契约与原后端接口的差异：显式校验 `draft_generation`、`business_revision`、批准效力版本和替代目标；正式化所需 number／document／file ID 由服务端生成；服务器计算仍只在 freeze 时发生。
- 拒绝理由和证据引用被持久化到对应报价／审批不可变事件。证据来源需为当前租户／公司的可访问 source，并要求 `read` 权限；它证明本地引用及访问检查，不替代来源真实性或企业核实。
- 成功动作写入现有 `action_result` 表；该动作记录、报价状态／事件、成功审计与正式化时已有的编号、文件、CommitEvidence、投递目标快照及内部 Outbox 同事务提交。拒绝只在回滚后追加拒绝审计。
- 新增迁移 8，为既有报价根按最早修订的 `created_by` 回填 `record_access(kind='quote')` owner/team，并对受影响租户／公司递增 `authority_epoch`。新报价在首个写事务中登记服务器 owner/team；迁移遇到没有可验证创建修订的报价根会整体失败。
- 报价写入和所有 T03 JSON 查询均对报价根执行 `own/team/company` 范围检查。无归属记录或不匹配的团队按 `NOT_FOUND` 处理，隐藏对象存在性。
- 成功重放按租户、公司、命令、幂等键定位，比较完整规范请求哈希，重查当前命令授权和对象控制后返回原动作／响应；不再次执行领域写函数。换载荷冲突不写业务事实。
- 新的 `authority-control-mapping-v0.23.json` 登记13个动作的运行权限、人工限制、控制对象、CAS、原子写集合和未实现边界。报价写请求／响应 schema 与 Core 实际加载的两份运行 schema 做逐字 JSON 结构一致性测试。
- 业务拒绝回滚报价事务后单独追加拒绝审计。意外 SQLite 错误会回滚并作为技术异常传播，不会伪装为业务拒绝；COMMIT unknown 对账仍未实现。

## 验证

| 范围 | 结果 |
|---|---:|
| A17 公共写命令与范围专项 | 6 个测试方法通过；13种动作均走公共入口成功路径 |
| 核心全量回归 | 214 项通过 |
| 候选契约复验 | 350 项通过 |
| 调用方事务适配复验 | 39 项通过 |
| `mypy --check-untyped-defs brant_core` | 29 个源文件通过 |
| `ruff check brant_core tests scripts` | 通过 |
| 写命令 schema／权利映射对齐 | 13/13 动作，运行 schema 与候选 schema 一致 |
| ZIP 完整性、逐文件 SHA-256 清单及独立解压专项复验 | 通过 |

核心公共入口专项另外验证了旧根版本／草稿代次／批准效力版本拒绝、审核人独立性、AI freeze 拒绝、对象绑定阻断、own/team/company 范围与跨团队拒绝、同键重放、换载荷冲突、服务重建后的正式化重放和成功动作账本晚期故障整体回滚。详细证据汇总见 `evidence/a17-verification.json`；分层原始输出见 `evidence/a17-*.txt`。测试数据均为合成资料。

## 边界和未关闭项

这是本地 Python `Core.execute` 对已解析 JSON 对象的运行态写入口，不是 HTTP 服务。入口尚未接收原始 JSON 字节，因此重复键、无效 UTF-8、网络认证与真实岗位身份需未来边缘适配器负责。报价基础配置写命令仍未注册；`quote_revision`、完整 `approval`、`document` 公共查询和完整场景矩阵仍未全部关闭。

正式化仅产生内部报价事实和排队 Outbox；外部渠道仍未配置，不发送报价、不记录送达或客户接受，也不创建订单。真实企业资料、SSO／岗位映射、生产文件存储、容量／监控、重试／死信、备份恢复目标和 COMMIT unknown 对账仍未完成。本地通过不等于生产准入或产品 V1.0 完成。

复验命令：

```bash
uv run --frozen python -m unittest tests.test_t03_write_contract -v
uv run --frozen python -m unittest discover -s tests -q
uv run --frozen python -m t03_candidate.verify
uv run --frozen python -m t03_candidate.verify_transaction_adapter
uv run --frozen mypy --check-untyped-defs brant_core
uv run --frozen ruff check brant_core tests scripts
```
