# T04 A44 客户回复公共契约 V0.48

本阶段把客户回复登记与核实从受信任本地接口接入 `brant.quotation/0.1.0` 公共命令：`quote.response.record` 和 `quote.response.verify`。公共请求不接受租户、公司、操作者或任务身份；服务端根据当前 Principal 检查人工身份、精确命令权限、报价读取权限、来源访问和报价对象控制。

`quote.response.record` 只登记 `response_id`、报价、来源、定位、分类和摘要，分类不等于客户接受。`quote.response.verify` 只接受已登记的 `full_unconditional` 回复，复用 A37 的报价版本／哈希、客户、联系人、来源消息、完整行范围和时间检查；Acceptance 与回复关联在同一事务提交，失败整体回滚。相同幂等键重放原回执，载荷不同返回冲突；验证复用不会重复创建 Acceptance。

两条公共命令已加入只读 `action_reconciliation`，读取权限为 `quote.read` 与 `read`，不授予写权限，也不重新执行客户回复登记或核实。运行时 schema 与候选 schema、写控制映射和对账权限映射同步。

验证范围包括 A44 专项、A43 对账回归、A36/A37 客户回复回归、写契约、对账授权、全量 unittest、候选契约、事务适配、Ruff、mypy、compileall 以及新鲜解压复验。数据为 synthetic，本阶段不声明真实客户渠道、消息真实性、外部订单系统或生产准入。
