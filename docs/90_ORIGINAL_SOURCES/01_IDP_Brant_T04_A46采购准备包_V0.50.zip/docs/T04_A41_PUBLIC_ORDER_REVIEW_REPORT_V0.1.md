# T04 A41 订单审批公共生命周期 V0.45

本阶段开放公共 order.review.request 与 order.review.decide 写命令。申请命令绑定订单当前快照；裁决命令检查订单仍为草稿、审核人当前为人工且与申请人及唯一 prepared actor 独立，审批有效期必须带时区并不晚于来源报价有效期。

公共命令与本地受信任接口共享 t04_order_review_request、t04_order_review_decision 不可变记录。成功结果写入统一 action_result 和审计；相同幂等键重放原回执，不同参数冲突。激活仍由 A39/A40 共享门禁最终裁决。

验证使用合成数据和本地 SQLite，不代表真实身份岗位、外部订单系统或生产准入。
