# 本地实现追踪

当前工作区无外部 git remote 或已配置问题追踪器；不创建外部 Issue、PR 或发布。
审查基点为既有核心 0.2.0 的 `161c9ec`。
T02 需求来源：`docs/T02_CONTRACT_SPEC.md`。
本次实现范围及未完成项：`docs/T02_IMPLEMENTATION.md`。
编码与运行约束：`docs/FOUNDATION_IMPLEMENTATION.md`、`ruff.toml`、`pyproject.toml`。

T02 本地核心阶段准入已通过，完整运行态验收仍未通过，见 `docs/T02_FINAL_ADMISSION.md`。
下一工作项：T03 最小闭环契约及验收矩阵；编码前关闭 T03-G01—G06。
T03 正式化须在写入事务内重新检查成本资格，不得以独立查询结果替代。

T03 领域规格 V0.1 与 48 组待执行场景已起草，见 `docs/T03_CONTRACT_SPEC.md`、`docs/T03_ACCEPTANCE_MATRIX.md`。
语义衔接和机器阶段差距见 `docs/T03_DESIGN_REVIEW.md`。六项门槛均未登记关闭。
下一工作项更新为：T03 候选封闭 schema／参考 DDL／配置权限矩阵／完整样例与哈希交叉验证；当前不修改业务运行态。

首批候选机器材料已交付：`t03_candidate/`、`docs/T03_MACHINE_CONTRACT_V0.1.md`。
187项候选检查、原核心162项独立回归通过；双轴记录见 `docs/T03_CANDIDATE_REVIEW.md`。
下一工作项：补齐配置生命周期与完整依赖准入、状态／权限矩阵和事务适配，再复审完整编码准入。
当前Core仍未注册T03命令；正式运行态及上线标记保持false。

配置及依赖参考增量见 `docs/T03_CONFIGURATION_REFERENCE_V0.2.md`，验收映射见 `docs/T03_ACCEPTANCE_PROGRESS_V0.2.md`。
本轮固定审查基点为上次交付提交 `e6937365ca6cf5d3fb15e91b962a84680bb70e4a`；沿用本地追踪，不新增外部事项。
两类配置已在顺序内存模型补齐生命周期，注册路径依赖闭包及T02 manifest访问适配仍为参考边界；尚未接入Core。
下一工作项：事务适配契约、完整编码准入复审，然后依准入结果实施持久化；不直接登记运行态完成。

当前增量基点为已交付4ce8c5e。共享事务适配见 `docs/T03_TRANSACTION_ADAPTER_V0.1.md`，
完整持久化准入复核见 `docs/T03_PERSISTENCE_ADMISSION_V0.1.md`。
核心0.5.1提供调用方连接上的实时T02资格接口；没有T03命令或迁移4。有限前置工程与完整编码准入分别登记。
下一工作包A1：补全组合算术、报价状态／事件／权利映射及迁移／授权／控制适配设计，再登记限定存储实施范围。
