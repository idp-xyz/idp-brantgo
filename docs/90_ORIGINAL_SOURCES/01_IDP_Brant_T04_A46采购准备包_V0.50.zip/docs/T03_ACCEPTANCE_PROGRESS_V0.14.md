# T03 验收进展 V0.14

日期：2026-11-04（Asia/Shanghai）。A29 V0.33、核心 0.5.1、迁移 12，仅合成资料及本地 SQLite。

本阶段增加公司登记资料、客户档案及指定地址、当前联系人和条款的服务端绑定；冻结后在新正式化、替代、新订单激活及 quote_ready 重查。调用方拥有事务，历史记录和已提交重放保留原状。A29 专项 16 项、联合 249 项、核心全量 430 项、候选 350 项及事务 39 项通过，ruff、mypy 和 compileall 通过。详细证据见 `evidence/a29-verification.json`，套件不相加。范围和未完成事项见 `docs/T03_A29_TRADE_PARTIES_REPORT_V0.1.md`。

contact_profile 的 contacts 路径、其他地址角色、逐单覆盖条款及完整报价运行态仍未认证；完整 T04、原 Q03-01—48、G01—G06、生产准入和 V1.0 仍未完成。
