# T03 A18 报价基础配置持久化运行态报告 V0.1

日期：2026-10-24。承接 A17 报价写命令运行态 V0.23。

## 实现范围

- `Core.execute` 注册 `brant.quotation-foundation/0.1.0`：`quote_document_template` 与 `sales_tax_application` 两类对象共享 `save_draft`、`revise`、`discard_draft`、`publish`、`retire` 五个命令，并提供精确修订读取。运行 schema 与候选生成 schema 逐结构一致。
- 新增迁移 9，持久化配置根、修订、当前工作稿／active 指针、贡献者、发布事实、基础配置事件、来源核实状态及服务端定价政策选择。支持从迁移 8 原子升级；新写入按 `quotation_foundation.{kind}` 声明 root owner/team。
- SQLite 对每个配置根约束最多一个未封存工作稿和一个 active 修订。封存正文、哈希、贡献者、基修订及发布事实不可变；效力只允许应用服务执行 active→superseded／retired 的转换。事件和核实变更记录禁止 UPDATE／DELETE。
- 每个写命令要求精确动作权限与 `quotation_foundation.read`，事务内重查 own/team/company 范围及服务器对象控制；读取和重放也检查当前授权、对象范围和历史引用访问。发布、丢弃和停用仅允许人工身份。
- 新动作的完整规范请求哈希绑定成功幂等键。配置状态、事件、`action_result`、内部 `outbox` 和成功审计在同一事务提交；业务拒绝回滚后单独写拒绝审计。注入成功动作账本写入故障后，配置根、修订、事件和 Outbox 整体回滚。
- 发布必须由非贡献者执行，引用当前服务器选定且独立审核策略的 active `pricing_policy`，重查配置依赖、有效期、客户／收费对象当前状态，并要求发布证据在本地被受信任适配器标记为已核实。没有核实事实时关闭发布。
- 现有 BC-T01 来源对象本身不含真实性核验事实。`Core.t03_config_verify_source` 是受信任本地边界，可追加已核实／撤销核实／反证状态和不可变变更事件；它不证明企业资料真实或具备法律效力。`Core.t03_config_select_pricing_policy` 同样是受信任本地边界，每次发布仍在写事务内重查该策略当前 active。

## 验证

| 范围 | 结果 |
|---|---:|
| 配置运行态专项 | 6 个测试方法通过；覆盖两种配置及全部五种动作 |
| 核心全量回归 | 221 项通过 |
| 候选契约复验 | 350 项通过 |
| 调用方事务适配复验 | 39 项通过 |
| `mypy --check-untyped-defs brant_core` | 30 个源文件通过 |
| `ruff check brant_core tests scripts` | 通过 |
| 迁移 9 | 新库初始化、迁移 8→9 以及回归到迁移 7 后补跑 8→9 均通过 |
| Schema 对齐 | 请求、命令响应、查询及查询响应 4 份一致 |
| 事务故障注入 | 成功动作账本失败时配置状态、事件和 Outbox 整体回滚 |
| 验证包 | ZIP 完整性、逐文件 SHA-256 清单及解压后 12 项专项／迁移测试通过 |

详细原始输出与机器摘要见 `evidence/a18-*.txt`、`evidence/a18-verification.json`。测试资料均为合成数据。

## 尚未关闭的边界

A18 持久化的是配置生命周期入口；quote.freeze 的既有计算适配器尚未读取这里的 `sales_tax_application` 或 `quote_document_template` 修订，报价计算组合和正式文件渲染仍需后续接线和独立验收。公开配置查询目前只提供按根／精确修订读取，没有公开事件历史端点。主体身份、真实岗位授权、来源真实性核验、生产数据存储、网络边缘认证和容量恢复目标未接入。

这不完成原 Q03 全部 48 场景，也不构成完整 T03 运行态、生产准入或产品 V1.0 上线声明。正式报价发送、送达、客户接受和订单转换继续关闭。

## 复验命令

```bash
uv run --frozen python -m unittest tests.test_t03_configuration_runtime -v
uv run --frozen python -m unittest discover -s tests -q
uv run --frozen python -m t03_candidate.verify
uv run --frozen python -m t03_candidate.verify_transaction_adapter
uv run --frozen mypy --check-untyped-defs brant_core
uv run --frozen ruff check brant_core tests scripts
```
