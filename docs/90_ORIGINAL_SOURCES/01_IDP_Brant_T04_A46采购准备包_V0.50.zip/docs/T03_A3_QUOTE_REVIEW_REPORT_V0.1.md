# T03 A3 报价草稿、冻结与审核持久化报告 V0.1

日期：2026-10-23。承接 A2。A3 使用可信本地 Core 后端接口，不注册客户端报价 JSON 命令。

## 已实现

- 迁移 5 新增报价根、商业修订、追加事件、审核请求、批准和批准效力事件表。
- 草稿保存支持 root CAS；商业哈希绑定数据和计算载荷。
- 冻结后商业修订内容和哈希不可变，仅状态推进；冻结事件追加写入。
- 审核请求绑定 quote、business_revision、business_hash、目标 activate／replace 和旧 active 修订。
- 批准仅允许当前人工审核人，且审核人不能属于 contributors；AI 和编制人拒绝。
- 批准效力含 expires_at、effectivity_version；撤销不删除原批准，只追加撤销事件并递增版本。
- 所有写入由调用方事务持有，先查权限和对象控制；失败整体回滚。

可信接口包括 `t03_quote_save_draft`、`t03_quote_freeze`、`t03_quote_submit_review`、`t03_quote_decide_review` 和 `t03_quote_revoke_approval`。

## 验证

| 层级 | 结果 |
|---|---:|
| A3 草稿／冻结／独立批准／撤销专项 | 3 项通过 |
| A2 授权控制专项 | 4 项通过 |
| 原核心全量回归 | 169 项通过 |
| 候选、事务适配、A1、ruff、格式、mypy | 全部通过 |

## 未完成

A3 不包含正式编号、正式客户文档、activate／replace 的最终时效裁决、同事务 T02 资格重查、Outbox 或发送渠道。
正式报价运行态、完整 G01—G06 和产品上线条件继续保持未通过。
