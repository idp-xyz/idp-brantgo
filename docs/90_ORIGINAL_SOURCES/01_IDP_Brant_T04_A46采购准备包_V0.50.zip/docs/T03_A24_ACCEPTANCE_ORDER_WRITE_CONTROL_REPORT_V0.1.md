# T03 A24 客户确认与订单写控制验证报告 V0.1

日期：2026-11-02（Asia/Shanghai）。源码版本 V0.28，承接 A23 V0.27。仅使用合成资料和本地 SQLite；没有客户渠道、外部订单或生产动作。旧版本目录与归档独立保留。

## 修复结果

修复前已经复现：源报价根绑定任务后，不带任务身份的本地接口仍能记录完整客户确认、准备订单并激活订单；公共 JSON 命令则会返回对象控制冲突。对应失败测试日志保存在 `evidence/a24-before-fix.txt`。

A24 在 `register_acceptance`、`prepare_order`、`activate_order` 三个共享存储函数内调用现有报价根控制检查；本地服务将受信任适配器提供的 `task_id` 传入，同一事务检查任务身份、当前授权 epoch 和 stopping 状态。检查先于写入或现存结果重放；不能以已存在确认、订单或 active 状态绕过。原业务 CAS、确认范围、审批和唯一槽位校验继续保留。

本地 `t03_order_activate` 对齐公共入口的 `order.activate`、`quote.read`、`read` 权限与人工身份要求。现有报价的公共写入口先检查源报价可见范围，再检查对象控制，避免向不可见对象的调用方透露控制状态。公共 JSON 契约继续拒绝 `task_id`，没有将受信任适配器字段开放给客户端。

## 验证证据

| 检查 | 结果 | 证据 |
|---|---|---|
| A24 专项 | 14 个测试方法通过，子用例不另累加 | `evidence/a24-special.txt` |
| 确认／订单／对账／查询联合专项 | 54 项通过 | `evidence/a24-focused.txt` |
| 核心全量回归 | 269 项通过 | `evidence/a24-unittest.txt` |
| 候选参考模型 | 350 项通过，不代表全部进入 Core | `evidence/a24-candidate.txt` |
| 调用方事务适配 | 39 项通过 | `evidence/a24-transaction.txt` |
| ruff、mypy、compileall | 全部通过，mypy 含 `--check-untyped-defs` | `evidence/a24-verification.json` |

专项覆盖未提供任务、错误任务、当前正确任务、scope 授权 epoch 变化、stopping、旧 epoch 解绑定失败、重新绑定后旧任务拒绝、撤权、人工身份变化、对象范围、公共 JSON 伪造任务、服务重建、现存结果重放及拒绝后业务／事件／成功账本无变化。

并发证据包含两个局部场景：同任务双并发激活只有一个激活事件、订单行版本仅递增一次；停止事务持有 SQLite 写锁并先提交后，等待中的激活读取到 stopping，不能修改订单或产生激活事件。本轮不将两个局部场景扩写成完整竞争矩阵。

只读对账在绑定期间继续可用，且执行 A23 当前读取权限与源报价范围检查；查看本地提交事实不产生新的业务写动作。

## 交付与复现

新增三动作权限与控制映射 `t03_candidate/contracts/write-control-mapping-v0.28.json`。运行 `uv run --frozen python scripts/verify_a24.py` 重现检查与原始日志；运行 `uv run --frozen python scripts/package_a24.py` 创建 V0.28 独立包，运行 `uv run --frozen python scripts/recheck_a24_package.py` 校验归档成员与 SHA-256，并从新解压目录复跑联合专项、候选、事务适配、ruff 和 mypy。精确归档哈希及解压复验回执位于 ZIP 旁的 `.zip.verification.json`。

数据库迁移仍为 11；本轮只修复写入口接线和校验顺序，没有增加表或迁移。

## 限制与后续验收

任务身份仍由本地受信任适配器断言，不等于企业岗位身份、远程认证或生产任务执行器。现有全局授权 epoch 变化会令旧绑定失效，须按原控制生命周期处理。A24 仅关闭三个业务动作的已列接口一致性和局部竞争子断言；全部核心／基础配置写入口、完整报价组合、订单商业字段与源报价的一致性、真实渠道、生产恢复和分布式提交仍须逐项验收。生产准入、原六项完整门槛与产品 V1.0 完成继续保持 false。
