# T03 A31 报价地址角色映射报告 V0.1

日期：2026-11-04（Asia/Shanghai）。承接 A30 V0.34，核心 0.5.1、迁移 12。验证只使用合成资料与本地 SQLite；没有真实客户数据、外发、外部订单或生产部署。

## 范围

Foundation `party_profile.addresses[].role` 有 buyer、seller、payer、payee、consignee、shipper、billing 七种角色。当前 T03 报价输入只有一个 `customer_address_id`，绑定目标是客户档案中的一个地址，没有发行方地址、付款方地址或收发货方的独立字段。因此 buyer 与 billing 映射到既有 `customer.address`／`customer.address_role` 凭证；其余五种角色明确拒绝。映射由 `t03_candidate/contracts/quote-address-role-mapping-v0.35.json` 记录，并从 Foundation 命令 schema 的角色枚举生成。

本阶段确认并测试既有边界：被选地址必须唯一、非空，角色必须是 buyer 或 billing；角色在冻结后变化会导致新业务动作的实时资格检查失败。buyer／billing 凭证形状和调用方事务责任保持不变。本阶段没有引入报价请求字段、数据库表、迁移、地址选择优先级或新的业务角色含义，也没有把客户地址映射成发行方或物流地址。

## 验证

专项用例覆盖 buyer 与 billing 的成功绑定、五种其余角色的拒绝、冻结后角色改变的拒绝，以及七种 Foundation 角色在映射文件中的全量覆盖。A31 专项 4 项、联合回归 268 项、Core 全量 449 项、候选检查 350 项、事务适配 39 项均通过；ruff、mypy（36 个源码文件）和 compileall 通过。验证脚本重复运行 A23 至 A31 映射生成器并比较输出哈希，同时核对 A30 的 468 个清单文件和归档 SHA-256。套件相互重叠，不应相加。各项命令、退出码、测试数及输入哈希见 `evidence/a31-verification.json`；逐项输出见同目录的 `a31-*.txt`。

所有结论限定于合成测试、本地 SQLite 和当前契约，不构成真实地址适用性或税务判断。正式报价运行态、完整 T04、原 Q03-01—48、G01—G06、生产准入及 V1.0 均未完成；本阶段也不声称报价组合授权及对象控制映射已全部关闭。
