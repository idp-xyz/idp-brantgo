# T03 A2 授权与对象控制持久化实施报告 V0.1

日期：2026-10-23。承接 A1 与 T03 事务适配 V0.4。产品范围仍为 V1.0／CN-M01／S01。

## 本轮实现

本轮把 A1 设计中的两项前置能力落到真实 Core／SQLite：

- 迁移 4 在可信本地 `Core(path, enable_t03=True)` 中以 `BEGIN IMMEDIATE` 原子安装，严格要求既有版本 `[1,2,3]`；未知历史拒绝，重复初始化幂等。
- `t03_authority_scope.authority_epoch` 保存 scope 级授权版本；授权、角色、数据范围或记录归属变化在同一写事务递增。
- `t03_object_control` 保存服务器对象控制状态、task、delegate_epoch、control_epoch 和绑定经办人。
- 可信后端方法 `t03_bind_object_control`、`t03_check_object_control`、`t03_stop_object_control`、`t03_unbind_object_control` 保持调用方责任边界，不成为客户端 JSON 命令。
- 所有 Core 写命令在 dispatch 前读取服务器控制；绑定对象没有服务器解析出的 task 时拒绝，停止对象拒绝，委托代次落后当前 authority_epoch 时拒绝。
- 新增 `OBJECT_CONTROL_CONFLICT` 到旧 Core 与 foundation 的封闭错误响应 schema，保证拒绝能够被稳定返回。

默认 `Core(path)` 不安装迁移 4；因此已有 T01/T02 使用方式和数据库仍保持原版本。A2 也没有注册 T03 报价命令、报价表、批准表、编号或正式文件事务。

## 验证

| 层级 | 结果 |
|---|---:|
| A2 专项（迁移幂等、epoch、绑定／停止／解绑、旧命令控制拒绝） | 4 项通过 |
| 原核心回归（含新增专项） | 166 项通过 |
| ruff、格式、mypy | 通过 |

专项源码位于 `tests/test_t03_persistence.py`。它使用临时 SQLite，不接触用户数据库。

## 未关闭事项

本轮不宣称完整 G03/G04 或 T03 编码准入通过。授权／归属的全部生产入口、企业身份映射、报价草稿／冻结／审核／批准、正式编号／文档、Outbox 和 COMMIT unknown 对账仍待 A3/A4；`t03_runtime_service_implemented`、`product_v1_launch_ready` 保持 false。
