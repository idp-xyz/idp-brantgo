# T03 A9 报价历史运行态报告 V0.1

日期：2026-10-23。承接 T03 A8 报价读取契约适配 V0.14。

## 本轮实现

- 新增 `quote_history` 只读查询，要求 `quote_id` 与明确的 `business_revision`，避免把整根历史读取误解释为单一当前报价。
- 返回稳定的根版本、根状态、当前 active 修订、修订状态／商业哈希、服务器 `issued_at`／`expires_at`、金额计算摘要、当前成本资格和事件数量。
- 当前成本资格仍与历史商业事实分离；成本反证、自然到期或当前权限变化不会改写历史哈希、金额和状态。
- 公共响应不带内部 `data`、contributors、对象控制和完整事件 payload，避免把内部存储结构直接升级为外部契约。
- 入口继续使用封闭 schema、1 MiB 请求上限和同一 SQLite 事务权限检查；历史查询要求 `quote.read`、`costing.read`、`read`、`foundation.read`。

## 验证

| 层级 | 结果 |
|---|---:|
| A9 历史查询专项 | 5 项通过 |
| A8 与既有核心全量回归 | 198 项通过 |
| `mypy --check-untyped-defs brant_core` | 28 个源文件通过 |
| `ruff check brant_core tests scripts` | 通过 |
| 查询 schema 自检 | 通过 |
| ZIP 解压复验 | 通过 |

测试使用合成主体、成本、税率、汇率和报价资料；没有外部发送、客户接受或订单动作。

## 当前边界

候选契约的完整 `quote_revision`、审批和正式文档查询仍未注册；当前开放的是稳定摘要视图。报价写命令外部 JSON 契约、企业 SSO／岗位映射、生产文件存储、发送／送达／客户接受、订单转换、生产监控和 COMMIT unknown 对账仍未完成。本包不构成生产上线声明。
