# T03 A19 报价配置消费与文件生成运行态报告 V0.1

日期：2026-10-24。承接 A18 配置持久化和 A17 报价写命令运行态。

## 实现范围

- `quote.freeze` 在原事务内读取当前封存的 `sales_tax_application` 和 `quote_document_template`。消费前检查 `quotation_foundation.read`、对象访问范围、当前 active 指针、封存正文／记录／发布哈希、当前发布证据、有效期、依赖与对象控制状态。A18 配置受控或证据撤销时，冻结被拒绝且报价仍为工作稿。
- 销售税配置按每条报价行的 `sku_profile_ref` 或收费行的 `fee_type_ref` 绑定，同时校验客户及发行主体。税额仍由服务器使用当前税档案计算。现存 T02 `tax_application` 显式引用继续兼容；不再把 A18 `sales_tax_application` 错误地回退解释成 T02 记录。
- 正式化事务内再次核对冻结配置的精确版本和哈希、active 效力、发布来源核实、当前对象控制及客户／发行主体／SKU／收费类型绑定。任一配置资格变化都会使编号、文件、配置绑定、提交证据和 Outbox 整体回滚。
- 当报价绑定模板时，正式化在同一事务里使用已发布模板生成有界 UTF-8 纯文本内部文件；文件包含模板修订、数据／记录／发布哈希、渲染器版本、报价行与服务器计算结果。没有绑定模板的旧非结构化报价保留内部审计文本路径。
- 新迁移 10 增加不可变 `t03_document_config_binding`，为正式文件按角色固定模板和税务配置版本及三种哈希。`document_history` 只返回这些绑定元数据，不返回文件字节。更新／删除触发器禁止改写绑定。
- 新增授权映射 `t03_candidate/contracts/authority-control-mapping-v0.25.json`。报价冻结／正式化／替代命令显式要求配置读取权限。外部发送、送达、客户接受和订单转换仍未开放。

## 验证

| 范围 | 结果 |
|---|---:|
| A19 配置消费与事务专项 | 5 个测试方法通过 |
| 核心全量回归 | 227 项通过 |
| 候选契约复验 | 350 项通过；候选复验不表示 Core 运行态包含 350 项 |
| 调用方事务适配复验 | 39 项通过 |
| 迁移 10 | 新库、迁移 9→10、迁移 7 后补齐 8→10、幂等重启通过 |
| `mypy --check-untyped-defs brant_core` | 通过 |
| `ruff check brant_core tests scripts` | 通过 |
| 合成端到端 | 发布模板生成内部文件；A18 税务配置参与计算并绑定到文件历史 |
| 拒绝与原子性 | 配置对象受控、发布来源核实撤销时拒绝；正式化持久点为零残留 |

详细原始输出与机器摘要见 `evidence/a19-*.txt`、`evidence/a19-verification.json` 和 `evidence/a19-package-manifest.json`。交付包为 `IDP_Brant_T03_A19报价配置消费与文件生成验证包_V0.25.zip`，包外 SHA-256 在交付记录中提供。全部资料为合成数据。

## 尚未关闭的边界

本增量完成 A18 持久配置到现有报价冻结和内部文件路径的首轮消费接线，不意味着报价组合和报价运行态全部完成。引用范围仍要求显式客户、SKU／收费类型和当前配置版本；主体快照、完整候选报价查询、真实身份／岗位映射、企业来源核验、生产文件服务、远程认证、容量与恢复目标、COMMIT unknown 对账仍未完成。纯文本渲染器仅处理本地内部文件，没有外发副作用。

这不完成原 Q03 全部 48 场景，不构成生产准入或产品 V1.0 上线声明。报价外发、送达、客户接受和订单转换继续关闭。

## 复验命令

```bash
uv run --frozen python -m unittest tests.test_t03_a19_configuration_consumption -v
uv run --frozen python -m unittest discover -s tests -q
uv run --frozen python -m t03_candidate.verify
uv run --frozen python -m t03_candidate.verify_transaction_adapter
uv run --frozen mypy --check-untyped-defs brant_core
uv run --frozen ruff check brant_core tests scripts
```
