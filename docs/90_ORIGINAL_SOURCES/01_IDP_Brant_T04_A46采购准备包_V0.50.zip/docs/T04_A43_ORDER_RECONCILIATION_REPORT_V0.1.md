# T04 A43 订单审批对账闭环 V0.47

本阶段把三条订单审批公共命令纳入 action_reconciliation：order.review.request、order.review.decide、order.approval.revoke。对账按原命令与幂等键读取 action_result，匹配请求哈希时返回 committed，哈希不同时返回 payload_conflict，不存在时返回 not_committed；不会重新执行申请、裁决或撤销。

审批申请回执直接使用 order_id，裁决和撤销回执通过 review_id 反查订单并重新检查来源报价访问。对账只需要 quote.read/read，不要求重复授予写权限；对象不存在、回执结构损坏或跨范围访问均失败关闭。运行时、候选 schema 和权限映射保持同步。

验证使用合成数据和本地 SQLite，不代表外部订单提交、分布式 COMMIT unknown 或生产准入。
