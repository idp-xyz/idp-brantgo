# T03 调用方事务适配契约 V0.1

日期：2026-10-23。产品范围V1.0／CN-M01／S01不变。承接T03_CONTRACT_SPEC第7—10节及候选参考0.2.0。
本轮工程范围为共享T02实时资格适配口和事务设计；不注册T03命令、配置服务或迁移4。

## 1. 事务所有者与新增接口

正式报价命令服务是唯一事务所有者，持有连接，开启BEGIN IMMEDIATE，决定最终commit或rollback并承担成功／拒绝审计。
内部资格、权限、批准、编号和文档函数只能使用它传入的同一连接；禁止另开连接或调用自带事务的公开Core命令。

本轮新增受信任后端接口：

```python
query = core.costing_snapshot_in_transaction(db, who, snapshot_id)
```

db必须是指向该Core规范数据库路径的sqlite3.Connection，isolation_level=None、row_factory=sqlite3.Row、foreign_keys=ON，
并且已处于调用方事务中，不带附加数据库或TEMP对象，避免既有无模式限定读取被其他对象遮蔽。
连接或事务上下文不符合约定，抛出固定RuntimeError；SQLite自身故障原样向调用方传播。
该接口使用固定WHERE 0的main.scope零行UPDATE取得主库写保留锁，再执行读取，不修改任何scope行；即使调用方误用DEFERRED也不能先资格判断后抢锁。
调用方仍应在任何根、权限或资格读取前开启BEGIN IMMEDIATE；不把补取得锁当成允许使用较早读取状态的依据。

who由受信任宿主提供，服务端重新读取costing.read、read、foundation.read及资料范围，不接收调用方自填grants、eligible或检查时点。
资格时点从Core注入的服务器时钟取得，沿用T02完整依赖、当前效力、反证和资源预算；输出与既有snapshot_query结构相同。
接口不BEGIN、不commit、不rollback、不创建独立动作或Outbox，不对失败登记另一笔成功。内部资格检查归调用方业务审计负责。
既有costing_get(snapshot_query)复用同一资格实现，继续自行拥有读取事务和审计；显示查询结果不是写入授权令牌。
该Python接口不允许直接暴露为接收数据库路径、连接或Principal的HTTP入口。

## 2. 错误与调用方责任

| 情况 | 内层结果 | 外层责任 |
|---|---|---|
| 可读快照当前合格 | currently_eligible_for_quote=true与服务器时点 | 继续验证报价其余条件；不得仅凭此提交 |
| 旧输入停用、反证或自然到期 | 已知业务资格false，历史快照不变 | 新正式化转换为COST_SNAPSHOT_NOT_ELIGIBLE并回滚 |
| 权限不足、范围隐藏、未知引用、容量超限 | 传播精确Rejected错误；不降为false | 业务回滚；按原防泄露口径记录拒绝审计 |
| 非法连接／事务上下文 | RuntimeError，不转换为业务资格 | 视为适配配置错误，回滚并停止该入口 |
| SQLITE_BUSY、只读、I/O或其他存储故障 | 传播sqlite3.Error | 整笔回滚；独立决定有界重试／告警；不返回伪业务成功 |

调用方在失败后必须rollback，不能捕获后仍提交同事务其他业务变化。没有成功提交就不占成功幂等键。
调用方把该结果与具体快照ID、result_hash、商业修订、服务器时点和提交证据绑定，不能跨事务缓存后复用。
调用方拥有读／拒绝审计；内层不偷偷提交审计来破坏外层原子性。现有独立查询保留原审计行为。

## 3. 当前授权与服务器对象控制（后续适配，尚未实现）

| 接口职责 | 必须读取／绑定 | 失败规则 |
|---|---|---|
| resolve_authority | 当前scope、actor_kind、精确命令权、读取权、own/team/company、所有者及团队；authority_epoch | 每次动作从数据库取得；管理员或配置权不代替交易权 |
| resolve_root_control | 服务器quote_root控制关联、control_epoch、绑定任务及委托代次 | 请求不带task_id仍须查服务器绑定；未知、stopping或过时代次阻断 |
| resolve_conversion_slot | 同根订单转换名额的权威表，使用同一锁序列 | replace/cancel遇占用拒绝；未知能力不能默认无订单 |

拟新增scope级authority_epoch及根级control_epoch。已有授权、角色／范围或记录归属变更入口须在同一事务递增相应epoch；
旧记录迁移必须能证明归属和初始授权，不允许把新epoch伪装为旧历史证据。没有全部变更入口接入就不能宣布守卫有效。
已有provision暂未写epoch，ObjectControl也未实现；本轮共享资格适配不关闭这两项缺口。

## 4. 审批解析与最终时效裁决（后续适配）

resolve_current_approval(db,who,target,as_of)须绑定scope、quote_id、business_revision、business_hash、activate/replace、
预期旧active、政策修订、批准效力版本、decided_at/expires_at；重新读取审核人当前资格与必要资料范围，并核对编制／冻结集合独立性。
替代目标改变时不能改旧批准。批准决定不是报价生效，撤销不是删除原决定；已生效后撤销追加风险及目标修订hold。

时间分为商业起算issued_at、原批准decided_at和当前裁决as_of。已冻结issued_at、expires_at不因等待审核或重试重设。
临近提交重新采集server_commit_at，检查报价／批准／配置／来源／FX有效区间和FX最大观察年龄；相等于期限即拒绝。
若时钟相对本事务前次裁决倒退，拒绝本次新正式化，不能用更早时间恢复资格；成功历史重放不重新作时效采用。
最终裁决还须核对authority_epoch、control_epoch、批准效力和根版本；同SQLite写锁保证本地变更不能中途先提交。
server_commit_at是持锁的最终授权裁决时点，不表示物理落盘完成；提交路径必须有界且无模型／网络／远端对象存储等待。

## 5. 正式化原子写集合（后续适配）

| 顺序 | 行为 | 失败时结果 |
|---|---|---|
| 1 | 严格契约、当前身份／范围／控制；成功键检查及原结果历史读取权 | 同键换完整请求冲突；获权旧成功只重放原事实 |
| 2 | 根CAS、目标修订、旧active、转换名额、hold；前向全依赖和商业重建 | 不做编号，不形成成功结果 |
| 3 | 用本轮接口在该db重算T02当前资格；复核批准及当前审核人 | 未知或失败不压成普通false继续执行 |
| 4 | 事务内分配编号、确定性本地渲染、数据库封存字节及哈希 | 编号、文件与其他新业务写入整体回滚 |
| 5 | 最终时效、授权／控制／根／批准裁决，追加CommitEvidence | 任一失效则同事务整体回滚 |
| 6 | 旧版效力、新active、根指针、归属、动作结果、成功审计、仅内部正式化Outbox | 所有事实共同提交，失败无部分成功 |

事务内编号使用无歧义业务键(scope,quote_id,business_revision)，复用底层分配器而非嵌套foundation.number.issue。
正式文件反向绑定商业哈希、模板、渲染器、编号、MIME、大小及字节哈希；不把编号／最终文件哈希再塞入商业哈希形成循环。
本轮不改变旧foundation.document.render的DRAFT语义。正式主文档不能由任意上传替代，也没有外发、送达或客户接受副作用。

## 6. 提交不确定、幂等与纠错

持久写事务成功才保存action_result；同scope+command+idempotency_key绑定完整规范请求，包括CAS。异键不允许重复同修订正式化。
若COMMIT返回未知故障，不能仅凭异常声称已回滚或安全重发；客户端使用原键查询／重试，由持久成功结果裁定是否已经提交。
无法确认结果时暴露技术不确定状态并进入对账，不分配新键重做。重开服务读取原事实，不受自然过期影响；当前读取权限仍须复核。
审批撤销、来源反证和成本变化后，历史金额／文件／原成功保留；quote_ready按当前资格另行失败，不依赖异步风险投影才开始阻断。

## 7. 存储选择、迁移与验证顺序

本地参考沿用单文件SQLite；不把本轮锁测试扩大为生产数据库ADR或分布式事务承诺。
迁移4仍未注册，既有schema_migration=1/2/3和历史记录保留。epoch／控制／T03新增表须先形成完整迁移脚本及故障／并发／恢复证明。
拟先实施有限前置项：共享资格适配、授权与控制存储、配置持久化，再实施报价草稿／冻结、审核、正式化及ready。
每步以公共Core接口和明确SQLite边界验证；拒绝后比较全部业务表，编号、文件、动作和Outbox不能留下部分成功。

## 8. 本轮证据与准入判定

本轮以真实Core公共接口建立合成T02快照，使用同一真实SQLite连接评估资格，验证调用方写入可回滚、
错误不提交、当前反证／撤权／到期、写保留锁及存储错误传播。伴随写入使用明确probe表，不冒充报价、审批或正式化。
新增实测另存transaction-verification.json，不与既有350条候选收据或162项核心回归混成一种测试计数。

本轮只登记共享资格适配的有限工程范围，不能据此关闭完整T03-G04/G05。
完整编码准入仍须逐项复核G01—G06；报价运行态与产品V1.0上线标记保持false。
