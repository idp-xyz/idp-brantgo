# T03 A12 内部投递状态运行态报告 V0.1

日期：2026-10-24。承接 T03 A11 文档历史运行态 V0.17。

## 本轮实现

- 新增 `outbox_history` 只读查询，要求明确的 `event_id`，在同一 SQLite 事务内完成权限检查、对象读取、审计和提交。
- 返回内部 Outbox 事件的稳定元数据：报价、商业修订、事件类型、创建时间和 payload SHA-256。
- 明确返回 `dispatch_state=queued` 与 `external_delivery_status=not_started`，避免把事务内 Outbox 记录误解释为已发送、已送达或客户已接受。
- 公共响应不带原始 `payload_json`；底层 Outbox 仍为正式化事务写入的不可变记录，没有外部 dispatcher、重试记录或送达回执。

## 验证

| 层级 | 结果 |
|---|---:|
| A12 内部投递状态专项 | 8 项通过 |
| A11 与既有核心全量回归 | 201 项通过 |
| 候选检查 | 350 项通过 |
| 事务适配检查 | 39 项通过 |
| `mypy --check-untyped-defs brant_core` | 28 个源文件通过 |
| `ruff check brant_core tests scripts` | 通过 |
| 查询 schema 自检 | 通过 |
| ZIP 解压复验 | 通过 |

测试使用合成报价、审批、文档和内部 Outbox 资料；未连接外部发送渠道，也未生成送达或客户接受事实。本包不构成生产上线声明。

## 当前边界

外部发送、送达回执、重试／死信、客户接受、订单转换、企业 SSO／岗位映射、生产监控和 COMMIT unknown 对账仍未完成。候选完整 `document` 查询和报价写命令外部契约继续保持未注册。
