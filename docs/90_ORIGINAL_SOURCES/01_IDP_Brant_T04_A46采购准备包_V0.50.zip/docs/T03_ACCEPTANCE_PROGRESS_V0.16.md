# T03 验收进展 V0.16

日期：2026-11-04（Asia/Shanghai）。A31 V0.35、核心 0.5.1、迁移 12；仅合成资料和本地 SQLite。

A31 将 Foundation 的七种地址角色逐项映射到当前报价契约：buyer 与 billing 可作为报价客户地址；seller、payer、payee、consignee、shipper 因报价没有相应独立绑定字段而拒绝。地址角色映射和失败边界已加入专项测试与生成文件。本轮不扩展地址业务语义、报价字段、数据库迁移或凭证格式。A31 专项 4 项、联合回归 268 项、Core 全量 449 项、候选检查 350 项、事务适配 39 项均通过；ruff、mypy、compileall 通过。映射生成器幂等，A30 的 468 项清单及原归档哈希保持不变。测试套件有交集，不应相加，完整命令与证据见 `evidence/a31-verification.json`。

后续继续补齐报价计算组合、授权及对象控制映射，再按映射推进持久化。正式报价运行态、完整 T04、原 Q03-01—48、G01—G06、生产准入和 V1.0 仍未完成。范围见 `docs/T03_A31_QUOTE_ADDRESS_ROLE_MAPPING_REPORT_V0.1.md`。
