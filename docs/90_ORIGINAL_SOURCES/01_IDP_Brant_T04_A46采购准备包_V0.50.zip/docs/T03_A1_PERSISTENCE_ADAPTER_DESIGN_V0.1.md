# T03 A1 持久化适配设计 V0.1

日期：2026-10-23。本文冻结迁移与适配边界，供 A2 实现；不表示迁移4已经安装。

## 迁移 4 设计

迁移必须在 `BEGIN IMMEDIATE` 中执行，校验历史严格为 `[1,2,3]`，未知历史拒绝；所有 DDL 完成后才插入版本 4。
升级前保留现有来源、主数据、RFQ、成本快照、编号、文件、审计和归属。重复启动只读版本并成功返回，并行启动由 SQLite 写锁串行化。

新增表组：

- `t03_quote_root(tenant, company, quote_id, root_version, working_revision, active_revision, control_epoch, status)`；复合主键，状态封闭，根版本 CAS。
- `t03_quote_revision(..., business_revision, business_hash, data_json, calculation_json, contributors_json, status)`；修订内容和商业哈希不可变。
- `t03_quote_line`、`t03_quote_charge`、`t03_quote_payment`；子项唯一键、金额守恒由服务层执行。
- `t03_quote_effectivity`、`t03_quote_event`；效力和追加事件不可更新／删除，根至多一个 active。
- `t03_review_request`、`t03_approval`、`t03_approval_effectivity`；审核目标、哈希、独立性和效力版本固定。
- `t03_document_binding`、`t03_commit_evidence`、`t03_risk`；正式文件、最终裁决和风险只追加，反向绑定商业哈希。
- `scope.authority_epoch` 或等价授权版本；既有授权／归属变更入口必须全部接入递增守卫。
- `t03_object_control`；根的任务绑定、委托代次、control_epoch、状态和停止原因由服务器持有。

已有 `document_number`、`business_file`、授权及来源表的不可变约束不放宽。正式编号在 T03 事务内复用底层分配器，业务键为 `(scope, quote_id, business_revision)`。

## 单事务写集合

`activate`／`replace` 依次完成身份与控制、幂等结果、根 CAS、依赖与金额、同连接 T02 资格重查、批准效力、编号、确定性 UTF-8 文档、最终时效裁决、业务事实、审计和内部 Outbox；任何失败整体回滚。
提交返回未知时，使用原幂等键对账；不能换键重做，也不能仅凭异常声称已回滚。

## A2 实施准入

必须补齐所有授权／归属／控制变更入口、迁移故障恢复、并发竞争、拒绝后全表不变性和 COMMIT unknown 对账，之后才可将迁移4登记为可执行并开始报价草稿持久化。
