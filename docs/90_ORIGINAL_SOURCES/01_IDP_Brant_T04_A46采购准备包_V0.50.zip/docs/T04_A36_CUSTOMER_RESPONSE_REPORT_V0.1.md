# T04 A36 客户回复登记 V0.1

基于 A35 V0.39，新增受信任本地接口 `t04_record_customer_response` 与 `t04_get_customer_response`，使用合成数据与本地 SQLite。迁移 13 增加独立、不可修改或删除的客户回复表；关联报价根、来源及来源定位，保存人工分类、摘要、登记人和服务端登记时间。分类为 full_unconditional、conditional、partial、reject、ambiguous。

登记需人工身份、`quote.response.record`、`quote.read`、`read`、报价对象和来源访问，遵守报价任务绑定控制。读取和同 ID 重放重新检查当前报价与来源访问。相同 ID 相同内容重放，内容不同拒绝；失败事务不保留回复。历史来源或报价仍须可访问。

回复只是操作人员登记的分类和摘要，不证明客户身份、消息真实性、报价版本、确认效力或订单资格。任何分类都不会自动创建 Acceptance 或订单；完整无条件确认仍须使用原有核实接口及其全部检查。本阶段不支持回复更正、公开 JSON API、收件箱列表、渠道收发或将回复关联至确认。真实身份、客户渠道、独立订单审批、完整 T04、生产准入和 V1.0 未完成。

验证与包记录见 `evidence/a36-verification.json` 和包旁复验记录；A35 基线目录及归档应保持原样。
