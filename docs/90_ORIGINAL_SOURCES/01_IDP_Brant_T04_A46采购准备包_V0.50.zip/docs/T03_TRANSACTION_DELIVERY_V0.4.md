# IDP Brant T03 事务适配与持久化准入报告 V0.4

日期：2026-10-23。核心版本0.5.1，候选参考版本0.2.0，产品范围维持V1.0／CN-M01／S01。
V0.4是交付材料版本；报价正式化、完整运行态和产品上线尚未完成。

## 已交付结果

新增真实后端接口Core.costing_snapshot_in_transaction(db,who,snapshot_id)，在调用方已经开启的SQLite事务中，
按服务器时钟、当前权限、完整T02资料和反证重新评估成本快照资格。它与现有独立查询共用资格实现，避免两套规则分叉。
内层不另开事务、不提交或回滚，也不创建独立成功动作或Outbox；调用方持有事务所有权并承担整体审计。

接口校验Core数据库路径、活动事务、显式事务管理、Row工厂、外键及无TEMP／附加数据库；
通过固定main.scope零行UPDATE取得写保留锁，不修改scope行。非法上下文明确失败，锁冲突和只读故障按存储错误传播。
已证明调用方未提交的来源反证和授权撤回立即影响同连接资格，回滚后原事实恢复；不能靠较早显示查询继续采用旧资格。

本轮修改核心的T02读取适配和新增Core后端方法，项目及锁文件仅更新本地版本号，没有升级第三方依赖。
未注册T03报价／新增配置命令，未安装迁移4；旧冻结样例、四份商业哈希向量及350条候选材料保留。

## 验证口径

| 验证层 | 本轮结果 | 说明 |
|---|---:|---|
| 真实Core／SQLite事务适配 | 39条收据全部通过 | 当前资格、服务器时钟、连接守卫、同连接未提交事实、调用方提交／回滚、实际writer锁及错误传播 |
| 既有候选参考验证 | 350条收据全部通过 | 配置、依赖、报价声明准入、算术、文档、黄金向量及参考DDL；不等同报价持久化 |
| 原核心全量回归 | 162项测试全部通过 | 核心0.5.1实际运行；保留新原始日志，不覆盖0.5.0的历史回归证据 |
| 类型与静态检查 | mypy40个源文件、ruff检查与格式检查通过 | Python使用uv锁定环境 |

三个验证层分别统计，不将子断言或收据数量相加后称为业务场景总数。
事务实测见t03_candidate/evidence/transaction-verification.json，原核心日志为core-regression-0.5.1.txt，阶段汇总见qualification.json。
探针写入使用临时transaction_probe表，只证明共享事务边界；它不是报价、批准、编号、主文件或正式化业务结果。
所有来源、主体、客户和交易参数均为合成资料，没有外部消息、订单、资金或申报动作。

## 双轴审查

### Standards

固定基点为上次交付4ce8c5e；本轮实现8d6efb2。独立规范审查未发现硬性问题，新增判断性气味建议0项。
共享读取避免资格规则重复；固定SQL、受信任连接边界、真实临时库及分层证据与本轮规范一致。

### Spec

规格符合性初审发现1项小的连接类型错误语义缺陷：传入None先访问连接属性，抛出AttributeError，未按契约统一RuntimeError。
fa28849在任何连接属性读取前检查类型，公开反例先复现失败再验证修复；独立限定复核确认缺陷关闭。
8项独立探针验证非法句柄、正常资格、事务保持、旧查询和错误传播，未发现新增实质回归；不与39条适配收据重复计数。
两轴审查范围内遗留阻断为0，完整记录见docs/T03_TRANSACTION_REVIEW_V0.1.md。
审查范围是共享资格前置工程及适配设计，没有把尚未实现的报价授权／控制／批准／编号／文档事务标记为通过。

## 持久化准入判定

已形成T03_TRANSACTION_ADAPTER_V0.1.md，明确唯一事务所有者、当前权利与对象控制职责、独立批准、最终时效裁决、
编号／文档／成功事实原子写集合、COMMIT结果不确定时的原键对账以及迁移顺序。

完整G01—G06仍未全部关闭，逐项证据与剩余工作见T03_PERSISTENCE_ADMISSION_V0.1.md。
本轮只完成实时T02共享事务适配；authority_epoch、ObjectControl、正式报价审批与最终提交仍待落实。
shared_t02_transaction_adapter_implemented可记录true；t03_full_coding_admission_passed、t03_runtime_service_implemented、
product_v1_launch_ready继续为false。

下一工作包A1补齐组合算术、报价动作／事件／权利映射以及迁移／授权／控制适配设计，再登记限定存储实施范围。
产品方向和CN-M01边界保持锁定，后续按配置持久化、报价草稿／冻结、审核批准、正式化／ready顺序推进。

## 完整包与复验

完整ZIP包含核心源码、原测试、锁文件、候选材料、事务契约、准入复核和原始证据。在解压根目录执行：

```bash
uv sync --frozen
uv run --frozen python -m t03_candidate.verify_transaction_adapter
uv run --frozen python -m t03_candidate.verify
uv run --frozen mypy --check-untyped-defs brant_core t03_candidate
uv run --frozen ruff check brant_core t03_candidate
uv run --frozen ruff format --check brant_core t03_candidate
```

需要Python3.12和Node.js24。首次安装须取得锁定依赖，不承诺离线安装。正常复验不重生成业务样例或黄金向量。
需要重新完整回归时执行uv run --frozen python -m unittest discover -s tests -v；解压复验是否重复该项按实际记录说明。
