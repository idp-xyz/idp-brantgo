# T03 A1 报价动作、事件、授权与对象控制映射 V0.1

日期：2026-10-23。该映射是 A2 持久化实现的输入；当前 Core 尚未注册这些命令。

## 动作映射

| 命令 | 状态转换 | 必需权限 | 数据范围 | 角色／控制 | 版本守卫 |
|---|---|---|---|---|---|
| quote.save_draft | root/new → working | `quote.write` | own/team/company | 人工或受信任 AI；根控制必须可解析 | root_version、幂等键 |
| quote.revise | sealed → working | `quote.write` | root + 依赖读取 | 人工或受信任 AI；不得越过根控制 | base_revision、root_version |
| quote.discard_draft | working → sealed | `quote.write` | root | 人工；控制冲突拒绝 | draft_generation |
| quote.freeze | working → frozen | `quote.freeze` | 完整依赖读取 | 人工；编制集合追加，不可清空 | draft_generation、root_version |
| quote.submit_review | frozen/pending → pending | `quote.review.request` | 完整依赖读取 | 人工；目标 activate／replace 固定 | root_version、business_revision |
| quote.review.approve | pending → pending | `quote.review.decide` | 完整依赖读取 | 人工且不在 contributors；当前 authority_epoch | review_request、business_hash |
| quote.review.return | pending → frozen | `quote.review.decide` | 完整依赖读取 | 独立人工；控制仍须有效 | review_request、root_version |
| quote.review.reject | pending → frozen | `quote.review.decide` | 完整依赖读取 | 独立人工；控制仍须有效 | review_request、root_version |
| quote.approval.revoke | approval valid → revoked | `quote.approval.revoke` | quote + approval | 当前人工权限；control_epoch | effectivity_version |
| quote.activate | pending → active | `quote.activate` | full dependency + cost | 人工；独立批准；服务器 root control | root_version、approval effectivity、authority_epoch、control_epoch |
| quote.replace | active + pending → superseded + active | `quote.replace` | full dependency + cost | 人工；旧 active 与转换名额锁定 | expected_old_active、root_version、两类 epoch |
| quote.withdraw | frozen/pending → withdrawn | `quote.withdraw` | quote | 人工；控制冲突拒绝 | root_version |
| quote.cancel | active → cancelled | `quote.cancel` | quote | 人工；转换名额为空；控制有效 | active revision、root_version |

`quote.read` 以及全部当前依赖的传递读取权是查询前置条件；配置、管理员、file.read 权限不能推导交易或批准权限。
AI 可以编制工作稿，但不能 freeze、提交审核、批准或正式化。`provision` 仍是可信本地初始化入口，不是报价 API。

## 事件与副作用

| 事件 | 产生动作 | 允许内容 | 禁止内容 |
|---|---|---|---|
| `quote.draft_saved` | save_draft/revise | 草稿版本、根版本、action_id | 正式编号、客户发送 |
| `quote.frozen` | freeze | 商业哈希、依赖清单 | 批准效力、active 指针 |
| `quote.review_requested` | submit_review | review_request、目标动作、哈希 | 自动批准 |
| `quote.review_decided` | approve/return/reject | 决定、审核人、效力版本 | 改写商业内容 |
| `quote.approval_revoked` | approval.revoke | 撤销追加事实、hold | 删除原批准 |
| `quote.activated` | activate | 正式编号、文件绑定、商业哈希 | 发信、送达、客户接受 |
| `quote.replaced` | replace | supersedes、旧／新修订绑定 | 复用旧正式编号 |
| `quote.withdrawn` / `quote.cancelled` | withdraw/cancel | 状态和原因 | 删除历史金额或文件 |

事件只表示已提交的内部业务事实；外发、送达和接受没有在本阶段开放。

## Epoch 与对象控制

- `scope.authority_epoch`：授权、角色、数据范围、记录归属或团队归属变化在同一事务递增；每次写动作从数据库读取，不接受请求自填。
- `t03_quote_root.control_epoch`：服务器对象控制、委托代次、绑定任务或停止状态变化在同一事务递增；请求缺少 task_id 不能推断“未绑定”。
- `t03_quote_root.root_version`：报价根 CAS；所有状态、active 指针和工作稿代次变化递增。
- `t03_review_request.effectivity_version`：批准撤销或效力变化递增；批准绑定 quote_id、business_revision、business_hash、command 和 expected_old_active_revision。

动作事务必须先取得同一数据库写序列，再按权限、对象控制、根 CAS、依赖、金额、批准、最终时效的顺序裁决。
任一 epoch 或控制版本不匹配，返回 `OBJECT_CONTROL_CONFLICT`／`VERSION_CONFLICT` 并整体回滚。
