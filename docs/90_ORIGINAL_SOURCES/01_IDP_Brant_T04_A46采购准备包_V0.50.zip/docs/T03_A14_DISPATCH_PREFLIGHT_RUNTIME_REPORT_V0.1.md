# T03 A14 发送前准入运行态报告 V0.1

日期：2026-10-24。承接 T03 A13 提交证据运行态 V0.19。

## 本轮实现

- 新增 `dispatch_preflight` 只读查询，要求明确的 `event_id`，在同一 SQLite 事务内完成权限检查、跨表一致性核对、审计和提交。
- 对内部 Outbox 事件同时核对对应 CommitEvidence、报价 active 指针、正式文档绑定／编号／文件完整性和审批当前效力及哈希引用。
- 返回 `ready_for_dispatch` 和去重原因码；成功条件只表示本地投递前资料链闭合，不表示已经发送或送达。
- 固定返回 `external_delivery_status=not_started`，不写 dispatcher 状态、重试、死信、送达回执或客户接受事实。

## 验证

| 层级 | 结果 |
|---|---:|
| A14 发送前准入专项 | 10 项通过 |
| A13 与既有核心全量回归 | 203 项通过 |
| 候选检查 | 350 项通过 |
| 事务适配检查 | 39 项通过 |
| `mypy --check-untyped-defs brant_core` | 28 个源文件通过 |
| `ruff check brant_core tests scripts` | 通过 |
| 查询 schema 自检 | 通过 |
| ZIP 解压复验 | 通过 |

测试使用合成报价、审批、文档、成本、CommitEvidence 和 Outbox 资料；未连接外部发送渠道，也未生成送达、客户接受或订单事实。本包不构成生产上线声明。

## 当前边界

外部发送、送达回执、重试／死信、客户接受、订单转换、企业 SSO／岗位映射、生产监控和 COMMIT unknown 对账仍未完成。候选完整 `document` 查询和报价写命令外部契约继续保持未注册。
