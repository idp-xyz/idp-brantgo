# T03 A1 工作范围 V0.5

日期：2026-10-23。承接 `IDP_Brant_T03_事务适配_V0.4`。

本轮补齐独立组合算术真值、报价动作／事件／授权映射，以及迁移、授权 epoch、服务器对象控制的实施设计和候选负例。
交付目录为 `IDP_Brant_T03_持久化前置_V0.5`；V0.4 原始交付与冻结样例保留。

验证完成前不登记通过。不安装迁移4，不注册报价运行态命令；A2—A4 持久化另行实施。
`t03_full_coding_admission_passed`、`t03_runtime_service_implemented`、`product_v1_launch_ready` 继续为 false。
