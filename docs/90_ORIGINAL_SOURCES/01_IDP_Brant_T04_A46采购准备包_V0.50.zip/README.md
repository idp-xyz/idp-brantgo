# IDP Brant T04 A46 采购准备 V0.50

承接 A45，增加受信任本地采购草稿：把已激活且订单审批未撤销的外销订单行，显式绑定到供应商报价（`supplier_offer`）或采购条件（`purchase_terms`）的当前有效版本，由服务端复核规格、数量、MOQ／订购倍数、阶梯价、税价拆分和交期，形成不可变、带哈希、可审核的采购草稿。采购草稿不是供应商承诺，也不发送采购单。详见 `docs/T04_A46_PURCHASE_DRAFT_REPORT_V0.1.md`，其中包含独立采购承诺审批的设计。

    uv run --frozen python scripts/verify_a46.py
    uv run --frozen python scripts/package_a46.py
    uv run --frozen python scripts/recheck_a46_package.py

本地调用示例：

```python
core.t04_purchase_prepare_draft(
    preparer, order_id, "purchase.draft.1",
    [{"order_line_id": "L1",
      "source": {"kind": "offer", "id": "offer.1", "revision": 1, "condition_line_id": "OL1"}}],
    "按核价所用供应报价备货",
)
core.t04_purchase_get_draft(reader, "purchase.draft.1")
```

编制要求人工身份及 `purchase.draft.prepare`、`quote.read`、`read`、`costing.read`、`foundation.read`；读取要求后四项。数据库迁移为第 17 版。本阶段仍使用合成资料和本地 SQLite，不提供公共 JSON 契约，不表示真实供应商、采购承诺、外部下单或生产准入已完成。
