"""Build a deterministic A30 archive from one verified source snapshot."""

from __future__ import annotations

import hashlib
import json
import zipfile

from verify_a30 import EXCLUDED, ROOT, source_hashes

ARCHIVE_NAME = "IDP_Brant_T03_A30联系人档案映射验证包_V0.34.zip"
MANIFEST_PATH = "evidence/a30-package-manifest.json"


def main() -> None:
    verification = json.loads((ROOT / "evidence/a30-verification.json").read_text(encoding="utf-8"))
    if verification.get("all_passed") is not True:
        raise RuntimeError("All A30 checks must pass before packaging")
    if (
        verification.get("source_input_set_unchanged") is not True
        or source_hashes() != verification["verified_source_hashes"]
    ):
        raise RuntimeError("The verified A30 source input set changed")
    snapshot = {}
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if (
            path.is_file()
            and not (set(relative.parts) & (EXCLUDED | {"build", "dist"}))
            and relative.as_posix() != MANIFEST_PATH
        ):
            snapshot[relative.as_posix()] = path.read_bytes()
    manifest = {
        "package": ARCHIVE_NAME,
        "source_version": "V0.34",
        "stage": "A30",
        "manifest_excludes_own_hash": True,
        "file_hash_algorithm": "sha256",
        "excluded_directory_names": sorted(EXCLUDED | {"build", "dist"}),
        "files": [
            {"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            for name, data in snapshot.items()
        ],
    }
    manifest_data = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    (ROOT / MANIFEST_PATH).write_bytes(manifest_data)
    snapshot[MANIFEST_PATH] = manifest_data
    archive = ROOT.parent / ARCHIVE_NAME
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, data in sorted(snapshot.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 4, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, data, compresslevel=9)
    result = {
        "archive": str(archive),
        "files_including_manifest": len(snapshot),
        "manifest_files": len(manifest["files"]),
        "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    }
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
