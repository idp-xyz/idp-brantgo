"""Run A35 checks and record their exact source inputs and baseline."""

import hashlib
import json
import re
import subprocess
import zipfile
from concurrent.futures import ThreadPoolExecutor

from verify_a31 import ROOT, source_hashes

BASE = ROOT.parent / "IDP_Brant_T03_A34报价就绪审核资格_V0.38"
ARCHIVE = ROOT.parent / "IDP_Brant_T03_A34报价就绪审核资格包_V0.38.zip"
EXPECTED = "3f0d7bd945a34440de06313f546f26d7c0009f5061e7a6f916bbe9e47f52bcd8"
CHECKS = {
    "special": ["python", "-m", "unittest", "tests.test_t03_a35_time_qualification", "-q"],
    "focused": ["python", "-m", "unittest", "tests.test_t03_a35_time_qualification",
                "tests.test_t03_a34_ready_reviewer", "tests.test_t03_a33_reviewer_qualification",
                "tests.test_t03_a32_sales_fx", "tests.test_t03_query_contract",
                "tests.test_t03_a26_order_qualification", "tests.test_t03_formalization", "-q"],
    "unittest": ["python", "-m", "unittest", "discover", "-s", "tests", "-q"],
    "candidate": ["python", "-m", "t03_candidate.verify"],
    "transaction": ["python", "-m", "t03_candidate.verify_transaction_adapter"],
    "ruff": ["ruff", "check", "brant_core", "tests", "scripts"],
    "mypy": ["mypy", "--check-untyped-defs", "brant_core"],
    "compileall": ["python", "-m", "compileall", "-q", "brant_core", "tests", "scripts"],
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def preserve_baseline():
    if sha(ARCHIVE.read_bytes()) != EXPECTED:
        raise RuntimeError("A34 archive hash changed")
    manifest_path = "evidence/a34-package-manifest.json"
    manifest = json.loads((BASE / manifest_path).read_text(encoding="utf-8"))
    with zipfile.ZipFile(ARCHIVE) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or archive.testzip() is not None:
            raise RuntimeError("A34 archive invalid")
        if set(names) != {item["path"] for item in manifest["files"]} | {manifest_path}:
            raise RuntimeError("A34 archive manifest mismatch")
        if archive.read(manifest_path) != (BASE / manifest_path).read_bytes():
            raise RuntimeError("A34 manifest changed")
        for item in manifest["files"]:
            source = (BASE / item["path"]).read_bytes()
            if len(source) != item["bytes"] or sha(source) != item["sha256"]:
                raise RuntimeError(f"A34 source changed: {item['path']}")
            if sha(archive.read(item["path"])) != item["sha256"]:
                raise RuntimeError(f"A34 archive member changed: {item['path']}")
    return {"sha256": EXPECTED, "manifest_files": len(manifest["files"]), "unchanged": True}


def main():
    baseline = preserve_baseline()
    inputs = source_hashes()

    def run(item):
        name, args = item
        command = ["uv", "run", "--frozen", *args]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
        output = result.stdout + result.stderr
        (ROOT / "evidence" / f"a35-{name}.txt").write_text(output, encoding="utf-8")
        count = re.search(r"Ran (\d+) tests?", output)
        return name, {"command": command, "exit_code": result.returncode,
                      "test_count": int(count.group(1)) if count else None,
                      "evidence": f"evidence/a35-{name}.txt"}

    with ThreadPoolExecutor(max_workers=4) as pool:
        checks = dict(pool.map(run, CHECKS.items()))
    unchanged = inputs == source_hashes()
    passed = unchanged and all(value["exit_code"] == 0 for value in checks.values())
    report = {"stage": "A35", "source_version": "V0.39", "core_version": "0.5.1",
              "migration": 12, "date": "2026-11-05", "timezone": "Asia/Shanghai",
              "verified_source_hashes": inputs, "source_input_set_unchanged": unchanged,
              "historical_a34_preservation": baseline, "checks": checks, "all_passed": passed,
              "fixture_classification": "synthetic", "production_admission": False}
    (ROOT / "evidence/a35-verification.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"checks": checks, "all_passed": passed}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
