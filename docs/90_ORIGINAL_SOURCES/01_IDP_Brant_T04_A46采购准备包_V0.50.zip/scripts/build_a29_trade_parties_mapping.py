"""Generate the bounded synthetic quotation trade-party mapping."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    mapping = {
        "stage": "A29", "source_version": "V0.33", "core_version": "0.5.1", "migration": 12,
        "contract": "brant.quote-trade-parties/0.1.0",
        "transaction": "caller-owned SQLite writer transaction, no commit or rollback",
        "issuer": "current authorized company with legal name, registration, country and address",
        "customer": "current confirmed customer and active party profile with matching row version",
        "address": "exactly one selected nonempty buyer or billing address",
        "contact": "confirmed contact belonging to customer, exact id and row version in contact_refs",
        "terms": "profile trade and payment term references must exactly match quotation references",
        "proof": "calculation.trade_party_binding contains resolved values, profile hashes and binding hash",
        "recheck": ["quote.freeze", "quote.activate", "quote.replace", "new order.activate", "quote_ready"],
        "history": "old records remain readable; missing or changed proof cannot authorize new formalization; committed replay remains unchanged",
        "limitations": ["contact profile contacts are not supported", "other address roles are not supported",
                        "term override and negotiation are not supported", "synthetic local SQLite only",
                        "no complete quotation runtime, T04, production admission or V1.0 claim"],
        "external_business_actions": 0,
    }
    path = ROOT / "t03_candidate/contracts/quote-trade-parties-mapping-v0.33.json"
    path.write_text(json.dumps(mapping, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"contract": mapping["contract"], "migration": mapping["migration"]}))


if __name__ == "__main__":
    main()
