import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def ref(name):
    return {"$ref": f"#/$defs/{name}"}


def branch(command, response_result):
    inner = {
        "type": "object",
        "properties": {
            "ok": {"const": True}, "command": {"const": command}, "action_id": ref("id"),
            "replayed": {"type": "boolean"}, "result": {"type": "object", "properties": response_result,
                "required": list(response_result), "additionalProperties": False},
        }, "required": ["ok", "command", "action_id", "replayed", "result"], "additionalProperties": False,
    }
    return {
        "type": "object", "properties": {"command": {"const": command}, "idempotency_key": ref("id"),
            "request_hash": ref("hash"), "state": {"const": "committed"}, "action_id": ref("id"),
            "object_id": ref("id"), "result": inner},
        "required": ["command", "idempotency_key", "request_hash", "state", "action_id", "object_id", "result"],
        "additionalProperties": False,
    }


def main():
    commands = {
        "quote.response.record": {
            "response_id": ref("id"), "quote_id": ref("id"),
            "classification": {"enum": ["full_unconditional", "conditional", "partial", "reject", "ambiguous"]},
            "recorded_at": ref("time"), "status": {"const": "recorded"},
        },
        "quote.response.verify": {
            "response_id": ref("id"), "acceptance_id": ref("id"), "quote_id": ref("id"), "status": {"const": "verified"},
        },
    }
    for relative in ("brant_core/contracts/T03_query-responses.schema.json", "t03_candidate/contracts/query-responses.schema.json"):
        path = ROOT / relative
        body = json.loads(path.read_text())
        action = next(item for item in body["oneOf"] if item.get("properties", {}).get("kind", {}).get("const") == "action_reconciliation")
        action["properties"]["value"]["oneOf"].extend(branch(command, result) for command, result in commands.items())
        path.write_text(json.dumps(body, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
