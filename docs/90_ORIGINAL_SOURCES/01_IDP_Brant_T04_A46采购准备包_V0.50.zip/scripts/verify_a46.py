"""Verify the A46 source and preserve the A45 delivery baseline."""

import json
import re
import subprocess
from concurrent.futures import ThreadPoolExecutor

import verify_a35 as baseline
from verify_a31 import ROOT, source_hashes

baseline.BASE = ROOT.parent / "IDP_Brant_T04_A45客户回复公共查询与恢复_V0.49"
baseline.ARCHIVE = ROOT.parent / "IDP_Brant_T04_A45客户回复公共查询与恢复包_V0.49.zip"
baseline.EXPECTED = "2e16ad23d100a48c020d25327f35ad6b2962eb8e67cb1cdf036718fe43ef60db"
CHECKS = {
    "special": ["python", "-m", "unittest", "tests.test_t04_a46_purchase_draft", "-q"],
    "focused": ["python", "-m", "unittest", "tests.test_t04_a46_purchase_draft",
                "tests.test_t04_a45_response_query_recovery", "tests.test_t04_a43_order_reconciliation",
                "tests.test_t04_a42_public_review_query", "tests.test_t04_a41_public_review",
                "tests.test_t04_a40_public_revoke", "tests.test_t04_a39_order_gate",
                "tests.test_t04_a38_order_review", "tests.test_t04_a37_response_verification",
                "tests.test_t04_a36_customer_response", "tests.test_t03_a25_order_snapshot",
                "tests.test_t03_a26_order_qualification", "tests.test_t03_a27_cost_scope",
                "tests.test_t03_a20_acceptance_order", "tests.test_t03_persistence",
                "tests.test_t03_snapshot", "tests.test_t03_configuration_runtime", "-q"],
    **{key: baseline.CHECKS[key] for key in ("unittest", "candidate", "transaction", "ruff", "mypy", "compileall")},
}


def preserve_baseline():
    # The inherited verifier hard-codes its manifest path.
    import hashlib
    import zipfile

    archive = baseline.ARCHIVE
    if hashlib.sha256(archive.read_bytes()).hexdigest() != baseline.EXPECTED:
        raise RuntimeError("A45 archive changed")
    manifest_path = "evidence/a45-package-manifest.json"
    manifest_bytes = (baseline.BASE / manifest_path).read_bytes()
    manifest = json.loads(manifest_bytes)
    with zipfile.ZipFile(archive) as packed:
        names = packed.namelist()
        if len(names) != len(set(names)) or packed.testzip() is not None:
            raise RuntimeError("A45 archive invalid")
        if set(names) != {entry["path"] for entry in manifest["files"]} | {manifest_path}:
            raise RuntimeError("A45 manifest mismatch")
        if packed.read(manifest_path) != manifest_bytes:
            raise RuntimeError("A45 manifest changed")
        for entry in manifest["files"]:
            data = (baseline.BASE / entry["path"]).read_bytes()
            if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
                raise RuntimeError("A45 source changed: " + entry["path"])
            if packed.read(entry["path"]) != data:
                raise RuntimeError("A45 archive member changed: " + entry["path"])
    return {"sha256": baseline.EXPECTED, "manifest_files": len(manifest["files"]), "unchanged": True}


def main():
    previous = preserve_baseline()
    inputs = source_hashes()

    def run(item):
        name, args = item
        command = ["uv", "run", "--frozen", *args]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
        output = result.stdout + result.stderr
        (ROOT / "evidence" / f"a46-{name}.txt").write_text(output, encoding="utf-8")
        count = re.search(r"Ran (\d+) tests?", output)
        return name, {"command": command, "exit_code": result.returncode,
                      "test_count": int(count.group(1)) if count else None,
                      "evidence": f"evidence/a46-{name}.txt"}

    with ThreadPoolExecutor(max_workers=4) as pool:
        checks = dict(pool.map(run, CHECKS.items()))
    unchanged = inputs == source_hashes()
    passed = unchanged and all(item["exit_code"] == 0 for item in checks.values())
    report = {"stage": "A46", "source_version": "V0.50", "migration": 17,
              "verified_source_hashes": inputs, "source_input_set_unchanged": unchanged,
              "historical_a45_preservation": previous, "checks": checks, "all_passed": passed,
              "fixture_classification": "synthetic", "supplier_commitment": False,
              "production_admission": False}
    (ROOT / "evidence/a46-verification.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"checks": checks, "all_passed": passed}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
