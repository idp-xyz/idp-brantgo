"""Package the verified A40 snapshot deterministically."""

import hashlib
import json
import zipfile

from verify_a31 import EXCLUDED, ROOT, source_hashes

ARCHIVE = ROOT.parent / "IDP_Brant_T04_A40审批撤销公共契约包_V0.44.zip"
MANIFEST = "evidence/a40-package-manifest.json"


def main():
    verification = json.loads((ROOT / "evidence/a40-verification.json").read_text(encoding="utf-8"))
    if not verification["all_passed"] or source_hashes() != verification["verified_source_hashes"]:
        raise RuntimeError("A40 source inputs have not passed verification")
    files = {}
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if (path.is_file() and not (set(relative.parts) & (EXCLUDED | {"build", "dist"}))
                and relative.as_posix() != MANIFEST):
            files[relative.as_posix()] = path.read_bytes()
    manifest = {"stage": "A40", "source_version": "V0.44", "manifest_excludes_own_hash": True,
                "files": [{"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                          for name, data in files.items()]}
    manifest_data = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    (ROOT / MANIFEST).write_bytes(manifest_data)
    files[MANIFEST] = manifest_data
    with zipfile.ZipFile(ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, data, compresslevel=9)
    with zipfile.ZipFile(ARCHIVE) as check:
        if check.testzip() is not None or set(check.namelist()) != set(files):
            raise RuntimeError("Archive integrity check failed")
        if any(check.read(name) != data for name, data in files.items()):
            raise RuntimeError("Archive does not match verified source")
    print(json.dumps({"archive": str(ARCHIVE), "files": len(files),
                      "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
