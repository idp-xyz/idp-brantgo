"""Reproduce A25 checks and record actual command output and return codes."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHECKS = {
    "unittest": ["python", "-m", "unittest", "discover", "-s", "tests", "-q"],
    "special": ["python", "-m", "unittest", "tests.test_t03_a25_order_snapshot", "-q"],
    "focused": [
        "python",
        "-m",
        "unittest",
        "tests.test_t03_a25_order_snapshot",
        "tests.test_t03_a24_write_control",
        "tests.test_t03_a23_reconciliation_access",
        "tests.test_t03_a20_acceptance_order",
        "tests.test_t03_query_contract",
        "tests.test_t03_persistence",
        "tests.test_t03_snapshot",
        "tests.test_t03_configuration_runtime",
        "-q",
    ],
    "candidate": ["python", "-m", "t03_candidate.verify"],
    "transaction": ["python", "-m", "t03_candidate.verify_transaction_adapter"],
    "ruff": ["ruff", "check", "brant_core", "tests", "scripts"],
    "mypy": ["mypy", "--check-untyped-defs", "brant_core"],
    "compileall": ["python", "-m", "compileall", "-q", "brant_core", "tests", "scripts"],
}


def main() -> None:
    paths = [
        ROOT / folder / name
        for folder, names in (
            (
                "brant_core/contracts",
                ("T03_queries.schema.json", "T03_query-responses.schema.json"),
            ),
            (
                "t03_candidate/contracts",
                (
                    "queries.schema.json",
                    "query-responses.schema.json",
                    "reconciliation-authority-mapping-v0.27.json",
                    "write-control-mapping-v0.28.json",
                    "order-commercial-snapshot-mapping-v0.29.json",
                ),
            ),
        )
        for name in names
    ]
    before = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    generated = subprocess.run(
        [sys.executable, "scripts/build_a23_reconciliation_contract.py"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=True,
    )
    snapshot_generated = subprocess.run(
        [sys.executable, "scripts/build_a25_order_snapshot_contract.py"],
        cwd=ROOT, capture_output=True, text=True, check=True,
    )
    after = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    if before != after:
        raise RuntimeError("Generated A25 contracts were stale; review and rerun verification")

    def check(item):
        name, args = item
        command = ["uv", "run", "--frozen", *args]
        process = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
        output = process.stdout + process.stderr
        (ROOT / "evidence" / f"a25-{name}.txt").write_text(output, encoding="utf-8")
        return name, {
            "command": command,
            "exit_code": process.returncode,
            "evidence": f"evidence/a25-{name}.txt",
        }

    with ThreadPoolExecutor(max_workers=4) as pool:
        checks = dict(pool.map(check, CHECKS.items()))
    passed = all(item["exit_code"] == 0 for item in checks.values())
    report = {
        "slice": "T03 A25 exact order commercial snapshot",
        "migration": 12,
        "verified_source_hashes": {
            str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(ROOT.rglob("*"))
            if p.is_file() and not set(p.relative_to(ROOT).parts) & {
                ".venv", "__pycache__", ".mypy_cache", ".ruff_cache", ".pytest_cache"
            } and (
                p.relative_to(ROOT).parts[0] in {"brant_core", "tests", "scripts", "t03_candidate"}
                or p.name in {"pyproject.toml", "uv.lock"}
            )
        },
        "source_version": "V0.29",
        "executed_at_local_date": "2026-11-04",
        "timezone": "Asia/Shanghai",
        "checks": checks,
        "all_passed": passed,
        "schema_generation_idempotent": before == after,
        "schema_hashes": after,
        "schema_generator_output": generated.stdout.strip() + "\n" + snapshot_generated.stdout.strip(),
        "fixture_classification": "synthetic",
        "external_business_actions": 0,
        "production_admission": False,
        "product_v1_complete": False,
    }
    (ROOT / "evidence/a25-verification.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
