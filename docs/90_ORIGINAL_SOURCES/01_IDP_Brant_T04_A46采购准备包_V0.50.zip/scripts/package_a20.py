"""Build the A19 flat verification ZIP and a per-file SHA-256 manifest."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_NAME = "IDP_Brant_T03_A20客户确认与订单落地验证包_V0.26.zip"
MANIFEST = ROOT / "evidence" / "a19-package-manifest.json"
EXCLUDED_DIRECTORIES = {
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "build",
    "dist",
}


def main() -> None:
    files = []
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if not path.is_file() or any(part in EXCLUDED_DIRECTORIES for part in relative.parts):
            continue
        if relative == MANIFEST.relative_to(ROOT):
            continue
        content = path.read_bytes()
        files.append(
            {
                "path": relative.as_posix(),
                "bytes": len(content),
                "sha256": hashlib.sha256(content).hexdigest(),
            }
        )
    manifest = {
        "package": ARCHIVE_NAME,
        "source_version": "V0.26",
        "file_hash_algorithm": "sha256",
        "manifest_excludes_own_hash": True,
        "excluded_directory_names": sorted(EXCLUDED_DIRECTORIES),
        "files": files,
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    archive = ROOT.parent / ARCHIVE_NAME
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for path in sorted(ROOT.rglob("*")):
            relative = path.relative_to(ROOT)
            if not path.is_file() or any(part in EXCLUDED_DIRECTORIES for part in relative.parts):
                continue
            out.write(path, relative.as_posix())
    with zipfile.ZipFile(archive) as packaged:
        corrupt = packaged.testzip()
        if corrupt is not None:
            raise RuntimeError(f"ZIP integrity failed at {corrupt}")
        names = set(packaged.namelist())
        expected = {item["path"] for item in files} | {MANIFEST.relative_to(ROOT).as_posix()}
        if names != expected:
            raise RuntimeError("ZIP file list does not match package source and manifest")
    print(json.dumps({"archive": str(archive), "files": len(files) + 1}, ensure_ascii=False))


if __name__ == "__main__":
    main()
