import json
from pathlib import Path

base = Path(__file__).parents[1] / "brant_core" / "contracts"

request_path = base / "T03_queries.schema.json"
request = json.loads(request_path.read_text(encoding="utf-8"))
request["oneOf"].insert(
    0,
    {
        "type": "object",
        "properties": {
            "contract": {"const": "brant.quotation/0.1.0"},
            "kind": {"const": "quote_history"},
            "args": {
                "type": "object",
                "properties": {
                    "quote_id": {"$ref": "#/$defs/id"},
                    "business_revision": {"$ref": "#/$defs/positive_version"},
                },
                "required": ["quote_id", "business_revision"],
                "additionalProperties": False,
            },
        },
        "required": ["contract", "kind", "args"],
        "additionalProperties": False,
    },
)
request_path.write_text(json.dumps(request, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

response_path = base / "T03_query-responses.schema.json"
response = json.loads(response_path.read_text(encoding="utf-8"))
calculation = {
    "type": "object",
    "properties": {
        "net_minor": {"$ref": "#/$defs/minor"},
        "tax_minor": {"$ref": "#/$defs/minor"},
        "payable_minor": {"$ref": "#/$defs/minor"},
        "comparison_revenue_minor": {"$ref": "#/$defs/minor"},
        "cost_minor": {"$ref": "#/$defs/minor"},
        "profit_minor": {"$ref": "#/$defs/signed_minor"},
        "margin_rule": {"enum": ["pass", "requires_approval"]},
    },
    "required": [
        "net_minor",
        "tax_minor",
        "payable_minor",
        "comparison_revenue_minor",
        "cost_minor",
        "profit_minor",
        "margin_rule",
    ],
    "additionalProperties": False,
}
qualification = {
    "type": "object",
    "properties": {
        "snapshot_id": {"$ref": "#/$defs/id"},
        "currently_eligible_for_quote": {"type": "boolean"},
        "result_hash": {"$ref": "#/$defs/hash"},
        "eligibility_checked_at": {"$ref": "#/$defs/time"},
        "reason": {"$ref": "#/$defs/text"},
    },
    "required": ["snapshot_id", "currently_eligible_for_quote"],
    "additionalProperties": False,
}
revision = {
    "type": "object",
    "properties": {
        "business_revision": {"$ref": "#/$defs/positive_version"},
        "status": {
            "enum": [
                "working",
                "frozen",
                "pending_approval",
                "active",
                "superseded",
                "withdrawn",
                "cancelled",
            ]
        },
        "business_hash": {"$ref": "#/$defs/hash"},
        "issued_at": {"$ref": "#/$defs/time"},
        "expires_at": {"$ref": "#/$defs/time"},
        "calculation": calculation,
        "current_cost_qualification": qualification,
    },
    "required": ["business_revision", "status", "business_hash"],
    "additionalProperties": False,
}
response["oneOf"].insert(
    0,
    {
        "type": "object",
        "properties": {
            "ok": {"const": True},
            "kind": {"const": "quote_history"},
            "value": {
                "type": "object",
                "properties": {
                    "quote_id": {"$ref": "#/$defs/id"},
                    "root_version": {"$ref": "#/$defs/positive_version"},
                    "status": {
                        "enum": [
                            "working",
                            "frozen",
                            "pending_approval",
                            "active",
                            "superseded",
                            "withdrawn",
                            "cancelled",
                        ]
                    },
                    "current_active_revision": {"$ref": "#/$defs/positive_version"},
                    "revision": revision,
                    "event_count": {"type": "integer", "minimum": 0, "maximum": 100000},
                },
                "required": ["quote_id", "root_version", "status", "revision", "event_count"],
                "additionalProperties": False,
            },
        },
        "required": ["ok", "kind", "value"],
        "additionalProperties": False,
    },
)
response_path.write_text(
    json.dumps(response, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print("schemas extended")
