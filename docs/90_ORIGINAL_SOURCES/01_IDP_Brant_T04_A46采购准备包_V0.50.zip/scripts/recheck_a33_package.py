"""Check the A33 archive and rerun its checks from a fresh extraction."""

import hashlib
import json
import subprocess
import tempfile
import zipfile
from pathlib import Path

from package_a33 import ARCHIVE, MANIFEST, ROOT
from verify_a33 import CHECKS


def main():
    archive_hash = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    checks = {}
    with tempfile.TemporaryDirectory(prefix="brant-a33-recheck-") as folder:
        target = Path(folder).resolve()
        with zipfile.ZipFile(ARCHIVE) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)) or archive.testzip() is not None:
                raise RuntimeError("Invalid archive")
            manifest = json.loads(archive.read(MANIFEST))
            if set(names) != {item["path"] for item in manifest["files"]} | {MANIFEST}:
                raise RuntimeError("Archive manifest mismatch")
            for name in names:
                if not (target / name).resolve().is_relative_to(target):
                    raise RuntimeError(f"Unsafe archive path: {name}")
                if archive.read(name) != (ROOT / name).read_bytes():
                    raise RuntimeError(f"Archive/source mismatch: {name}")
            for item in manifest["files"]:
                data = archive.read(item["path"])
                if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
                    raise RuntimeError(f"Manifest mismatch: {item['path']}")
            archive.extractall(target)
        for name, args in CHECKS.items():
            command = ["uv", "run", "--frozen", *args]
            result = subprocess.run(command, cwd=target, capture_output=True, text=True, check=False)
            checks[name] = {"command": command, "exit_code": result.returncode,
                            "output": result.stdout + result.stderr}
    if hashlib.sha256(ARCHIVE.read_bytes()).hexdigest() != archive_hash:
        raise RuntimeError("Archive changed during recheck")
    report = {"stage": "A33", "archive": ARCHIVE.name, "sha256": archive_hash,
              "members": len(names), "manifest_verified": True, "source_matches": True,
              "checks": checks, "all_passed": all(item["exit_code"] == 0 for item in checks.values()),
              "fixture_classification": "synthetic", "production_admission": False}
    sidecar = ARCHIVE.with_name(ARCHIVE.name + ".verification.json")
    sidecar.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["all_passed"] else 1)


if __name__ == "__main__":
    main()
