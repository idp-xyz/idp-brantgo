"""Generate the closed A23 reconciliation contract from public write receipts."""

from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from brant_core.t03_reconciliation import READ_PERMISSIONS  # noqa: E402


def build() -> None:
    contracts = ROOT / "brant_core" / "contracts"
    request = json.loads((contracts / "T03_queries.schema.json").read_text())
    response = json.loads((contracts / "T03_query-responses.schema.json").read_text())
    writes = json.loads((contracts / "T03_write-responses.schema.json").read_text())
    commands = list(READ_PERMISSIONS)
    successes = {
        b["properties"]["command"]["const"]: b
        for b in writes["oneOf"]
        if b["properties"]["ok"].get("const") is True
    }
    assert set(commands) == set(successes)
    for branch in request["oneOf"]:
        if branch["properties"]["kind"].get("const") == "action_reconciliation":
            branch["properties"]["args"]["properties"]["command"] = {"enum": commands}
    for key, definition in writes["$defs"].items():
        assert response["$defs"].get(key) == definition, key
    common = {
        "command": {"enum": commands},
        "idempotency_key": {"$ref": "#/$defs/id"},
        "request_hash": {"$ref": "#/$defs/hash"},
        "state": {"const": "not_committed"},
        "action_id": {"type": "null"},
        "object_id": {"type": "null"},
        "result": {"type": "null"},
    }

    def closed(properties):
        return {
            "type": "object",
            "properties": properties,
            "required": list(properties),
            "additionalProperties": False,
        }

    states = [closed(copy.deepcopy(common))]
    conflict = copy.deepcopy(common)
    conflict.update(
        state={"const": "payload_conflict"},
        action_id={"$ref": "#/$defs/id"},
        object_id={"$ref": "#/$defs/id"},
    )
    states.append(closed(conflict))
    for command in commands:
        committed = copy.deepcopy(common)
        committed.update(
            command={"const": command},
            state={"const": "committed"},
            action_id={"$ref": "#/$defs/id"},
            object_id={"$ref": "#/$defs/id"},
            result=copy.deepcopy(successes[command]),
        )
        states.append(closed(committed))
    for branch in response["oneOf"]:
        if branch["properties"]["kind"].get("const") == "action_reconciliation":
            branch["properties"]["value"] = {
                "description": "Local action_result evidence at the serialized read; no external delivery or commit guarantee.",
                "oneOf": states,
            }
    for filename, body in [
        ("T03_queries.schema.json", request),
        ("T03_query-responses.schema.json", response),
    ]:
        Draft202012Validator.check_schema(body)
        (contracts / filename).write_text(json.dumps(body, ensure_ascii=False, indent=2) + "\n")
    candidate = ROOT / "t03_candidate" / "contracts"
    (candidate / "queries.schema.json").write_text(
        json.dumps(request, ensure_ascii=False, indent=2) + "\n"
    )
    (candidate / "query-responses.schema.json").write_text(
        json.dumps(response, ensure_ascii=False, indent=2) + "\n"
    )
    mapping = {
        "slice": "A23",
        "version": "V0.27",
        "contract": "brant.quotation/0.1.0",
        "query": "action_reconciliation",
        "scope": ["tenant", "company", "command", "idempotency_key"],
        "commands": {
            command: {
                "read_permissions": list(permissions),
                "object_access": "persisted order source quote"
                if command.startswith("order.")
                else "quote",
                "control": "read only; object ownership control does not authorize a mutation",
                "hash_match_and_conflict_share_access_check": True,
            }
            for command, permissions in READ_PERMISSIONS.items()
        },
        "external_business_actions": 0,
        "production_admission": False,
    }
    (candidate / "reconciliation-authority-mapping-v0.27.json").write_text(
        json.dumps(mapping, ensure_ascii=False, indent=2) + "\n"
    )
    print(
        json.dumps({"reconciliation_commands": len(commands), "closed_state_branches": len(states)})
    )


if __name__ == "__main__":
    build()
