import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

COMMAND_RECORD = "quote.response.record"
COMMAND_VERIFY = "quote.response.verify"
ACTION_COMMANDS = (COMMAND_RECORD, COMMAND_VERIFY)


def ref(name):
    return {"$ref": f"#/$defs/{name}"}


def envelope_branch(command, args, result):
    return {
        "type": "object",
        "properties": {
            "contract": {"const": "brant.quotation/0.1.0"},
            "command": {"const": command},
            "idempotency_key": ref("id"),
            "args": {"type": "object", "properties": args, "required": list(args), "additionalProperties": False},
        },
        "required": ["contract", "command", "idempotency_key", "args"],
        "additionalProperties": False,
    }


def response_branch(command, result):
    return {
        "type": "object",
        "properties": {
            "ok": {"const": True},
            "command": {"const": command},
            "action_id": ref("id"),
            "replayed": {"type": "boolean"},
            "result": {"type": "object", "properties": result, "required": list(result), "additionalProperties": False},
        },
        "required": ["ok", "command", "action_id", "replayed", "result"],
        "additionalProperties": False,
    }


def response_args():
    return {
        "response_id": ref("id"),
        "quote_id": ref("id"),
        "source_id": ref("id"),
        "locator": ref("text"),
        "classification": {"enum": ["full_unconditional", "conditional", "partial", "reject", "ambiguous"]},
        "summary": ref("text"),
    }


def verification_args():
    return {
        "response_id": ref("id"),
        "verification": {
            "type": "object",
            "properties": {
                "acceptance_id": ref("id"),
                "quote_business_revision": ref("positive_version"),
                "quote_business_hash": ref("hash"),
                "customer_ref": ref("master_ref"),
                "contact_ref": ref("master_ref"),
                "source_message_id": ref("id"),
                "source_author": ref("text"),
                "forward_chain_ref": {"anyOf": [ref("id"), {"type": "null"}]},
                "recorded_at": ref("time"),
                "line_ids": {"type": "array", "items": ref("id"), "minItems": 1, "maxItems": 200, "uniqueItems": True},
            },
            "required": [
                "acceptance_id", "quote_business_revision", "quote_business_hash", "customer_ref", "contact_ref",
                "source_message_id", "source_author", "forward_chain_ref", "recorded_at", "line_ids",
            ],
            "additionalProperties": False,
        },
    }


def walk_command_lists(value):
    if isinstance(value, dict):
        for child in value.values():
            walk_command_lists(child)
    elif isinstance(value, list):
        if "quote.acceptance.verify" in value and "quote.response.record" not in value:
            value.extend(ACTION_COMMANDS)
        for child in value:
            walk_command_lists(child)


def main():
    command_args = {
        COMMAND_RECORD: response_args(),
        COMMAND_VERIFY: verification_args(),
    }
    command_results = {
        COMMAND_RECORD: {
            "response_id": ref("id"), "quote_id": ref("id"), "classification": {"enum": ["full_unconditional", "conditional", "partial", "reject", "ambiguous"]},
            "recorded_at": ref("time"), "status": {"const": "recorded"},
        },
        COMMAND_VERIFY: {
            "response_id": ref("id"), "acceptance_id": ref("id"), "quote_id": ref("id"), "status": {"const": "verified"},
        },
    }
    for relative in (
        "brant_core/contracts/T03_write-commands.schema.json",
        "t03_candidate/contracts/commands.schema.json",
    ):
        path = ROOT / relative
        body = json.loads(path.read_text())
        body["oneOf"].extend([envelope_branch(command, command_args[command], command_args[command]) for command in ACTION_COMMANDS])
        path.write_text(json.dumps(body, ensure_ascii=False, indent=2) + "\n")
    for relative in (
        "brant_core/contracts/T03_write-responses.schema.json",
        "t03_candidate/contracts/responses.schema.json",
    ):
        path = ROOT / relative
        body = json.loads(path.read_text())
        body["oneOf"][0:0] = [response_branch(command, command_results[command]) for command in ACTION_COMMANDS]
        path.write_text(json.dumps(body, ensure_ascii=False, indent=2) + "\n")
    for relative in (
        "brant_core/contracts/T03_queries.schema.json",
        "brant_core/contracts/T03_query-responses.schema.json",
        "t03_candidate/contracts/queries.schema.json",
        "t03_candidate/contracts/query-responses.schema.json",
    ):
        path = ROOT / relative
        body = json.loads(path.read_text())
        walk_command_lists(body)
        path.write_text(json.dumps(body, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
