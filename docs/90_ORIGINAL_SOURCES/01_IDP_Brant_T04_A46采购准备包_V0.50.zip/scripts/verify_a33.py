"""Run A33 checks and record their exact source inputs and baseline."""

import hashlib
import json
import re
import subprocess
import zipfile
from concurrent.futures import ThreadPoolExecutor

from verify_a31 import ROOT, source_hashes

BASE = ROOT.parent / "IDP_Brant_T03_A32销售汇率资格验证_V0.36"
ARCHIVE = ROOT.parent / "IDP_Brant_T03_A32销售汇率资格验证包_V0.36.zip"
EXPECTED = "554e69d7da6566249fdfb81d75acea1242b123a92e04855d301fdd488f60c08b"
CHECKS = {
    "special": ["python", "-m", "unittest", "tests.test_t03_a33_reviewer_qualification", "-q"],
    "unittest": ["python", "-m", "unittest", "discover", "-s", "tests", "-q"],
    "candidate": ["python", "-m", "t03_candidate.verify"],
    "transaction": ["python", "-m", "t03_candidate.verify_transaction_adapter"],
    "ruff": ["ruff", "check", "brant_core", "tests", "scripts"],
    "mypy": ["mypy", "--check-untyped-defs", "brant_core"],
    "compileall": ["python", "-m", "compileall", "-q", "brant_core", "tests", "scripts"],
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def preserve_baseline():
    if sha(ARCHIVE.read_bytes()) != EXPECTED:
        raise RuntimeError("A32 archive hash changed")
    manifest_path = "evidence/a32-package-manifest.json"
    manifest = json.loads((BASE / manifest_path).read_text(encoding="utf-8"))
    with zipfile.ZipFile(ARCHIVE) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or archive.testzip() is not None:
            raise RuntimeError("A32 archive invalid")
        if set(names) != {item["path"] for item in manifest["files"]} | {manifest_path}:
            raise RuntimeError("A32 archive manifest mismatch")
        if archive.read(manifest_path) != (BASE / manifest_path).read_bytes():
            raise RuntimeError("A32 manifest changed")
        for item in manifest["files"]:
            source = (BASE / item["path"]).read_bytes()
            if len(source) != item["bytes"] or sha(source) != item["sha256"]:
                raise RuntimeError(f"A32 source changed: {item['path']}")
            if sha(archive.read(item["path"])) != item["sha256"]:
                raise RuntimeError(f"A32 archive member changed: {item['path']}")
    return {"sha256": EXPECTED, "manifest_files": len(manifest["files"]), "unchanged": True}


def main():
    baseline = preserve_baseline()
    inputs = source_hashes()

    def run(item):
        name, args = item
        command = ["uv", "run", "--frozen", *args]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
        output = result.stdout + result.stderr
        (ROOT / "evidence" / f"a33-{name}.txt").write_text(output, encoding="utf-8")
        count = re.search(r"Ran (\d+) tests?", output)
        return name, {"command": command, "exit_code": result.returncode,
                      "test_count": int(count.group(1)) if count else None,
                      "evidence": f"evidence/a33-{name}.txt"}

    with ThreadPoolExecutor(max_workers=4) as pool:
        checks = dict(pool.map(run, CHECKS.items()))
    unchanged = inputs == source_hashes()
    passed = unchanged and all(value["exit_code"] == 0 for value in checks.values())
    report = {"stage": "A33", "source_version": "V0.37", "core_version": "0.5.1",
              "migration": 12, "date": "2026-11-05", "timezone": "Asia/Shanghai",
              "verified_source_hashes": inputs, "source_input_set_unchanged": unchanged,
              "historical_a32_preservation": baseline, "checks": checks, "all_passed": passed,
              "fixture_classification": "synthetic", "production_admission": False}
    (ROOT / "evidence/a33-verification.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"checks": checks, "all_passed": passed}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
