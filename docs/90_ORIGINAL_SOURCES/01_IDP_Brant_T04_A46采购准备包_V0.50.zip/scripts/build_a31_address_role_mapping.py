"""Generate an explicit Foundation-to-quotation address-role mapping."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FOUNDATION_SCHEMA = ROOT / "brant_core/contracts/foundation.commands.schema.json"

ROLE_POLICY = {
    "buyer": ("supported", "customer.address", "customer.address_role"),
    "billing": ("supported", "customer.address", "customer.address_role"),
    "seller": ("unsupported", None, "No distinct issuer-address field exists in this quotation input."),
    "payer": ("unsupported", None, "No distinct payment-party field exists in this quotation input."),
    "payee": ("unsupported", None, "No distinct payment-party field exists in this quotation input."),
    "consignee": ("unsupported", None, "No distinct delivery-party field exists in this quotation input."),
    "shipper": ("unsupported", None, "No distinct delivery-party field exists in this quotation input."),
}


def find_address_roles(node):
    if isinstance(node, dict):
        properties = node.get("properties")
        if isinstance(properties, dict) and "addresses" in properties:
            return properties["addresses"]["items"]["properties"]["role"]["enum"]
        for value in node.values():
            try:
                return find_address_roles(value)
            except LookupError:
                continue
    elif isinstance(node, list):
        for value in node:
            try:
                return find_address_roles(value)
            except LookupError:
                continue
    raise LookupError("Foundation party_profile address role enum was not found")


def main():
    schema = json.loads(FOUNDATION_SCHEMA.read_text(encoding="utf-8"))
    source_roles = set(find_address_roles(schema))
    if source_roles != set(ROLE_POLICY):
        raise RuntimeError("Foundation address roles changed; review the quotation role policy")
    roles = []
    for role in sorted(source_roles):
        status, target, detail = ROLE_POLICY[role]
        roles.append(
            {
                "role": role,
                "status": status,
                "quote_field": target,
                "mapping_or_rejection": detail,
            }
        )
    mapping = {
        "stage": "A31",
        "source_version": "V0.35",
        "core_version": "0.5.1",
        "migration": 12,
        "contract": "brant.quote-trade-parties/0.1.0",
        "foundation_role_source": "brant_core/contracts/foundation.commands.schema.json",
        "quotation_input_field": "customer_address_id",
        "quotation_binding_fields": ["customer.address", "customer.address_role"],
        "supported_roles": sorted(
            role for role, (status, _, _) in ROLE_POLICY.items() if status == "supported"
        ),
        "roles": roles,
        "fail_closed_for_unmapped_roles": True,
        "selection_rule": "The selected address_id must resolve to exactly one nonempty address whose role is buyer or billing.",
        "compatibility": "No request field or persisted format changed; existing buyer and billing bindings retain their proof shape.",
        "limitations": [
            "seller, payer, payee, consignee and shipper roles have no distinct T03 quotation binding fields",
            "adding a role requires an explicit quotation contract and document mapping",
            "term override and negotiation remain unsupported",
            "synthetic local SQLite only; no production admission or V1.0 claim",
        ],
        "external_business_actions": 0,
    }
    target = ROOT / "t03_candidate/contracts/quote-address-role-mapping-v0.35.json"
    target.write_text(json.dumps(mapping, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"mapping": str(target), "roles": len(roles)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
