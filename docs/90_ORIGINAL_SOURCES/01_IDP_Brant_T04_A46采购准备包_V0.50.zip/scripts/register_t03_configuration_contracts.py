"""Copy the candidate closed configuration schemas into the Core runtime."""

import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "t03_candidate" / "contracts"
TARGET = ROOT / "brant_core" / "contracts"
FILES = {
    "configuration.commands.schema.json": "T03_configuration.commands.schema.json",
    "configuration.responses.schema.json": "T03_configuration.responses.schema.json",
    "configuration.queries.schema.json": "T03_configuration.queries.schema.json",
    "configuration.query-responses.schema.json": "T03_configuration.query-responses.schema.json",
}

for source_name, target_name in FILES.items():
    shutil.copyfile(SOURCE / source_name, TARGET / target_name)
