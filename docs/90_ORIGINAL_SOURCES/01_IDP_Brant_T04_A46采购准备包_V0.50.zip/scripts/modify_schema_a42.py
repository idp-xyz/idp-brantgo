import json
from pathlib import Path

ROOT = Path(__file__).parents[1]

for relative in ("brant_core/contracts/T03_queries.schema.json", "t03_candidate/contracts/queries.schema.json"):
    path = ROOT / relative
    document = json.loads(path.read_text(encoding="utf-8"))
    branch = {
        "type": "object",
        "properties": {
            "contract": {"const": "brant.quotation/0.1.0"},
            "kind": {"const": "order_review"},
            "args": {
                "type": "object",
                "properties": {"review_id": {"$ref": "#/$defs/id"}},
                "required": ["review_id"],
                "additionalProperties": False,
            },
        },
        "required": ["contract", "kind", "args"],
        "additionalProperties": False,
    }
    if not any(item.get("properties", {}).get("kind", {}).get("const") == "order_review"
               for item in document["oneOf"]):
        document["oneOf"].append(branch)
    path.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

for relative in ("brant_core/contracts/T03_query-responses.schema.json", "t03_candidate/contracts/query-responses.schema.json"):
    path = ROOT / relative
    document = json.loads(path.read_text(encoding="utf-8"))
    branch = {
        "type": "object",
        "properties": {
            "ok": {"const": True},
            "kind": {"const": "order_review"},
            "value": {
                "type": "object",
                "properties": {
                    "review_id": {"$ref": "#/$defs/id"},
                    "order_id": {"$ref": "#/$defs/id"},
                    "order_hash": {"$ref": "#/$defs/hash"},
                    "order_version": {"$ref": "#/$defs/positive_version"},
                    "requested_by": {"$ref": "#/$defs/id"},
                    "requested_at": {"$ref": "#/$defs/time"},
                    "decision": {"type": ["object", "null"]},
                    "activation": {"type": ["object", "null"]},
                    "revocation": {"type": ["object", "null"]},
                    "decision_state": {"enum": ["pending", "approved", "rejected", "expired", "revoked"]},
                },
                "required": ["review_id", "order_id", "order_hash", "order_version", "requested_by",
                             "requested_at", "decision", "activation", "revocation", "decision_state"],
                "additionalProperties": False,
            },
        },
        "required": ["ok", "kind", "value"],
        "additionalProperties": False,
    }
    if not any(item.get("properties", {}).get("kind", {}).get("const") == "order_review"
               for item in document["oneOf"]):
        document["oneOf"].append(branch)
    path.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
