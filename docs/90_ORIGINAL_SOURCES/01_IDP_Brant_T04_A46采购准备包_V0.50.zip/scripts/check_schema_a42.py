import json
from pathlib import Path

for relative in (
    "brant_core/contracts/T03_query-responses.schema.json",
    "t03_candidate/contracts/query-responses.schema.json",
):
    text = (Path(__file__).parents[1] / relative).read_text(encoding="utf-8")
    document = json.loads(text)
    bad = []

    def walk(value, path=""):
        if isinstance(value, dict):
            if "" in value:
                bad.append(path)
            for key, item in value.items():
                walk(item, path + "/" + key)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                walk(item, path + "/" + str(index))

    walk(document)
    print(relative, "empty_keys", len(bad), "order_review", any(
        item.get("properties", {}).get("kind", {}).get("const") == "order_review"
        for item in document["oneOf"]
    ))
