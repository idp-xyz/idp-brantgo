"""Verify the A28 ZIP byte-for-byte and rerun checks after fresh extraction."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import tempfile
import zipfile
from pathlib import Path

from package_a28 import ARCHIVE_NAME, MANIFEST_PATH, ROOT
from verify_a28 import BASELINE_TESTS


def main() -> None:
    archive = ROOT.parent / ARCHIVE_NAME
    archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
    checks = {}
    with tempfile.TemporaryDirectory(prefix="brant-a28-recheck-") as folder:
        unpacked = Path(folder)
        with zipfile.ZipFile(archive) as source:
            if source.testzip() is not None:
                raise RuntimeError("Corrupt ZIP member")
            names = source.namelist()
            if len(names) != len(set(names)):
                raise RuntimeError("Duplicate ZIP entries")
            manifest = json.loads(source.read(MANIFEST_PATH))
            if set(names) != {item["path"] for item in manifest["files"]} | {MANIFEST_PATH}:
                raise RuntimeError("Archive entries do not match the manifest")
            for name in names:
                destination = (unpacked / name).resolve()
                if not destination.is_relative_to(unpacked.resolve()):
                    raise RuntimeError(f"Unsafe ZIP path: {name}")
            for item in manifest["files"]:
                data = source.read(item["path"])
                if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
                    raise RuntimeError(f"Manifest mismatch: {item['path']}")
            for name in names:
                if source.read(name) != (ROOT / name).read_bytes():
                    raise RuntimeError(f"Archive/source mismatch: {name}")
            source.extractall(unpacked)
        focused = [
            "python", "-m", "unittest", "tests.test_t03_a28_sales_terms", *BASELINE_TESTS,
            "tests.test_t03_a19_configuration_consumption", "tests.test_t03_a25_order_snapshot", "-q",
        ]
        commands = {
            "focused": focused,
            "candidate": ["python", "-m", "t03_candidate.verify"],
            "transaction": ["python", "-m", "t03_candidate.verify_transaction_adapter"],
            "ruff": ["ruff", "check", "brant_core", "tests", "scripts"],
            "mypy": ["mypy", "--check-untyped-defs", "brant_core"],
        }
        for name, args in commands.items():
            command = ["uv", "run", "--frozen", *args]
            process = subprocess.run(command, cwd=unpacked, capture_output=True, text=True, check=False)
            output = process.stdout + process.stderr
            found = re.search(r"Ran (\d+) tests?", output)
            checks[name] = {
                "command": command,
                "exit_code": process.returncode,
                "test_count": int(found.group(1)) if found else None,
                "output": output,
            }
    if hashlib.sha256(archive.read_bytes()).hexdigest() != archive_hash:
        raise RuntimeError("Archive changed during fresh-extraction recheck")
    report = {
        "archive": archive.name,
        "sha256": archive_hash,
        "files_including_manifest": len(names),
        "manifest_files_verified": len(manifest["files"]),
        "zip_integrity": True,
        "manifest_hashes_verified": True,
        "source_archive_byte_equality": True,
        "migration": 12,
        "checks": checks,
        "all_passed": all(result["exit_code"] == 0 for result in checks.values()),
        "fixture_classification": "synthetic",
        "external_business_actions": 0,
        "production_admission": False,
    }
    sidecar = archive.with_name(archive.name + ".verification.json")
    sidecar.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["all_passed"] else 1)


if __name__ == "__main__":
    main()
