"""Extract the A19 ZIP, verify its manifest, and rerun focused packaged checks."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT.parent / "IDP_Brant_T03_A19报价配置消费与文件生成验证包_V0.25.zip"


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="a19-unpack-") as temp:
        target = Path(temp)
        with zipfile.ZipFile(ARCHIVE) as packaged:
            corrupt = packaged.testzip()
            if corrupt is not None:
                raise RuntimeError(f"ZIP integrity failed at {corrupt}")
            packaged.extractall(target)
        manifest_path = target / "evidence/a19-package-manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for item in manifest["files"]:
            content = (target / item["path"]).read_bytes()
            if len(content) != item["bytes"] or hashlib.sha256(content).hexdigest() != item["sha256"]:
                raise RuntimeError(f"Manifest hash mismatch: {item['path']}")
        commands = [
            [
                "uv",
                "run",
                "--frozen",
                "python",
                "-m",
                "unittest",
                "tests.test_t03_a19_configuration_consumption",
                "tests.test_t03_persistence",
                "-q",
            ],
            ["uv", "run", "--frozen", "python", "-m", "t03_candidate.verify"],
            ["uv", "run", "--frozen", "python", "-m", "t03_candidate.verify_transaction_adapter"],
        ]
        environment = os.environ.copy()
        environment.pop("VIRTUAL_ENV", None)
        output = []
        for command in commands:
            result = subprocess.run(
                command,
                cwd=target,
                env=environment,
                capture_output=True,
                text=True,
                check=False,
            )
            output.append("$ " + " ".join(command) + "\n" + result.stdout + result.stderr)
            if result.returncode:
                raise RuntimeError(output[-1])
        print(
            json.dumps(
                {
                    "archive": ARCHIVE.name,
                    "manifest_files_verified": len(manifest["files"]),
                    "focused_and_migration_tests": "passed",
                    "candidate_checks": 350,
                    "transaction_adapter_checks": 39,
                    "output": output,
                },
                ensure_ascii=False,
                indent=2,
            )
        )


if __name__ == "__main__":
    main()
