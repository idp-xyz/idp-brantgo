"""Run A34 checks and record their exact source inputs and baseline."""

import hashlib
import json
import re
import subprocess
import zipfile
from concurrent.futures import ThreadPoolExecutor

from verify_a31 import ROOT, source_hashes

BASE = ROOT.parent / "IDP_Brant_T03_A33审核人当前资格验证_V0.37"
ARCHIVE = ROOT.parent / "IDP_Brant_T03_A33审核人当前资格验证包_V0.37.zip"
EXPECTED = "7205e5faaa9d3f4d1fde695b2c93ba322bf09c57d763d01241e3207a4d4e343a"
CHECKS = {
    "special": ["python", "-m", "unittest", "tests.test_t03_a34_ready_reviewer", "-q"],
    "focused": ["python", "-m", "unittest", "tests.test_t03_a34_ready_reviewer",
                "tests.test_t03_a33_reviewer_qualification", "tests.test_t03_a32_sales_fx",
                "tests.test_t03_query_contract", "tests.test_t03_a26_order_qualification", "-q"],
    "unittest": ["python", "-m", "unittest", "discover", "-s", "tests", "-q"],
    "candidate": ["python", "-m", "t03_candidate.verify"],
    "transaction": ["python", "-m", "t03_candidate.verify_transaction_adapter"],
    "ruff": ["ruff", "check", "brant_core", "tests", "scripts"],
    "mypy": ["mypy", "--check-untyped-defs", "brant_core"],
    "compileall": ["python", "-m", "compileall", "-q", "brant_core", "tests", "scripts"],
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def preserve_baseline():
    if sha(ARCHIVE.read_bytes()) != EXPECTED:
        raise RuntimeError("A33 archive hash changed")
    manifest_path = "evidence/a33-package-manifest.json"
    manifest = json.loads((BASE / manifest_path).read_text(encoding="utf-8"))
    with zipfile.ZipFile(ARCHIVE) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or archive.testzip() is not None:
            raise RuntimeError("A33 archive invalid")
        if set(names) != {item["path"] for item in manifest["files"]} | {manifest_path}:
            raise RuntimeError("A33 archive manifest mismatch")
        if archive.read(manifest_path) != (BASE / manifest_path).read_bytes():
            raise RuntimeError("A33 manifest changed")
        for item in manifest["files"]:
            source = (BASE / item["path"]).read_bytes()
            if len(source) != item["bytes"] or sha(source) != item["sha256"]:
                raise RuntimeError(f"A33 source changed: {item['path']}")
            if sha(archive.read(item["path"])) != item["sha256"]:
                raise RuntimeError(f"A33 archive member changed: {item['path']}")
    return {"sha256": EXPECTED, "manifest_files": len(manifest["files"]), "unchanged": True}


def main():
    baseline = preserve_baseline()
    inputs = source_hashes()

    def run(item):
        name, args = item
        command = ["uv", "run", "--frozen", *args]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
        output = result.stdout + result.stderr
        (ROOT / "evidence" / f"a34-{name}.txt").write_text(output, encoding="utf-8")
        count = re.search(r"Ran (\d+) tests?", output)
        return name, {"command": command, "exit_code": result.returncode,
                      "test_count": int(count.group(1)) if count else None,
                      "evidence": f"evidence/a34-{name}.txt"}

    with ThreadPoolExecutor(max_workers=4) as pool:
        checks = dict(pool.map(run, CHECKS.items()))
    unchanged = inputs == source_hashes()
    passed = unchanged and all(value["exit_code"] == 0 for value in checks.values())
    report = {"stage": "A34", "source_version": "V0.38", "core_version": "0.5.1",
              "migration": 12, "date": "2026-11-05", "timezone": "Asia/Shanghai",
              "verified_source_hashes": inputs, "source_input_set_unchanged": unchanged,
              "historical_a33_preservation": baseline, "checks": checks, "all_passed": passed,
              "fixture_classification": "synthetic", "production_admission": False}
    (ROOT / "evidence/a34-verification.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"checks": checks, "all_passed": passed}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
