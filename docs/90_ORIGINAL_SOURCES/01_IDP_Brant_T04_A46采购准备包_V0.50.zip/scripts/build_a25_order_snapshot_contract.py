"""Record local snapshot field mappings without certifying full quote readiness."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from brant_core.t03_order_snapshot import CONTRACT, TERM_KEYS  # noqa: E402


def build() -> None:
    mapping = {
        "stage": "A25", "source_version": "V0.29", "snapshot_contract": CONTRACT,
        "source": "exact persisted t03_quote_revision data_json and calculation_json",
        "source_identity": ["tenant", "company", "quote_id", "business_revision", "business_hash"],
        "whole_source_copy": "source_quote_snapshot",
        "term_projection": list(TERM_KEYS),
        "projections": ["customer_ref", "contact_ref", "currency_ref", "lines", "charges", "calculation"],
        "checked_at": ["new preparation", "local existing preparation", "local activation and replay",
                       "public preparation/activation same-key success receipt replay"],
        "checks": ["source hash recomputation", "exact source/projection equality", "order body hash",
                   "order column identity", "acceptance identity/customer/contact/full line set",
                   "line/charge calculation IDs", "line/charge amount and total conservation",
                   "payment amount conservation"],
        "legacy_body": "readable; no automatic rewrite or new-contract certification; write/replay rejected",
        "reconciliation": "original local committed fact only; not snapshot certification",
        "migration": 12,
        "migration_changes": ["immutable commercial order columns", "order delete guard",
                              "primary-key and root-slot replacement guard"],
        "not_certified": ["full quotation combinations", "full source schema",
                          "current commercial dependency eligibility", "T04 full business admission",
                          "external order", "production durability"],
        "external_business_actions": 0, "production_admission": False, "product_v1_complete": False,
    }
    (ROOT / "t03_candidate/contracts/order-commercial-snapshot-mapping-v0.29.json").write_text(
        json.dumps(mapping, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"snapshot_contract": CONTRACT, "migration": 12}))


if __name__ == "__main__":
    build()
