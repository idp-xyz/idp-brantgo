"""Reproduce A29 business checks and verify historical inputs are preserved."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
A27_ROOT = ROOT.parent / "IDP_Brant_T03_A28销售收费与税适用组合验证_V0.32"
A27_ARCHIVE = ROOT.parent / "IDP_Brant_T03_A28销售收费与税适用组合验证包_V0.32.zip"
A27_SHA256 = "83d4238ef622d789f39fbdfbc2e645ac3194c33cac915e5363b4cd2c92df3308"
EXCLUDED = {".venv", "__pycache__", ".mypy_cache", ".ruff_cache", ".pytest_cache"}
BASELINE_TESTS = [
    "tests.test_t03_a27_cost_scope",
    "tests.test_t03_a26_order_qualification",
    "tests.test_t03_server_calculation",
    "tests.test_t03_a25_order_snapshot",
    "tests.test_t03_a24_write_control",
    "tests.test_t03_a23_reconciliation_access",
    "tests.test_t03_a20_acceptance_order",
    "tests.test_t03_query_contract",
    "tests.test_t03_persistence",
    "tests.test_t03_snapshot",
    "tests.test_t03_configuration_runtime",
    "tests.test_t03_cost_binding",
]
CHECKS = {
    "unittest": ["python", "-m", "unittest", "discover", "-s", "tests", "-q"],
    "special": ["python", "-m", "unittest", "tests.test_t03_a29_trade_parties", "-q"],
    "focused": [
        "python", "-m", "unittest", "tests.test_t03_a29_trade_parties", "tests.test_t03_a28_sales_terms", *BASELINE_TESTS,
        "tests.test_t03_a19_configuration_consumption",
        "-q",
    ],
    "candidate": ["python", "-m", "t03_candidate.verify"],
    "transaction": ["python", "-m", "t03_candidate.verify_transaction_adapter"],
    "ruff": ["ruff", "check", "brant_core", "tests", "scripts"],
    "mypy": ["mypy", "--check-untyped-defs", "brant_core"],
    "compileall": ["python", "-m", "compileall", "-q", "brant_core", "tests", "scripts"],
}
GENERATORS = [
    "scripts/build_a23_reconciliation_contract.py",
    "scripts/build_a25_order_snapshot_contract.py",
    "scripts/build_a26_order_qualification_mapping.py",
    "scripts/build_a27_cost_scope_mapping.py",
    "scripts/build_a28_sales_terms_mapping.py",
    "scripts/build_a29_trade_parties_mapping.py",
]
GENERATED_PATHS = [
    "brant_core/contracts/T03_queries.schema.json",
    "brant_core/contracts/T03_query-responses.schema.json",
    "t03_candidate/contracts/queries.schema.json",
    "t03_candidate/contracts/query-responses.schema.json",
    "t03_candidate/contracts/reconciliation-authority-mapping-v0.27.json",
    "t03_candidate/contracts/write-control-mapping-v0.28.json",
    "t03_candidate/contracts/order-commercial-snapshot-mapping-v0.29.json",
    "t03_candidate/contracts/order-activation-qualification-mapping-v0.30.json",
    "t03_candidate/contracts/quote-cost-scope-mapping-v0.31.json",
    "t03_candidate/contracts/quote-sales-terms-mapping-v0.32.json",
    "t03_candidate/contracts/quote-trade-parties-mapping-v0.33.json",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hashes() -> dict[str, str]:
    return {
        path.relative_to(ROOT).as_posix(): sha256(path)
        for path in sorted(ROOT.rglob("*"))
        if path.is_file()
        and not (set(path.relative_to(ROOT).parts) & EXCLUDED)
        and (
            path.relative_to(ROOT).parts[0] in {"brant_core", "tests", "scripts", "t03_candidate"}
            or path.name in {"pyproject.toml", "uv.lock"}
        )
        and not path.relative_to(ROOT).as_posix().startswith("t03_candidate/evidence/")
    }


def preserve_a27() -> dict:
    if sha256(A27_ARCHIVE) != A27_SHA256:
        raise RuntimeError("The A27 delivery archive no longer matches its recorded SHA-256")
    manifest_path = A27_ROOT / "evidence/a28-package-manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    source_hashes = {item["path"]: item["sha256"] for item in manifest["files"]}
    if len(source_hashes) != 429:
        raise RuntimeError("Unexpected A27 manifest file count")
    for relative, digest in source_hashes.items():
        if sha256(A27_ROOT / relative) != digest:
            raise RuntimeError(f"Historical A27 source changed: {relative}")
    with zipfile.ZipFile(A27_ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("Historical A27 archive is corrupt")
        if archive.read("evidence/a28-package-manifest.json") != manifest_path.read_bytes():
            raise RuntimeError("Historical A27 manifest differs from its archive")
        for relative, digest in source_hashes.items():
            if hashlib.sha256(archive.read(relative)).hexdigest() != digest:
                raise RuntimeError(f"Historical A27 archive member changed: {relative}")
    return {
        "archive": A27_ARCHIVE.name,
        "sha256": A27_SHA256,
        "manifest_files": len(source_hashes),
        "source_and_archive_unchanged": True,
    }


def main() -> None:
    baseline = preserve_a27()
    generator_runs = []
    first_generation = None
    for index in range(2):
        for relative in GENERATORS:
            generated = subprocess.run(
                [sys.executable, relative], cwd=ROOT, capture_output=True, text=True, check=True
            )
            generator_runs.append(generated.stdout.strip())
        hashes = {name: sha256(ROOT / name) for name in GENERATED_PATHS}
        if index == 0:
            first_generation = hashes
        elif first_generation != hashes:
            raise RuntimeError("Generated mappings are not deterministic")
    generated_hashes = first_generation
    if generated_hashes is None:
        raise RuntimeError("No generated mapping snapshot was captured")

    tested_inputs = source_hashes()

    def check(item):
        name, args = item
        command = ["uv", "run", "--frozen", *args]
        process = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
        output = process.stdout + process.stderr
        (ROOT / "evidence" / f"a29-{name}.txt").write_text(output, encoding="utf-8")
        found = re.search(r"Ran (\d+) tests?", output)
        return name, {
            "command": command,
            "exit_code": process.returncode,
            "test_count": int(found.group(1)) if found else None,
            "evidence": f"evidence/a29-{name}.txt",
        }

    with ThreadPoolExecutor(max_workers=4) as pool:
        checks = dict(pool.map(check, CHECKS.items()))
    source_unchanged = tested_inputs == source_hashes()
    all_passed = source_unchanged and all(item["exit_code"] == 0 for item in checks.values())
    report = {
        "stage": "A29",
        "source_version": "V0.33",
        "core_version": "0.5.1",
        "migration": 12,
        "executed_at_local_date": "2026-11-04",
        "timezone": "Asia/Shanghai",
        "verified_source_hashes": tested_inputs,
        "source_input_set_unchanged": source_unchanged,
        "checks": checks,
        "all_passed": all_passed,
        "mapping_generators_idempotent": True,
        "generated_mapping_hashes": generated_hashes,
        "generator_output": generator_runs,
        "historical_a28_preservation": baseline,
        "fixture_classification": "synthetic",
        "external_business_actions": 0,
        "tax_law_conclusion": False,
        "production_admission": False,
        "complete_T04": False,
        "product_v1_complete": False,
    }
    (ROOT / "evidence/a29-verification.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
