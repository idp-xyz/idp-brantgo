"""Create the A25 verification archive from one source-file snapshot."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_NAME = "IDP_Brant_T03_A25订单商业快照一致性验证包_V0.29.zip"
MANIFEST_PATH = "evidence/a25-package-manifest.json"
EXCLUDED = {".venv", "__pycache__", ".mypy_cache", ".ruff_cache", ".pytest_cache", "build", "dist"}


def main() -> None:
    verification = json.loads((ROOT / "evidence/a25-verification.json").read_text())
    if verification.get("all_passed") is not True:
        raise RuntimeError("A25 checks must pass before packaging")
    for relative, expected in verification["verified_source_hashes"].items():
        if hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() != expected:
            raise RuntimeError("Verified source changed: " + relative)
    snapshot = {}
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if (
            path.is_file()
            and not (set(relative.parts) & EXCLUDED)
            and relative.as_posix() != MANIFEST_PATH
        ):
            snapshot[relative.as_posix()] = path.read_bytes()
    manifest = {
        "package": ARCHIVE_NAME,
        "source_version": "V0.29",
        "stage": "A25",
        "manifest_excludes_own_hash": True,
        "file_hash_algorithm": "sha256",
        "excluded_directory_names": sorted(EXCLUDED),
        "files": [
            {"path": path, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            for path, data in snapshot.items()
        ],
    }
    manifest_data = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    (ROOT / MANIFEST_PATH).write_bytes(manifest_data)
    snapshot[MANIFEST_PATH] = manifest_data
    archive = ROOT.parent / ARCHIVE_NAME
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for path, data in sorted(snapshot.items()):
            info = zipfile.ZipInfo(path, (2026, 11, 4, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            out.writestr(info, data, compresslevel=9)
    print(
        json.dumps(
            {
                "archive": str(archive),
                "files": len(snapshot),
                "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
