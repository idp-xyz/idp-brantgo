"""Idempotently add A45 read schemas and stage-specific delivery scripts."""

import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def ref(name):
    return {"$ref": "#/$defs/" + name}


def obj(properties):
    return {"type": "object", "properties": properties, "required": list(properties),
            "additionalProperties": False}


def main():
    commands = json.loads((ROOT / "brant_core/contracts/T03_write-commands.schema.json").read_text())
    record = next(b for b in commands["oneOf"] if b["properties"]["command"]["const"] == "quote.response.record")
    value = copy.deepcopy(record["properties"]["args"])
    # Local registration allows summaries up to 4000 characters.
    value["properties"]["summary"] = {"type": "string", "minLength": 1, "maxLength": 4000}
    value["properties"].update(recorded_by=ref("text"), recorded_at=ref("time"), verification={
        "oneOf": [{"type": "null"}, obj({"acceptance_id": ref("id"), "verified_by": ref("text"),
                                        "verified_at": ref("time")})]})
    value["required"] = list(value["properties"])
    request = obj({"contract": {"const": "brant.quotation/0.1.0"},
                   "kind": {"const": "customer_response"}, "args": obj({"response_id": ref("id")})})
    response = obj({"ok": {"const": True}, "kind": {"const": "customer_response"}, "value": value})
    for runtime, candidate, branch in (
        ("T03_queries.schema.json", "queries.schema.json", request),
        ("T03_query-responses.schema.json", "query-responses.schema.json", response),
    ):
        path = ROOT / "brant_core/contracts" / runtime
        schema = json.loads(path.read_text())
        schema["oneOf"] = [b for b in schema["oneOf"]
                           if b.get("properties", {}).get("kind", {}).get("const") != "customer_response"]
        schema["oneOf"].append(branch)
        for b in schema["oneOf"]:
            kinds = b.get("properties", {}).get("kind", {}).get("enum", [])
            if kinds and "customer_response" not in kinds:
                kinds.append("customer_response")
        data = json.dumps(schema, ensure_ascii=False, indent=2) + "\n"
        path.write_text(data, encoding="utf-8")
        (ROOT / "t03_candidate/contracts" / candidate).write_text(data, encoding="utf-8")
    for name in ("verify", "package", "recheck"):
        old = "recheck_a44_package.py" if name == "recheck" else name + "_a44.py"
        new = old.replace("a44", "a45")
        text = (ROOT / "scripts" / old).read_text()
        # Replace the previous baseline first, then the new stage identifiers.
        if name == "verify":
            text = text.replace("A43", "A44").replace("a43", "a44")
            text = text.replace("订单审批对账闭环", "客户回复公共契约").replace("V0.47", "V0.48")
            text = text.replace("62e0af76dea0a55dad91d71be9532d5e91710385c0908ead764d450d34275f5b",
                                "a8c4abd412ec2ba945001dd9f4295fcc28a9f474028c2c6189c814dbb54b1ff2")
            # Preserve baseline A44 references while updating active-stage metadata.
            text = text.replace("A44", "A45").replace("a44", "a45").replace("V0.48", "V0.49")
            text = text.replace("baseline.BASE = ROOT.parent / \"IDP_Brant_T04_A45客户回复公共契约_V0.49\"",
                                "baseline.BASE = ROOT.parent / \"IDP_Brant_T04_A44客户回复公共契约_V0.48\"")
            text = text.replace("baseline.ARCHIVE = ROOT.parent / \"IDP_Brant_T04_A45客户回复公共契约包_V0.49.zip\"",
                                "baseline.ARCHIVE = ROOT.parent / \"IDP_Brant_T04_A44客户回复公共契约包_V0.48.zip\"")
            text = text.replace("evidence/a45-package-manifest.json", "evidence/a44-package-manifest.json")
            text = text.replace("historical_a45_preservation", "historical_a44_preservation")
            text = text.replace("tests.test_t04_a45_public_customer_response", "tests.test_t04_a45_response_query_recovery")
            # A44 and A43 remain in the regression set, avoiding duplicate fixtures in this new module.
            text = text.replace('"tests.test_t04_a45_order_reconciliation",',
                                '"tests.test_t04_a44_public_customer_response", "tests.test_t04_a43_order_reconciliation",')
            text = text.replace("preserve the A45 delivery baseline", "preserve the A44 delivery baseline")
            text = text.replace('RuntimeError("A45 ', 'RuntimeError("A44 ')
        else:
            text = text.replace("A44", "A45").replace("a44", "a45").replace("V0.48", "V0.49")
            text = text.replace("客户回复公共契约", "客户回复公共查询与恢复")
            text = text.replace("brant-a43-recheck-", "brant-a45-recheck-")
        (ROOT / "scripts" / new).write_text(text, encoding="utf-8")
    print("A45 schemas and delivery scripts configured")
    print({key: commands["$defs"][key] for key in ("text", "id")})


if __name__ == "__main__":
    main()
