"""Check the exact archive and run verification in a fresh extracted workspace."""

from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
import zipfile
from pathlib import Path

from package_a25 import ARCHIVE_NAME, MANIFEST_PATH, ROOT


def main() -> None:
    archive = ROOT.parent / ARCHIVE_NAME
    archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
    checks = {}
    with tempfile.TemporaryDirectory(prefix="brant-a25-recheck-") as folder:
        unpacked = Path(folder)
        with zipfile.ZipFile(archive) as source:
            assert source.testzip() is None, "Corrupt ZIP member"
            names = source.namelist()
            assert len(names) == len(set(names)), "Duplicate archive entries"
            manifest = json.loads(source.read(MANIFEST_PATH))
            assert set(names) == {item["path"] for item in manifest["files"]} | {MANIFEST_PATH}
            for name in names:
                destination = (unpacked / name).resolve()
                assert destination.is_relative_to(unpacked.resolve()), name
            for item in manifest["files"]:
                data = source.read(item["path"])
                assert len(data) == item["bytes"], item["path"]
                assert hashlib.sha256(data).hexdigest() == item["sha256"], item["path"]
            for name in names:
                assert source.read(name) == (ROOT / name).read_bytes(), name
            source.extractall(unpacked)
        for name, args in (
            (
                "focused",
                [
                    "python",
                    "-m",
                    "unittest",
                    "tests.test_t03_a25_order_snapshot",
                    "tests.test_t03_a24_write_control",
                    "tests.test_t03_a23_reconciliation_access",
                    "tests.test_t03_a20_acceptance_order",
                    "tests.test_t03_query_contract",
                    "tests.test_t03_persistence",
                    "tests.test_t03_snapshot",
                    "tests.test_t03_configuration_runtime",
                    "-q",
                ],
            ),
            ("candidate", ["python", "-m", "t03_candidate.verify"]),
            ("transaction", ["python", "-m", "t03_candidate.verify_transaction_adapter"]),
            ("ruff", ["ruff", "check", "brant_core", "tests", "scripts"]),
            ("mypy", ["mypy", "--check-untyped-defs", "brant_core"]),
        ):
            command = ["uv", "run", "--frozen", *args]
            process = subprocess.run(
                command, cwd=unpacked, capture_output=True, text=True, check=False
            )
            checks[name] = {
                "command": command,
                "exit_code": process.returncode,
                "output": process.stdout + process.stderr,
            }
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == archive_hash, (
        "Archive changed during recheck"
    )
    report = {
        "archive": archive.name,
        "sha256": archive_hash,
        "packaged_files": len(names),
        "manifest_files_verified": len(manifest["files"]),
        "zip_integrity": True,
        "source_archive_byte_equality": True,
        "migration": 12,
        "checks": checks,
        "all_passed": all(item["exit_code"] == 0 for item in checks.values()),
        "fixture_classification": "synthetic",
        "external_business_actions": 0,
        "production_admission": False,
    }
    sidecar = archive.with_name(archive.name + ".verification.json")
    sidecar.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["all_passed"] else 1)


if __name__ == "__main__":
    main()
