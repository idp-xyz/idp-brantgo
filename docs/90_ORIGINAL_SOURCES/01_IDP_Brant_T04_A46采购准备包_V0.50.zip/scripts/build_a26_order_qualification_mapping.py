"""Record the bounded local activation gate and historical-recovery semantics."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from brant_core.t03_order_qualification import CONTRACT, FOUNDATION_KINDS  # noqa: E402


def build() -> None:
    # Repair only the observed order-history branch; historical bodies/events
    # retain their pre-existing permissive shape, not a claim of full precision.
    path = ROOT / "brant_core/contracts/T03_query-responses.schema.json"
    response = json.loads(path.read_text(encoding="utf-8"))
    matches = [
        branch for branch in response["oneOf"]
        if branch["properties"]["ok"].get("const") is True
        and branch["properties"]["kind"].get("const") == "order_history"
    ]
    assert len(matches) == 1
    properties = matches[0]["properties"]["value"]["properties"]
    for key in ("order_id", "root_quote_id", "source_quote_id", "acceptance_id"):
        properties[key] = {"$ref": "#/$defs/id"}
    properties["source_quote_revision"] = {"$ref": "#/$defs/positive_version"}
    for key in ("source_quote_hash", "order_hash"):
        properties[key] = {"$ref": "#/$defs/hash"}
    properties["approval_id"] = {"oneOf": [{"$ref": "#/$defs/id"}, {"type": "null"}]}
    properties["status"] = {"enum": ["draft", "active", "cancelled"]}
    properties["conversion_slot"] = {"const": "full_v1"}
    Draft202012Validator.check_schema(response)
    encoded = json.dumps(response, ensure_ascii=False, indent=2) + "\n"
    path.write_text(encoded, encoding="utf-8")
    (ROOT / "t03_candidate/contracts/query-responses.schema.json").write_text(
        encoded, encoding="utf-8"
    )
    mapping = {
        "stage": "A26", "source_version": "V0.30", "contract": CONTRACT, "migration": 12,
        "command": "order.activate",
        "localized_order_history_schema_fix": [
            "approval_id is an ID or null", "typed identity/revision/hash references",
            "registered order status and full_v1 slot",
        ],
        "new_activation_only": "draft to active; never accept an advisory query as a token",
        "base_permissions": ["order.activate", "quote.read", "read"],
        "conditional_dependency_permissions": [
            "costing.read", "foundation.read", "quotation_foundation.read",
        ],
        "reviewer_current_permissions": ["quote.review.decide", "quote.read", "read"],
        "reviewer_checks": ["human", "source quote access", "not a source commercial contributor"],
        "formalization_binding": [
            "exact source revision/hash", "one persisted commit", "exact commit approval",
            "approved request and action", "number and file identity", "actual file byte SHA-256",
        ],
        "revocation_hold": {
            "source": "immutable t03_approval_event revoked event for the formalized approval",
            "scope": "exact formalized quote revision",
            "automatic_clear": False, "generic_risk_lifecycle_delivered": False,
        },
        "cost": "Core.costing_snapshot_in_transaction on the exact order writer connection",
        "foundation_reference_kinds_checked": sorted(FOUNDATION_KINDS),
        "quotation_configuration": "frozen A18 binding hashes and current publication/evidence",
        "time": [
            "aware timestamp comparison",
            "quote and approval expiry before checks and immediately before state update",
            "sales FX purpose, current revision and policy maximum observation age",
        ],
        "qualification_evidence": "immutable activated event in the same business transaction",
        "recovery": (
            "Already active local recovery and public same-key receipt replay preserve the original "
            "committed fact; A24 current base authority/control and A25 integrity still apply."
        ),
        "read_only_reconciliation": "original local ledger fact, not current adoption certification",
        "not_certified": [
            "full quote/RFQ/trade-responsibility matrix", "all legacy extension tax references",
            "all dependency deadlines at the physical COMMIT boundary", "general risk lifecycle",
            "remote reviewer identity", "complete T04", "production or distributed durability",
        ],
        "external_business_actions": 0, "production_admission": False, "product_v1_complete": False,
    }
    (ROOT / "t03_candidate/contracts/order-activation-qualification-mapping-v0.30.json").write_text(
        json.dumps(mapping, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"contract": CONTRACT, "migration": 12}))


if __name__ == "__main__":
    build()
