"""Run A32 checks and record their exact source inputs and baseline."""

import hashlib
import json
import re
import subprocess
import zipfile
from concurrent.futures import ThreadPoolExecutor

from verify_a31 import ROOT, source_hashes

BASE = ROOT.parent / "IDP_Brant_T03_A31报价地址角色映射验证_V0.35"
ARCHIVE = ROOT.parent / "IDP_Brant_T03_A31报价地址角色映射验证包_V0.35.zip"
EXPECTED = "c6c0fe91e0a08180dc408dc6c3cf0642e8748c0e2722be983cb08da25ecfa8fa"
CHECKS = {
    "special": ["python", "-m", "unittest", "tests.test_t03_a32_sales_fx", "-q"],
    "unittest": ["python", "-m", "unittest", "discover", "-s", "tests", "-q"],
    "candidate": ["python", "-m", "t03_candidate.verify"],
    "transaction": ["python", "-m", "t03_candidate.verify_transaction_adapter"],
    "ruff": ["ruff", "check", "brant_core", "tests", "scripts"],
    "mypy": ["mypy", "--check-untyped-defs", "brant_core"],
    "compileall": ["python", "-m", "compileall", "-q", "brant_core", "tests", "scripts"],
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def preserve_baseline():
    if sha(ARCHIVE.read_bytes()) != EXPECTED:
        raise RuntimeError("A31 archive hash changed")
    manifest_path = "evidence/a31-package-manifest.json"
    manifest = json.loads((BASE / manifest_path).read_text(encoding="utf-8"))
    with zipfile.ZipFile(ARCHIVE) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or archive.testzip() is not None:
            raise RuntimeError("A31 archive invalid")
        if set(names) != {item["path"] for item in manifest["files"]} | {manifest_path}:
            raise RuntimeError("A31 archive manifest mismatch")
        if archive.read(manifest_path) != (BASE / manifest_path).read_bytes():
            raise RuntimeError("A31 manifest changed")
        for item in manifest["files"]:
            source = (BASE / item["path"]).read_bytes()
            if len(source) != item["bytes"] or sha(source) != item["sha256"]:
                raise RuntimeError(f"A31 source changed: {item['path']}")
            if sha(archive.read(item["path"])) != item["sha256"]:
                raise RuntimeError(f"A31 archive member changed: {item['path']}")
    return {"sha256": EXPECTED, "manifest_files": len(manifest["files"]), "unchanged": True}


def main():
    baseline = preserve_baseline()
    inputs = source_hashes()

    def run(item):
        name, args = item
        command = ["uv", "run", "--frozen", *args]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
        output = result.stdout + result.stderr
        (ROOT / "evidence" / f"a32-{name}.txt").write_text(output, encoding="utf-8")
        count = re.search(r"Ran (\d+) tests?", output)
        return name, {"command": command, "exit_code": result.returncode,
                      "test_count": int(count.group(1)) if count else None,
                      "evidence": f"evidence/a32-{name}.txt"}

    with ThreadPoolExecutor(max_workers=4) as pool:
        checks = dict(pool.map(run, CHECKS.items()))
    unchanged = inputs == source_hashes()
    passed = unchanged and all(value["exit_code"] == 0 for value in checks.values())
    report = {"stage": "A32", "source_version": "V0.36", "core_version": "0.5.1",
              "migration": 12, "date": "2026-11-05", "timezone": "Asia/Shanghai",
              "verified_source_hashes": inputs, "source_input_set_unchanged": unchanged,
              "historical_a31_preservation": baseline, "checks": checks, "all_passed": passed,
              "fixture_classification": "synthetic", "production_admission": False}
    (ROOT / "evidence/a32-verification.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"checks": checks, "all_passed": passed}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
