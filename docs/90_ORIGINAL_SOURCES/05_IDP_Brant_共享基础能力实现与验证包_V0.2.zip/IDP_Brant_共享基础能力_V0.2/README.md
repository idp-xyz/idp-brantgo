# IDP Brant 共享基础能力与BC-T01实现包 V0.2

本轮将核价前基础能力落实到本地应用服务：18类版本化配置、确定性换算、资料归档、编号与纯文本草稿模板。
保留原BC-T01的来源、最小主数据及询价命令。产品范围基线仍为V1.0；本包V0.2不等于完整产品V1.0已交付。

## 运行与复验

```bash
uv sync --frozen
uv run --frozen python scripts/verify.py
uv run --frozen python -m brant_core demo
uv run --frozen python -m brant_core foundation-demo
```

两种演示均创建新的临时目录并返回结果路径，也可通过`--directory 新目录`指定位置，拒绝覆盖已有数据库。
`foundation-demo`固定合成业务时钟2026-10-22T09:00:00Z，独立经办／核实人发布22份配置，覆盖18种类型。
汇率7.123456、税率0.13、贸易地点和主体均为测试参数，不是市场汇率、适用税法或真实贸易承诺。
演示真值：120 USD×7.123456=854.81 CNY；2 DOZEN=24 PCS；113.00含税金额拆为100.00未税＋13.00税额。

## 基础配置与命令

| 配置类型 | 已实现内容 |
|---|---|
| company／currency | 单一经营主体档案、本位币、时区、币种精度及HALF_UP舍入 |
| unit／conversion | 单位维度、精度、按SKU及技术规格引用的有依据换算 |
| fx | 币种方向、用途、来源、观察时点、有效期，禁自动倒算／交叉推导 |
| calendar／trade_terms | 工作周、核实的例外日期、术语版本、指定地点、交期锚点和日历引用 |
| payment_terms | 阶段比例、触发条件、天数及日历版本，合计100 |
| tax_profile／fee_type／pricing_policy | 含税／未税、税额处理、费用包含关系、费用归属、毛利门槛及核价规则配置 |
| party_profile／contact_profile | 客户／供应商档案、交易地址及角色、客户或供应商联系人 |
| sku_profile／code_mapping | 规格版本、基础单位、客户／供应商货号映射，外部编码冲突拒绝 |
| bank_account | 账户归属及用途、双人核实、独立敏感字段读取权限 |
| sequence／document_template | 原子编号、按业务引用防重、纯文本字段白名单与草稿水印 |

新增契约`brant.foundation/0.1.0`，旧`brant.trade-core/0.1.0`输入及响应结构保持独立。
配置使用foundation.save（新不可变修订）／foundation.publish（独立人工核实发布）／foundation.retire。
基础服务包括foundation.snapshot、foundation.fx.convert、foundation.unit.convert、foundation.tax.preview、foundation.number.issue、foundation.file.register及foundation.document.render。
master.revise显式打开新的草稿版本，保存旧confirmed内容和核实证据；无需放宽旧upsert命令以覆盖已核实记录。

配置引用必须携带kind、id及revision，主数据引用同时绑定已核实row_version。
新稿不撤旧版；发布原子替代；当前引用已被替代、撤销、到期或不再获权时，阻断新的前向动作。
历史快照可继续读取，但仍核对当前资料访问权限；不能借历史快照越权。
汇率缺失时不取1；同币种明确不传fx且系数1，不假造同币种汇率记录。

## 接口与可信边界

```python
from brant_core import Core, Principal
core = Core('local.sqlite')
editor = Principal('tenant.demo', 'company.demo', 'editor')
core.provision(editor, ['*'], team_id='trade', data_scope='company')
# 以上是可信本地初始化；真实HTTP适配不得接受请求自授Principal或provision。
result = core.execute(editor, {
    'contract':'brant.foundation/0.1.0',
    'command':'foundation.save', 'idempotency_key':'currency.CNY.1',
    'args':{'id':'CNY', 'kind':'currency', 'expected_version':0,
        'data':{'code':'CNY','name':'人民币','minor_units':2,'rounding':'HALF_UP'},
        'evidence_ids':['已登记且可读取的source_id']}
})
```

`provision`提供本地身份属性、命令授权、own／team／company范围；新身份默认own，人工／AI属性由可信适配层登记。
记录所有者及所属团队由服务器登记，团队字段是记录归属，不随人员换组自动转移。
历史V0.1权限按原company语义迁移，不静默扩大或收窄；所有者必须有原始成功审计可验证，否则迁移整体回滚。
真实企业认证、岗位映射、身份生命周期、配置数据和生产部署仍需企业实测；本包不宣称已接SSO。

`Core.foundation_get(principal, kind, id, revision=None)`读取当前或指定历史版本；kind还支持snapshot、file及master_history。
bank_account的account_number仅具foundation.sensitive.read时完整返回，否则掩码。
附件需要foundation.read和file.read及记录范围；支持文本、PDF和XLSX归档，不解析、执行或承诺真实性。
新契约JSON入口上限15MiB以容纳10MiB附件Base64，旧契约维持1MiB。文件校验类型／扩展名／基础签名，不能替代恶意文件扫描。

本地CLI `execute-local --db 路径 --tenant 租户 --company 公司 --actor 身份`从stdin接收JSON；这是开发者持有本地数据库的测试工具，不是远程认证入口。
业务拒绝退出码1，入口／存储故障退出码2。拒绝和敏感读取留审计；业务、动作、Outbox及成功审计同事务。

## 交付边界

基础定义、校验和换算已实现；T02才实现供应报价比选与成本组件归集，T03才执行毛利审批及正式报价。
付款条件与交期的定义／校验已实现，实际付款计划、工作日交期推算和履约由对应业务切片使用，不能将基础配置当作已发生业务。
模板输出强制DRAFT水印，绑定模板修订与编号；正式报价文档还须绑定报价商业哈希，由T03交付。
未接真实文件解析、模型、外部银行／申报渠道、EER/BIP或业务网页。未创建实际报价、订单、银行到账或税务退税事实。

详见`docs/FOUNDATION_SPEC.md`、`docs/FOUNDATION_IMPLEMENTATION.md`、`evidence/verification.json`与验收报告。
