"""Atomic initialization for the T01-only SQLite file format."""

import sqlite3
from pathlib import Path

VERSION = 1


def initialize(db: sqlite3.Connection, reference: Path) -> None:
    db.execute("BEGIN IMMEDIATE")
    try:
        exists = db.execute("SELECT 1 FROM sqlite_master WHERE name='schema_migration'").fetchone()
        if exists:
            versions = [
                r[0] for r in db.execute("SELECT version FROM schema_migration ORDER BY version")
            ]
            if versions not in ([VERSION], [VERSION, 2]):
                raise RuntimeError("Unsupported database migration version")
            db.commit()
            return
        tables = db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        if tables:
            raise RuntimeError("Refusing to initialize a non-T01 database")
        # execute individually: executescript would implicitly commit the writer lock.
        statements = "\n".join(
            line
            for line in reference.read_text().splitlines()
            if not line.lstrip().startswith("--")
        ).split(";")
        for statement in statements:
            if statement.strip():
                db.execute(statement)
        db.execute("""CREATE TABLE authorization(
            tenant TEXT NOT NULL,company TEXT NOT NULL,actor TEXT NOT NULL,
            grants_json TEXT NOT NULL CHECK(json_valid(grants_json)),
            actor_kind TEXT NOT NULL CHECK(actor_kind IN ('human','ai')),
            PRIMARY KEY(tenant,company,actor),FOREIGN KEY(tenant,company) REFERENCES scope)""")
        db.execute("""CREATE TABLE audit_event(
            seq INTEGER PRIMARY KEY AUTOINCREMENT,tenant TEXT NOT NULL,company TEXT NOT NULL,
            actor TEXT NOT NULL,event_id TEXT NOT NULL UNIQUE,command TEXT NOT NULL,
            object_id TEXT,outcome TEXT NOT NULL,code TEXT,correlation_id TEXT NOT NULL,
            recorded_at TEXT NOT NULL,reason TEXT)""")
        db.execute(
            "CREATE TABLE schema_migration(version INTEGER PRIMARY KEY,applied_at TEXT NOT NULL)"
        )
        db.execute(
            "INSERT INTO schema_migration VALUES(?,strftime('%Y-%m-%dT%H:%M:%fZ','now'))",
            (VERSION,),
        )
        for table in ("source_content", "source_origin", "source_import"):
            for op in ("UPDATE", "DELETE"):
                db.execute(f"""CREATE TRIGGER immutable_{table}_{op.lower()} BEFORE {op} ON {table}
                    BEGIN SELECT RAISE(ABORT,'immutable source'); END""")
        db.commit()
    except BaseException:
        db.rollback()
        raise
