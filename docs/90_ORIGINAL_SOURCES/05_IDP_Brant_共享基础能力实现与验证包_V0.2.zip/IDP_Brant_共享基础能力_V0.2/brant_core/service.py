"""BC-T01 local application service. Principal and provision require a trusted adapter."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from . import foundation
from .common import Principal, Rejected, canonical, now
from .foundation_storage import migrate
from .storage import initialize

CONTRACT = "brant.trade-core/0.1.0"
SCHEMAS = Path(__file__).parent / "contracts"
REQUEST_SCHEMA = json.loads((SCHEMAS / "BC_T01_commands.schema.json").read_text())
RESPONSE_SCHEMA = json.loads((SCHEMAS / "BC_T01_response.schema.json").read_text())
Draft202012Validator.check_schema(REQUEST_SCHEMA)
Draft202012Validator.check_schema(RESPONSE_SCHEMA)
REQUEST_VALIDATOR = Draft202012Validator(REQUEST_SCHEMA)
RESPONSE_VALIDATOR = Draft202012Validator(RESPONSE_SCHEMA)


class Core:
    def __init__(self, path: str | Path, *, clock=None):
        self.path = Path(path)
        self.clock = clock or (lambda: datetime.now(UTC))
        with self._connection() as db:
            initialize(db, SCHEMAS / "BC_T01_reference.sql")
            migrate(db)

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        db = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            yield db
        finally:
            db.close()

    def provision(
        self,
        who: Principal,
        grants: list[str],
        *,
        actor_kind: str = "human",
        team_id: str | None = None,
        data_scope: str = "own",
    ) -> None:
        """Out-of-band local bootstrap/revocation; never expose as a user command."""
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                db.execute("INSERT OR IGNORE INTO scope VALUES(?,?)", who.scope)
                db.execute(
                    "INSERT INTO authorization VALUES(?,?,?,?,?) "
                    "ON CONFLICT(tenant,company,actor) DO UPDATE SET grants_json=excluded.grants_json,actor_kind=excluded.actor_kind",
                    (*who.scope, who.actor, canonical(grants), actor_kind),
                )
                db.execute(
                    "INSERT INTO actor_access VALUES(?,?,?,?,?) ON CONFLICT(tenant,company,actor) DO UPDATE SET team_id=excluded.team_id,data_scope=excluded.data_scope",
                    (*who.scope, who.actor, team_id, data_scope),
                )
                self._audit(
                    db,
                    who,
                    "authorization.provision",
                    None,
                    "succeeded",
                    None,
                    uuid.uuid4().hex,
                )
                db.commit()
            except BaseException:
                db.rollback()
                raise

    def _authorize(self, db, who, permission):
        row = db.execute(
            "SELECT grants_json,actor_kind FROM authorization WHERE tenant=? AND company=? AND actor=?",
            (*who.scope, who.actor),
        ).fetchone()
        grants = json.loads(row["grants_json"]) if row else []
        if (
            permission
            in ("master.confirm", "rfq.confirm_scope", "foundation.publish", "foundation.retire")
            and row
            and row["actor_kind"] != "human"
        ):
            raise Rejected("PERMISSION_DENIED")
        if (
            permission in ("master.confirm", "rfq.confirm_scope")
            and "read" not in grants
            and "*" not in grants
        ):
            raise Rejected("PERMISSION_DENIED")
        if permission not in grants and "*" not in grants:
            raise Rejected("PERMISSION_DENIED")

    def _audit(self, db, who, command, object_id, outcome, code, correlation, reason=None):
        db.execute(
            "INSERT INTO audit_event(tenant,company,actor,event_id,command,object_id,outcome,code,correlation_id,recorded_at,reason) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (
                *who.scope,
                who.actor,
                uuid.uuid4().hex,
                command,
                object_id,
                outcome,
                code,
                correlation,
                now(),
                reason,
            ),
        )

    def execute(self, who: Principal, request: Any) -> dict[str, Any]:
        correlation = uuid.uuid4().hex
        command = request.get("command", "invalid") if isinstance(request, dict) else "invalid"
        if not isinstance(command, str) or len(command) > 100:
            command = "invalid"
        object_id = None
        try:
            contract = request.get("contract") if isinstance(request, dict) else None
            if isinstance(request, dict) and contract not in (CONTRACT, foundation.CONTRACT):
                raise Rejected("UNSUPPORTED_CONTRACT", "/contract")
            validator = (
                foundation.REQUEST_VALIDATOR
                if contract == foundation.CONTRACT
                else REQUEST_VALIDATOR
            )
            response_validator = (
                foundation.RESPONSE_VALIDATOR
                if contract == foundation.CONTRACT
                else RESPONSE_VALIDATOR
            )
            try:
                encoded = canonical(request).encode("utf-8")
            except (TypeError, ValueError, UnicodeError, RecursionError):
                raise Rejected("SCHEMA_INVALID") from None
            if len(encoded) > (
                15 * 1024 * 1024 if contract == foundation.CONTRACT else 1024 * 1024
            ) or not validator.is_valid(request):
                raise Rejected(
                    "SCHEMA_INVALID",
                    "/",
                    "Request does not match bounded closed schema",
                )
            args = request["args"]
            object_id = args["id"]
            payload = {k: v for k, v in args.items() if k != "expected_version"}
            digest = hashlib.sha256(canonical(payload).encode("utf-8")).hexdigest()
            with self._connection() as db:
                db.execute("BEGIN IMMEDIATE")
                try:
                    self._authorize(db, who, command)
                    old = db.execute(
                        "SELECT request_hash,result_json FROM action_result WHERE "
                        "tenant=? AND company=? AND command=? AND idempotency_key=?",
                        (*who.scope, command, request["idempotency_key"]),
                    ).fetchone()
                    if old:
                        if old["request_hash"] != digest:
                            raise Rejected("IDEMPOTENCY_PAYLOAD_CONFLICT")
                        self._authorize(db, who, "read")
                        replay_result = json.loads(old["result_json"])
                        if not command.startswith("foundation."):
                            self._access(
                                db,
                                who,
                                "source"
                                if command == "source.register"
                                else "master"
                                if command.startswith("master.")
                                else "rfq",
                                replay_result["object_id"],
                            )
                        else:
                            foundation.replay_access(self, db, who, command, args, replay_result)
                        result = json.loads(old["result_json"])
                        result["replayed"] = True
                        self._audit(
                            db,
                            who,
                            command,
                            result["object_id"],
                            "replayed",
                            None,
                            correlation,
                        )
                    else:
                        result = (
                            foundation.handle(self, db, who, command, args)
                            if contract == foundation.CONTRACT
                            else self._dispatch(db, who, command, args)
                        )
                        result.update(ok=True, action_id=uuid.uuid4().hex, replayed=False)
                        response_validator.validate(result)
                        db.execute(
                            "INSERT INTO action_result VALUES(?,?,?,?,?,?,?)",
                            (
                                *who.scope,
                                command,
                                request["idempotency_key"],
                                digest,
                                result["action_id"],
                                canonical(result),
                            ),
                        )
                        db.execute(
                            "INSERT INTO outbox VALUES(?,?,?,?,?)",
                            (
                                *who.scope,
                                uuid.uuid4().hex,
                                result["action_id"],
                                canonical(
                                    {
                                        "command": command,
                                        "object_id": result["object_id"],
                                        "row_version": result["row_version"],
                                    }
                                ),
                            ),
                        )
                        self._audit(
                            db,
                            who,
                            command,
                            result["object_id"],
                            "succeeded",
                            None,
                            correlation,
                            args.get("reason"),
                        )
                    db.commit()
                    return result
                except BaseException:
                    db.rollback()
                    raise
        except Rejected as exc:
            with self._connection() as db:
                self._audit(db, who, command, object_id, "rejected", exc.code, correlation)
            result = {
                "ok": False,
                "code": exc.code,
                "field_errors": exc.fields,
                "correlation_id": correlation,
                "retryable": False,
            }
            (
                foundation.RESPONSE_VALIDATOR
                if isinstance(request, dict) and request.get("contract") == foundation.CONTRACT
                else RESPONSE_VALIDATOR
            ).validate(result)
            return result

    def _dispatch(self, db, who, command, args):
        if command == "source.register":
            return self._register_source(db, who, args)
        if command == "master.upsert_draft":
            return self._save_master(db, who, args)
        if command == "rfq.save_draft":
            return self._save_rfq(db, who, args)
        table = "master" if command.startswith("master.") else "rfq"
        record = self._load(db, who, table, args["id"])
        self._version(record, args["expected_version"])
        if command == "master.confirm":
            self._state(record, ["draft"])
            self._sources(db, who, args["evidence_ids"])
            self._confirm_master(db, who, record)
            for sid in args["evidence_ids"]:
                db.execute(
                    "INSERT OR IGNORE INTO master_evidence VALUES(?,?,?,?)",
                    (*who.scope, record["id"], sid),
                )
            status = "confirmed"
        elif command == "master.deactivate":
            self._state(record, ["confirmed"])
            status = "inactive"
        elif command == "rfq.confirm_scope":
            self._state(record, ["draft"])
            self._sources(db, who, args["evidence_ids"])
            self._confirm_rfq(db, who, record, args["evidence_ids"])
            for sid in args["evidence_ids"]:
                db.execute(
                    "INSERT OR IGNORE INTO source_use VALUES(?,?,?,?)",
                    (*who.scope, record["id"], sid),
                )
            status = "ready"
        elif command == "rfq.cancel":
            self._state(record, ["draft", "ready"])
            status = "cancelled"
        elif command == "rfq.close":
            self._state(record, ["ready"])
            status = "closed"
        else:
            raise Rejected("SCHEMA_INVALID")
        db.execute(
            f"UPDATE {table} SET status=?,row_version=row_version+1 WHERE tenant=? AND company=? AND id=?",
            (status, *who.scope, record["id"]),
        )
        return {
            "object_id": record["id"],
            "row_version": record["row_version"] + 1,
            "status": status,
        }

    def _claim(self, db, who, kind, object_id):
        row = db.execute(
            "SELECT team_id FROM actor_access WHERE tenant=? AND company=? AND actor=?",
            (*who.scope, who.actor),
        ).fetchone()
        db.execute(
            "INSERT OR IGNORE INTO record_access VALUES(?,?,?,?,?,?)",
            (*who.scope, kind, object_id, who.actor, row["team_id"] if row else None),
        )

    def _access(self, db, who, kind, object_id):
        access = db.execute(
            "SELECT * FROM actor_access WHERE tenant=? AND company=? AND actor=?",
            (*who.scope, who.actor),
        ).fetchone()
        record = db.execute(
            "SELECT * FROM record_access WHERE tenant=? AND company=? AND kind=? AND object_id=?",
            (*who.scope, kind, object_id),
        ).fetchone()
        if not access or not record:
            raise Rejected("NOT_FOUND", "/args/id")
        if record["owner_id"] == who.actor or access["data_scope"] == "company":
            return
        if (
            access["data_scope"] == "team"
            and access["team_id"]
            and access["team_id"] == record["team_id"]
        ):
            return
        raise Rejected("NOT_FOUND", "/args/id")

    def _load(self, db, who, table, object_id):
        row = db.execute(
            f"SELECT * FROM {table} WHERE tenant=? AND company=? AND id=?",
            (*who.scope, object_id),
        ).fetchone()
        if not row:
            raise Rejected("NOT_FOUND", "/args/id")
        if table in ("master", "rfq", "source_origin"):
            self._access(
                db,
                who,
                {"master": "master", "rfq": "rfq", "source_origin": "source"}[table],
                object_id,
            )
        return dict(row)

    @staticmethod
    def _version(record, expected):
        if record["row_version"] != expected:
            raise Rejected("VERSION_CONFLICT", "/args/expected_version")

    @staticmethod
    def _state(record, allowed):
        if record["status"] not in allowed:
            raise Rejected("INVALID_STATE", "/args/id")

    def _master_ref(self, db, who, object_id, kind, path, confirmed=False):
        row = db.execute(
            "SELECT * FROM master WHERE tenant=? AND company=? AND id=? AND kind=?",
            (*who.scope, object_id, kind),
        ).fetchone()
        if not row or (confirmed and row["status"] != "confirmed"):
            raise Rejected("REFERENCE_INVALID", path)
        try:
            self._access(db, who, "master", object_id)
        except Rejected:
            raise Rejected("REFERENCE_INVALID", path) from None
        return dict(row)

    def _sources(self, db, who, ids, path="/args/evidence_ids"):
        for i, sid in enumerate(ids):
            self._source_ref(db, who, sid, f"{path}/{i}")

    def _source_ref(self, db, who, sid, path):
        self._authorize(db, who, "read")
        if not db.execute(
            "SELECT 1 FROM source_origin WHERE tenant=? AND company=? AND id=?", (*who.scope, sid)
        ).fetchone():
            raise Rejected("REFERENCE_INVALID", path, "Source is not accessible")
        try:
            self._access(db, who, "source", sid)
        except Rejected:
            raise Rejected("REFERENCE_INVALID", path, "Source is not accessible") from None

    def _register_source(self, db, who, args):
        digest = hashlib.sha256(args["content_text"].encode("utf-8")).hexdigest()
        by_id = db.execute(
            "SELECT * FROM source_origin WHERE tenant=? AND company=? AND id=?",
            (*who.scope, args["id"]),
        ).fetchone()
        existing = None
        if args["source_kind"] == "email_text":
            existing = db.execute(
                "SELECT * FROM source_origin WHERE tenant=? AND company=? AND provider=? AND account_ref=? AND message_id=?",
                (
                    *who.scope,
                    args["provider"],
                    args["account_ref"],
                    args["external_message_id"],
                ),
            ).fetchone()
        for accessible_origin in (by_id, existing):
            if accessible_origin:
                self._access(db, who, "source", accessible_origin["id"])
        if by_id and existing and by_id["id"] != existing["id"]:
            raise Rejected("SOURCE_IDENTITY_CONFLICT", "/args/id")
        existing = existing or by_id
        if existing:
            content = self._load(db, who, "source_content", existing["content_id"])
            identity = tuple(
                existing[k]
                for k in (
                    "kind",
                    "provider",
                    "account_ref",
                    "message_id",
                    "author_claim",
                )
            )
            incoming = (
                args["source_kind"],
                args.get("provider"),
                args.get("account_ref"),
                args.get("external_message_id"),
                args.get("author_claim"),
            )
            if content["sha256"] != digest or identity != incoming:
                raise Rejected("SOURCE_IDENTITY_CONFLICT", "/args/id")
            origin_id = existing["id"]
        else:
            content = db.execute(
                "SELECT id FROM source_content WHERE tenant=? AND company=? AND sha256=?",
                (*who.scope, digest),
            ).fetchone()
            content_id = content["id"] if content else uuid.uuid4().hex
            if not content:
                db.execute(
                    "INSERT INTO source_content VALUES(?,?,?,?,?)",
                    (*who.scope, content_id, digest, args["content_text"]),
                )
            origin_id = args["id"]
            db.execute(
                "INSERT INTO source_origin VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    *who.scope,
                    origin_id,
                    content_id,
                    args["source_kind"],
                    args.get("provider"),
                    args.get("account_ref"),
                    args.get("external_message_id"),
                    args.get("author_claim"),
                ),
            )
        db.execute(
            "INSERT INTO source_import VALUES(?,?,?,?,?,?)",
            (*who.scope, uuid.uuid4().hex, origin_id, who.actor, now()),
        )
        if existing:
            self._access(db, who, "source", origin_id)
        self._claim(db, who, "source", origin_id)
        return {"object_id": origin_id, "row_version": 1, "status": "registered"}

    def _save_master(self, db, who, args):
        current = db.execute(
            "SELECT * FROM master WHERE tenant=? AND company=? AND id=?",
            (*who.scope, args["id"]),
        ).fetchone()
        if current:
            self._access(db, who, "master", args["id"])
            self._version(current, args["expected_version"])
            self._state(current, ["draft"])
            if args["kind"] != current["kind"]:
                raise Rejected("INVALID_STATE", "/args/kind")
        elif args["expected_version"] != 0:
            raise Rejected("NOT_FOUND", "/args/id")
        if args.get("parent_customer_id"):
            if args["kind"] != "contact":
                raise Rejected("INVALID_KNOWN_VALUE", "/args/parent_customer_id")
            self._master_ref(
                db,
                who,
                args["parent_customer_id"],
                "customer",
                "/args/parent_customer_id",
            )
        if args.get("base_uom") and args["kind"] != "sku":
            raise Rejected("INVALID_KNOWN_VALUE", "/args/base_uom")
        version = args["expected_version"] + 1
        db.execute(
            "INSERT INTO master VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant,company,id) DO UPDATE SET "
            "name=excluded.name,parent_customer_id=excluded.parent_customer_id,base_uom=excluded.base_uom,row_version=excluded.row_version",
            (
                *who.scope,
                args["id"],
                args["kind"],
                args.get("name"),
                args.get("parent_customer_id"),
                args.get("base_uom"),
                "draft",
                version,
            ),
        )
        self._claim(db, who, "master", args["id"])
        return {"object_id": args["id"], "row_version": version, "status": "draft"}

    def _confirm_master(self, db, who, record):
        if not record["name"] or not record["name"].strip():
            raise Rejected("DRAFT_NOT_READY", "/args/name")
        if record["kind"] == "contact":
            if not record["parent_customer_id"]:
                raise Rejected("DRAFT_NOT_READY", "/args/parent_customer_id")
            self._master_ref(
                db,
                who,
                record["parent_customer_id"],
                "customer",
                "/args/parent_customer_id",
                True,
            )
        if record["kind"] == "sku" and record["base_uom"] != "PCS":
            raise Rejected("DRAFT_NOT_READY", "/args/base_uom")

    def _save_rfq(self, db, who, args):
        current = db.execute(
            "SELECT * FROM rfq WHERE tenant=? AND company=? AND id=?",
            (*who.scope, args["id"]),
        ).fetchone()
        if current:
            self._access(db, who, "rfq", args["id"])
            self._version(current, args["expected_version"])
            self._state(current, ["draft"])
        elif args["expected_version"] != 0:
            raise Rejected("NOT_FOUND", "/args/id")
        lines = args.get("lines", [])
        if len({line["line_id"] for line in lines}) != len(lines):
            raise Rejected("DUPLICATE_LINE_ID", "/args/lines")
        for i, line in enumerate(lines):
            if "quantity" in line and Decimal(line["quantity"]) <= 0:
                raise Rejected("INVALID_KNOWN_VALUE", f"/args/lines/{i}/quantity")
        customer, contact = args.get("customer_id"), args.get("contact_id")
        if customer:
            self._master_ref(db, who, customer, "customer", "/args/customer_id")
        if contact:
            c = self._master_ref(db, who, contact, "contact", "/args/contact_id")
            if customer and c["parent_customer_id"] != customer:
                raise Rejected("REFERENCE_INVALID", "/args/contact_id")
        self._sources(db, who, args.get("source_ids", []), "/args/source_ids")
        for i, line in enumerate(lines):
            if "sku_id" in line:
                self._master_ref(db, who, line["sku_id"], "sku", f"/args/lines/{i}/sku_id")
            if "source_id" in line:
                self._source_ref(db, who, line["source_id"], f"/args/lines/{i}/source_id")
        version = args["expected_version"] + 1
        db.execute(
            "INSERT INTO rfq VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(tenant,company,id) DO UPDATE SET "
            "customer_id=excluded.customer_id,contact_id=excluded.contact_id,row_version=excluded.row_version,unresolved_json=excluded.unresolved_json",
            (
                *who.scope,
                args["id"],
                customer,
                contact,
                "draft",
                version,
                canonical(args.get("unresolved_fields", [])),
            ),
        )
        db.execute(
            "DELETE FROM rfq_line WHERE tenant=? AND company=? AND rfq_id=?",
            (*who.scope, args["id"]),
        )
        db.execute(
            "DELETE FROM source_use WHERE tenant=? AND company=? AND rfq_id=?",
            (*who.scope, args["id"]),
        )
        uses = set(args.get("source_ids", []))
        for line in lines:
            db.execute(
                "INSERT INTO rfq_line VALUES(?,?,?,?,?,?,?,?,?,?)",
                (
                    *who.scope,
                    args["id"],
                    line["line_id"],
                    line.get("sku_id"),
                    line.get("quantity"),
                    line.get("uom"),
                    line.get("requested_item"),
                    line.get("source_id"),
                    line.get("locator"),
                ),
            )
            if line.get("source_id"):
                uses.add(line["source_id"])
        for sid in uses:
            db.execute("INSERT INTO source_use VALUES(?,?,?,?)", (*who.scope, args["id"], sid))
        self._claim(db, who, "rfq", args["id"])
        return {"object_id": args["id"], "row_version": version, "status": "draft"}

    def _confirm_rfq(self, db, who, record, evidence):
        if not record["customer_id"] or not record["contact_id"]:
            raise Rejected("DRAFT_NOT_READY", "/args/customer_id", "Customer and contact required")
        self._master_ref(db, who, record["customer_id"], "customer", "/args/customer_id", True)
        contact = self._master_ref(
            db, who, record["contact_id"], "contact", "/args/contact_id", True
        )
        if contact["parent_customer_id"] != record["customer_id"]:
            raise Rejected("REFERENCE_INVALID", "/args/contact_id")
        if json.loads(record["unresolved_json"]):
            raise Rejected("DRAFT_NOT_READY", "/args/unresolved_fields")
        lines = db.execute(
            "SELECT * FROM rfq_line WHERE tenant=? AND company=? AND rfq_id=? ORDER BY line_id",
            (*who.scope, record["id"]),
        ).fetchall()
        if not lines:
            raise Rejected("DRAFT_NOT_READY", "/args/lines")
        for i, line in enumerate(lines):
            for field in ("sku_id", "quantity", "uom", "source_id", "locator"):
                if not line[field] or not str(line[field]).strip():
                    raise Rejected("DRAFT_NOT_READY", f"/args/lines/{i}/{field}")
            self._master_ref(db, who, line["sku_id"], "sku", f"/args/lines/{i}/sku_id", True)
        referenced = {
            row[0]
            for row in db.execute(
                "SELECT source_id FROM source_use WHERE tenant=? AND company=? AND rfq_id=?",
                (*who.scope, record["id"]),
            )
        }
        if not referenced.issubset(set(evidence)):
            raise Rejected(
                "DRAFT_NOT_READY",
                "/args/evidence_ids",
                "Human confirmation must cover all referenced sources",
            )

    def get(self, who: Principal, kind: str, object_id: str) -> dict:
        correlation = uuid.uuid4().hex
        try:
            return self._get(who, kind, object_id, correlation)
        except Rejected as exc:
            with self._connection() as db:
                self._audit(db, who, "get", object_id, "rejected", exc.code, correlation)
            raise

    def _get(self, who: Principal, kind: str, object_id: str, correlation: str) -> dict:
        if kind not in ("master", "rfq", "source"):
            raise Rejected("NOT_FOUND")
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            self._authorize(db, who, "read")
            record = self._load(db, who, "source_origin" if kind == "source" else kind, object_id)
            if kind == "rfq":
                record["unresolved_fields"] = json.loads(record.pop("unresolved_json"))
                record["lines"] = [
                    dict(row)
                    for row in db.execute(
                        "SELECT * FROM rfq_line WHERE tenant=? AND company=? AND rfq_id=? ORDER BY line_id",
                        (*who.scope, object_id),
                    )
                ]
                record["source_ids"] = [
                    row[0]
                    for row in db.execute(
                        "SELECT source_id FROM source_use WHERE tenant=? AND company=? AND rfq_id=? ORDER BY source_id",
                        (*who.scope, object_id),
                    )
                ]
            elif kind == "source":
                record["content"] = self._load(db, who, "source_content", record["content_id"])
                record["imports"] = [
                    dict(row)
                    for row in db.execute(
                        "SELECT * FROM source_import WHERE tenant=? AND company=? AND origin_id=? ORDER BY imported_at,id",
                        (*who.scope, object_id),
                    )
                ]
            self._audit(db, who, "get", object_id, "read", None, correlation)
            db.commit()
            return record

    def audit(self, who: Principal) -> list[dict]:
        with self._connection() as db:
            db.execute("BEGIN IMMEDIATE")
            self._authorize(db, who, "audit.read")
            records = [
                dict(row)
                for row in db.execute(
                    "SELECT * FROM audit_event WHERE tenant=? AND company=? ORDER BY seq", who.scope
                )
            ]
            db.commit()
            return records

    def foundation_get(
        self, who: Principal, kind: str, object_id: str, revision: int | None = None
    ) -> dict:
        correlation = uuid.uuid4().hex
        try:
            with self._connection() as db:
                db.execute("BEGIN IMMEDIATE")
                output = foundation.get(self, db, who, kind, object_id, revision)
                self._audit(db, who, "foundation.get", object_id, "read", None, correlation)
                db.commit()
                return output
        except Rejected as exc:
            with self._connection() as db:
                self._audit(db, who, "foundation.get", object_id, "rejected", exc.code, correlation)
            raise
