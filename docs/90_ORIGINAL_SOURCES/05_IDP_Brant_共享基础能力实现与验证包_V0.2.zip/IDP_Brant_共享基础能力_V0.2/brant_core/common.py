import json
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any


def canonical(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def now() -> str:
    return datetime.now(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")


@dataclass(frozen=True)
class Principal:
    tenant: str
    company: str
    actor: str

    @property
    def scope(self) -> tuple[str, str]:
        return self.tenant, self.company


class Rejected(Exception):
    def __init__(self, code: str, path: str = "/", reason: str = ""):
        self.code = code
        self.fields = [{"path": path[:200], "reason": (reason or code)[:200]}]
        super().__init__(code)
