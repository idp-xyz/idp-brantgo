"""Deterministic synthetic foundation demonstration, not real rates or tax policy."""

import base64
import json
from datetime import UTC, datetime
from pathlib import Path

from .common import Principal
from .service import Core


def demo(directory: Path) -> dict:
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "brant-foundation.sqlite"
    if path.exists():
        raise ValueError("Fresh demo directory required")
    core = Core(path, clock=lambda: datetime(2026, 10, 22, 9, tzinfo=UTC))
    editor = Principal("tenant.demo", "company.demo", "editor")
    reviewer = Principal("tenant.demo", "company.demo", "reviewer")
    for who in [editor, reviewer]:
        core.provision(who, ["*"], team_id="trade", data_scope="company")
    commands: list[dict] = []
    configs = []

    def run(command, args, who=editor, old=False):
        answer = core.execute(
            who,
            {
                "contract": "brant.trade-core/0.1.0" if old else "brant.foundation/0.1.0",
                "command": command,
                "args": args,
                "idempotency_key": f"demo.{len(commands) + 1}",
            },
        )
        if not answer["ok"]:
            raise RuntimeError(f"{command}: {answer['code']}")
        commands.append({"command": command, "result": answer})
        return answer

    run(
        "source.register",
        {
            "id": "evidence",
            "source_kind": "manual_text",
            "content_text": "SYNTHETIC ONLY: all names, addresses, exchange rates and tax parameters are test fixtures, not real policies or market facts.",
        },
        old=True,
    )
    for id_, kind, fields in [
        ("customer", "customer", {}),
        ("contact", "contact", {"parent_customer_id": "customer"}),
        ("supplier", "supplier", {}),
        ("sku", "sku", {"base_uom": "PCS"}),
    ]:
        run(
            "master.upsert_draft",
            {"id": id_, "kind": kind, "name": id_, "expected_version": 0, **fields},
            old=True,
        )
        run(
            "master.confirm",
            {"id": id_, "expected_version": 1, "evidence_ids": ["evidence"]},
            old=True,
        )

    def config(kind, id_, data):
        if kind == "sku_profile":
            data = {**data, "sku_row_version": 2}
        if kind in ("party_profile", "contact_profile", "code_mapping"):
            data = {**data, "party_row_version": 2}
        saved = run(
            "foundation.save",
            {
                "id": id_,
                "kind": kind,
                "expected_version": 0,
                "data": data,
                "evidence_ids": ["evidence"],
            },
        )
        run(
            "foundation.publish",
            {
                "id": id_,
                "kind": kind,
                "expected_version": 1,
                "revision": saved["revision"],
                "reason": "Independent review of synthetic fixture",
            },
            who=reviewer,
        )
        reference = {"kind": kind, "id": id_, "revision": 1}
        configs.append(reference)
        return reference

    cny = config(
        "currency", "CNY", {"code": "CNY", "name": "CNY", "minor_units": 2, "rounding": "HALF_UP"}
    )
    usd = config(
        "currency", "USD", {"code": "USD", "name": "USD", "minor_units": 2, "rounding": "HALF_UP"}
    )
    company = config(
        "company",
        "company.demo",
        {
            "legal_name": "合成外贸企业",
            "registration_no": "SYNTHETIC-NOT-REAL",
            "country": "CN",
            "address": "测试地址",
            "base_currency": cny,
            "timezone": "Asia/Shanghai",
            "policy_scope": "synthetic general trade scenario",
        },
    )
    pcs = config("unit", "PCS", {"code": "PCS", "name": "件", "dimension": "count", "precision": 0})
    dozen = config(
        "unit", "DOZEN", {"code": "DOZEN", "name": "打", "dimension": "count", "precision": 0}
    )
    sku = config(
        "sku_profile",
        "sku.profile",
        {
            "sku_id": "sku",
            "item_name": "合成商品",
            "specification_version": "TECH.r1",
            "base_unit": pcs,
            "description": "synthetic specification",
        },
    )
    dates = {"valid_from": "2026-10-22T00:00:00Z", "valid_until": "2026-10-23T00:00:00Z"}
    conversion = config(
        "conversion",
        "dozen.pcs",
        {
            "sku_profile": sku,
            "from_unit": dozen,
            "to_unit": pcs,
            "factor": "12",
            "basis": "synthetic SKU-specific pack definition",
            **dates,
        },
    )
    calendar = config(
        "calendar",
        "calendar",
        {"timezone": "Asia/Shanghai", "working_weekdays": [1, 2, 3, 4, 5], "holidays": []},
    )
    terms = config(
        "trade_terms",
        "terms",
        {
            "incoterm": "FCA",
            "edition": "2020",
            "named_place": "TEST NAMED PLACE",
            "responsibility_note": "synthetic terms, no ownership inference",
            "delivery": {
                "kind": "lead_time",
                "anchor_event": "technical_approved",
                "days": 30,
                "day_basis": "working",
                "calendar": calendar,
            },
        },
    )
    stage = {
        "stage_id": "deposit",
        "percent": "30",
        "trigger": "order_confirmed",
        "days": 0,
        "day_basis": "calendar",
        "calendar": calendar,
    }
    payment = config(
        "payment_terms",
        "payment",
        {
            "name": "30/70 TEST",
            "stages": [
                stage,
                {**stage, "stage_id": "balance", "percent": "70", "trigger": "before_shipment"},
            ],
        },
    )
    contact = config(
        "contact_profile",
        "supplier.contact",
        {
            "party_id": "supplier",
            "party_role": "supplier",
            "name": "合成联系人",
            "email": "supplier@example.invalid",
        },
    )
    for party in ["customer", "supplier"]:
        config(
            "party_profile",
            party + ".profile",
            {
                "party_id": party,
                "legal_name": "合成" + party,
                "country": "CN",
                "addresses": [
                    {
                        "address_id": "address1",
                        "role": "buyer" if party == "customer" else "seller",
                        "address": "测试交易地址",
                    }
                ],
                **(
                    {"contact_refs": [{"id": "contact", "row_version": 2}]}
                    if party == "customer"
                    else {"contacts": [contact]}
                ),
                "trade_terms": terms,
                "payment_terms": payment,
            },
        )
        config(
            "code_mapping",
            party + ".mapping",
            {
                "party_id": party,
                "party_role": party,
                "external_code": "EXT-" + party,
                "sku_profile": sku,
            },
        )
    tax = config(
        "tax_profile",
        "tax",
        {
            "name": "SYNTHETIC 13%",
            "rate": "0.13",
            "price_basis": "inclusive",
            "recovery_treatment": "nonrecoverable",
            "policy_basis": "synthetic arithmetic only; not tax advice",
            **dates,
        },
    )
    fee = config(
        "fee_type",
        "packaging",
        {
            "name": "包装费",
            "category": "packaging",
            "side": "purchase_cost",
            "inclusion": "included_in_line",
            "allocation_basis": "quantity",
            "policy_basis": "synthetic included fee",
        },
    )
    policy = config(
        "pricing_policy",
        "pricing",
        {
            "name": "synthetic policy",
            "calculation_currency": cny,
            "minimum_margin": "0.25",
            "quote_valid_days": 7,
            "max_fx_age_seconds": 86400,
            "independent_review": True,
            "tax_profile": tax,
        },
    )
    fx = config(
        "fx",
        "usd.cny",
        {
            "from_currency": usd,
            "to_currency": cny,
            "rate": "7.123456",
            "purpose": "cost_estimate",
            "source_name": "SYNTHETIC RATE",
            "observed_at": dates["valid_from"],
            **dates,
        },
    )
    config(
        "bank_account",
        "bank",
        {
            "owner_kind": "company",
            "owner_id": "company.demo",
            "bank_name": "synthetic bank",
            "account_number": "TEST1234567890",
            "currency": cny,
            "purpose": "both",
        },
    )
    sequence = config(
        "sequence",
        "quote.sequence",
        {
            "document_type": "quote",
            "prefix": "QT-",
            "width": 5,
            "company": company,
            "reset": "annual",
        },
    )
    template = config(
        "document_template",
        "quote.template",
        {
            "name": "synthetic plaintext draft",
            "document_type": "quote",
            "template_text": "{document.number}\n{customer.name}\n{quote.total} {quote.currency}",
            "field_names": ["document.number", "customer.name", "quote.total", "quote.currency"],
        },
    )
    fx_result = run(
        "foundation.fx.convert",
        {
            "id": "fx.result",
            "amount": "120",
            "from_currency": usd,
            "to_currency": cny,
            "fx": fx,
            "policy": policy,
            "purpose": "cost_estimate",
        },
    )
    unit_result = run(
        "foundation.unit.convert",
        {"id": "unit.result", "quantity": "2", "conversion": conversion, "sku_profile": sku},
    )
    tax_result = run(
        "foundation.tax.preview",
        {"id": "tax.result", "amount": "113", "currency": cny, "tax_profile": tax},
    )
    snapshot = run(
        "foundation.snapshot",
        {
            "id": "snapshot",
            "refs": [company, fx, policy, sku, conversion, terms, payment, fee],
            "purpose": "cost_estimate",
        },
    )
    number = run(
        "foundation.number.issue",
        {"id": "number1", "sequence": sequence, "business_ref": "draft.quote1"},
    )
    generated = run(
        "foundation.document.render",
        {
            "id": "draft.file",
            "template": template,
            "number_id": "number1",
            "values": {
                "customer.name": "合成客户",
                "quote.total": "960.00",
                "quote.currency": "USD",
            },
        },
    )
    run(
        "foundation.file.register",
        {
            "id": "original.file",
            "file_name": "original.txt",
            "mime_type": "text/plain",
            "content_base64": base64.b64encode("合成原文".encode()).decode(),
        },
    )
    document = {
        "synthetic": True,
        "business_clock": "2026-10-22T09:00:00Z",
        "configuration_kinds": len({r["kind"] for r in configs}),
        "configurations": len(configs),
        "commands": commands,
        "fx": fx_result["values"],
        "unit": unit_result["values"],
        "tax": tax_result["values"],
        "snapshot": snapshot,
        "number": number["values"],
        "draft": generated,
        "model_calls": 0,
        "external_business_actions": 0,
    }
    (directory / "foundation-demo-result.json").write_text(
        json.dumps(document, ensure_ascii=False, indent=2)
    )
    return document
