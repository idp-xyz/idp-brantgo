"""Versioned shared configuration and deterministic calculation primitives.

No market/tax defaults, external calls or legal-policy inference occur here.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import string
from datetime import UTC, datetime
from decimal import ROUND_HALF_UP, Decimal, localcontext
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from jsonschema import Draft202012Validator, FormatChecker

from .common import Rejected, canonical, now

CONTRACT = "brant.foundation/0.1.0"
DIRECTORY = Path(__file__).parent / "contracts"
REQUEST_SCHEMA = json.loads((DIRECTORY / "foundation.commands.schema.json").read_text())
RESPONSE_SCHEMA = json.loads((DIRECTORY / "foundation.response.schema.json").read_text())
Draft202012Validator.check_schema(REQUEST_SCHEMA)
Draft202012Validator.check_schema(RESPONSE_SCHEMA)
REQUEST_VALIDATOR = Draft202012Validator(REQUEST_SCHEMA, format_checker=FormatChecker())
RESPONSE_VALIDATOR = Draft202012Validator(RESPONSE_SCHEMA)
FIELDS = {
    "company.name",
    "customer.name",
    "document.number",
    "document.date",
    "lines.summary",
    "quote.total",
    "quote.currency",
}
SENSITIVE = {"bank_account"}


def stamp(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def result(id_, version=1, status="active", **fields):
    return {"object_id": id_, "row_version": version, "status": status, **fields}


def root(db, who, kind, id_):
    row = db.execute(
        "SELECT * FROM foundation_root WHERE tenant=? AND company=? AND kind=? AND id=?",
        (*who.scope, kind, id_),
    ).fetchone()
    if not row:
        raise Rejected("NOT_FOUND")
    return dict(row)


def revision(db, who, ref):
    row = db.execute(
        "SELECT * FROM foundation_revision WHERE tenant=? AND company=? AND kind=? AND id=? AND revision=?",
        (*who.scope, ref["kind"], ref["id"], ref["revision"]),
    ).fetchone()
    if not row:
        raise Rejected("REFERENCE_INVALID")
    return dict(row)


def refs(value):
    if isinstance(value, dict):
        if set(value) == {"kind", "id", "revision"}:
            yield value
        else:
            for child in value.values():
                yield from refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from refs(child)


def active(core, db, who, ref, visited=None, *, purpose=None):
    core._authorize(db, who, "foundation.read")
    record = revision(db, who, ref)
    head = root(db, who, ref["kind"], ref["id"])
    if head["active_revision"] != ref["revision"] or record["status"] != "active":
        raise Rejected("CONFIG_NOT_ACTIVE")
    key = (ref["kind"], ref["id"], ref["revision"])
    visited = set() if visited is None else visited
    if key in visited:
        raise Rejected("REFERENCE_INVALID", reason="Cyclic configuration reference")
    visited.add(key)
    data = json.loads(record["data_json"])
    validate(core, db, who, ref["kind"], ref["id"], data, at_use=True)
    core._sources(db, who, json.loads(record["evidence_json"]))
    if "valid_from" in data:
        instant = core.clock().astimezone(UTC)
        if not stamp(data["valid_from"]) <= instant < stamp(data["valid_until"]):
            raise Rejected("CONFIG_EXPIRED")
    if ref["kind"] == "fx" and purpose and data["purpose"] != purpose:
        raise Rejected("FX_SCOPE_MISMATCH")
    for child in refs(data):
        active(core, db, who, child, visited.copy(), purpose=purpose)
    return data


def validate(core, db, who, kind, id_, data, *, at_use=False):
    if kind == "company" and id_ != who.company:
        raise Rejected(
            "INVALID_KNOWN_VALUE", reason="Company profile must identify the current company"
        )
    if kind in ("company", "calendar"):
        try:
            ZoneInfo(data["timezone"])
        except (ZoneInfoNotFoundError, ValueError):
            raise Rejected("INVALID_KNOWN_VALUE", "/args/data/timezone") from None
    if kind == "currency" and id_ != data["code"]:
        raise Rejected("INVALID_KNOWN_VALUE", "/args/id", "Currency id must equal its code")
    if kind == "unit" and id_ != data["code"]:
        raise Rejected("INVALID_KNOWN_VALUE", "/args/id", "Unit id must equal its code")
    if "valid_from" in data and stamp(data["valid_from"]) >= stamp(data["valid_until"]):
        raise Rejected("INVALID_KNOWN_VALUE", "/args/data/valid_until")
    if kind == "fx":
        if (
            not Decimal("0") < Decimal(data["rate"]) <= Decimal("1000")
            or data["from_currency"]["id"] == data["to_currency"]["id"]
        ):
            raise Rejected("INVALID_KNOWN_VALUE", "/args/data/rate")
        if stamp(data["observed_at"]) > stamp(data["valid_from"]):
            raise Rejected("INVALID_KNOWN_VALUE", "/args/data/observed_at")
    if kind == "conversion":
        if Decimal(data["factor"]) <= 0 or data["from_unit"] == data["to_unit"]:
            raise Rejected("INVALID_KNOWN_VALUE", "/args/data/factor")
    if kind == "payment_terms":
        if len({s["stage_id"] for s in data["stages"]}) != len(data["stages"]):
            raise Rejected("INVALID_KNOWN_VALUE", "/args/data/stages")
        if (
            any(Decimal(s["percent"]) <= 0 for s in data["stages"])
            or sum(Decimal(s["percent"]) for s in data["stages"]) != 100
        ):
            raise Rejected("PAYMENT_TOTAL_MISMATCH", "/args/data/stages")
    if kind in ("tax_profile", "pricing_policy"):
        field = "rate" if kind == "tax_profile" else "minimum_margin"
        if not Decimal(0) <= Decimal(data[field]) <= Decimal(1):
            raise Rejected("INVALID_KNOWN_VALUE", f"/args/data/{field}")
        if (
            kind == "tax_profile"
            and data["price_basis"] == "not_applicable"
            and Decimal(data["rate"]) != 0
        ):
            raise Rejected("INVALID_KNOWN_VALUE", "/args/data/rate")
    if kind == "document_template":
        try:
            names = []
            for _, template_field, format_, conversion in string.Formatter().parse(
                data["template_text"]
            ):
                if template_field is not None:
                    if template_field not in FIELDS or format_ or conversion:
                        raise ValueError("Unsafe field")
                    names.append(template_field)
            if set(names) != set(data["field_names"]):
                raise ValueError("Field list mismatch")
        except ValueError:
            raise Rejected("TEMPLATE_INVALID") from None
    if kind == "sku_profile":
        master = core._master_ref(db, who, data["sku_id"], "sku", "/args/data/sku_id", True)
        if master["row_version"] != data["sku_row_version"]:
            raise Rejected("REFERENCE_INVALID", "/args/data/sku_row_version")
        unit = revision(db, who, data["base_unit"])
        unit_data = json.loads(unit["data_json"])
        if (
            unit_data["code"] != master["base_uom"]
            or unit_data["dimension"] != "count"
            or unit_data["precision"] != 0
        ):
            raise Rejected(
                "UNIT_SCOPE_MISMATCH",
                reason="Legacy SKU base unit remains PCS; extend the inquiry contract before changing it",
            )
    if kind in ("party_profile", "code_mapping"):
        if kind == "code_mapping":
            party_kind = data["party_role"]
        else:
            record = core._load(db, who, "master", data["party_id"])
            party_kind = record["kind"]
            if party_kind not in ("customer", "supplier"):
                raise Rejected("REFERENCE_INVALID")
        core._master_ref(db, who, data["party_id"], party_kind, "/args/data/party_id", True)
        if kind == "party_profile":
            if len({a["address_id"] for a in data["addresses"]}) != len(data["addresses"]):
                raise Rejected("INVALID_KNOWN_VALUE")
            for contact_ref in data.get("contact_refs", []):
                contact = core._master_ref(
                    db, who, contact_ref["id"], "contact", "/args/data/contact_refs", True
                )
                if (
                    contact["parent_customer_id"] != data["party_id"]
                    or contact["row_version"] != contact_ref["row_version"]
                ):
                    raise Rejected("REFERENCE_INVALID")
    if kind == "contact_profile":
        core._master_ref(db, who, data["party_id"], data["party_role"], "/args/data/party_id", True)
        if data.get("legacy_contact_ref"):
            contact_ref = data["legacy_contact_ref"]
            contact = core._master_ref(
                db, who, contact_ref["id"], "contact", "/args/data/legacy_contact_ref", True
            )
            if (
                data["party_role"] != "customer"
                or contact["parent_customer_id"] != data["party_id"]
                or contact["row_version"] != contact_ref["row_version"]
            ):
                raise Rejected("REFERENCE_INVALID")
    if kind == "party_profile":
        for contact_ref in data.get("contacts", []):
            contact = active(core, db, who, contact_ref)
            if contact["party_id"] != data["party_id"]:
                raise Rejected("REFERENCE_INVALID")
    if kind in ("party_profile", "contact_profile", "code_mapping"):
        master = core._load(db, who, "master", data["party_id"])
        if master["row_version"] != data["party_row_version"]:
            raise Rejected("REFERENCE_INVALID", "/args/data/party_row_version")
    if kind == "bank_account":
        if data["owner_kind"] == "company":
            if data["owner_id"] != who.company:
                raise Rejected("REFERENCE_INVALID")
        else:
            record = core._load(db, who, "master", data["owner_id"])
            if (
                record["kind"] not in ("customer", "supplier")
                or record["status"] != "confirmed"
                or record["row_version"] != data["owner_row_version"]
            ):
                raise Rejected("REFERENCE_INVALID")


def handle(core, db, who, command, args):
    if command == "foundation.save":
        return save(core, db, who, args)
    if command == "foundation.publish":
        return publish(core, db, who, args)
    if command == "foundation.retire":
        head = root(db, who, args["kind"], args["id"])
        core._version(head, args["expected_version"])
        if head["active_revision"] is None:
            raise Rejected("INVALID_STATE")
        db.execute(
            "UPDATE foundation_revision SET status='retired' WHERE tenant=? AND company=? AND kind=? AND id=? AND revision=?",
            (*who.scope, args["kind"], args["id"], head["active_revision"]),
        )
        db.execute(
            "UPDATE foundation_root SET active_revision=NULL,row_version=row_version+1 WHERE tenant=? AND company=? AND kind=? AND id=?",
            (*who.scope, args["kind"], args["id"]),
        )
        return result(
            args["id"], head["row_version"] + 1, "retired", revision=head["active_revision"]
        )
    if command == "foundation.snapshot":
        return capture(core, db, who, args)
    if command == "foundation.fx.convert":
        return fx_convert(core, db, who, args)
    if command == "foundation.unit.convert":
        return unit_convert(core, db, who, args)
    if command == "foundation.tax.preview":
        return tax_preview(core, db, who, args)
    if command == "foundation.number.issue":
        return number_issue(core, db, who, args)
    if command == "foundation.file.register":
        return file_register(core, db, who, args)
    if command == "foundation.document.render":
        return document_render(core, db, who, args)
    if command == "master.revise":
        record = core._load(db, who, "master", args["id"])
        core._version(record, args["expected_version"])
        core._state(record, ["confirmed"])
        record["verification_evidence_ids"] = [
            r[0]
            for r in db.execute(
                "SELECT source_id FROM master_evidence WHERE tenant=? AND company=? AND master_id=?",
                (*who.scope, args["id"]),
            )
        ]
        db.execute(
            "INSERT INTO master_history VALUES(?,?,?,?,?,?)",
            (*who.scope, args["id"], record["row_version"], canonical(record), now()),
        )
        db.execute(
            "DELETE FROM master_evidence WHERE tenant=? AND company=? AND master_id=?",
            (*who.scope, args["id"]),
        )
        db.execute(
            "UPDATE master SET status='draft',row_version=row_version+1 WHERE tenant=? AND company=? AND id=?",
            (*who.scope, args["id"]),
        )
        return result(args["id"], record["row_version"] + 1, "draft")
    raise Rejected("SCHEMA_INVALID")


def save(core, db, who, args):
    kind, id_, data = args["kind"], args["id"], args["data"]
    head = db.execute(
        "SELECT * FROM foundation_root WHERE tenant=? AND company=? AND kind=? AND id=?",
        (*who.scope, kind, id_),
    ).fetchone()
    if head:
        core._version(head, args["expected_version"])
    elif args["expected_version"] != 0:
        raise Rejected("NOT_FOUND")
    validate(core, db, who, kind, id_, data)
    core._sources(db, who, args["evidence_ids"])
    for child in refs(data):
        active(core, db, who, child)
    next_revision = head["last_revision"] + 1 if head else 1
    version = args["expected_version"] + 1
    db.execute(
        "INSERT INTO foundation_root VALUES(?,?,?,?,?,?,NULL) ON CONFLICT(tenant,company,kind,id) DO UPDATE SET row_version=excluded.row_version,last_revision=excluded.last_revision",
        (*who.scope, kind, id_, version, next_revision),
    )
    hashed = digest(data)
    db.execute(
        "INSERT INTO foundation_revision VALUES(?,?,?,?,?,?,?,?,?,?,'draft',NULL,NULL)",
        (
            *who.scope,
            kind,
            id_,
            next_revision,
            canonical(data),
            hashed,
            canonical(args["evidence_ids"]),
            who.actor,
            now(),
        ),
    )
    return result(id_, version, "draft", revision=next_revision, business_hash=hashed)


def publish(core, db, who, args):
    kind, id_ = args["kind"], args["id"]
    head = root(db, who, kind, id_)
    core._version(head, args["expected_version"])
    ref = {"kind": kind, "id": id_, "revision": args["revision"]}
    record = revision(db, who, ref)
    if record["status"] != "draft":
        raise Rejected("INVALID_STATE")
    if record["created_by"] == who.actor:
        raise Rejected("INDEPENDENT_REVIEW_REQUIRED")
    data = json.loads(record["data_json"])
    validate(core, db, who, kind, id_, data)
    if "valid_from" in data and not stamp(data["valid_from"]) <= core.clock().astimezone(
        UTC
    ) < stamp(data["valid_until"]):
        raise Rejected("CONFIG_EXPIRED")
    core._sources(db, who, json.loads(record["evidence_json"]))
    for child in refs(data):
        active(core, db, who, child)
    if kind in ("currency", "unit"):
        old = db.execute(
            "SELECT data_json FROM foundation_revision WHERE tenant=? AND company=? AND kind=? AND id=? AND reviewed_by IS NOT NULL ORDER BY revision DESC LIMIT 1",
            (*who.scope, kind, id_),
        ).fetchone()
        invariant = (
            ["code", "minor_units", "rounding"]
            if kind == "currency"
            else ["code", "dimension", "precision"]
        )
        old_data = json.loads(old["data_json"]) if old else data
        if any(data[k] != old_data[k] for k in invariant):
            raise Rejected("IMMUTABLE_DEFINITION")
    if kind == "conversion":
        a = active(core, db, who, data["from_unit"])
        b = active(core, db, who, data["to_unit"])
        if a["dimension"] != b["dimension"]:
            raise Rejected("UNIT_SCOPE_MISMATCH")
    if kind == "code_mapping":
        for other in db.execute(
            "SELECT r.id,r.data_json FROM foundation_revision r JOIN foundation_root h ON r.tenant=h.tenant AND r.company=h.company AND r.kind=h.kind AND r.id=h.id AND r.revision=h.active_revision WHERE r.tenant=? AND r.company=? AND r.kind='code_mapping'",
            who.scope,
        ):
            old = json.loads(other["data_json"])
            if other["id"] != id_ and (
                old["party_id"],
                old["party_role"],
                old["external_code"],
            ) == (data["party_id"], data["party_role"], data["external_code"]):
                raise Rejected("BUSINESS_KEY_CONFLICT")
    if head["active_revision"]:
        db.execute(
            "UPDATE foundation_revision SET status='superseded' WHERE tenant=? AND company=? AND kind=? AND id=? AND revision=?",
            (*who.scope, kind, id_, head["active_revision"]),
        )
    db.execute(
        "UPDATE foundation_revision SET status='active',reviewed_by=?,reviewed_at=? WHERE tenant=? AND company=? AND kind=? AND id=? AND revision=?",
        (who.actor, now(), *who.scope, kind, id_, args["revision"]),
    )
    db.execute(
        "UPDATE foundation_root SET active_revision=?,row_version=row_version+1 WHERE tenant=? AND company=? AND kind=? AND id=?",
        (args["revision"], *who.scope, kind, id_),
    )
    return result(
        id_,
        head["row_version"] + 1,
        revision=args["revision"],
        business_hash=record["content_hash"],
    )


def capture(core, db, who, args):
    if db.execute(
        "SELECT 1 FROM foundation_snapshot WHERE tenant=? AND company=? AND id=?",
        (*who.scope, args["id"]),
    ).fetchone():
        raise Rejected("BUSINESS_KEY_CONFLICT")
    entries = {}

    def collect(ref):
        key = f"{ref['kind']}:{ref['id']}:{ref['revision']}"
        if key in entries:
            return
        data = active(core, db, who, ref, purpose=args["purpose"])
        entries[key] = {
            "ref": ref,
            "data": data,
            "business_hash": revision(db, who, ref)["content_hash"],
        }
        for child in refs(data):
            collect(child)

    for ref in args["refs"]:
        if ref["kind"] in SENSITIVE:
            raise Rejected("PERMISSION_DENIED")
        collect(ref)
    companies = [entry for entry in entries.values() if entry["ref"]["kind"] == "company"]
    policies = [
        entry["data"] for entry in entries.values() if entry["ref"]["kind"] == "pricing_policy"
    ]
    if len(companies) != 1 or len(policies) != 1:
        raise Rejected("DRAFT_NOT_READY", reason="One company and one pricing policy are required")
    policy = policies[0]
    for entry in entries.values():
        data = entry["data"]
        if entry["ref"]["kind"] == "tax_profile" and data["recovery_treatment"] == "unknown":
            raise Rejected("TAX_POLICY_UNCONFIRMED")
        if (
            entry["ref"]["kind"] == "fx"
            and (core.clock().astimezone(UTC) - stamp(data["observed_at"])).total_seconds()
            > policy["max_fx_age_seconds"]
        ):
            raise Rejected("FX_STALE")
    master_entries = {}
    for entry in entries.values():
        for field in ("party_id", "sku_id"):
            if field in entry["data"]:
                mid = entry["data"][field]
                master = core._load(db, who, "master", mid)
                master["verification_evidence_ids"] = [
                    r[0]
                    for r in db.execute(
                        "SELECT source_id FROM master_evidence WHERE tenant=? AND company=? AND master_id=?",
                        (*who.scope, mid),
                    )
                ]
                core._sources(db, who, master["verification_evidence_ids"])
                master_entries[mid] = master
    for entry in entries.values():
        contacts = list(entry["data"].get("contact_refs", []))
        if entry["data"].get("legacy_contact_ref"):
            contacts.append(entry["data"]["legacy_contact_ref"])
        for contact_ref in contacts:
            cid = contact_ref["id"]
            contact = core._load(db, who, "master", cid)
            contact["verification_evidence_ids"] = [
                r[0]
                for r in db.execute(
                    "SELECT source_id FROM master_evidence WHERE tenant=? AND company=? AND master_id=?",
                    (*who.scope, cid),
                )
            ]
            core._sources(db, who, contact["verification_evidence_ids"])
            master_entries[cid] = contact
    document = {
        "purpose": args["purpose"],
        "as_of": core.clock().astimezone(UTC).isoformat(),
        "entries": list(entries.values()),
        "master_entries": list(master_entries.values()),
    }
    hashed = digest(document)
    db.execute(
        "INSERT INTO foundation_snapshot VALUES(?,?,?,?,?,?)",
        (*who.scope, args["id"], canonical(document), hashed, now()),
    )
    core._claim(db, who, "snapshot", args["id"])
    return result(args["id"], status="snapshot", business_hash=hashed)


def rounded(amount, precision):
    with localcontext() as ctx:
        ctx.prec = 50
        return format(amount.quantize(Decimal(1).scaleb(-precision), rounding=ROUND_HALF_UP), "f")


def fx_convert(core, db, who, args):
    active(core, db, who, args["from_currency"])
    target = active(core, db, who, args["to_currency"])
    policy = active(core, db, who, args["policy"])
    if policy["calculation_currency"] != args["to_currency"]:
        raise Rejected("FX_SCOPE_MISMATCH")
    if args["from_currency"] == args["to_currency"]:
        if args.get("fx"):
            raise Rejected(
                "FX_SCOPE_MISMATCH", reason="Same-currency conversion requires no FX reference"
            )
        rate = Decimal(1)
    else:
        if not args.get("fx"):
            raise Rejected("DRAFT_NOT_READY", "/args/fx")
        fx = active(core, db, who, args["fx"], purpose=args["purpose"])
        if fx["from_currency"] != args["from_currency"] or fx["to_currency"] != args["to_currency"]:
            raise Rejected("FX_SCOPE_MISMATCH")
        if (core.clock().astimezone(UTC) - stamp(fx["observed_at"])).total_seconds() > policy[
            "max_fx_age_seconds"
        ]:
            raise Rejected("FX_STALE")
        rate = Decimal(fx["rate"])
    with localcontext() as ctx:
        ctx.prec = 50
        value = rounded(Decimal(args["amount"]) * rate, target["minor_units"])
        if Decimal(value) > Decimal("1000000000000"):
            raise Rejected("INVALID_KNOWN_VALUE", reason="Document amount exceeds experiment limit")
    return result(
        args["id"], status="converted", values={"amount": value, "currency": target["code"]}
    )


def unit_convert(core, db, who, args):
    if not Decimal(0) < Decimal(args["quantity"]) <= Decimal(1000000):
        raise Rejected("INVALID_KNOWN_VALUE")
    data = active(core, db, who, args["conversion"])
    if data["sku_profile"] != args["sku_profile"]:
        raise Rejected("UNIT_SCOPE_MISMATCH")
    unit = active(core, db, who, data["to_unit"])
    with localcontext() as ctx:
        ctx.prec = 50
        value = Decimal(args["quantity"]) * Decimal(data["factor"])
        text = rounded(value, unit["precision"])
        if value > Decimal(1000000) or Decimal(text) != value:
            raise Rejected("INVALID_KNOWN_VALUE", reason="Quantity conversion would lose precision")
    return result(args["id"], status="converted", values={"quantity": text, "unit": unit["code"]})


def tax_preview(core, db, who, args):
    tax = active(core, db, who, args["tax_profile"])
    currency = active(core, db, who, args["currency"])
    if tax["recovery_treatment"] == "unknown":
        raise Rejected("TAX_POLICY_UNCONFIRMED")
    with localcontext() as ctx:
        ctx.prec = 50
        value = Decimal(args["amount"])
        rate = Decimal(tax["rate"])
        precision = currency["minor_units"]
        if tax["price_basis"] == "inclusive":
            gross = Decimal(rounded(value, precision))
            net = Decimal(rounded(gross / (1 + rate), precision))
            tax_amount = gross - net
        else:
            net = Decimal(rounded(value, precision))
            tax_amount = Decimal(rounded(net * rate, precision))
            gross = net + tax_amount
    if gross > Decimal("1000000000000"):
        raise Rejected("INVALID_KNOWN_VALUE", reason="Document amount exceeds experiment limit")
    return result(
        args["id"],
        status="evaluated",
        values={
            "net_amount": rounded(net, precision),
            "tax_amount": rounded(tax_amount, precision),
            "gross_amount": rounded(gross, precision),
            "currency": currency["code"],
        },
    )


def number_issue(core, db, who, args):
    sequence = active(core, db, who, args["sequence"])
    company = active(core, db, who, sequence["company"])
    year = core.clock().astimezone(ZoneInfo(company["timezone"])).year
    if db.execute(
        "SELECT 1 FROM document_number WHERE tenant=? AND company=? AND (id=? OR (document_type=? AND business_ref=?))",
        (*who.scope, args["id"], sequence["document_type"], args["business_ref"]),
    ).fetchone():
        raise Rejected("BUSINESS_KEY_CONFLICT")
    row = db.execute(
        "SELECT last_value FROM document_counter WHERE tenant=? AND company=? AND document_type=? AND year=?",
        (*who.scope, sequence["document_type"], year),
    ).fetchone()
    count = row[0] + 1 if row else 1
    if count >= 10 ** sequence["width"]:
        raise Rejected("SEQUENCE_EXHAUSTED")
    number = f"{sequence['prefix']}{year}-{count:0{sequence['width']}d}"
    if db.execute(
        "SELECT 1 FROM document_number WHERE tenant=? AND company=? AND number=?",
        (*who.scope, number),
    ).fetchone():
        raise Rejected("BUSINESS_KEY_CONFLICT")
    db.execute(
        "INSERT INTO document_counter VALUES(?,?,?,?,?) ON CONFLICT(tenant,company,document_type,year) DO UPDATE SET last_value=excluded.last_value",
        (*who.scope, sequence["document_type"], year, count),
    )
    db.execute(
        "INSERT INTO document_number VALUES(?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            args["id"],
            sequence["document_type"],
            args["business_ref"],
            number,
            args["sequence"]["id"],
            args["sequence"]["revision"],
            now(),
        ),
    )
    core._claim(db, who, "number", args["id"])
    return result(args["id"], status="issued", values={"document_number": number})


def file_register(core, db, who, args, *, content=None, template=None, number_id=None):
    if db.execute(
        "SELECT 1 FROM business_file WHERE tenant=? AND company=? AND id=?",
        (*who.scope, args["id"]),
    ).fetchone():
        raise Rejected("BUSINESS_KEY_CONFLICT")
    if content is None:
        try:
            content = base64.b64decode(args["content_base64"], validate=True)
        except (binascii.Error, ValueError):
            raise Rejected("FILE_INVALID") from None
    if not content or len(content) > 10 * 1024 * 1024:
        raise Rejected("FILE_INVALID")
    if any(c in args["file_name"] for c in ("/", "\\", "\x00")):
        raise Rejected("FILE_INVALID")
    extension = {
        "text/plain": ".txt",
        "application/pdf": ".pdf",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    }[args["mime_type"]]
    if not args["file_name"].lower().endswith(extension):
        raise Rejected("FILE_INVALID")
    if args["mime_type"] == "text/plain":
        try:
            content.decode("utf-8")
        except UnicodeError:
            raise Rejected("FILE_INVALID") from None
    if args["mime_type"] == "application/pdf" and not content.startswith(b"%PDF-"):
        raise Rejected("FILE_INVALID")
    if args["mime_type"].endswith("sheet") and not content.startswith(b"PK\x03\x04"):
        raise Rejected("FILE_INVALID")

    if args.get("supersedes_file_id"):
        core._access(db, who, "file", args["supersedes_file_id"])
        if db.execute(
            "SELECT 1 FROM business_file WHERE tenant=? AND company=? AND supersedes_file_id=?",
            (*who.scope, args["supersedes_file_id"]),
        ).fetchone():
            raise Rejected("BUSINESS_KEY_CONFLICT")
    hashed = hashlib.sha256(content).hexdigest()
    db.execute(
        "INSERT INTO business_file VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            *who.scope,
            args["id"],
            args["file_name"],
            args["mime_type"],
            content,
            hashed,
            args.get("supersedes_file_id"),
            template["id"] if template else None,
            template["revision"] if template else None,
            number_id,
            now(),
        ),
    )
    core._claim(db, who, "file", args["id"])
    return result(
        args["id"],
        status="generated" if template else "registered",
        values={"content_sha256": hashed, "file_id": args["id"]},
    )


def document_render(core, db, who, args):
    template = active(core, db, who, args["template"])
    core._access(db, who, "number", args["number_id"])
    number = db.execute(
        "SELECT * FROM document_number WHERE tenant=? AND company=? AND id=?",
        (*who.scope, args["number_id"]),
    ).fetchone()
    if not number or number["document_type"] != template["document_type"]:
        raise Rejected("REFERENCE_INVALID")
    supplied = dict(args["values"])
    if supplied.get("document.number", number["number"]) != number["number"]:
        raise Rejected("INVALID_KNOWN_VALUE")
    supplied["document.number"] = number["number"]
    if not set(template["field_names"]).issubset(supplied):
        raise Rejected("DRAFT_NOT_READY")
    chunks = ["DRAFT / 业务草稿（未绑定已生效报价）\n"]
    length = 0
    for literal, field, _, _ in string.Formatter().parse(template["template_text"]):
        chunk = literal + (supplied[field] if field is not None else "")
        length += len(chunk.encode("utf-8"))
        if length > 10 * 1024 * 1024 - 200:
            raise Rejected("FILE_INVALID")
        chunks.append(chunk)
    text = "".join(chunks)
    file_args = {
        "id": args["id"],
        "file_name": number["number"] + ".txt",
        "mime_type": "text/plain",
    }
    return file_register(
        core,
        db,
        who,
        file_args,
        content=text.encode("utf-8"),
        template=args["template"],
        number_id=args["number_id"],
    )


def historical_access(core, db, who, record, visited=None):
    visited = set() if visited is None else visited
    key = (record["kind"], record["id"], record["revision"])
    if key in visited:
        return json.loads(record["data_json"])
    visited.add(key)
    core._sources(db, who, json.loads(record["evidence_json"]))
    data = json.loads(record["data_json"])
    for field in ("party_id", "sku_id"):
        if field in data:
            core._access(db, who, "master", data[field])
    if data.get("owner_kind") == "party":
        core._access(db, who, "master", data["owner_id"])
    for contact in data.get("contact_refs", []):
        core._access(db, who, "master", contact["id"])
    if data.get("legacy_contact_ref"):
        core._access(db, who, "master", data["legacy_contact_ref"]["id"])
    for child in refs(data):
        historical_access(core, db, who, revision(db, who, child), visited)
    return data


def get(core, db, who, kind, id_, revision_number=None):
    core._authorize(db, who, "foundation.read")
    if kind == "snapshot":
        core._access(db, who, "snapshot", id_)
        row = db.execute(
            "SELECT data_json,content_hash FROM foundation_snapshot WHERE tenant=? AND company=? AND id=?",
            (*who.scope, id_),
        ).fetchone()
        if not row:
            raise Rejected("NOT_FOUND")
        snapshot = json.loads(row["data_json"])
        for entry in snapshot["entries"]:
            historical_access(core, db, who, revision(db, who, entry["ref"]))
        for master in snapshot.get("master_entries", []):
            core._access(db, who, "master", master["id"])
            core._sources(db, who, master["verification_evidence_ids"])
        return {"id": id_, "data": snapshot, "business_hash": row["content_hash"]}
    if kind == "file":
        core._authorize(db, who, "file.read")
        core._access(db, who, "file", id_)
        row = db.execute(
            "SELECT * FROM business_file WHERE tenant=? AND company=? AND id=?", (*who.scope, id_)
        ).fetchone()
        if not row:
            raise Rejected("NOT_FOUND")
        output = dict(row)
        output["content_base64"] = base64.b64encode(output.pop("content")).decode("ascii")
        return output
    if kind == "master_history":
        core._access(db, who, "master", id_)
        row = db.execute(
            "SELECT data_json FROM master_history WHERE tenant=? AND company=? AND id=? AND row_version=?",
            (*who.scope, id_, revision_number),
        ).fetchone()
        if not row:
            raise Rejected("NOT_FOUND")
        document = json.loads(row[0])
        core._sources(db, who, document.get("verification_evidence_ids", []))
        return document
    head = root(db, who, kind, id_)
    selected = revision_number or head["active_revision"]
    if not selected:
        raise Rejected("CONFIG_NOT_ACTIVE")
    row = revision(db, who, {"kind": kind, "id": id_, "revision": selected})
    data = historical_access(core, db, who, row)
    row.pop("data_json")
    row["data"] = data
    row["evidence_ids"] = json.loads(row.pop("evidence_json"))
    row["root_version"] = head["row_version"]
    if kind == "bank_account":
        try:
            core._authorize(db, who, "foundation.sensitive.read")
        except Rejected:
            data["account_number"] = (
                "*" * (len(data["account_number"]) - 4) + data["account_number"][-4:]
            )
    return row


def replay_access(core, db, who, command, args, action_result):
    core._authorize(db, who, "foundation.read")
    kind = {
        "foundation.snapshot": "snapshot",
        "foundation.number.issue": "number",
        "foundation.file.register": "file",
        "foundation.document.render": "file",
    }.get(command)
    if kind:
        core._access(db, who, kind, args["id"])
        if kind == "snapshot":
            get(core, db, who, "snapshot", args["id"])
    for reference in refs(args):
        historical_access(core, db, who, revision(db, who, reference))
    if command in ("foundation.save", "foundation.publish", "foundation.retire"):
        core._sources(db, who, args.get("evidence_ids", []))
        historical_access(
            core,
            db,
            who,
            revision(
                db,
                who,
                {"kind": args["kind"], "id": args["id"], "revision": action_result["revision"]},
            ),
        )
