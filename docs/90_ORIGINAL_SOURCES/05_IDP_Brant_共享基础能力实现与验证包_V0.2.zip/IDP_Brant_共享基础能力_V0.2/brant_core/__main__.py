"""Local synthetic-data runner. This CLI is not an authenticated remote API."""

import argparse
import json
import sqlite3
import sys
import tempfile
from pathlib import Path

from .service import Core, Principal, Rejected


def demo(directory: Path) -> dict:
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "brant-t01.sqlite"
    if path.exists():
        raise ValueError("Demo requires a fresh directory; existing data will not be overwritten")
    core = Core(path)
    who = Principal("tenant.demo", "company.demo", "human.demo")
    core.provision(who, ["*"])
    results: list[dict] = []

    def run(command, args):
        result = core.execute(
            who,
            {
                "contract": "brant.trade-core/0.1.0",
                "command": command,
                "idempotency_key": f"demo.{len(results) + 1}",
                "args": args,
            },
        )
        if not result["ok"]:
            raise RuntimeError(result["code"])
        results.append({"command": command, "result": result})

    run(
        "source.register",
        {
            "id": "source.1",
            "source_kind": "manual_text",
            "content_text": "合成样例：ST01四个SKU，24、36、12、48件，合计120 PCS。",
        },
    )
    for id_, kind, fields in [
        ("customer.1", "customer", {}),
        ("contact.1", "contact", {"parent_customer_id": "customer.1"}),
        *[
            (f"ST01.{color}.{size}", "sku", {"base_uom": "PCS"})
            for color, size in [("red", "S"), ("red", "M"), ("blue", "S"), ("blue", "M")]
        ],
    ]:
        run(
            "master.upsert_draft",
            {"id": id_, "kind": kind, "name": id_, "expected_version": 0, **fields},
        )
        run("master.confirm", {"id": id_, "expected_version": 1, "evidence_ids": ["source.1"]})
    run(
        "rfq.save_draft",
        {
            "id": "rfq.1",
            "expected_version": 0,
            "customer_id": "customer.1",
            "contact_id": "contact.1",
            "source_ids": ["source.1"],
            "lines": [
                {
                    "line_id": f"L{i}",
                    "sku_id": sku,
                    "quantity": str(q),
                    "uom": "PCS",
                    "source_id": "source.1",
                    "locator": f"第1段，第{i}项",
                }
                for i, (sku, q) in enumerate(
                    [
                        ("ST01.red.S", 24),
                        ("ST01.red.M", 36),
                        ("ST01.blue.S", 12),
                        ("ST01.blue.M", 48),
                    ],
                    1,
                )
            ],
        },
    )
    run("rfq.confirm_scope", {"id": "rfq.1", "expected_version": 1, "evidence_ids": ["source.1"]})
    saved = core.get(who, "rfq", "rfq.1")
    report = {
        "synthetic": True,
        "slice": "BC-T01",
        "status": saved["status"],
        "quantity_PCS": "120",
        "database": str(path),
        "commands": results,
        "rfq": saved,
        "audit": core.audit(who),
        "model_calls": 0,
    }
    (directory / "demo-result.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="IDP Brant BC-T01 local runner")
    sub = parser.add_subparsers(dest="mode", required=True)
    d = sub.add_parser("demo", help="Run synthetic source → master → ready RFQ chain")
    d.add_argument("--directory", type=Path)
    e = sub.add_parser(
        "execute-local", help="Trusted local harness; actor is selected locally, not authenticated"
    )
    e.add_argument("--db", type=Path, required=True)
    e.add_argument("--actor", required=True)
    e.add_argument("--tenant", required=True)
    e.add_argument("--company", required=True)
    f = sub.add_parser("foundation-demo", help="Run synthetic versioned foundation scenario")
    f.add_argument("--directory", type=Path)
    args = parser.parse_args()
    try:
        if args.mode == "foundation-demo":
            from .foundation_demo import demo as run_foundation_demo

            directory = args.directory or Path(tempfile.mkdtemp(prefix="brant-foundation-demo-"))
            output = run_foundation_demo(directory)
            print(
                json.dumps(
                    {
                        "synthetic": True,
                        "configurations": output["configurations"],
                        "configuration_kinds": output["configuration_kinds"],
                        "fx": output["fx"],
                        "unit": output["unit"],
                        "tax": output["tax"],
                        "result_file": str(directory / "foundation-demo-result.json"),
                    },
                    ensure_ascii=False,
                )
            )
            return 0
        if args.mode == "demo":
            directory = args.directory or Path(tempfile.mkdtemp(prefix="brant-t01-demo-"))
            report = demo(directory)
            print(
                json.dumps(
                    {
                        "status": report["status"],
                        "quantity_PCS": report["quantity_PCS"],
                        "result_file": str(directory / "demo-result.json"),
                        "synthetic": True,
                    },
                    ensure_ascii=False,
                )
            )
            return 0
        raw = sys.stdin.buffer.read(15 * 1024 * 1024 + 1)
        if len(raw) > 15 * 1024 * 1024 or (len(raw) > 1024 * 1024 and not raw.strip()):
            print(json.dumps({"transport_error": "REQUEST_TOO_LARGE"}))
            return 2

        # Duplicate JSON keys cannot be silently overwritten at a trusted ingress.
        def unique_keys(pairs):
            value = {}
            for key, item in pairs:
                if key in value:
                    raise ValueError("Duplicate JSON key")
                value[key] = item
            return value

        request = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_keys)
        if len(raw) > 1024 * 1024 and (
            not isinstance(request, dict) or request.get("contract") != "brant.foundation/0.1.0"
        ):
            print(json.dumps({"transport_error": "REQUEST_TOO_LARGE"}))
            return 2
        result = Core(args.db).execute(Principal(args.tenant, args.company, args.actor), request)
        print(json.dumps(result, ensure_ascii=False))
        return 0 if result["ok"] else 1
    except (ValueError, UnicodeError, RecursionError):
        print(json.dumps({"transport_error": "INVALID_INPUT"}))
        return 2
    except (sqlite3.Error, OSError, RuntimeError, Rejected):
        # Storage/adapter failure is not a retryable business rejection or success.
        print(json.dumps({"transport_error": "LOCAL_EXECUTION_UNAVAILABLE"}))
        return 2


if __name__ == "__main__":
    sys.exit(main())
