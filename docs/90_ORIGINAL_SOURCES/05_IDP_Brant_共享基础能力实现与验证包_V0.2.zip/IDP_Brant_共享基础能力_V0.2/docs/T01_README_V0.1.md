# IDP Brant — BC-T01 业务核心实现 V0.1

本包承接《业务核心详细设计 V0.2》第18章，提供可运行的 Python / SQLite 本地应用服务。
实现范围为文本来源、最小交易主数据、询价缺项草稿与人工核实，不等于 Brant 产品 V1.0 已完成。
产品范围基线 V1.0、旧 Q01 包和候选契约的版本含义相互独立。

## 快速运行

安装 Python 3.12 和 uv。在本目录执行：

```bash
uv sync --frozen
uv run --frozen python -m unittest discover -s tests -v
uv run --frozen mypy --check-untyped-defs brant_core
uv run --frozen ruff check brant_core tests
uv run --frozen python -m brant_core demo
```

`demo` 自动创建临时目录，输出结果文件位置；也可指定一个新的目录：

```bash
uv run --frozen python -m brant_core demo --directory ./demo-output
```

它以合成数据运行15个命令：登记原文、核实客户及联系人、核实四个SKU、保存四行120 PCS询价并确认为ready。
结果和审计保存在 `demo-result.json`，业务数据在该目录的 SQLite 文件中。已有数据库不会被演示命令覆盖。
所有样例均为合成资料，无模型调用、真实文件解析、发信或资金动作。

## 应用接口与可信边界

```python
from brant_core import Core, Principal

core = Core("local.sqlite")
# provision仅用于可信本地初始化／撤权；不得作为用户可调用接口。
operator = Principal("tenant.demo", "company.demo", "human.demo")
core.provision(operator, ["rfq.save_draft", "read", "audit.read"])
result = core.execute(operator, {
    "contract": "brant.trade-core/0.1.0",
    "command": "rfq.save_draft",
    "idempotency_key": "request.1",
    "args": {"id": "rfq.1", "expected_version": 0}
})
print(result)
print(core.get(operator, "rfq", "rfq.1"))
```

`Principal`只能由可信认证适配层构造；本包尚未接入真实企业身份提供方。
`provision`中的`actor_kind`由可信适配层设置，AI身份即使有`*`授权也不能执行两个人工核实命令。
本包使用本公司范围授权，没有实现个人／团队细粒度文件ACL；接真实企业前须补齐岗位、数据范围及访问策略。
`execute-local`是持有本地数据库的开发者执行工具，命令行可选择本地身份，不能直接发布到公网作为认证接口。

```bash
uv run --frozen python -m brant_core execute-local --db ./local.sqlite --tenant tenant.demo --company company.demo --actor human.demo < request.json
```

未授权身份默认拒绝；业务拒绝返回封闭错误结构和退出码1；传输入口／存储故障返回独立transport_error和退出码2。
入口先限制1 MiB、拒绝重复JSON键，再进入schema与命令守卫。应用服务不会把存储故障伪装成业务成功。

## 已实现命令

| 命令 | 结果 |
|---|---|
| source.register | 内容／来源／导入记录分离，返回来源ID |
| master.upsert_draft | customer、contact、supplier、sku最小资料草稿 |
| master.confirm | 人工核实，客户关系与PCS单位检查 |
| master.deactivate | 停用已核实资料，历史快照保留 |
| rfq.save_draft | 允许缺项；整稿替换、版本守卫、来源用途关联 |
| rfq.confirm_scope | 人工核实所有来源及完整需求，进入ready |
| rfq.cancel | draft／ready取消，保留行及来源 |
| rfq.close | ready关闭，保留理由和审计 |

保存是整稿替换：省略字段表示未知／清除，不是PATCH。已提供但非法的数量、引用、重复行必须拒绝。
已核实主数据不允许原地编辑／改变类型；本切片未实现其新版本编辑流程。
询价ready后的实质变更须走后续询价修订设计，当前接口不会解锁ready供直接覆盖。

## 验证与状态

测试通过只覆盖本包公共应用接口、SQLite适配和本地CLI，不自动将完整 BC-AT01／24 或产品P0登记通过。
详见 `docs/IMPLEMENTATION.md`、`evidence/verification.json` 与 `验收报告.html`。
T02供应报价与成本、T03报价审核与根控制、T04确认及订单、T05页面、T06运行接管、T07真实AI输入继续按原顺序实施。
