import json
from pathlib import Path

P = Path(__file__).resolve().parents[1] / "brant_core" / "contracts"
ID = {
    "type": "string",
    "minLength": 1,
    "maxLength": 64,
    "pattern": "^[A-Za-z0-9][A-Za-z0-9._:-]*$",
    "not": {"pattern": "[^A-Za-z0-9._:-]"},
}
TEXT = {"type": "string", "minLength": 1, "maxLength": 500, "pattern": "\\S"}
DEC = {
    "type": "string",
    "maxLength": 32,
    "pattern": "^(?:0|[1-9][0-9]{0,11})(?:\\.[0-9]{1,12})?$",
    "not": {"pattern": "[^0-9.]"},
}
STAMP = {"type": "string", "format": "date-time", "maxLength": 40}
DATE = {"type": "string", "format": "date"}
BOOL = {"type": "boolean"}
VER = {"type": "integer", "minimum": 0, "maximum": 2147483647}


def enum(*xs):
    return {"enum": list(xs)}


def arr(item, lo=0, hi=200):
    return {"type": "array", "items": item, "minItems": lo, "maxItems": hi, "uniqueItems": True}


def obj(props, required=None):
    return {
        "type": "object",
        "properties": props,
        "required": list(props) if required is None else required,
        "additionalProperties": False,
    }


def ref(kind):
    return obj({"kind": {"const": kind}, "id": ID, "revision": {"type": "integer", "minimum": 1}})


KINDS = [
    "currency",
    "company",
    "unit",
    "conversion",
    "fx",
    "calendar",
    "trade_terms",
    "payment_terms",
    "tax_profile",
    "fee_type",
    "pricing_policy",
    "party_profile",
    "contact_profile",
    "sku_profile",
    "code_mapping",
    "bank_account",
    "sequence",
    "document_template",
]
REF = {"oneOf": [ref(k) for k in KINDS]}
cfg = {}
cfg["currency"] = obj(
    {
        "code": {"type": "string", "pattern": "^[A-Z]{3}$", "minLength": 3, "maxLength": 3},
        "name": TEXT,
        "minor_units": {"type": "integer", "minimum": 0, "maximum": 4},
        "rounding": {"const": "HALF_UP"},
    }
)
cfg["company"] = obj(
    {
        "legal_name": TEXT,
        "registration_no": TEXT,
        "country": {"type": "string", "pattern": "^[A-Z]{2}$", "maxLength": 2},
        "address": TEXT,
        "base_currency": ref("currency"),
        "timezone": TEXT,
        "policy_scope": TEXT,
    }
)
cfg["unit"] = obj(
    {
        "code": ID,
        "name": TEXT,
        "dimension": enum("count", "mass", "length", "volume"),
        "precision": {"type": "integer", "minimum": 0, "maximum": 6},
    }
)
cfg["calendar"] = obj(
    {
        "timezone": TEXT,
        "working_weekdays": arr({"type": "integer", "minimum": 1, "maximum": 7}, 1, 7),
        "holidays": arr(DATE, 0, 3660),
    }
)
cfg["sku_profile"] = obj(
    {
        "sku_id": ID,
        "item_name": TEXT,
        "specification_version": ID,
        "base_unit": ref("unit"),
        "description": TEXT,
    }
)
cfg["conversion"] = obj(
    {
        "sku_profile": ref("sku_profile"),
        "from_unit": ref("unit"),
        "to_unit": ref("unit"),
        "factor": DEC,
        "basis": TEXT,
        "valid_from": STAMP,
        "valid_until": STAMP,
    }
)
cfg["fx"] = obj(
    {
        "from_currency": ref("currency"),
        "to_currency": ref("currency"),
        "rate": DEC,
        "purpose": enum("quotation", "cost_estimate"),
        "source_name": TEXT,
        "observed_at": STAMP,
        "valid_from": STAMP,
        "valid_until": STAMP,
    }
)
cfg["trade_terms"] = obj(
    {
        "incoterm": enum(
            "EXW", "FCA", "CPT", "CIP", "DAP", "DPU", "DDP", "FAS", "FOB", "CFR", "CIF"
        ),
        "edition": {"const": "2020"},
        "named_place": TEXT,
        "responsibility_note": TEXT,
        "delivery": {
            "oneOf": [
                obj({"kind": {"const": "fixed_date"}, "date": DATE}),
                obj(
                    {
                        "kind": {"const": "lead_time"},
                        "anchor_event": enum(
                            "order_confirmed", "deposit_received", "technical_approved"
                        ),
                        "days": {"type": "integer", "minimum": 0, "maximum": 3650},
                        "day_basis": enum("calendar", "working"),
                        "calendar": ref("calendar"),
                    }
                ),
            ]
        },
    }
)
cfg["payment_terms"] = obj(
    {
        "name": TEXT,
        "stages": arr(
            obj(
                {
                    "stage_id": ID,
                    "percent": DEC,
                    "trigger": enum(
                        "order_confirmed", "before_shipment", "after_shipment", "after_invoice"
                    ),
                    "days": {"type": "integer", "minimum": 0, "maximum": 3650},
                    "day_basis": enum("calendar", "working"),
                    "calendar": ref("calendar"),
                }
            ),
            1,
            20,
        ),
    }
)
cfg["tax_profile"] = obj(
    {
        "name": TEXT,
        "rate": DEC,
        "price_basis": enum("inclusive", "exclusive", "not_applicable"),
        "recovery_treatment": enum("unknown", "recoverable", "nonrecoverable"),
        "policy_basis": TEXT,
        "valid_from": STAMP,
        "valid_until": STAMP,
    }
)
cfg["fee_type"] = obj(
    {
        "name": TEXT,
        "category": enum(
            "goods",
            "freight",
            "insurance",
            "packaging",
            "inspection",
            "commission",
            "bank",
            "other",
        ),
        "side": enum("purchase_cost", "sales_charge"),
        "inclusion": enum("separate", "included_in_line"),
        "allocation_basis": enum("document", "quantity", "value"),
        "policy_basis": TEXT,
    }
)
cfg["pricing_policy"] = obj(
    {
        "name": TEXT,
        "calculation_currency": ref("currency"),
        "minimum_margin": DEC,
        "quote_valid_days": {"type": "integer", "minimum": 1, "maximum": 365},
        "max_fx_age_seconds": {"type": "integer", "minimum": 1, "maximum": 31536000},
        "independent_review": {"const": True},
        "tax_profile": ref("tax_profile"),
    }
)
cfg["party_profile"] = obj(
    {
        "party_id": ID,
        "legal_name": TEXT,
        "country": {"type": "string", "pattern": "^[A-Z]{2}$", "maxLength": 2},
        "addresses": arr(
            obj(
                {
                    "address_id": ID,
                    "role": enum(
                        "buyer", "seller", "payer", "payee", "consignee", "shipper", "billing"
                    ),
                    "address": TEXT,
                }
            ),
            1,
            20,
        ),
        "contact_ids": arr(ID, 1, 50),
        "trade_terms": ref("trade_terms"),
        "payment_terms": ref("payment_terms"),
    }
)
cfg["contact_profile"] = obj(
    {
        "party_id": ID,
        "party_role": enum("customer", "supplier"),
        "name": TEXT,
        "email": {"type": "string", "format": "email", "maxLength": 254},
        "phone": TEXT,
        "position": TEXT,
        "legacy_contact_id": ID,
    },
    ["party_id", "party_role", "name"],
)
cfg["contact_profile"]["anyOf"] = [{"required": ["email"]}, {"required": ["phone"]}]
cfg["party_profile"]["properties"]["contacts"] = arr(ref("contact_profile"), 1, 50)
cfg["party_profile"]["required"].remove("contact_ids")
cfg["party_profile"]["anyOf"] = [{"required": ["contact_ids"]}, {"required": ["contacts"]}]
cfg["code_mapping"] = obj(
    {
        "party_id": ID,
        "party_role": enum("customer", "supplier"),
        "external_code": TEXT,
        "sku_profile": ref("sku_profile"),
    }
)
cfg["bank_account"] = obj(
    {
        "owner_kind": enum("company", "party"),
        "owner_id": ID,
        "bank_name": TEXT,
        "account_number": {"type": "string", "minLength": 4, "maxLength": 64},
        "currency": ref("currency"),
        "purpose": enum("receipt", "payment", "both"),
    }
)
cfg["sequence"] = obj(
    {
        "document_type": enum("rfq", "quote", "order", "purchase_order", "invoice"),
        "prefix": {
            "type": "string",
            "minLength": 1,
            "maxLength": 16,
            "pattern": "^[A-Z0-9-]+$",
            "not": {"pattern": "[^A-Z0-9-]"},
        },
        "width": {"type": "integer", "minimum": 4, "maximum": 12},
        "company": ref("company"),
        "reset": {"const": "annual"},
    }
)
FIELDS = [
    "company.name",
    "customer.name",
    "document.number",
    "document.date",
    "lines.summary",
    "quote.total",
    "quote.currency",
]
VALUES = obj({k: {"type": "string", "maxLength": 10000} for k in FIELDS}, [])
cfg["document_template"] = obj(
    {
        "name": TEXT,
        "document_type": enum("rfq", "quote", "order"),
        "template_text": {"type": "string", "minLength": 1, "maxLength": 50000},
        "field_names": arr(enum(*FIELDS), 1, len(FIELDS)),
    }
)
for k in ["party_profile", "contact_profile", "code_mapping"]:
    cfg[k]["properties"]["party_row_version"] = {"type": "integer", "minimum": 1}
    cfg[k]["required"].append("party_row_version")
cfg["sku_profile"]["properties"]["sku_row_version"] = {"type": "integer", "minimum": 1}
cfg["sku_profile"]["required"].append("sku_row_version")
CONTACT_REF = obj({"id": ID, "row_version": {"type": "integer", "minimum": 1}})
cfg["party_profile"]["properties"].pop("contact_ids")
cfg["party_profile"]["properties"]["contact_refs"] = arr(CONTACT_REF, 1, 50)
cfg["party_profile"]["anyOf"] = [{"required": ["contact_refs"]}, {"required": ["contacts"]}]
cfg["contact_profile"]["properties"].pop("legacy_contact_id")
cfg["contact_profile"]["properties"]["legacy_contact_ref"] = CONTACT_REF
cfg["bank_account"]["properties"]["owner_row_version"] = {"type": "integer", "minimum": 1}
cfg["bank_account"]["allOf"] = [
    {
        "if": {"properties": {"owner_kind": {"const": "party"}}},
        "then": {"required": ["owner_row_version"]},
    }
]
commands = []
base = {"contract": {"const": "brant.foundation/0.1.0"}, "idempotency_key": ID}


def command(name, args):
    return obj({**base, "command": {"const": name}, "args": args})


for k, data in cfg.items():
    commands.append(
        command(
            "foundation.save",
            obj(
                {
                    "id": ID,
                    "expected_version": VER,
                    "kind": {"const": k},
                    "data": data,
                    "evidence_ids": arr(ID, 1, 200),
                }
            ),
        )
    )
commands.append(
    command(
        "foundation.publish",
        obj(
            {
                "id": ID,
                "kind": enum(*KINDS),
                "revision": {"type": "integer", "minimum": 1},
                "expected_version": VER,
                "reason": TEXT,
            }
        ),
    )
)
commands.append(
    command(
        "foundation.retire",
        obj({"id": ID, "kind": enum(*KINDS), "expected_version": VER, "reason": TEXT}),
    )
)
commands.append(
    command(
        "foundation.snapshot",
        obj({"id": ID, "refs": arr(REF, 1, 100), "purpose": enum("quotation", "cost_estimate")}),
    )
)
commands.append(
    command(
        "foundation.fx.convert",
        obj(
            {
                "id": ID,
                "amount": DEC,
                "from_currency": ref("currency"),
                "to_currency": ref("currency"),
                "fx": ref("fx"),
                "policy": ref("pricing_policy"),
                "purpose": enum("quotation", "cost_estimate"),
            }
        ),
    )
)
commands.append(
    command(
        "foundation.unit.convert",
        obj(
            {
                "id": ID,
                "quantity": DEC,
                "conversion": ref("conversion"),
                "sku_profile": ref("sku_profile"),
            }
        ),
    )
)
commands.append(
    command(
        "foundation.tax.preview",
        obj(
            {
                "id": ID,
                "amount": DEC,
                "currency": ref("currency"),
                "tax_profile": ref("tax_profile"),
            }
        ),
    )
)
commands.append(
    command(
        "foundation.number.issue", obj({"id": ID, "sequence": ref("sequence"), "business_ref": ID})
    )
)
commands.append(
    command(
        "foundation.file.register",
        obj(
            {
                "id": ID,
                "file_name": TEXT,
                "mime_type": enum(
                    "text/plain",
                    "application/pdf",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                ),
                "content_base64": {"type": "string", "minLength": 1, "maxLength": 13981016},
                "supersedes_file_id": ID,
            },
            ["id", "file_name", "mime_type", "content_base64"],
        ),
    )
)
commands.append(
    command(
        "foundation.document.render",
        obj({"id": ID, "template": ref("document_template"), "number_id": ID, "values": VALUES}),
    )
)
commands.append(command("master.revise", obj({"id": ID, "expected_version": VER, "reason": TEXT})))
for entry in commands:
    if entry["properties"]["command"]["const"] == "foundation.fx.convert":
        entry["properties"]["args"]["required"].remove("fx")
request = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "urn:brant:foundation:0.1.0",
    "oneOf": commands,
}
OUT_DEC = {**DEC, "pattern": "^(?:0|[1-9][0-9]{0,15})(?:\\.[0-9]{1,12})?$"}
values = obj(
    {
        "amount": OUT_DEC,
        "quantity": DEC,
        "currency": ID,
        "unit": ID,
        "net_amount": OUT_DEC,
        "tax_amount": OUT_DEC,
        "gross_amount": OUT_DEC,
        "document_number": TEXT,
        "content_sha256": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
        "file_id": ID,
    },
    [],
)
errors = [
    "SCHEMA_INVALID",
    "UNSUPPORTED_CONTRACT",
    "PERMISSION_DENIED",
    "NOT_FOUND",
    "VERSION_CONFLICT",
    "IDEMPOTENCY_PAYLOAD_CONFLICT",
    "REFERENCE_INVALID",
    "INVALID_KNOWN_VALUE",
    "INVALID_STATE",
    "DRAFT_NOT_READY",
    "CONFIG_NOT_ACTIVE",
    "CONFIG_EXPIRED",
    "INDEPENDENT_REVIEW_REQUIRED",
    "FX_SCOPE_MISMATCH",
    "FX_STALE",
    "UNIT_SCOPE_MISMATCH",
    "TAX_POLICY_UNCONFIRMED",
    "PAYMENT_TOTAL_MISMATCH",
    "BUSINESS_KEY_CONFLICT",
    "TEMPLATE_INVALID",
    "FILE_INVALID",
    "IMMUTABLE_DEFINITION",
    "SEQUENCE_EXHAUSTED",
]
response = {
    "$schema": request["$schema"],
    "oneOf": [
        obj(
            {
                "ok": {"const": True},
                "action_id": ID,
                "object_id": ID,
                "row_version": {"type": "integer", "minimum": 1},
                "status": enum(
                    "draft",
                    "active",
                    "retired",
                    "snapshot",
                    "converted",
                    "evaluated",
                    "issued",
                    "registered",
                    "generated",
                ),
                "replayed": BOOL,
                "revision": {"type": "integer", "minimum": 1},
                "business_hash": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
                "values": values,
            },
            ["ok", "action_id", "object_id", "row_version", "status", "replayed"],
        ),
        obj(
            {
                "ok": {"const": False},
                "code": enum(*errors),
                "field_errors": arr(obj({"path": TEXT, "reason": TEXT}), 1, 200),
                "correlation_id": ID,
                "retryable": {"const": False},
            }
        ),
    ],
}
for n, data in [
    ("foundation.commands.schema.json", request),
    ("foundation.response.schema.json", response),
]:
    P.joinpath(n).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
