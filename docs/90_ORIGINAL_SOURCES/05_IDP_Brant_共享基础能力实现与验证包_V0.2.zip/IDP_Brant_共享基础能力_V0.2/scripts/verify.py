"""Reproduce the release checks and write evidence without changing business data."""

import importlib.metadata
import io
import json
import os
import platform
import subprocess
import sys
import unittest
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    os.chdir(ROOT)
    sys.path.insert(0, str(ROOT))
    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=True)
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    (evidence / "unittest.txt").write_text(log.getvalue())
    checks = []
    for name, command in [
        ("mypy", [sys.executable, "-m", "mypy", "--check-untyped-defs", "brant_core"]),
        ("ruff", [sys.executable, "-m", "ruff", "check", "brant_core", "tests", "scripts"]),
    ]:
        process = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
        output = process.stdout + process.stderr
        (evidence / f"{name}.txt").write_text(output)
        checks.append({"name": name, "exit_code": process.returncode, "output": output})
    revision = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True, check=False
    )
    report = {
        "slice": "BC-T01 + shared foundation",
        "implementation_version": "0.2.0",
        "executed_at_utc": datetime.now(UTC).isoformat(),
        "python": platform.python_version(),
        "source_commit": revision.stdout.strip() if revision.returncode == 0 else None,
        "packages": {
            name: importlib.metadata.version(name) for name in ["jsonschema", "mypy", "ruff"]
        },
        "tests": {
            "run": result.testsRun,
            "failed": len(result.failures),
            "errors": len(result.errors),
            "skipped": len(result.skipped),
            "successful": result.wasSuccessful(),
        },
        "checks": checks,
        "model_calls": 0,
        "external_business_actions": 0,
        "fixture_classification": "synthetic",
        "product_p0_complete": False,
        "legacy_q01_66_rerun": False,
    }
    (evidence / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if result.wasSuccessful() and all(c["exit_code"] == 0 for c in checks) else 1


if __name__ == "__main__":
    sys.exit(main())
