import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from brant_core import Core, Principal


class CliTests(unittest.TestCase):
    def call(self, *args, data=None):
        return subprocess.run(
            [sys.executable, "-m", "brant_core", *args],
            input=data,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_demo_reaches_ready_and_wont_overwrite_existing_database(self):
        with tempfile.TemporaryDirectory() as temp:
            result = self.call("demo", "--directory", temp)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)["status"], "ready")
            saved = json.loads(Path(temp, "demo-result.json").read_text())
            self.assertEqual(
                [line["quantity"] for line in saved["rfq"]["lines"]], ["24", "36", "12", "48"]
            )
            self.assertEqual(saved["model_calls"], 0)
            second = self.call("demo", "--directory", temp)
            self.assertEqual(second.returncode, 2)
            self.assertEqual(
                json.loads(Path(temp, "demo-result.json").read_text())["commands"],
                saved["commands"],
            )

    def test_local_execute_rejects_duplicate_keys_and_size_before_parsing(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp, "local.sqlite")
            core = Core(path)
            core.provision(Principal("t", "c", "human"), ["*"])
            args = [
                "execute-local",
                "--db",
                str(path),
                "--tenant",
                "t",
                "--company",
                "c",
                "--actor",
                "human",
            ]
            duplicate = self.call(*args, data='{"command":"x","command":"y"}')
            self.assertEqual(json.loads(duplicate.stdout)["transport_error"], "INVALID_INPUT")
            huge = self.call(*args, data=" " * (1024 * 1024 + 1))
            self.assertEqual(json.loads(huge.stdout)["transport_error"], "REQUEST_TOO_LARGE")
            request = {
                "contract": "brant.trade-core/0.1.0",
                "command": "rfq.save_draft",
                "idempotency_key": "cli.1",
                "args": {"id": "r", "expected_version": 0},
            }
            success = self.call(*args, data=json.dumps(request))
            self.assertEqual(success.returncode, 0)
            self.assertEqual(json.loads(success.stdout)["status"], "draft")

    def test_foundation_demo_has_explicit_synthetic_truth_values(self):
        with tempfile.TemporaryDirectory() as temp:
            result = self.call("foundation-demo", "--directory", temp)
            self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
            saved = json.loads(Path(temp, "foundation-demo-result.json").read_text())
            self.assertEqual((saved["configuration_kinds"], saved["configurations"]), (18, 22))
            self.assertEqual(saved["fx"], {"amount": "854.81", "currency": "CNY"})
            self.assertEqual(saved["tax"]["gross_amount"], "113.00")
            self.assertEqual(saved["unit"]["quantity"], "24")
            self.assertEqual(saved["model_calls"], 0)
