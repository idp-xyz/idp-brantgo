import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from brant_core import Core, Principal


class StorageTests(unittest.TestCase):
    def test_non_t01_database_is_not_modified(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp, "existing.sqlite")
            with sqlite3.connect(path) as db:
                db.execute("CREATE TABLE external_data(value TEXT)")
                original_journal = db.execute("PRAGMA journal_mode").fetchone()[0]
                db.execute("INSERT INTO external_data VALUES('keep')")
            with self.assertRaises(RuntimeError):
                Core(path)
            with sqlite3.connect(path) as db:
                self.assertEqual(
                    db.execute("SELECT value FROM external_data").fetchone()[0], "keep"
                )
                self.assertEqual(db.execute("PRAGMA journal_mode").fetchone()[0], original_journal)
                self.assertIsNone(
                    db.execute("SELECT name FROM sqlite_master WHERE name='scope'").fetchone()
                )

    def test_parallel_startup_uses_one_atomic_schema(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp, "same.sqlite")
            with ThreadPoolExecutor(max_workers=2) as pool:
                cores = list(pool.map(lambda _: Core(path), [1, 2]))
            who = Principal("t", "c", "human")
            cores[0].provision(who, ["*"])
            result = cores[1].execute(
                who,
                {
                    "contract": "brant.trade-core/0.1.0",
                    "command": "rfq.save_draft",
                    "idempotency_key": "k",
                    "args": {"id": "r", "expected_version": 0},
                },
            )
            self.assertTrue(result["ok"])
            self.assertEqual(cores[0].get(who, "rfq", "r")["row_version"], 1)
