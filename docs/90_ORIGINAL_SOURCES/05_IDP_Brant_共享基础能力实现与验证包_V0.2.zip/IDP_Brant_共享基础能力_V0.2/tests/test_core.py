import tempfile
import unittest
from pathlib import Path

from brant_core import Core, Principal


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "business.sqlite"
        self.core = Core(self.path)
        self.who = Principal("tenant.A", "company.A", "human.1")
        self.core.provision(self.who, ["*"])
        self.serial = 0

    def tearDown(self):
        self.tmp.cleanup()

    def command(self, command, args, who=None, key=None):
        self.serial += 1
        return self.core.execute(
            who or self.who,
            {
                "contract": "brant.trade-core/0.1.0",
                "command": command,
                "idempotency_key": key or f"k{self.serial}",
                "args": args,
            },
        )

    def test_incomplete_rfq_can_be_saved_without_invented_facts(self):
        result = self.command(
            "rfq.save_draft",
            {
                "id": "rfq.1",
                "expected_version": 0,
                "lines": [{"line_id": "L1", "requested_item": "待核实商品"}],
            },
        )
        self.assertTrue(result["ok"], result)
        self.assertEqual((result["status"], result["row_version"]), ("draft", 1))
        saved = self.core.get(self.who, "rfq", "rfq.1")
        self.assertIsNone(saved["customer_id"])
        self.assertIsNone(saved["lines"][0]["quantity"])
        refused = self.command(
            "rfq.confirm_scope",
            {"id": "rfq.1", "expected_version": 1, "evidence_ids": ["source.unknown"]},
        )
        self.assertEqual(refused["code"], "REFERENCE_INVALID")
        self.assertEqual(self.core.get(self.who, "rfq", "rfq.1")["status"], "draft")

    def source(self, object_id="src.1", **fields):
        args = {
            "id": object_id,
            "source_kind": "manual_text",
            "content_text": "合成询价120件",
        }
        args.update(fields)
        result = self.command("source.register", args)
        self.assertTrue(result["ok"], result)
        return result["object_id"]

    def master(self, object_id, kind, confirm=True, **fields):
        args = {"id": object_id, "kind": kind, "name": object_id, "expected_version": 0}
        args.update(fields)
        saved = self.command("master.upsert_draft", args)
        self.assertTrue(saved["ok"], saved)
        if confirm:
            verified = self.command(
                "master.confirm",
                {"id": object_id, "expected_version": 1, "evidence_ids": ["src.1"]},
            )
            self.assertTrue(verified["ok"], verified)
        return object_id

    def ready_args(self):
        self.source()
        self.master("customer.1", "customer")
        self.master("contact.1", "contact", parent_customer_id="customer.1")
        self.master("sku.1", "sku", base_uom="PCS")
        return {
            "id": "rfq.1",
            "expected_version": 0,
            "customer_id": "customer.1",
            "contact_id": "contact.1",
            "source_ids": ["src.1"],
            "unresolved_fields": [],
            "lines": [
                {
                    "line_id": "L1",
                    "sku_id": "sku.1",
                    "quantity": "120",
                    "uom": "PCS",
                    "source_id": "src.1",
                    "locator": "第1段",
                }
            ],
        }

    def test_complete_rfq_becomes_ready_and_closes_with_reason(self):
        args = self.ready_args()
        self.assertTrue(self.command("rfq.save_draft", args)["ok"])
        result = self.command(
            "rfq.confirm_scope",
            {"id": "rfq.1", "expected_version": 1, "evidence_ids": ["src.1"]},
        )
        self.assertEqual((result["status"], result["row_version"]), ("ready", 2))
        closed = self.command(
            "rfq.close",
            {"id": "rfq.1", "expected_version": 2, "reason": "客户不再推进"},
        )
        self.assertEqual((closed["status"], closed["row_version"]), ("closed", 3))
        self.assertEqual(self.core.get(self.who, "rfq", "rfq.1")["lines"][0]["quantity"], "120")
        self.assertEqual(
            [e for e in self.core.audit(self.who) if e["command"] == "rfq.close"][-1]["reason"],
            "客户不再推进",
        )

    def test_null_extra_scope_and_float_are_schema_invalid(self):
        for extra in [
            {"customer_id": None},
            {"status": "ready"},
            {"tenant_id": "other"},
            {"lines": [{"line_id": "L1", "quantity": 120.0}]},
        ]:
            with self.subTest(extra=extra):
                result = self.command("rfq.save_draft", {"id": "r", "expected_version": 0, **extra})
                self.assertEqual(result["code"], "SCHEMA_INVALID")

    def test_duplicate_line_and_zero_quantity_have_exact_codes(self):
        for lines, code in [
            ([{"line_id": "L1"}, {"line_id": "L1"}], "DUPLICATE_LINE_ID"),
            ([{"line_id": "L1", "quantity": "0.000"}], "INVALID_KNOWN_VALUE"),
        ]:
            self.assertEqual(
                self.command("rfq.save_draft", {"id": "r", "expected_version": 0, "lines": lines})[
                    "code"
                ],
                code,
            )

    def test_omission_replaces_draft_and_old_version_does_not_overwrite(self):
        self.command(
            "rfq.save_draft",
            {"id": "r", "expected_version": 0, "lines": [{"line_id": "L1"}]},
        )
        saved = self.command("rfq.save_draft", {"id": "r", "expected_version": 1})
        self.assertEqual(saved["row_version"], 2)
        stale = self.command(
            "rfq.save_draft",
            {"id": "r", "expected_version": 1, "lines": [{"line_id": "L2"}]},
        )
        self.assertEqual(stale["code"], "VERSION_CONFLICT")
        self.assertEqual(self.core.get(self.who, "rfq", "r")["lines"], [])

    def test_confirmed_master_cannot_be_edited_or_retyped(self):
        self.source()
        self.master("c", "customer")
        result = self.command(
            "master.upsert_draft",
            {"id": "c", "expected_version": 2, "kind": "supplier", "name": "changed"},
        )
        self.assertEqual(result["code"], "INVALID_STATE")
        self.assertEqual(self.core.get(self.who, "master", "c")["name"], "c")

    def test_same_key_replays_without_repeating_import_and_different_content_conflicts(
        self,
    ):
        args = {"id": "s", "source_kind": "manual_text", "content_text": "same"}
        first = self.command("source.register", args, key="same")
        second = self.command("source.register", args, key="same")
        self.assertEqual(second["action_id"], first["action_id"])
        self.assertTrue(second["replayed"])
        self.assertEqual(len(self.core.get(self.who, "source", "s")["imports"]), 1)
        conflict = self.command(
            "source.register", {**args, "content_text": "different"}, key="same"
        )
        self.assertEqual(conflict["code"], "IDEMPOTENCY_PAYLOAD_CONFLICT")

    def test_email_identity_deduplicates_origin_but_preserves_imports(self):
        email = {
            "source_kind": "email_text",
            "provider": "test",
            "account_ref": "acct.1",
            "external_message_id": "msg.1",
            "author_claim": "synthetic buyer",
        }
        self.source("s1", **email)
        self.assertEqual(self.source("s2", **email), "s1")
        original = self.core.get(self.who, "source", "s1")
        self.assertEqual(len(original["imports"]), 2)
        result = self.command("source.register", {"id": "s3", "content_text": "changed", **email})
        self.assertEqual(result["code"], "SOURCE_IDENTITY_CONFLICT")
        self.assertEqual(len(self.core.get(self.who, "source", "s1")["imports"]), 2)

    def test_same_content_different_origins_can_support_different_rfqs(self):
        self.source("s1")
        self.source("s2")
        a, b = [self.core.get(self.who, "source", s) for s in ["s1", "s2"]]
        self.assertEqual(a["content_id"], b["content_id"])
        self.assertNotEqual(a["id"], b["id"])
        for i in (1, 2):
            self.assertTrue(
                self.command(
                    "rfq.save_draft",
                    {"id": f"r{i}", "expected_version": 0, "source_ids": [f"s{i}"]},
                )["ok"]
            )
            self.assertEqual(self.core.get(self.who, "rfq", f"r{i}")["source_ids"], [f"s{i}"])

    def test_cross_company_reference_is_rejected_without_existence_leak(self):
        self.master("c", "customer", confirm=False)
        other = Principal("tenant.A", "company.B", "human.1")
        self.core.provision(other, ["*"])
        for ref in ["c", "not.existing"]:
            result = self.command(
                "rfq.save_draft",
                {"id": "r", "expected_version": 0, "customer_id": ref},
                who=other,
            )
            self.assertEqual(
                (result["code"], result["field_errors"]),
                (
                    "REFERENCE_INVALID",
                    [{"path": "/args/customer_id", "reason": "REFERENCE_INVALID"}],
                ),
            )
        self.source("s")
        other_result = self.command(
            "source.register",
            {"id": "s", "source_kind": "manual_text", "content_text": "合成询价120件"},
            who=other,
        )
        self.assertTrue(other_result["ok"])
        self.assertNotEqual(
            self.core.get(self.who, "source", "s")["content_id"],
            self.core.get(other, "source", "s")["content_id"],
        )

    def test_revocation_is_current_and_blocks_replay(self):
        args = {"id": "r", "expected_version": 0}
        self.assertTrue(self.command("rfq.save_draft", args, key="k")["ok"])
        self.core.provision(self.who, ["read", "audit.read"])
        self.assertEqual(self.command("rfq.save_draft", args, key="k")["code"], "PERMISSION_DENIED")
        self.assertEqual(self.core.audit(self.who)[-1]["code"], "PERMISSION_DENIED")

    def test_unconfirmed_and_inactive_masters_block_ready(self):
        args = self.ready_args()
        self.command("rfq.save_draft", args)
        self.command(
            "master.deactivate",
            {"id": "sku.1", "expected_version": 2, "reason": "停用"},
        )
        result = self.command(
            "rfq.confirm_scope",
            {"id": "rfq.1", "expected_version": 1, "evidence_ids": ["src.1"]},
        )
        self.assertEqual(result["code"], "REFERENCE_INVALID")
        self.assertEqual(self.core.get(self.who, "rfq", "rfq.1")["row_version"], 1)

    def test_ai_cannot_verify_sources_even_with_broad_command_grants(self):
        ai = Principal("tenant.A", "company.A", "ai.1")
        self.core.provision(ai, ["*"], actor_kind="ai")
        self.source()
        self.master("c", "customer", confirm=False)
        result = self.command(
            "master.confirm",
            {"id": "c", "expected_version": 1, "evidence_ids": ["src.1"]},
            who=ai,
        )
        self.assertEqual(result["code"], "PERMISSION_DENIED")

    def test_concurrent_edit_has_one_winner_and_one_version_conflict(self):
        from concurrent.futures import ThreadPoolExecutor
        from threading import Barrier

        self.command("rfq.save_draft", {"id": "r", "expected_version": 0})
        barrier = Barrier(2)

        def edit(n):
            barrier.wait()
            return self.core.execute(
                self.who,
                {
                    "contract": "brant.trade-core/0.1.0",
                    "command": "rfq.save_draft",
                    "idempotency_key": f"parallel.{n}",
                    "args": {
                        "id": "r",
                        "expected_version": 1,
                        "lines": [{"line_id": f"L{n}"}],
                    },
                },
            )

        with ThreadPoolExecutor(max_workers=2) as pool:
            result = list(pool.map(edit, [1, 2]))
        self.assertEqual(sum(r["ok"] for r in result), 1)
        self.assertEqual([r["code"] for r in result if not r["ok"]], ["VERSION_CONFLICT"])
        self.assertEqual(self.core.get(self.who, "rfq", "r")["row_version"], 2)

    def test_reopen_preserves_source_and_rfq(self):
        self.source()
        self.command(
            "rfq.save_draft",
            {"id": "r", "expected_version": 0, "source_ids": ["src.1"]},
        )
        reopened = Core(self.path)
        self.assertEqual(reopened.get(self.who, "rfq", "r")["source_ids"], ["src.1"])
        self.assertEqual(
            reopened.get(self.who, "source", "src.1")["content"]["content_text"],
            "合成询价120件",
        )

    def test_contact_must_match_customer_and_wrong_reference_kind_is_rejected(self):
        args = self.ready_args()
        self.master("customer.2", "customer")
        result = self.command("rfq.save_draft", {**args, "customer_id": "customer.2"})
        self.assertEqual(result["code"], "REFERENCE_INVALID")
        self.assertEqual(
            self.command("rfq.save_draft", {**args, "customer_id": "sku.1"})["code"],
            "REFERENCE_INVALID",
        )

    def test_confirmation_requires_all_sources_and_no_unresolved_fields(self):
        args = self.ready_args()
        self.source("src.2")
        self.command("rfq.save_draft", {**args, "source_ids": ["src.1", "src.2"]})
        refused = self.command(
            "rfq.confirm_scope",
            {"id": "rfq.1", "expected_version": 1, "evidence_ids": ["src.1"]},
        )
        self.assertEqual(refused["code"], "DRAFT_NOT_READY")
        saved = self.command(
            "rfq.save_draft",
            {**args, "expected_version": 1, "unresolved_fields": ["交期尚未澄清"]},
        )
        self.assertEqual(saved["row_version"], 2)
        refused = self.command(
            "rfq.confirm_scope",
            {"id": "rfq.1", "expected_version": 2, "evidence_ids": ["src.1"]},
        )
        self.assertEqual(refused["field_errors"][0]["path"], "/args/unresolved_fields")

    def test_terminal_rfq_cannot_be_reopened_by_save(self):
        self.command("rfq.save_draft", {"id": "r", "expected_version": 0})
        result = self.command("rfq.cancel", {"id": "r", "expected_version": 1, "reason": "撤回"})
        self.assertEqual(result["status"], "cancelled")
        self.assertEqual(
            self.command("rfq.save_draft", {"id": "r", "expected_version": 2})["code"],
            "INVALID_STATE",
        )

    def test_rollback_when_storage_rejects_outbox_write(self):
        # Fault injection at the storage boundary, observations via public service only.
        import sqlite3

        from brant_core.service import Rejected

        with sqlite3.connect(self.path) as db:
            db.execute(
                "CREATE TRIGGER fail_outbox BEFORE INSERT ON outbox BEGIN SELECT RAISE(ABORT,'injected failure'); END"
            )
        with self.assertRaises(sqlite3.IntegrityError):
            self.command("rfq.save_draft", {"id": "atomic", "expected_version": 0}, key="atomic")
        with self.assertRaises(Rejected) as error:
            self.core.get(self.who, "rfq", "atomic")
        self.assertEqual(error.exception.code, "NOT_FOUND")
        self.assertFalse(
            any(
                e["object_id"] == "atomic" and e["outcome"] == "succeeded"
                for e in self.core.audit(self.who)
            )
        )
        with sqlite3.connect(self.path) as db:
            db.execute("DROP TRIGGER fail_outbox")
        result = self.command(
            "rfq.save_draft", {"id": "atomic", "expected_version": 0}, key="atomic"
        )
        self.assertTrue(result["ok"])
        self.assertFalse(result["replayed"])

    def test_concurrent_duplicate_import_is_single_action(self):
        from concurrent.futures import ThreadPoolExecutor

        request = {
            "contract": "brant.trade-core/0.1.0",
            "command": "source.register",
            "idempotency_key": "parallel.source",
            "args": {"id": "s", "source_kind": "manual_text", "content_text": "same"},
        }
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: self.core.execute(self.who, request), [1, 2]))
        self.assertTrue(all(r["ok"] for r in results))
        self.assertEqual(len({r["action_id"] for r in results}), 1)
        self.assertEqual(sum(r["replayed"] for r in results), 1)
        self.assertEqual(len(self.core.get(self.who, "source", "s")["imports"]), 1)

    def test_replay_ignores_changed_cas_but_not_changed_business_fields(self):
        args = {"id": "r", "expected_version": 0}
        original = self.command("rfq.save_draft", args, key="once")
        replay = self.command("rfq.save_draft", {**args, "expected_version": 999}, key="once")
        self.assertEqual(replay["action_id"], original["action_id"])
        changed = self.command("rfq.save_draft", {**args, "lines": []}, key="once")
        self.assertEqual(changed["code"], "IDEMPOTENCY_PAYLOAD_CONFLICT")

    def test_limits_unknown_contract_and_sensitive_audit(self):
        oversized = self.command(
            "source.register",
            {"id": "s", "source_kind": "manual_text", "content_text": "秘" * 50001},
        )
        self.assertEqual(oversized["code"], "SCHEMA_INVALID")
        result = self.core.execute(self.who, {"contract": "unknown"})
        self.assertEqual(result["code"], "UNSUPPORTED_CONTRACT")
        self.source("s", content_text="PRIVATE_SOURCE_TEXT")
        self.assertNotIn("PRIVATE_SOURCE_TEXT", str(self.core.audit(self.who)))

    def test_denied_reader_cannot_get_source(self):
        from brant_core.service import Rejected

        self.source()
        other = Principal("tenant.A", "company.A", "no.read")
        self.core.provision(other, ["rfq.save_draft"])
        with self.assertRaises(Rejected) as error:
            self.core.get(other, "source", "src.1")
        self.assertEqual(error.exception.code, "PERMISSION_DENIED")

    def test_source_read_and_denied_read_are_audited(self):
        from brant_core.service import Rejected

        self.source()
        self.core.get(self.who, "source", "src.1")
        self.assertEqual(self.core.audit(self.who)[-1]["outcome"], "read")
        blocked = Principal("tenant.A", "company.A", "blocked")
        self.core.provision(blocked, [])
        with self.assertRaises(Rejected):
            self.core.get(blocked, "source", "src.1")
        self.assertEqual(self.core.audit(self.who)[-1]["code"], "PERMISSION_DENIED")

    def test_confirmation_requires_source_read_permission(self):
        self.source()
        self.master("c", "customer", confirm=False)
        verifier = Principal("tenant.A", "company.A", "limited")
        self.core.provision(verifier, ["master.confirm"])
        result = self.command(
            "master.confirm",
            {"id": "c", "expected_version": 1, "evidence_ids": ["src.1"]},
            who=verifier,
        )
        self.assertEqual(result["code"], "PERMISSION_DENIED")

    def test_supplemental_confirmation_evidence_is_retained(self):
        args = self.ready_args()
        self.source("clarification")
        self.command("rfq.save_draft", args)
        result = self.command(
            "rfq.confirm_scope",
            {"id": "rfq.1", "expected_version": 1, "evidence_ids": ["src.1", "clarification"]},
        )
        self.assertEqual(result["status"], "ready")
        self.assertEqual(
            self.core.get(self.who, "rfq", "rfq.1")["source_ids"], ["clarification", "src.1"]
        )

    def test_unknown_source_points_to_actual_request_field(self):
        for args, path in [
            ({"source_ids": ["missing"]}, "/args/source_ids/0"),
            ({"lines": [{"line_id": "L1", "source_id": "missing"}]}, "/args/lines/0/source_id"),
        ]:
            result = self.command("rfq.save_draft", {"id": "r", "expected_version": 0, **args})
            self.assertEqual(result["code"], "REFERENCE_INVALID")
            self.assertEqual(result["field_errors"][0]["path"], path)

    def test_manual_text_with_channel_identity_is_closed_schema_rejection(self):
        result = self.command(
            "source.register",
            {
                "id": "s",
                "source_kind": "manual_text",
                "content_text": "text",
                "provider": "mail",
                "account_ref": "a",
                "external_message_id": "m",
            },
        )
        self.assertEqual(result["code"], "SCHEMA_INVALID")

    def test_audit_waits_for_prior_revocation_transaction(self):
        import sqlite3
        from concurrent.futures import ThreadPoolExecutor
        from threading import Event

        from brant_core.service import Rejected

        reader = Principal("tenant.A", "company.A", "audit.reader")
        self.core.provision(reader, ["audit.read"])
        started = Event()
        # A competing authority-store transaction is intentionally held open.
        with sqlite3.connect(self.path, isolation_level=None) as authority:
            authority.execute("BEGIN IMMEDIATE")
            authority.execute(
                "UPDATE authorization SET grants_json='[]' WHERE actor='audit.reader'"
            )

            def read_audit():
                started.set()
                return self.core.audit(reader)

            with ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(read_audit)
                self.assertTrue(started.wait(2))
                authority.commit()
                with self.assertRaises(Rejected) as error:
                    future.result(timeout=5)
                self.assertEqual(error.exception.code, "PERMISSION_DENIED")
