import base64
import tempfile
import unittest
from datetime import UTC, datetime
from pathlib import Path

from brant_core import Core, Principal
from brant_core.common import Rejected

CLOCK = datetime(2026, 10, 22, 9, tzinfo=UTC)
START = "2026-10-22T00:00:00Z"
END = "2026-10-23T00:00:00Z"


def ref(kind, id_, revision=1):
    return {"kind": kind, "id": id_, "revision": revision}


class FoundationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "core.sqlite"
        self.core = Core(self.path, clock=lambda: CLOCK)
        self.editor = Principal("t", "company.A", "editor")
        self.reviewer = Principal("t", "company.A", "reviewer")
        for p in [self.editor, self.reviewer]:
            self.core.provision(p, ["*"], team_id="trade", data_scope="company")
        self.counter = 0
        self.legacy(
            "source.register",
            {
                "id": "evidence",
                "source_kind": "manual_text",
                "content_text": "SYNTHETIC CONFIGURATION EVIDENCE ONLY",
            },
        )

    def tearDown(self):
        self.tmp.cleanup()

    def legacy(self, command, args, who=None):
        self.counter += 1
        return self.core.execute(
            who or self.editor,
            {
                "contract": "brant.trade-core/0.1.0",
                "idempotency_key": f"old.{self.counter}",
                "command": command,
                "args": args,
            },
        )

    def call(self, command, args, who=None, key=None):
        self.counter += 1
        return self.core.execute(
            who or self.editor,
            {
                "contract": "brant.foundation/0.1.0",
                "idempotency_key": key or f"new.{self.counter}",
                "command": command,
                "args": args,
            },
        )

    def config(self, kind, id_, data, expected=0, publish=True):
        if kind == "sku_profile":
            data = {
                **data,
                "sku_row_version": self.core.get(self.editor, "master", data["sku_id"])[
                    "row_version"
                ],
            }
        if kind in ("party_profile", "contact_profile", "code_mapping"):
            data = {
                **data,
                "party_row_version": self.core.get(self.editor, "master", data["party_id"])[
                    "row_version"
                ],
            }
        saved = self.call(
            "foundation.save",
            {
                "kind": kind,
                "id": id_,
                "data": data,
                "expected_version": expected,
                "evidence_ids": ["evidence"],
            },
        )
        self.assertTrue(saved["ok"], saved)
        if publish:
            published = self.call(
                "foundation.publish",
                {
                    "kind": kind,
                    "id": id_,
                    "revision": saved["revision"],
                    "expected_version": saved["row_version"],
                    "reason": "核实合成测试配置",
                },
                who=self.reviewer,
            )
            self.assertTrue(published["ok"], published)
        return ref(kind, id_, saved["revision"])

    def currency(self, code):
        return self.config(
            "currency", code, {"code": code, "name": code, "minor_units": 2, "rounding": "HALF_UP"}
        )

    def tax(self, treatment="nonrecoverable", id_="tax"):
        return self.config(
            "tax_profile",
            id_,
            {
                "name": "SYNTHETIC TAX",
                "rate": "0.13",
                "price_basis": "inclusive",
                "recovery_treatment": treatment,
                "policy_basis": "test only, not a legal determination",
                "valid_from": START,
                "valid_until": END,
            },
        )

    def fx_setup(self):
        usd = self.currency("USD")
        cny = self.currency("CNY")
        tax = self.tax()
        policy = self.config(
            "pricing_policy",
            "policy",
            {
                "name": "test",
                "calculation_currency": cny,
                "minimum_margin": "0.25",
                "quote_valid_days": 7,
                "max_fx_age_seconds": 86400,
                "independent_review": True,
                "tax_profile": tax,
            },
        )
        fx = self.config(
            "fx",
            "usd.cny",
            {
                "from_currency": usd,
                "to_currency": cny,
                "rate": "7.123456",
                "purpose": "cost_estimate",
                "source_name": "SYNTHETIC RATE",
                "observed_at": START,
                "valid_from": START,
                "valid_until": END,
            },
        )
        return usd, cny, policy, fx

    def company(self, currency):
        return self.config(
            "company",
            "company.A",
            {
                "legal_name": "合成企业",
                "registration_no": "SYNTHETIC-NOT-REAL",
                "country": "CN",
                "address": "合成地址",
                "base_currency": currency,
                "timezone": "Asia/Shanghai",
                "policy_scope": "synthetic general trade test",
            },
        )

    def master(self, id_, kind, **fields):
        self.assertTrue(
            self.legacy(
                "master.upsert_draft",
                {"id": id_, "kind": kind, "name": id_, "expected_version": 0, **fields},
            )["ok"]
        )
        self.assertTrue(
            self.legacy(
                "master.confirm", {"id": id_, "expected_version": 1, "evidence_ids": ["evidence"]}
            )["ok"]
        )

    def units(self):
        pcs = self.config(
            "unit", "PCS", {"code": "PCS", "name": "件", "dimension": "count", "precision": 0}
        )
        dozen = self.config(
            "unit", "DOZEN", {"code": "DOZEN", "name": "打", "dimension": "count", "precision": 0}
        )
        self.master("sku", "sku", base_uom="PCS")
        sku = self.config(
            "sku_profile",
            "sku.profile",
            {
                "sku_id": "sku",
                "item_name": "测试产品",
                "specification_version": "TECH.r1",
                "base_unit": pcs,
                "description": "SYNTHETIC",
            },
        )
        conversion = self.config(
            "conversion",
            "dozen.pcs",
            {
                "sku_profile": sku,
                "from_unit": dozen,
                "to_unit": pcs,
                "factor": "12",
                "basis": "test SKU TECH.r1 packaging evidence",
                "valid_from": START,
                "valid_until": END,
            },
        )
        return pcs, dozen, sku, conversion

    def test_independent_publication_and_ai_guard(self):
        draft = self.config(
            "currency",
            "USD",
            {"code": "USD", "name": "USD", "minor_units": 2, "rounding": "HALF_UP"},
            publish=False,
        )
        args = {
            "kind": "currency",
            "id": "USD",
            "revision": 1,
            "expected_version": 1,
            "reason": "核实",
        }
        self.assertEqual(
            self.call("foundation.publish", args)["code"], "INDEPENDENT_REVIEW_REQUIRED"
        )
        ai = Principal("t", "company.A", "ai")
        self.core.provision(ai, ["*"], actor_kind="ai", data_scope="company")
        self.assertEqual(self.call("foundation.publish", args, who=ai)["code"], "PERMISSION_DENIED")
        self.assertTrue(self.call("foundation.publish", args, who=self.reviewer)["ok"])
        self.assertEqual(
            self.core.foundation_get(self.editor, "currency", draft["id"])["data"]["code"], "USD"
        )

    def test_fx_direction_purpose_rounding_and_expiry(self):
        usd, cny, policy, fx = self.fx_setup()
        args = {
            "id": "calc",
            "amount": "10",
            "from_currency": usd,
            "to_currency": cny,
            "fx": fx,
            "policy": policy,
            "purpose": "cost_estimate",
        }
        self.assertEqual(
            self.call("foundation.fx.convert", args)["values"],
            {"amount": "71.23", "currency": "CNY"},
        )
        self.assertEqual(
            self.call("foundation.fx.convert", {**args, "purpose": "quotation"})["code"],
            "FX_SCOPE_MISMATCH",
        )
        self.assertEqual(
            self.call("foundation.fx.convert", {**args, "from_currency": cny, "to_currency": usd})[
                "code"
            ],
            "FX_SCOPE_MISMATCH",
        )
        self.core.clock = lambda: datetime(2026, 10, 23, tzinfo=UTC)
        self.assertEqual(self.call("foundation.fx.convert", args)["code"], "CONFIG_EXPIRED")

    def test_historical_snapshot_survives_rate_revision(self):
        usd, cny, policy, fx = self.fx_setup()
        company = self.company(cny)
        result = self.call(
            "foundation.snapshot",
            {"id": "snapshot.1", "refs": [fx, policy, company], "purpose": "cost_estimate"},
        )
        self.assertTrue(result["ok"], result)
        before = self.core.foundation_get(self.editor, "snapshot", "snapshot.1")
        old = self.core.foundation_get(self.editor, "fx", fx["id"])
        data = {**old["data"], "rate": "7.500000"}
        new = self.config("fx", fx["id"], data, expected=2)
        after = self.core.foundation_get(self.editor, "snapshot", "snapshot.1")
        self.assertEqual(before, after)
        self.assertEqual(new["revision"], 2)
        self.assertEqual(
            self.call(
                "foundation.snapshot",
                {"id": "snapshot.2", "refs": [fx], "purpose": "cost_estimate"},
            )["code"],
            "CONFIG_NOT_ACTIVE",
        )
        self.assertEqual(
            self.core.foundation_get(self.editor, "fx", fx["id"], 1)["data"]["rate"], "7.123456"
        )

    def test_unit_conversion_is_sku_scoped_and_exact(self):
        pcs, dozen, sku, conversion = self.units()
        args = {"id": "units", "quantity": "2", "conversion": conversion, "sku_profile": sku}
        self.assertEqual(
            self.call("foundation.unit.convert", args)["values"], {"quantity": "24", "unit": "PCS"}
        )
        self.assertEqual(
            self.call(
                "foundation.unit.convert", {**args, "sku_profile": ref("sku_profile", "other")}
            )["code"],
            "UNIT_SCOPE_MISMATCH",
        )
        self.assertEqual(
            self.call("foundation.unit.convert", {**args, "quantity": "0.1"})["code"],
            "INVALID_KNOWN_VALUE",
        )

    def test_tax_split_is_exact_and_unknown_recovery_blocks(self):
        cny = self.currency("CNY")
        tax = self.tax()
        result = self.call(
            "foundation.tax.preview",
            {"id": "tax.calc", "amount": "113", "currency": cny, "tax_profile": tax},
        )
        self.assertEqual(
            result["values"],
            {
                "net_amount": "100.00",
                "tax_amount": "13.00",
                "gross_amount": "113.00",
                "currency": "CNY",
            },
        )
        unknown = self.tax("unknown", "tax.unknown")
        self.assertEqual(
            self.call(
                "foundation.tax.preview",
                {"id": "unknown", "amount": "113", "currency": cny, "tax_profile": unknown},
            )["code"],
            "TAX_POLICY_UNCONFIRMED",
        )

    def test_payment_stage_total_and_declared_calendar(self):
        cal = self.config(
            "calendar",
            "calendar",
            {
                "timezone": "Asia/Shanghai",
                "working_weekdays": [1, 2, 3, 4, 5],
                "holidays": ["2026-10-01"],
            },
        )
        stage = {
            "stage_id": "deposit",
            "percent": "30",
            "trigger": "order_confirmed",
            "days": 0,
            "day_basis": "calendar",
            "calendar": cal,
        }
        bad = self.call(
            "foundation.save",
            {
                "kind": "payment_terms",
                "id": "payment",
                "data": {"name": "test", "stages": [stage]},
                "expected_version": 0,
                "evidence_ids": ["evidence"],
            },
        )
        self.assertEqual(bad["code"], "PAYMENT_TOTAL_MISMATCH")
        full = self.config(
            "payment_terms",
            "payment",
            {
                "name": "30/70",
                "stages": [
                    stage,
                    {**stage, "stage_id": "balance", "percent": "70", "trigger": "before_shipment"},
                ],
            },
        )
        self.assertEqual(
            self.core.foundation_get(self.editor, "payment_terms", full["id"])["data"]["stages"][1][
                "percent"
            ],
            "70",
        )

    def test_company_identity_and_immutable_currency_semantics(self):
        cny = self.currency("CNY")
        self.company(cny)
        bad = self.call(
            "foundation.save",
            {
                "id": "company.B",
                "kind": "company",
                "expected_version": 0,
                "evidence_ids": ["evidence"],
                "data": self.core.foundation_get(self.editor, "company", "company.A")["data"],
            },
        )
        self.assertEqual(bad["code"], "INVALID_KNOWN_VALUE")
        draft = self.config(
            "currency",
            "CNY",
            {"code": "CNY", "name": "changed", "minor_units": 3, "rounding": "HALF_UP"},
            expected=2,
            publish=False,
        )
        self.assertEqual(
            self.call(
                "foundation.publish",
                {
                    "id": "CNY",
                    "kind": "currency",
                    "revision": draft["revision"],
                    "expected_version": 3,
                    "reason": "test",
                },
                who=self.reviewer,
            )["code"],
            "IMMUTABLE_DEFINITION",
        )

    def test_master_revision_preserves_old_confirmed_record(self):
        self.master("customer", "customer")
        result = self.call(
            "master.revise", {"id": "customer", "expected_version": 2, "reason": "受控修订"}
        )
        self.assertEqual((result["status"], result["row_version"]), ("draft", 3))
        history = self.core.foundation_get(self.editor, "master_history", "customer", 2)
        self.assertEqual((history["status"], history["name"]), ("confirmed", "customer"))
        self.assertTrue(
            self.legacy(
                "master.upsert_draft",
                {"id": "customer", "kind": "customer", "name": "new name", "expected_version": 3},
            )["ok"]
        )
        self.assertEqual(
            self.core.foundation_get(self.editor, "master_history", "customer", 2)["name"],
            "customer",
        )

    def test_own_team_scope_and_replay_do_not_leak(self):
        a = Principal("t", "company.A", "a")
        b = Principal("t", "company.A", "b")
        outsider = Principal("t", "company.A", "outside")
        for p, team in [(a, "team1"), (b, "team1"), (outsider, "team2")]:
            self.core.provision(p, ["*"], team_id=team, data_scope="team")
        args = {"id": "private", "expected_version": 0}
        request = {
            "contract": "brant.trade-core/0.1.0",
            "command": "rfq.save_draft",
            "idempotency_key": "shared.key",
            "args": args,
        }
        self.assertTrue(self.core.execute(a, request)["ok"])
        self.assertEqual(self.core.get(b, "rfq", "private")["id"], "private")
        with self.assertRaises(Rejected):
            self.core.get(outsider, "rfq", "private")
        self.assertEqual(self.core.execute(outsider, request)["code"], "NOT_FOUND")
        self.core.provision(b, ["*"], team_id="team1", data_scope="own")
        with self.assertRaises(Rejected):
            self.core.get(b, "rfq", "private")

    def test_attachment_immutable_versions_and_access(self):
        args = {
            "id": "f1",
            "file_name": "evidence.txt",
            "mime_type": "text/plain",
            "content_base64": base64.b64encode("原文".encode()).decode(),
        }
        first = self.call("foundation.file.register", args)
        self.assertTrue(first["ok"], first)
        next_ = self.call(
            "foundation.file.register",
            {
                **args,
                "id": "f2",
                "supersedes_file_id": "f1",
                "content_base64": base64.b64encode(b"new").decode(),
            },
        )
        self.assertTrue(next_["ok"])
        self.assertEqual(
            base64.b64decode(
                self.core.foundation_get(self.editor, "file", "f1")["content_base64"]
            ).decode(),
            "原文",
        )
        outsider = Principal("t", "company.A", "outsider")
        self.core.provision(outsider, ["*"])
        with self.assertRaises(Rejected):
            self.core.foundation_get(outsider, "file", "f1")
        self.assertEqual(
            self.call(
                "foundation.file.register", {**args, "id": "invalid", "content_base64": "%%%bad"}
            )["code"],
            "FILE_INVALID",
        )

    def test_number_and_plaintext_template_bind_snapshot(self):
        cny = self.currency("CNY")
        company = self.company(cny)
        seq = self.config(
            "sequence",
            "quote.seq",
            {
                "document_type": "quote",
                "prefix": "QT-",
                "width": 5,
                "company": company,
                "reset": "annual",
            },
        )
        template = self.config(
            "document_template",
            "quote.template",
            {
                "name": "quote test",
                "document_type": "quote",
                "template_text": "报价 {document.number}：{customer.name}，{quote.total} {quote.currency}",
                "field_names": [
                    "document.number",
                    "customer.name",
                    "quote.total",
                    "quote.currency",
                ],
            },
        )
        number = self.call(
            "foundation.number.issue", {"id": "number1", "sequence": seq, "business_ref": "quote1"}
        )
        self.assertEqual(number["values"]["document_number"], "QT-2026-00001")
        self.assertEqual(
            self.call(
                "foundation.number.issue",
                {"id": "number2", "sequence": seq, "business_ref": "quote1"},
            )["code"],
            "BUSINESS_KEY_CONFLICT",
        )
        generated = self.call(
            "foundation.document.render",
            {
                "id": "doc1",
                "template": template,
                "number_id": "number1",
                "values": {
                    "customer.name": "合成客户",
                    "quote.total": "960.00",
                    "quote.currency": "USD",
                },
            },
        )
        self.assertTrue(generated["ok"], generated)
        file = self.core.foundation_get(self.editor, "file", "doc1")
        self.assertEqual(file["template_revision"], 1)
        self.assertEqual(
            base64.b64decode(file["content_base64"]).decode(),
            "DRAFT / 业务草稿（未绑定已生效报价）\n报价 QT-2026-00001：合成客户，960.00 USD",
        )
        unsafe = self.call(
            "foundation.save",
            {
                "id": "unsafe",
                "kind": "document_template",
                "expected_version": 0,
                "evidence_ids": ["evidence"],
                "data": {
                    "name": "unsafe",
                    "document_type": "quote",
                    "template_text": "{customer.name.__class__}",
                    "field_names": ["customer.name"],
                },
            },
        )
        self.assertEqual(unsafe["code"], "TEMPLATE_INVALID")

    def test_sensitive_account_field_requires_separate_grant(self):
        cny = self.currency("CNY")
        self.config(
            "bank_account",
            "bank",
            {
                "owner_kind": "company",
                "owner_id": "company.A",
                "bank_name": "synthetic bank",
                "account_number": "1234567890",
                "currency": cny,
                "purpose": "receipt",
            },
        )
        reader = Principal("t", "company.A", "reader")
        self.core.provision(reader, ["foundation.read", "read"], data_scope="company")
        self.assertEqual(
            self.core.foundation_get(reader, "bank_account", "bank")["data"]["account_number"],
            "******7890",
        )
        self.assertEqual(
            self.core.foundation_get(self.editor, "bank_account", "bank")["data"]["account_number"],
            "1234567890",
        )

    def trading(self):
        calendar = self.config(
            "calendar",
            "cal",
            {"timezone": "Asia/Shanghai", "working_weekdays": [1, 2, 3, 4, 5], "holidays": []},
        )
        terms = self.config(
            "trade_terms",
            "FCA.test",
            {
                "incoterm": "FCA",
                "edition": "2020",
                "named_place": "TEST NAMED PLACE",
                "responsibility_note": "synthetic evidence only, no ownership inference",
                "delivery": {
                    "kind": "lead_time",
                    "anchor_event": "technical_approved",
                    "days": 30,
                    "day_basis": "working",
                    "calendar": calendar,
                },
            },
        )
        payment = self.config(
            "payment_terms",
            "payment",
            {
                "name": "test",
                "stages": [
                    {
                        "stage_id": "balance",
                        "percent": "100",
                        "trigger": "before_shipment",
                        "days": 0,
                        "day_basis": "calendar",
                        "calendar": calendar,
                    }
                ],
            },
        )
        return terms, payment

    def test_supplier_contacts_addresses_and_external_sku_mapping(self):
        pcs, dozen, sku, conversion = self.units()
        self.master("supplier", "supplier")
        contact = self.config(
            "contact_profile",
            "supplier.contact",
            {
                "party_id": "supplier",
                "party_role": "supplier",
                "name": "合成采购联系人",
                "email": "synthetic@example.invalid",
                "position": "销售",
            },
        )
        terms, payment = self.trading()
        party = self.config(
            "party_profile",
            "supplier.profile",
            {
                "party_id": "supplier",
                "legal_name": "合成供应商",
                "country": "CN",
                "addresses": [{"address_id": "factory", "role": "seller", "address": "测试地址"}],
                "contacts": [contact],
                "trade_terms": terms,
                "payment_terms": payment,
            },
        )
        self.assertEqual(
            self.core.foundation_get(self.editor, "party_profile", party["id"])["data"]["contacts"],
            [contact],
        )
        mapping = self.config(
            "code_mapping",
            "mapping1",
            {
                "party_id": "supplier",
                "party_role": "supplier",
                "external_code": "SUP-01",
                "sku_profile": sku,
            },
        )
        self.assertEqual(
            self.core.foundation_get(self.editor, "code_mapping", mapping["id"])["data"][
                "sku_profile"
            ],
            sku,
        )
        self.config(
            "code_mapping",
            "mapping2",
            {
                "party_id": "supplier",
                "party_role": "supplier",
                "external_code": "SUP-01",
                "sku_profile": sku,
            },
            publish=False,
        )
        self.assertEqual(
            self.call(
                "foundation.publish",
                {
                    "kind": "code_mapping",
                    "id": "mapping2",
                    "revision": 1,
                    "expected_version": 1,
                    "reason": "test",
                },
                who=self.reviewer,
            )["code"],
            "BUSINESS_KEY_CONFLICT",
        )

    def test_fee_classification_preserves_inclusion_and_side(self):
        fee = self.config(
            "fee_type",
            "packaging",
            {
                "name": "包装",
                "category": "packaging",
                "side": "purchase_cost",
                "inclusion": "included_in_line",
                "allocation_basis": "quantity",
                "policy_basis": "synthetic cost scope",
            },
        )
        self.assertEqual(
            self.core.foundation_get(self.editor, "fee_type", fee["id"])["data"]["inclusion"],
            "included_in_line",
        )

    def test_configuration_cas_and_cross_company_reference(self):
        self.currency("CNY")
        changed = {"code": "CNY", "name": "new", "minor_units": 2, "rounding": "HALF_UP"}
        self.assertEqual(
            self.call(
                "foundation.save",
                {
                    "id": "CNY",
                    "kind": "currency",
                    "expected_version": 1,
                    "data": changed,
                    "evidence_ids": ["evidence"],
                },
            )["code"],
            "VERSION_CONFLICT",
        )
        other = Principal("t", "company.B", "operator")
        self.core.provision(other, ["*"], data_scope="company")
        with self.assertRaises(Rejected):
            self.core.foundation_get(other, "currency", "CNY")

    def test_stale_fx_is_not_silently_reused_and_no_reciprocal(self):
        usd, cny, policy, fx = self.fx_setup()
        old = self.core.foundation_get(self.editor, "pricing_policy", "policy")["data"]
        newpolicy = self.config(
            "pricing_policy", "policy", {**old, "max_fx_age_seconds": 60}, expected=2
        )
        args = {
            "id": "fx.old",
            "amount": "10",
            "from_currency": usd,
            "to_currency": cny,
            "fx": fx,
            "policy": newpolicy,
            "purpose": "cost_estimate",
        }
        self.assertEqual(self.call("foundation.fx.convert", args)["code"], "FX_STALE")
        company = self.company(cny)
        self.assertEqual(
            self.call(
                "foundation.snapshot",
                {
                    "id": "stale.snapshot",
                    "refs": [company, newpolicy, fx],
                    "purpose": "cost_estimate",
                },
            )["code"],
            "FX_STALE",
        )

    def test_retired_currency_cannot_be_redefined(self):
        self.currency("USD")
        self.assertTrue(
            self.call(
                "foundation.retire",
                {"id": "USD", "kind": "currency", "expected_version": 2, "reason": "停用"},
                who=self.reviewer,
            )["ok"]
        )
        self.config(
            "currency",
            "USD",
            {"code": "USD", "name": "USD", "minor_units": 0, "rounding": "HALF_UP"},
            expected=3,
            publish=False,
        )
        self.assertEqual(
            self.call(
                "foundation.publish",
                {
                    "id": "USD",
                    "kind": "currency",
                    "revision": 2,
                    "expected_version": 4,
                    "reason": "test",
                },
                who=self.reviewer,
            )["code"],
            "IMMUTABLE_DEFINITION",
        )

    def test_snapshot_requires_company_policy_and_unknown_tax_blocks(self):
        usd, cny, policy, fx = self.fx_setup()
        self.assertEqual(
            self.call(
                "foundation.snapshot",
                {"id": "incomplete", "refs": [fx], "purpose": "cost_estimate"},
            )["code"],
            "DRAFT_NOT_READY",
        )
        company = self.company(cny)
        unknown = self.tax("unknown", "unknown.tax")
        self.assertEqual(
            self.call(
                "foundation.snapshot",
                {"id": "unknown", "refs": [company, policy, unknown], "purpose": "cost_estimate"},
            )["code"],
            "TAX_POLICY_UNCONFIRMED",
        )

    def test_file_signature_size_and_branching_are_explicit(self):
        args = {
            "id": "pdf",
            "file_name": "x.pdf",
            "mime_type": "application/pdf",
            "content_base64": base64.b64encode(b"not a pdf").decode(),
        }
        self.assertEqual(self.call("foundation.file.register", args)["code"], "FILE_INVALID")
        args = {
            "id": "root",
            "file_name": "a.txt",
            "mime_type": "text/plain",
            "content_base64": base64.b64encode(b"original").decode(),
        }
        self.assertTrue(self.call("foundation.file.register", args)["ok"])
        self.assertTrue(
            self.call(
                "foundation.file.register", {**args, "id": "version2", "supersedes_file_id": "root"}
            )["ok"]
        )
        self.assertEqual(
            self.call(
                "foundation.file.register", {**args, "id": "branch", "supersedes_file_id": "root"}
            )["code"],
            "BUSINESS_KEY_CONFLICT",
        )

    def test_concurrent_number_issue_has_unique_numbers(self):
        from concurrent.futures import ThreadPoolExecutor

        cny = self.currency("CNY")
        company = self.company(cny)
        seq = self.config(
            "sequence",
            "sequence",
            {
                "document_type": "quote",
                "prefix": "QT-",
                "width": 5,
                "company": company,
                "reset": "annual",
            },
        )

        def issue(i):
            return self.core.execute(
                self.editor,
                {
                    "contract": "brant.foundation/0.1.0",
                    "command": "foundation.number.issue",
                    "idempotency_key": f"parallel.{i}",
                    "args": {"id": f"n{i}", "sequence": seq, "business_ref": f"q{i}"},
                },
            )

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(issue, [1, 2]))
        self.assertTrue(all(r["ok"] for r in results))
        self.assertEqual(
            {r["values"]["document_number"] for r in results}, {"QT-2026-00001", "QT-2026-00002"}
        )

    def test_reference_deactivation_blocks_new_work_but_preserves_snapshot(self):
        usd, cny, policy, fx = self.fx_setup()
        company = self.company(cny)
        self.call(
            "foundation.snapshot",
            {"id": "old", "refs": [company, policy, fx], "purpose": "cost_estimate"},
        )
        self.assertTrue(
            self.call(
                "foundation.retire",
                {"id": fx["id"], "kind": "fx", "expected_version": 2, "reason": "撤销来源"},
                who=self.reviewer,
            )["ok"]
        )
        self.assertEqual(
            self.call(
                "foundation.fx.convert",
                {
                    "id": "new",
                    "amount": "10",
                    "from_currency": usd,
                    "to_currency": cny,
                    "fx": fx,
                    "policy": policy,
                    "purpose": "cost_estimate",
                },
            )["code"],
            "CONFIG_NOT_ACTIVE",
        )
        self.assertEqual(
            self.core.foundation_get(self.editor, "snapshot", "old")["data"]["purpose"],
            "cost_estimate",
        )

    def test_same_currency_explicit_one_and_missing_cross_rate_blocks(self):
        usd, cny, policy, fx = self.fx_setup()
        same = {
            "id": "same",
            "amount": "10.005",
            "from_currency": cny,
            "to_currency": cny,
            "policy": policy,
            "purpose": "cost_estimate",
        }
        self.assertEqual(self.call("foundation.fx.convert", same)["values"]["amount"], "10.01")
        self.assertEqual(
            self.call("foundation.fx.convert", {**same, "from_currency": usd})["code"],
            "DRAFT_NOT_READY",
        )
        self.assertEqual(
            self.call("foundation.fx.convert", {**same, "fx": fx})["code"], "FX_SCOPE_MISMATCH"
        )

    def test_snapshot_read_rechecks_sources_without_revalidating_expiry(self):
        usd, cny, policy, fx = self.fx_setup()
        company = self.company(cny)
        self.assertTrue(
            self.call(
                "foundation.snapshot",
                {"id": "history", "refs": [company, policy, fx], "purpose": "cost_estimate"},
            )["ok"]
        )
        peer = Principal("t", "company.A", "peer")
        self.core.provision(peer, ["*"], data_scope="company")
        self.assertEqual(
            self.core.foundation_get(peer, "snapshot", "history")["data"]["purpose"],
            "cost_estimate",
        )
        self.core.provision(peer, ["*"], data_scope="own")
        with self.assertRaises(Rejected):
            self.core.foundation_get(peer, "snapshot", "history")
        self.core.clock = lambda: datetime(2026, 10, 24, tzinfo=UTC)
        self.assertEqual(
            self.core.foundation_get(self.editor, "snapshot", "history")["data"]["purpose"],
            "cost_estimate",
        )

    def test_master_revision_invalidates_old_sku_profile_for_new_conversion(self):
        pcs, dozen, sku, conversion = self.units()
        self.assertTrue(
            self.call(
                "master.revise",
                {"id": "sku", "expected_version": 2, "reason": "new technical review"},
            )["ok"]
        )
        self.assertTrue(
            self.legacy(
                "master.confirm", {"id": "sku", "expected_version": 3, "evidence_ids": ["evidence"]}
            )["ok"]
        )
        result = self.call(
            "foundation.unit.convert",
            {"id": "new", "quantity": "2", "conversion": conversion, "sku_profile": sku},
        )
        self.assertEqual(result["code"], "REFERENCE_INVALID")

    def test_source_deduplication_replay_uses_canonical_id(self):
        args = {
            "id": "s1",
            "source_kind": "email_text",
            "content_text": "same",
            "provider": "mail",
            "account_ref": "a",
            "external_message_id": "msg",
            "author_claim": "synthetic",
        }
        self.assertTrue(self.legacy("source.register", args)["ok"])
        request = {
            "contract": "brant.trade-core/0.1.0",
            "command": "source.register",
            "idempotency_key": "canonical.replay",
            "args": {**args, "id": "s2"},
        }
        first = self.core.execute(self.editor, request)
        second = self.core.execute(self.editor, request)
        self.assertEqual(first["object_id"], "s1")
        self.assertTrue(second["replayed"], second)
        self.assertEqual(first["action_id"], second["action_id"])

    def test_private_source_cannot_be_probed_by_guessing_body(self):
        owner = Principal("t", "company.A", "private.owner")
        outsider = Principal("t", "company.A", "private.outsider")
        for p in [owner, outsider]:
            self.core.provision(p, ["*"], data_scope="own")
        args = {"id": "secret", "source_kind": "manual_text", "content_text": "secret-body"}
        self.assertTrue(self.legacy("source.register", args, who=owner)["ok"])
        errors = []
        for body in ["secret-body", "wrong-guess"]:
            result = self.legacy("source.register", {**args, "content_text": body}, who=outsider)
            errors.append((result["code"], result["field_errors"]))
        self.assertEqual(errors[0], errors[1])
        self.assertEqual(errors[0][0], "NOT_FOUND")

    def test_calculation_replay_rechecks_current_dependency_access(self):
        usd, cny, policy, fx = self.fx_setup()
        operator = Principal("t", "company.A", "calculator")
        self.core.provision(operator, ["*"], data_scope="company")
        args = {
            "id": "calculation",
            "amount": "10",
            "from_currency": usd,
            "to_currency": cny,
            "fx": fx,
            "policy": policy,
            "purpose": "cost_estimate",
        }
        first = self.call("foundation.fx.convert", args, who=operator, key="calculate.once")
        self.assertEqual(first["values"]["amount"], "71.23")
        self.core.provision(operator, ["*"], data_scope="own")
        self.assertFalse(
            self.call("foundation.fx.convert", args, who=operator, key="calculate.once")["ok"]
        )
        # Natural expiry alone must not make authorized historical replay execute again.
        self.assertTrue(self.call("foundation.fx.convert", args, key="editor.once")["ok"])
        self.core.clock = lambda: datetime(2026, 10, 24, tzinfo=UTC)
        replay = self.call("foundation.fx.convert", args, key="editor.once")
        self.assertTrue(replay["replayed"])
        self.assertEqual(replay["values"]["amount"], "71.23")

    def test_account_sensitive_permission_does_not_replace_owner_scope(self):
        cny = self.currency("CNY")
        self.master("customer", "customer")
        account = self.config(
            "bank_account",
            "private.bank",
            {
                "owner_kind": "party",
                "owner_id": "customer",
                "owner_row_version": 2,
                "bank_name": "test",
                "account_number": "SECRET12345678",
                "currency": cny,
                "purpose": "receipt",
            },
        )
        reader = Principal("t", "company.A", "private.reader")
        self.core.provision(reader, ["*"], data_scope="company")
        self.assertEqual(
            self.core.foundation_get(reader, "bank_account", account["id"])["data"][
                "account_number"
            ],
            "SECRET12345678",
        )
        self.core.provision(reader, ["*"], data_scope="own")
        with self.assertRaises(Rejected):
            self.core.foundation_get(reader, "bank_account", account["id"])

    def test_expired_and_future_publication_cannot_replace_active_rate(self):
        usd, cny, policy, fx = self.fx_setup()
        data = self.core.foundation_get(self.editor, "fx", fx["id"])["data"]
        for start, end, expected, revision in [
            ("2026-10-20T00:00:00Z", "2026-10-21T00:00:00Z", 2, 2),
            ("2026-10-24T00:00:00Z", "2026-10-25T00:00:00Z", 3, 3),
        ]:
            changed = {**data, "observed_at": start, "valid_from": start, "valid_until": end}
            self.config("fx", fx["id"], changed, expected=expected, publish=False)
            result = self.call(
                "foundation.publish",
                {
                    "id": fx["id"],
                    "kind": "fx",
                    "revision": revision,
                    "expected_version": expected + 1,
                    "reason": "test",
                },
                who=self.reviewer,
            )
            self.assertEqual(result["code"], "CONFIG_EXPIRED")
            self.assertEqual(self.core.foundation_get(self.editor, "fx", fx["id"])["revision"], 1)

    def test_contact_version_and_snapshot_evidence_are_preserved(self):
        usd, cny, policy, fx = self.fx_setup()
        company = self.company(cny)
        self.master("customer", "customer")
        self.master("contact", "contact", parent_customer_id="customer")
        terms, payment = self.trading()
        party = self.config(
            "party_profile",
            "customer.profile",
            {
                "party_id": "customer",
                "legal_name": "synthetic",
                "country": "CN",
                "addresses": [{"address_id": "a", "role": "buyer", "address": "test"}],
                "contact_refs": [{"id": "contact", "row_version": 2}],
                "trade_terms": terms,
                "payment_terms": payment,
            },
        )
        self.assertTrue(
            self.call(
                "foundation.snapshot",
                {
                    "id": "contact.snapshot",
                    "refs": [company, policy, party],
                    "purpose": "cost_estimate",
                },
            )["ok"]
        )
        before = self.core.foundation_get(self.editor, "snapshot", "contact.snapshot")
        self.assertEqual(
            {r["id"] for r in before["data"]["master_entries"]}, {"customer", "contact"}
        )
        self.call(
            "master.revise", {"id": "contact", "expected_version": 2, "reason": "changed contact"}
        )
        self.legacy(
            "master.upsert_draft",
            {
                "id": "contact",
                "expected_version": 3,
                "kind": "contact",
                "name": "new name",
                "parent_customer_id": "customer",
            },
        )
        self.legacy(
            "master.confirm", {"id": "contact", "expected_version": 4, "evidence_ids": ["evidence"]}
        )
        self.assertEqual(
            self.call(
                "foundation.snapshot",
                {
                    "id": "new.snapshot",
                    "refs": [company, policy, party],
                    "purpose": "cost_estimate",
                },
            )["code"],
            "REFERENCE_INVALID",
        )
        self.assertEqual(
            self.core.foundation_get(self.editor, "snapshot", "contact.snapshot"), before
        )

    def test_configuration_save_race_has_one_winner(self):
        from concurrent.futures import ThreadPoolExecutor
        from threading import Barrier

        self.currency("CNY")
        barrier = Barrier(2)

        def save(i):
            barrier.wait()
            return self.core.execute(
                self.editor,
                {
                    "contract": "brant.foundation/0.1.0",
                    "command": "foundation.save",
                    "idempotency_key": f"currency.race.{i}",
                    "args": {
                        "kind": "currency",
                        "id": "CNY",
                        "expected_version": 2,
                        "data": {
                            "code": "CNY",
                            "name": f"name{i}",
                            "minor_units": 2,
                            "rounding": "HALF_UP",
                        },
                        "evidence_ids": ["evidence"],
                    },
                },
            )

        with ThreadPoolExecutor(max_workers=2) as pool:
            answers = list(pool.map(save, [1, 2]))
        self.assertEqual(sum(a["ok"] for a in answers), 1)
        self.assertEqual([a["code"] for a in answers if not a["ok"]], ["VERSION_CONFLICT"])
        self.assertEqual(self.core.foundation_get(self.editor, "currency", "CNY")["revision"], 1)

    def test_attachment_limit_and_large_valid_content(self):
        small = base64.b64encode(b"A" * (1100 * 1024)).decode()
        args = {
            "id": "large",
            "file_name": "large.txt",
            "mime_type": "text/plain",
            "content_base64": small,
        }
        self.assertTrue(self.call("foundation.file.register", args)["ok"])
        large = base64.b64encode(b"A" * (10 * 1024 * 1024 + 1)).decode()
        self.assertEqual(
            self.call(
                "foundation.file.register", {**args, "id": "too.large", "content_base64": large}
            )["code"],
            "FILE_INVALID",
        )
