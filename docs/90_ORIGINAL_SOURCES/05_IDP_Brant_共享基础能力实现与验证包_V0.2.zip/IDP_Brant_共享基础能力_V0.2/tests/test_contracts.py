import copy
import json
import unittest

from brant_core.service import REQUEST_SCHEMA, REQUEST_VALIDATOR, RESPONSE_VALIDATOR, SCHEMAS


class ContractTests(unittest.TestCase):
    def test_document_examples_are_validated_with_standard_validator(self):
        fixtures = json.loads((SCHEMAS / "BC_T01_examples.json").read_text())
        self.assertTrue(REQUEST_VALIDATOR.is_valid(fixtures["valid_partial"]))
        self.assertFalse(REQUEST_VALIDATOR.is_valid(fixtures["invalid_null"]))
        self.assertFalse(REQUEST_VALIDATOR.is_valid(fixtures["invalid_extra"]))

    def test_email_requires_full_origin_identity(self):
        req = {
            "contract": "brant.trade-core/0.1.0",
            "command": "source.register",
            "idempotency_key": "k",
            "args": {"id": "s", "source_kind": "email_text", "content_text": "正文"},
        }
        self.assertFalse(REQUEST_VALIDATOR.is_valid(req))
        req["args"].update(
            provider="mail", account_ref="a", external_message_id="m", author_claim="buyer"
        )
        self.assertTrue(REQUEST_VALIDATOR.is_valid(req))

    def test_command_and_args_cannot_be_mixed_or_broadened(self):
        req = {
            "contract": "brant.trade-core/0.1.0",
            "command": "master.confirm",
            "idempotency_key": "k",
            "args": {"id": "c", "expected_version": 1, "evidence_ids": ["s"]},
        }
        self.assertTrue(REQUEST_VALIDATOR.is_valid(req))
        for field, value in [("grants", ["*"]), ("actor", "admin"), ("status", "confirmed")]:
            bad = copy.deepcopy(req)
            bad["args"][field] = value
            self.assertFalse(REQUEST_VALIDATOR.is_valid(bad))
        self.assertEqual(len(REQUEST_SCHEMA["oneOf"]), 8)

    def test_closed_response_disallows_forged_fields(self):
        success = {
            "ok": True,
            "action_id": "a",
            "object_id": "r",
            "row_version": 1,
            "status": "draft",
            "replayed": False,
        }
        self.assertTrue(RESPONSE_VALIDATOR.is_valid(success))
        self.assertFalse(RESPONSE_VALIDATOR.is_valid({**success, "approved": True}))

    def test_ids_and_decimal_strings_cannot_include_trailing_line_breaks(self):
        for bad in [
            {"id": "r\n", "expected_version": 0},
            {"id": "r", "expected_version": 0, "lines": [{"line_id": "L1", "quantity": "120\n"}]},
        ]:
            req = {
                "contract": "brant.trade-core/0.1.0",
                "command": "rfq.save_draft",
                "idempotency_key": "k",
                "args": bad,
            }
            self.assertFalse(REQUEST_VALIDATOR.is_valid(req))
