import sqlite3
import tempfile
import unittest
from pathlib import Path

from brant_core import Core, Principal
from brant_core.service import SCHEMAS
from brant_core.storage import initialize


class FoundationMigrationTests(unittest.TestCase):
    def legacy(self, path, has_audit=True):
        with sqlite3.connect(path, isolation_level=None) as db:
            initialize(db, SCHEMAS / "BC_T01_reference.sql")
            db.execute("INSERT INTO scope VALUES('t','c')")
            db.execute("INSERT INTO authorization VALUES('t','c','owner','[\"*\"]','human')")
            db.execute("INSERT INTO rfq VALUES('t','c','old',NULL,NULL,'draft',1,'[]')")
            if has_audit:
                db.execute(
                    "INSERT INTO audit_event(tenant,company,actor,event_id,command,object_id,outcome,code,correlation_id,recorded_at,reason) VALUES('t','c','owner','e','rfq.save_draft','old','succeeded',NULL,'trace','2026-10-21T00:00:00Z',NULL)"
                )

    def test_v1_migration_preserves_data_and_verifiable_owner(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "old.sqlite"
            self.legacy(path)
            core = Core(path)
            self.assertEqual(core.get(Principal("t", "c", "owner"), "rfq", "old")["row_version"], 1)
            self.assertEqual(
                [
                    e["object_id"]
                    for e in core.audit(Principal("t", "c", "owner"))
                    if e["outcome"] == "succeeded"
                ],
                ["old"],
            )
            reopened = Core(path)
            self.assertEqual(
                reopened.get(Principal("t", "c", "owner"), "rfq", "old")["status"], "draft"
            )

    def test_unverifiable_owner_migration_rolls_back(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "old.sqlite"
            self.legacy(path, False)
            with self.assertRaises(RuntimeError):
                Core(path)
            with sqlite3.connect(path) as db:
                self.assertEqual(
                    db.execute("SELECT version FROM schema_migration").fetchall(), [(1,)]
                )
                self.assertEqual(db.execute("SELECT row_version FROM rfq").fetchone()[0], 1)
                self.assertIsNone(
                    db.execute(
                        "SELECT name FROM sqlite_master WHERE name='foundation_root'"
                    ).fetchone()
                )
