"""Run the named suite once and retain complete local evidence."""

import argparse
import hashlib
import io
import json
import platform
import sqlite3
import sys
import unittest
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="evidence")
    args = parser.parse_args()
    target = Path(args.output)
    target.mkdir(parents=True, exist_ok=True)
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    log = stream.getvalue()
    (target / "tests.txt").write_text(log, encoding="utf-8")
    failures = [{"test": test.id(), "traceback": trace} for test, trace in result.failures + result.errors]
    report = {"generated_at_utc": datetime.now(timezone.utc).isoformat(), "python": platform.python_version(), "jsonschema": version("jsonschema"), "sqlite": sqlite3.sqlite_version, "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped), "passed": result.wasSuccessful(), "failure_details": failures, "evidence_scope": "synthetic fixtures; actual local SQLite transactions, threads and one worker process exit; no live model/EER/BIP/SMTP", "baseline_sha256": "5111c2986f9e6dd8578bdb09dd86a42d5322f41d5a9530753881a48c16c85d13", "schema_sha256": hashlib.sha256((ROOT / "q01/contracts/q01.schema.json").read_bytes()).hexdigest()}
    (target / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("tests_run", "failures", "errors", "skipped", "passed")}, ensure_ascii=False))
    if not result.wasSuccessful():
        print(log)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
