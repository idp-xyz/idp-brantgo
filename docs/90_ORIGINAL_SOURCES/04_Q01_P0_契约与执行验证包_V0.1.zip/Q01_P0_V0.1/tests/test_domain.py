import unittest
from decimal import Decimal as D

from q01.domain import RuleError, quote_hash, validate_acceptance, validate_quote
from q01.fixtures import NOW, dataset


class DomainTests(unittest.TestCase):
    def setUp(self):
        self.q, self.a, self.facts, _ = dataset()

    def check(self):
        self.q["business_hash"] = quote_hash(self.q)
        validate_quote(self.q, self.facts, NOW)

    def error(self, code):
        with self.assertRaises(RuleError) as found:
            self.check()
        self.assertEqual(found.exception.code, code)

    def test_synthetic_matrix_and_money(self):
        self.check()
        self.assertEqual(sum(D(x["base_quantity"]) for x in self.q["lines"]), D(120))
        self.assertEqual(sum(D(x["line_amount"]) for x in self.q["lines"]), D(960))

    def test_dozen_has_same_amount_and_quantity(self):
        self.q["lines"][0].update(quantity="2", uom="DOZEN", conversion_ref="conv.dozen.v1", unit_net_price="96.00")
        self.check()

    def test_incorrect_dozen_base_is_rejected(self):
        self.q["lines"][0].update(quantity="2", uom="DOZEN", conversion_ref="conv.dozen.v1", unit_net_price="96.00", base_quantity="2")
        self.error("BASE_QUANTITY_MISMATCH")

    def test_matrix_conflicting_with_source(self):
        self.facts.expected_quantities[next(iter(self.facts.expected_quantities))] = D(118)
        self.error("MATRIX_SOURCE_CONFLICT")

    def test_zero_quantity_is_semantically_invalid(self):
        self.q["lines"][0]["quantity"] = "0"
        self.error("QUANTITY_OUT_OF_RANGE")

    def test_duplicate_line_identity(self):
        self.q["lines"][1]["line_id"] = "L1"
        self.error("DUPLICATE_LINE")

    def test_line_amount_mismatch(self):
        self.q["lines"][0]["line_amount"] = "191.00"
        self.error("LINE_AMOUNT_MISMATCH")

    def test_included_charge_not_counted_again(self):
        self.q["terms"]["charges"] = [{"charge_id": "freight", "kind": "freight", "amount": "10.00", "included_in_item_prices": True}]
        self.check()
        self.q["total_amount"] = "970.00"
        self.error("CHARGE_DOUBLE_COUNT")

    def test_payment_plan_must_reconcile(self):
        self.q["terms"]["payment_stages"][0]["amount"] = "287.00"
        self.error("PAYMENT_TOTAL_MISMATCH")

    def test_passthrough_tax_cannot_inflate_margin(self):
        self.q["terms"]["charges"] = [{"charge_id": "tax", "kind": "tax_pass_through", "amount": "40.00", "included_in_item_prices": False}]
        self.q["total_amount"] = "1000.00"
        self.q["terms"]["payment_stages"][0]["amount"] = "300.00"
        self.q["terms"]["payment_stages"][1]["amount"] = "700.00"
        self.facts.costs["cost.660.USD.v1"] = ("USD", D(750))
        # 25% of gross would pass; the required net-sales margin is only 21.875%.
        self.error("MARGIN_APPROVAL_REQUIRED")

    def test_expired_quote(self):
        self.q["expires_at"] = "2026-10-21T08:59:59Z"
        self.error("QUOTE_EXPIRED")

    def test_missing_industry_confirmation(self):
        self.facts.sample_confirmations.clear()
        self.error("REQUIRED_CHECK_UNKNOWN")

    def test_estimated_date_is_not_committed(self):
        self.q["terms"]["delivery_kind"] = "estimated"
        self.error("DELIVERY_NOT_CONFIRMED")

    def test_cross_currency_cost_is_not_silently_subtracted(self):
        self.facts.costs["cost.660.USD.v1"] = ("CNY", D(660))
        self.error("COST_CURRENCY_MISMATCH")

    def test_unknown_pricing_policy(self):
        self.q["pricing_policy_ref"] = "unknown"
        self.error("PRICING_POLICY_UNKNOWN")

    def test_unapproved_low_margin_stops(self):
        self.facts.costs["cost.660.USD.v1"] = ("USD", D(900))
        self.error("MARGIN_APPROVAL_REQUIRED")

    def test_tampered_hash_rejected(self):
        self.q["business_hash"] = "a" * 64
        with self.assertRaisesRegex(RuleError, "BUSINESS_HASH_MISMATCH"):
            validate_quote(self.q, self.facts, NOW)

    def test_wrong_customer_or_revision_confirmation(self):
        for field, value in [("customer_id", "wrong"), ("quote_business_revision", 2)]:
            q, a, f, _ = dataset()
            a[field] = value
            with self.subTest(field=field), self.assertRaisesRegex(RuleError, "ACCEPTANCE_SCOPE_MISMATCH"):
                validate_acceptance(a, q, f, NOW)

    def test_confirmation_cannot_drop_lines(self):
        self.a["line_ids"].pop()
        with self.assertRaisesRegex(RuleError, "ACCEPTANCE_LINES_MISMATCH"):
            validate_acceptance(self.a, self.q, self.facts, NOW)

    def test_confirmation_time_conflict(self):
        self.a["verified_at"] = "2026-10-21T10:00:00Z"
        with self.assertRaisesRegex(RuleError, "ACCEPTANCE_TIME_CONFLICT"):
            validate_acceptance(self.a, self.q, self.facts, NOW)

    def test_confirmation_cannot_precede_quote_issuance(self):
        self.a["recorded_at"] = "2026-10-21T07:00:00Z"
        self.a["verified_at"] = "2026-10-21T07:30:00Z"
        with self.assertRaisesRegex(RuleError, "ACCEPTANCE_TIME_CONFLICT"):
            validate_acceptance(self.a, self.q, self.facts, NOW)


if __name__ == "__main__":
    unittest.main()
