import copy
import json
import os
import subprocess
import sys
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor

from q01.domain import RuleError, canonical, digest, quote_hash
from q01.fixtures import NOW, SCOPE, request
from q01.store import Engine
from tests.support import Harness


class ExecutionTests(unittest.TestCase):
    def setUp(self):
        self.h = Harness()
        self.addCleanup(self.h.tmp.cleanup)
        self.e = self.h.engine

    def ready(self):
        self.h.activate_quote()
        self.h.register()

    def test_local_quote_to_active_order_and_truthful_completion(self):
        result, _ = self.h.through_order()
        done = self.e.verify_and_complete("agent", SCOPE, "T1")
        self.assertEqual(done["status"], "satisfied")
        self.assertEqual(done["order_id"], result["order_id"])
        self.assertEqual(done["completion_actor"], "ai_with_required_review")
        self.assertEqual(done["model_calls"], 0)
        self.assertEqual(self.e.inspect("agent", SCOPE, "T1")["orders"], 1)

    def test_quote_only_cannot_complete_order_goal(self):
        self.h.activate_quote()
        result = self.e.verify_and_complete("agent", SCOPE, "T1")
        self.assertEqual(result["reason"], "ORDER_MISSING")
        self.assertEqual(self.e.inspect("agent", SCOPE, "T1")["task"]["state"], "verifying")

    def test_quote_ready_is_a_different_goal(self):
        self.h.activate_quote()
        self.e.create_task("reviewer", SCOPE, "T2", goal="quote_ready")
        self.e.transition("agent", SCOPE, "T2", "start", 1)
        self.e.transition("agent", SCOPE, "T2", "scope_ready", 2)
        result = self.e.verify_and_complete("agent", SCOPE, "T2")
        self.assertEqual(result["status"], "satisfied")
        self.assertNotIn("order_id", result)

    def test_draft_order_cannot_complete(self):
        self.ready()
        self.h.prepare()
        result = self.e.verify_and_complete("agent", SCOPE, "T1")
        self.assertEqual(result["reason"], "ORDER_NOT_ACTIVE")

    def test_missing_document_blocks_completion(self):
        self.h.through_order()
        self.h.facts.document_bindings.clear()
        result = self.e.verify_and_complete("agent", SCOPE, "T1")
        self.assertEqual(result["reason"], "DOCUMENT_BINDING_MISMATCH")

    def test_corrupt_order_customer_is_not_success(self):
        result, _ = self.h.through_order()
        with self.e.tx() as db:
            o = self.e.order(db, SCOPE, result["order_id"])
            o["customer_id"] = "wrong.customer"
            db.execute("UPDATE orders SET body=? WHERE t=? AND c=? AND id=?", (canonical(o), *self.e.sc(SCOPE), o["order_id"]))
        outcome = self.e.verify_and_complete("agent", SCOPE, "T1")
        self.assertEqual(outcome["reason"], "ORDER_QUOTE_MISMATCH")

    def test_same_action_replay_preserves_order_and_event_count(self):
        _, req = self.h.through_order()
        before = self.e.inspect("agent", SCOPE, "T1")
        r = copy.deepcopy(req)
        r.update(attempt_id="attempt.2", plan_revision=2)
        first = self.e.execute("agent", r)
        second = self.e.execute("agent", r)
        self.assertEqual(first, second)
        after = self.e.inspect("agent", SCOPE, "T1")
        self.assertEqual(after["orders"], 1)
        self.assertEqual(len(after["events"]), len(before["events"]))

    def test_same_key_with_changed_payload_conflicts(self):
        self.h.activate_quote()
        r = copy.deepcopy(self.h.activate_quote_request)
        r["payload"]["business_revision"] = 2
        r["payload_sha256"] = digest(r["payload"])
        with self.assertRaisesRegex(RuleError, "IDEMPOTENCY_PAYLOAD_CONFLICT"):
            self.e.execute("agent", r)

    def test_failure_before_outbox_commit_rolls_back_business_and_result(self):
        self.ready()
        req = self.h.prepare_request()
        original = self.e.event
        def fail_event(db, scope, kind, aggregate, payload):
            raise RuntimeError("injected failure before transaction commit")
        self.e.event = fail_event
        try:
            with self.assertRaisesRegex(RuntimeError, "injected failure"):
                self.e.execute("agent", req)
        finally:
            self.e.event = original
        self.assertEqual(self.e.inspect("agent", SCOPE, "T1")["orders"], 0)
        with self.e.tx() as db:
            row = db.execute("SELECT status,result FROM actions WHERE id=?", (req["action_id"],)).fetchone()
            self.assertEqual(row["status"], "planned")
            self.assertIsNone(row["result"])
        self.e.execute("agent", req)
        state = self.e.inspect("agent", SCOPE, "T1")
        self.assertEqual(state["orders"], 1)
        self.assertEqual(sum(x["event_type"] == "order.prepare" for x in state["events"]), 1)

    def test_new_key_does_not_bypass_conversion_slot(self):
        self.ready()
        self.h.prepare()
        with self.assertRaisesRegex(RuleError, "CONVERSION_SLOT_CONFLICT"):
            self.e.execute("agent", self.h.prepare_request("new.prepare"))

    def test_same_intent_cannot_be_registered_as_new_action(self):
        self.ready()
        r = self.h.prepare_request()
        self.e.admit("agent", r)
        r["action_id"] = r["idempotency_key"] = "different.action"
        with self.assertRaisesRegex(RuleError, "BUSINESS_INTENT_CONFLICT"):
            self.e.admit("agent", r)

    def test_stale_row_version_is_rejected(self):
        self.ready()
        r = self.h.prepare_request()
        r["expected_versions"][0]["row_version"] = 1
        with self.assertRaisesRegex(RuleError, "VERSION_CONFLICT"):
            self.e.execute("agent", r)

    def test_nonmaterial_row_version_refresh_reuses_approval(self):
        q = self.h.quote
        self.e.approve("reviewer", SCOPE, "AQ", "quote.activate", "Q1", q["business_hash"], "2026-10-27T00:00:00Z")
        with self.e.tx() as db:
            value = self.e.quote(db, SCOPE, "Q1", 1)
            value["row_version"] = 2
            db.execute("UPDATE quotes SET version=2,body=? WHERE t=? AND c=? AND id='Q1'", (canonical(value), *self.e.sc(SCOPE)))
        r = request("quote.activate", {"quote_id": "Q1", "business_revision": 1, "business_hash": q["business_hash"]}, action_id="activate.quote", versions=[{"object_type": "quote", "object_id": "Q1", "row_version": 1}], approvals=["AQ"])
        with self.assertRaisesRegex(RuleError, "VERSION_CONFLICT"):
            self.e.execute("agent", r)
        r["expected_versions"][0]["row_version"] = 2
        self.assertEqual(self.e.execute("agent", r)["row_version"], 3)

    def test_old_approval_cannot_approve_new_business_revision(self):
        self.h.activate_quote()
        q = copy.deepcopy(self.h.quote)
        q["business_revision"] = 2
        q["business_hash"] = quote_hash(q)
        self.e.add_quote("reviewer", q)
        self.e.create_task("reviewer", SCOPE, "T2", rev=2)
        self.e.transition("agent", SCOPE, "T2", "start", 1)
        self.e.transition("agent", SCOPE, "T2", "scope_ready", 2)
        r = request("quote.activate", {"quote_id": "Q1", "business_revision": 2, "business_hash": q["business_hash"]}, action_id="activate.rev2", task_id="T2", versions=[{"object_type": "quote", "object_id": "Q1", "row_version": 1}], approvals=["AQ"])
        with self.assertRaisesRegex(RuleError, "APPROVAL_STALE"):
            self.e.execute("agent", r)

    def test_grant_reference_is_checked(self):
        self.ready()
        r = self.h.prepare_request()
        r["grant_ref"] = "forged.grant"
        with self.assertRaisesRegex(RuleError, "GRANT_INVALID"):
            self.e.execute("agent", r)

    def test_revoked_actor_cannot_execute_or_read_old_result(self):
        self.ready()
        r = self.h.prepare_request()
        self.e.execute("agent", r)
        self.h.identity.revoked.add("agent")
        with self.assertRaisesRegex(RuleError, "PERMISSION_DENIED"):
            self.e.execute("agent", r)

    def test_tenant_scope_rejected_before_lookup(self):
        with self.assertRaisesRegex(RuleError, "SCOPE_MISMATCH"):
            self.e.inspect("other", SCOPE, "T1")

    def test_human_confirmation_identity_cannot_be_forged(self):
        self.h.activate_quote()
        a = copy.deepcopy(self.h.acceptance)
        a["verified_by"] = "agent"
        with self.assertRaisesRegex(RuleError, "VERIFIER_IDENTITY_MISMATCH"):
            self.e.register_acceptance("reviewer", a)
        with self.assertRaisesRegex(RuleError, "PERMISSION_DENIED"):
            self.e.register_acceptance("agent", self.h.acceptance)

    def test_duplicate_message_cannot_create_second_confirmation(self):
        self.ready()
        a = copy.deepcopy(self.h.acceptance)
        a["acceptance_id"] = "A2"
        with self.assertRaisesRegex(RuleError, "SOURCE_MESSAGE_DUPLICATE"):
            self.e.register_acceptance("reviewer", a)

    def test_takeover_fences_old_agent_and_records_manual_completion(self):
        self.ready()
        self.e.take_control("reviewer", SCOPE, "T1", 3)
        self.e.finish_control("reviewer", SCOPE, "T1")
        self.e.transition("reviewer", SCOPE, "T1", "resume", 5)
        r = self.h.prepare_request()
        with self.assertRaisesRegex(RuleError, "CONTROL_EPOCH_STALE"):
            self.e.execute("agent", r)
        r["control_epoch"] = 2
        prepared = self.e.execute("reviewer", r)
        activation = self.h.order_activation(prepared["order_id"])
        activation["control_epoch"] = 2
        self.e.execute("reviewer", activation)
        self.assertEqual(self.e.verify_and_complete("reviewer", SCOPE, "T1")["completion_actor"], "manual")

    def test_unknown_external_record_blocks_takeover_barrier(self):
        self.ready()
        r = self.h.prepare_request()
        self.e.admit("agent", r)
        # Fault injection only: no real external send is performed by this prototype.
        with self.e.tx() as db:
            db.execute("UPDATE actions SET status='unknown' WHERE id=?", (r["action_id"],))
        self.e.take_control("reviewer", SCOPE, "T1", 3)
        with self.assertRaisesRegex(RuleError, "EXTERNAL_RESULT_UNKNOWN"):
            self.e.finish_control("reviewer", SCOPE, "T1")

    def test_incompatible_persisted_bundle_stops_actions(self):
        self.ready()
        with self.e.tx() as db:
            t = self.e.task(db, SCOPE, "T1")
            bundle = json.loads(t["bundle"])
            bundle["application"] = "incompatible"
            db.execute("UPDATE tasks SET bundle=? WHERE id='T1'", (canonical(bundle),))
        with self.assertRaisesRegex(RuleError, "EXECUTION_BUNDLE_INCOMPATIBLE"):
            self.e.execute("agent", self.h.prepare_request())

    def test_terminal_task_rejects_new_forward_action(self):
        self.h.through_order()
        self.e.verify_and_complete("agent", SCOPE, "T1")
        with self.assertRaisesRegex(RuleError, "TASK_NOT_RUNNING"):
            self.e.execute("agent", self.h.prepare_request("late.action"))

    def test_generic_transition_cannot_set_completed(self):
        with self.assertRaisesRegex(RuleError, "TRANSITION_NOT_ALLOWED"):
            self.e.transition("agent", SCOPE, "T1", "completed", 3)

    def test_expired_approval_is_not_reused(self):
        self.ready()
        self.e.clock = lambda: "2026-10-27T01:00:00Z"
        with self.assertRaisesRegex(RuleError, "APPROVAL_STALE"):
            self.e.execute("agent", self.h.prepare_request())

    def test_superseded_quote_cannot_accept_late_confirmation(self):
        self.h.activate_quote()
        with self.e.tx() as db:
            q = self.e.quote(db, SCOPE, "Q1", 1)
            q.update(status="superseded", row_version=3)
            db.execute("UPDATE quotes SET status='superseded',version=3,body=? WHERE t=? AND c=? AND id='Q1'", (canonical(q), *self.e.sc(SCOPE)))
        with self.assertRaisesRegex(RuleError, "QUOTE_NOT_EFFECTIVE"):
            self.e.register_acceptance("reviewer", self.h.acceptance)

    def test_new_revision_does_not_get_second_full_conversion_slot(self):
        self.ready()
        self.h.prepare()
        q = copy.deepcopy(self.h.quote)
        q["business_revision"] = 2
        q["business_hash"] = quote_hash(q)
        self.e.add_quote("reviewer", q)
        self.e.create_task("reviewer", SCOPE, "T2", rev=2)
        self.e.transition("agent", SCOPE, "T2", "start", 1)
        self.e.transition("agent", SCOPE, "T2", "scope_ready", 2)
        self.e.approve("reviewer", SCOPE, "AQ2", "quote.activate", "Q1", q["business_hash"], "2026-10-27T00:00:00Z")
        activate = request("quote.activate", {"quote_id": "Q1", "business_revision": 2, "business_hash": q["business_hash"]}, action_id="activate.rev2", task_id="T2", versions=[{"object_type": "quote", "object_id": "Q1", "row_version": 1}], approvals=["AQ2"])
        self.e.execute("agent", activate)
        a = copy.deepcopy(self.h.acceptance)
        a.update(acceptance_id="A2", quote_business_revision=2, quote_business_hash=q["business_hash"], source_message_id="message.2")
        self.e.register_acceptance("reviewer", a)
        prepare = request("order.prepare", {"quote_id": "Q1", "business_revision": 2, "business_hash": q["business_hash"], "acceptance_id": "A2", "conversion_slot": "full_v1"}, action_id="prepare.rev2", task_id="T2", versions=[{"object_type": "quote", "object_id": "Q1", "row_version": 2}], approvals=["AQ2"])
        with self.assertRaisesRegex(RuleError, "CONVERSION_SLOT_CONFLICT"):
            self.e.execute("agent", prepare)

    def test_commit_then_real_worker_exit_is_recovered_without_duplicate(self):
        self.ready()
        prepared = self.h.prepare()
        req = self.h.order_activation(prepared["order_id"])
        code = """
import json,os,sys
from q01.fixtures import dataset,NOW
from q01.store import Engine
q,a,f,i=dataset()
e=Engine(sys.argv[1],i,f,lambda:NOW)
e.execute('agent',json.loads(sys.argv[2]))
os._exit(73)  # After local commit, before the runtime can receive/acknowledge.
"""
        child = subprocess.run([sys.executable, "-c", code, str(self.h.path), json.dumps(req)], capture_output=True, text=True, timeout=15)
        self.assertEqual(child.returncode, 73, child.stderr)
        reopened = Engine(self.h.path, self.h.identity, self.h.facts, lambda: NOW)
        before = reopened.inspect("agent", SCOPE, "T1")
        recovered = reopened.execute("agent", req)
        after = reopened.inspect("agent", SCOPE, "T1")
        self.assertEqual(recovered["status"], "active")
        self.assertEqual(before["orders"], after["orders"])
        self.assertEqual(len(before["events"]), len(after["events"]))
        self.assertEqual(reopened.verify_and_complete("agent", SCOPE, "T1")["status"], "satisfied")


class SQLiteConcurrencyTests(unittest.TestCase):
    def setUp(self):
        self.h = Harness()
        self.addCleanup(self.h.tmp.cleanup)
        self.h.activate_quote()
        self.h.register()

    def race(self, functions):
        barrier = threading.Barrier(len(functions))
        def run(fn):
            barrier.wait(timeout=5)
            try:
                return fn()
            except RuleError as e:
                return e.code
        with ThreadPoolExecutor(max_workers=len(functions)) as pool:
            return list(pool.map(run, functions))

    def test_two_connections_same_action_one_effect(self):
        req = self.h.prepare_request()
        results = self.race([lambda: self.h.engine.execute("agent", copy.deepcopy(req)) for _ in range(2)])
        self.assertEqual(results[0], results[1])
        state = self.h.engine.inspect("agent", SCOPE, "T1")
        self.assertEqual(state["orders"], 1)
        self.assertEqual(sum(x["event_type"] == "order.prepare" for x in state["events"]), 1)

    def test_two_intents_same_quote_only_one_conversion(self):
        results = self.race([lambda: self.h.engine.execute("agent", self.h.prepare_request("prepare.a")), lambda: self.h.engine.execute("agent", self.h.prepare_request("prepare.b"))])
        self.assertEqual(sum(isinstance(x, dict) for x in results), 1)
        self.assertIn("CONVERSION_SLOT_CONFLICT", results)

    def test_takeover_vs_commit_is_serialized_and_old_epoch_stops(self):
        results = self.race([lambda: self.h.engine.execute("agent", self.h.prepare_request()), lambda: self.h.engine.take_control("reviewer", SCOPE, "T1", 3)])
        state = self.h.engine.inspect("reviewer", SCOPE, "T1")
        self.assertEqual(state["task"]["epoch"], 2)
        self.assertEqual(state["task"]["state"], "stopping")
        self.assertLessEqual(state["orders"], 1)
        with self.assertRaisesRegex(RuleError, "CONTROL_EPOCH_STALE"):
            self.h.engine.execute("agent", self.h.prepare_request("late.old.epoch"))
        self.assertTrue(all(x is None or isinstance(x, dict) or x == "CONTROL_EPOCH_STALE" for x in results))


if __name__ == "__main__":
    unittest.main()
