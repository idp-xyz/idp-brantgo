import copy
import unittest

from jsonschema import Draft202012Validator, ValidationError

from q01.contracts import SCHEMA, validate
from q01.fixtures import dataset
from tests.support import Harness


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.q, self.a, _, _ = dataset()

    def test_meta_schema_and_all_definition_references(self):
        Draft202012Validator.check_schema(SCHEMA)
        for name in SCHEMA["$defs"]:
            with self.subTest(definition=name):
                s = {k: v for k, v in SCHEMA.items() if k != "oneOf"}
                s["$ref"] = "#/$defs/" + name
                Draft202012Validator.check_schema(s)

    def test_quote_and_human_acceptance_shapes(self):
        validate("Quote", self.q)
        validate("Acceptance", self.a)

    def test_root_dispatches_quote_and_acceptance(self):
        validator = Draft202012Validator(SCHEMA)
        validator.validate(self.q)
        validator.validate(self.a)

    def test_invalid_or_missing_timezone(self):
        for value in ["2026-02-30T00:00:00Z", "2026-10-21T09:00:00", "not-a-time"]:
            with self.subTest(value=value), self.assertRaises(ValidationError):
                self.q["issued_at"] = value
                validate("Quote", self.q)

    def test_invalid_delivery_date(self):
        self.q["terms"]["delivery_date"] = "2026-02-30"
        with self.assertRaises(ValidationError):
            validate("Quote", self.q)

    def test_non_decimal_and_overprecision(self):
        for value in [8.0, "NaN", "1e3", "-1", "8.123456789"]:
            with self.subTest(value=value), self.assertRaises(ValidationError):
                self.q["lines"][0]["unit_net_price"] = value
                validate("Quote", self.q)

    def test_unknown_field_cannot_grant_admin(self):
        self.q["admin"] = True
        with self.assertRaises(ValidationError):
            validate("Quote", self.q)

    def test_acceptance_is_full_only(self):
        self.a["kind"] = "partial"
        with self.assertRaises(ValidationError):
            validate("Acceptance", self.a)

    def test_acceptance_lines_cannot_repeat(self):
        self.a["line_ids"].append("L1")
        with self.assertRaises(ValidationError):
            validate("Acceptance", self.a)

    def test_payload_matches_registered_command(self):
        h = Harness()
        self.addCleanup(h.tmp.cleanup)
        req = h.prepare_request()
        validate("ActionRequest", req)
        req["command_type"] = "quote.activate"
        with self.assertRaises(ValidationError):
            validate("ActionRequest", req)

    def test_unknown_command_and_missing_argument(self):
        h = Harness()
        self.addCleanup(h.tmp.cleanup)
        req = h.prepare_request()
        bad = copy.deepcopy(req)
        bad["command_type"] = "sql.execute"
        with self.assertRaises(ValidationError):
            validate("ActionRequest", bad)
        del req["payload"]["acceptance_id"]
        with self.assertRaises(ValidationError):
            validate("ActionRequest", req)

    def test_required_check_cannot_claim_satisfied_without_evidence(self):
        value = {"check_id": "sample", "required": True, "result": "satisfied", "evidence_refs": [], "message_code": "OK", "verifier_version": "v1", "observed_at": "2026-10-21T09:00:00Z", "versions": [{"object_type": "quote", "object_id": "Q1", "row_version": 1}]}
        with self.assertRaises(ValidationError):
            validate("CheckResult", value)


if __name__ == "__main__":
    unittest.main()
