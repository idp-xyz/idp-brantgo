import tempfile
import unittest
from pathlib import Path

from q01.__main__ import demo


class CliTests(unittest.TestCase):
    def test_order_demo_emits_truthful_reproducible_trace(self):
        with tempfile.TemporaryDirectory() as root:
            result = demo(root)
            self.assertEqual(result["outcome"]["status"], "satisfied")
            self.assertEqual(result["orders"], 1)
            self.assertFalse(result["live_llm"])
            self.assertFalse(result["eer_connected"])
            self.assertTrue((Path(root) / "trace.json").exists())
            with self.assertRaises(FileExistsError):
                demo(root)

    def test_quote_goal_does_not_claim_an_order(self):
        with tempfile.TemporaryDirectory() as root:
            result = demo(root, "quote")
            self.assertEqual(result["outcome"]["status"], "satisfied")
            self.assertEqual(result["orders"], 0)
            self.assertNotIn("order_id", result["outcome"])
