import tempfile
from pathlib import Path

from q01.domain import order_hash
from q01.fixtures import NOW, SCOPE, dataset, request
from q01.store import Engine


class Harness:
    def __init__(self, path=None):
        self.tmp = tempfile.TemporaryDirectory() if path is None else None
        self.path = Path(path or Path(self.tmp.name) / "test.db")
        self.quote, self.acceptance, self.facts, self.identity = dataset()
        self.engine = Engine(self.path, self.identity, self.facts, lambda: NOW)
        self.engine.add_quote("reviewer", self.quote)
        self.engine.create_task("reviewer", SCOPE, "T1")
        self.engine.transition("agent", SCOPE, "T1", "start", 1)
        self.engine.transition("agent", SCOPE, "T1", "scope_ready", 2)

    def activate_quote(self):
        self.engine.approve("reviewer", SCOPE, "AQ", "quote.activate", "Q1", self.quote["business_hash"], "2026-10-27T00:00:00Z")
        self.activate_quote_request = request("quote.activate", {"quote_id": "Q1", "business_revision": 1, "business_hash": self.quote["business_hash"]}, action_id="activate.quote", versions=[{"object_type": "quote", "object_id": "Q1", "row_version": 1}], approvals=["AQ"])
        return self.engine.execute("agent", self.activate_quote_request)

    def register(self):
        self.engine.register_acceptance("reviewer", self.acceptance)

    def prepare_request(self, action_id="prepare.order"):
        return request("order.prepare", {"quote_id": "Q1", "business_revision": 1, "business_hash": self.quote["business_hash"], "acceptance_id": "A1", "conversion_slot": "full_v1"}, action_id=action_id, versions=[{"object_type": "quote", "object_id": "Q1", "row_version": 2}], approvals=["AQ"])

    def prepare(self):
        return self.engine.execute("agent", self.prepare_request())

    def order_activation(self, oid):
        with self.engine.tx() as db:
            order = self.engine.order(db, SCOPE, oid)
        self.engine.approve("reviewer", SCOPE, "AO", "order.activate", oid, order_hash(order), "2026-10-27T00:00:00Z")
        return request("order.activate", {"order_id": oid, "quote_id": "Q1", "quote_business_hash": self.quote["business_hash"], "acceptance_id": "A1"}, action_id="activate.order", versions=[{"object_type": "order", "object_id": oid, "row_version": 1}], approvals=["AO"])

    def through_order(self):
        self.activate_quote()
        self.register()
        result = self.prepare()
        req = self.order_activation(result["order_id"])
        return self.engine.execute("agent", req), req
