"""Q01 contract and SQLite execution validation subset, version 0.1.0."""

__version__ = "0.1.0"
