"""Synthetic S-D dataset; review/document assertions are explicit test doubles."""

import hashlib
from copy import deepcopy
from decimal import Decimal as D

from .domain import digest, quote_hash
from .ports import FixtureFacts, FixtureIdentity

SCOPE = {"tenant_id": "tenant.A", "company_id": "company.A"}
NOW = "2026-10-21T09:00:00Z"


def evidence(name, kind="confirmed_document"):
    return {"evidence_id": name, "content_sha256": hashlib.sha256(("SYNTHETIC:" + name).encode()).hexdigest(), "source_kind": kind, "access_ref": "access." + name}


def dataset():
    rfq, tech, reply = evidence("e.rfq", "external_material"), evidence("e.tech"), evidence("e.reply", "external_material")
    lines = []
    for i, (color, size, qty) in enumerate([("red", "S", 24), ("red", "M", 36), ("blue", "S", 12), ("blue", "M", 48)], 1):
        lines.append({"line_id": f"L{i}", "sku_id": f"ST01.{color}.{size}", "sku_revision": 1, "quantity": str(qty), "uom": "PCS", "base_quantity": str(qty), "base_uom": "PCS", "conversion_ref": "conv.pcs.v1", "unit_net_price": "8.00", "line_amount": f"{qty * 8}.00", "color_code": color, "size_code": size})
    quote = {"scope": deepcopy(SCOPE), "quote_id": "Q1", "root_quote_id": "QR1", "business_revision": 1, "row_version": 1, "status": "draft", "customer_id": "customer.1", "contact_id": "contact.1", "industry_profile": "apparel", "industry_config_ref": "apparel.cfg.v1", "currency": "USD", "issued_at": "2026-10-21T08:00:00Z", "expires_at": "2026-10-28T08:00:00Z", "terms": {"trade_term_ref": "term.test.v1", "named_place": "TEST_NAMED_PLACE", "payment_stages": [{"stage_id": "deposit", "trigger": "on_order", "offset_days": 0, "amount": "288.00"}, {"stage_id": "balance", "trigger": "before_dispatch", "offset_days": 0, "amount": "672.00"}], "delivery_kind": "committed", "delivery_date": "2026-11-15", "delivery_anchor_ref": "delivery.confirmed.1", "freight_payer": "seller", "charges": []}, "lines": lines, "total_amount": "960.00", "cost_snapshot_ref": "cost.660.USD.v1", "pricing_policy_ref": "pricing.v1", "fx_snapshot_ref": "fx.USD.USD.v1", "source_refs": [rfq, tech], "business_hash": "0" * 64, "document_refs": [], "approval_refs": []}
    quote["business_hash"] = quote_hash(quote)
    doc = {**evidence("e.pdf", "derived"), "quote_business_hash": quote["business_hash"]}
    quote["document_refs"] = [doc]
    acceptance = {"scope": deepcopy(SCOPE), "acceptance_id": "A1", "customer_id": "customer.1", "contact_id": "contact.1", "quote_id": "Q1", "quote_business_revision": 1, "quote_business_hash": quote["business_hash"], "kind": "full_unconditional", "source_ref": reply, "source_message_id": "message.1", "source_author": "SYNTHETIC_CUSTOMER", "forward_chain_ref": None, "recorded_at": "2026-10-21T08:30:00Z", "verified_at": "2026-10-21T08:45:00Z", "verification_mode": "human_verified", "verified_by": "reviewer", "line_ids": [x["line_id"] for x in lines]}
    facts = FixtureFacts(units={"conv.pcs.v1": ("PCS", "PCS", D(1)), "conv.dozen.v1": ("DOZEN", "PCS", D(12))}, skus={x["sku_id"]: (1, x["color_code"], x["size_code"]) for x in lines}, sources={r["evidence_id"]: {"scope": deepcopy(SCOPE), "sha256": r["content_sha256"], "kind": r["source_kind"]} for r in [rfq, tech, reply]}, costs={"cost.660.USD.v1": ("USD", D(660))}, trade_terms={"term.test.v1"}, delivery_evidence={"delivery.confirmed.1"}, fx_snapshots={"fx.USD.USD.v1": ("USD", "USD", D(1))}, sample_confirmations={tech["content_sha256"]: "satisfied"}, document_bindings={(doc["evidence_id"], doc["content_sha256"]): quote["business_hash"]}, expected_quantities={rfq["content_sha256"]: D(120)})
    writes = {"read", "quote.create", "quote.activate", "order.prepare", "order.activate", "task.create", "task.transition"}
    identity = FixtureIdentity({"agent": {"scope": deepcopy(SCOPE), "permissions": writes, "mode": "ai"}, "reviewer": {"scope": deepcopy(SCOPE), "permissions": writes | {"approve", "acceptance.verify", "task.control"}, "mode": "manual"}, "other": {"scope": {"tenant_id": "tenant.B", "company_id": "company.B"}, "permissions": writes | {"approve"}, "mode": "manual"}})
    return quote, acceptance, facts, identity


def request(command, payload, *, action_id, task_id="T1", epoch=1, versions, approvals):
    return {"scope": deepcopy(SCOPE), "task_id": task_id, "business_intent_id": "intent." + action_id, "action_id": action_id, "attempt_id": "attempt.1", "plan_revision": 1, "control_epoch": epoch, "grant_ref": "fixture.grant", "idempotency_key": action_id, "command_type": command, "payload": deepcopy(payload), "payload_sha256": digest(payload), "expected_versions": versions, "approval_refs": approvals}
