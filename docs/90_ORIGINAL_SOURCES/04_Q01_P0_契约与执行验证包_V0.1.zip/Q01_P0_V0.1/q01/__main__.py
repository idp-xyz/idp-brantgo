"""Local, scripted demonstration. No LLM/EER/BIP/network calls are made."""

import argparse
import json
from pathlib import Path

from jsonschema import Draft202012Validator

from .contracts import SCHEMA
from .domain import canonical, order_hash
from .fixtures import NOW, SCOPE, dataset, request
from .store import Engine


def demo(output, scenario="order"):
    root = Path(output)
    root.mkdir(parents=True, exist_ok=True)
    path = root / "q01.db"
    if path.exists():
        raise FileExistsError("Use a new output directory; existing database is preserved.")
    quote, acceptance, facts, identity = dataset()
    engine = Engine(path, identity, facts, lambda: NOW)
    engine.add_quote("reviewer", quote)
    engine.create_task("reviewer", SCOPE, "T1", goal="quote_ready" if scenario == "quote" else "order_active")
    engine.transition("agent", SCOPE, "T1", "start", 1)
    engine.transition("agent", SCOPE, "T1", "scope_ready", 2)
    engine.approve("reviewer", SCOPE, "AQ", "quote.activate", "Q1", quote["business_hash"], "2026-10-27T00:00:00Z")
    activate = request("quote.activate", {"quote_id": "Q1", "business_revision": 1, "business_hash": quote["business_hash"]}, action_id="activate.quote", versions=[{"object_type": "quote", "object_id": "Q1", "row_version": 1}], approvals=["AQ"])
    engine.execute("agent", activate)
    if scenario == "order":
        engine.register_acceptance("reviewer", acceptance)
        prepare = request("order.prepare", {"quote_id": "Q1", "business_revision": 1, "business_hash": quote["business_hash"], "acceptance_id": "A1", "conversion_slot": "full_v1"}, action_id="prepare.order", versions=[{"object_type": "quote", "object_id": "Q1", "row_version": 2}], approvals=["AQ"])
        prepared = engine.execute("agent", prepare)
        with engine.tx() as db:
            order = engine.order(db, SCOPE, prepared["order_id"])
        engine.approve("reviewer", SCOPE, "AO", "order.activate", order["order_id"], order_hash(order), "2026-10-27T00:00:00Z")
        activate_order = request("order.activate", {"order_id": order["order_id"], "quote_id": "Q1", "quote_business_hash": quote["business_hash"], "acceptance_id": "A1"}, action_id="activate.order", versions=[{"object_type": "order", "object_id": order["order_id"], "row_version": 1}], approvals=["AO"])
        engine.execute("agent", activate_order)
    result = engine.verify_and_complete("agent", SCOPE, "T1")
    snapshot = {"prototype": "Q01-P0-validation-subset-0.1.0", "environment": "synthetic_fixtures", "fixture_clock": NOW, "live_llm": False, "eer_connected": False, "bip_connected": False, "document_and_industry_facts": "test_doubles", "outcome": result, **engine.inspect("agent", SCOPE, "T1")}
    (root / "trace.json").write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (root / "input_quote.json").write_text(json.dumps(quote, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return snapshot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("check-schema")
    p = sub.add_parser("demo")
    p.add_argument("--output", required=True)
    p.add_argument("--scenario", choices=["quote", "order"], default="order")
    args = parser.parse_args()
    if args.command == "check-schema":
        Draft202012Validator.check_schema(SCHEMA)
        print(json.dumps({"meta_schema": "passed", "draft": "2020-12", "definitions": len(SCHEMA["$defs"])}))
    else:
        result = demo(args.output, args.scenario)
        print(json.dumps({"environment": result["environment"], "outcome": result["outcome"], "trace": str(Path(args.output) / "trace.json")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
