"""Ports and explicitly synthetic facts. These are not identity/CMI integrations."""

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Protocol

from .domain import ensure


class IdentityPort(Protocol):
    def authorize(self, actor: str, permission: str, scope: dict, grant_ref=None) -> str:
        """Return an authenticated execution mode, or reject. No client self-grants."""


class RuntimePort(Protocol):
    def submit(self, execution_ref: dict) -> str: ...
    def lookup(self, runtime_operation_id: str) -> dict: ...


class ChannelPort(Protocol):
    def send(self, operation_id: str, approved_content: dict) -> dict: ...
    def lookup(self, operation_id: str) -> dict: ...


@dataclass
class FixtureIdentity:
    # Only trusted local test/demo code constructs this mapping. No HTTP auth exists.
    actors: dict
    revoked: set = field(default_factory=set)

    def authorize(self, actor, permission, scope, grant_ref=None):
        profile = self.actors.get(actor)
        ensure(profile is not None and actor not in self.revoked, "PERMISSION_DENIED")
        ensure(profile["scope"] == scope, "SCOPE_MISMATCH")
        ensure(permission in profile["permissions"], "PERMISSION_DENIED")
        if grant_ref is not None:
            ensure(grant_ref == "fixture.grant", "GRANT_INVALID")
        return profile["mode"]


@dataclass
class FixtureFacts:
    units: dict
    skus: dict
    sources: dict
    costs: dict
    trade_terms: set
    delivery_evidence: set
    fx_snapshots: dict
    sample_confirmations: dict
    document_bindings: dict
    expected_quantities: dict
    pricing_policies: set = field(default_factory=lambda: {"pricing.v1"})
    industry_config: str = "apparel.cfg.v1"
    minimum_margin: Decimal = Decimal("0.25")

    def source_matches(self, ref, scope):
        entry = self.sources.get(ref["evidence_id"])
        return bool(entry and entry["scope"] == scope and entry["sha256"] == ref["content_sha256"] and entry["kind"] == ref["source_kind"])

    def check_industry(self, quote):
        ensure(quote["industry_profile"] == "apparel" and quote["industry_config_ref"] == self.industry_config, "INDUSTRY_PROFILE_UNSUPPORTED")
        refs = {x["evidence_id"]: x["content_sha256"] for x in quote["source_refs"]}
        ensure(self.sample_confirmations.get(refs.get("e.tech")) == "satisfied", "REQUIRED_CHECK_UNKNOWN")
        from decimal import Decimal
        expected = self.expected_quantities.get(refs.get("e.rfq"))
        ensure(expected is not None, "REQUIRED_CHECK_UNKNOWN")
        ensure(sum(Decimal(x["base_quantity"]) for x in quote["lines"]) == expected, "MATRIX_SOURCE_CONFLICT")

    def check_document(self, quote):
        ensure(bool(quote["document_refs"]), "DOCUMENT_MISSING")
        for ref in quote["document_refs"]:
            ensure(ref["quote_business_hash"] == quote["business_hash"], "DOCUMENT_BINDING_MISMATCH")
            ensure(self.document_bindings.get((ref["evidence_id"], ref["content_sha256"])) == quote["business_hash"], "DOCUMENT_BINDING_MISMATCH")


class UnconnectedRuntime:
    def submit(self, execution_ref):
        raise NotImplementedError("EER adapter not connected")

    def lookup(self, runtime_operation_id):
        raise NotImplementedError("EER adapter not connected")


class UnconnectedChannel:
    def send(self, operation_id, approved_content):
        raise NotImplementedError("BIP/email adapter not connected")

    def lookup(self, operation_id):
        raise NotImplementedError("BIP/email adapter not connected")
