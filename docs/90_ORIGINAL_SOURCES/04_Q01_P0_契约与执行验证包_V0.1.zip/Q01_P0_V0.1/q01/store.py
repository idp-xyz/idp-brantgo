"""SQLite local transactions; no claim about PostgreSQL/distributed isolation."""

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone

from .contracts import SCHEMA_PATH, validate
from .domain import (RuleError, canonical, digest, ensure, order_hash, time,
                     validate_acceptance, validate_order, validate_quote)

DDL = """
CREATE TABLE IF NOT EXISTS quotes(t TEXT,c TEXT,id TEXT,rev INTEGER,root TEXT,
 status TEXT,version INTEGER,hash TEXT,body TEXT NOT NULL,
 PRIMARY KEY(t,c,id,rev));
CREATE TABLE IF NOT EXISTS tasks(t TEXT,c TEXT,id TEXT,goal TEXT,qid TEXT,qrev INTEGER,
 customer TEXT,state TEXT,mode TEXT,epoch INTEGER,version INTEGER,actor TEXT,bundle TEXT,
 PRIMARY KEY(t,c,id));
CREATE TABLE IF NOT EXISTS approvals(t TEXT,c TEXT,id TEXT,command TEXT,target TEXT,
 hash TEXT,expires TEXT,reviewer TEXT,active INTEGER NOT NULL,
 PRIMARY KEY(t,c,id));
CREATE TABLE IF NOT EXISTS acceptances(t TEXT,c TEXT,id TEXT,body TEXT NOT NULL,
 PRIMARY KEY(t,c,id));
CREATE TABLE IF NOT EXISTS orders(t TEXT,c TEXT,id TEXT,root TEXT,slot TEXT,
 status TEXT,version INTEGER,body TEXT NOT NULL, PRIMARY KEY(t,c,id),
 UNIQUE(t,c,root,slot));
CREATE TABLE IF NOT EXISTS actions(t TEXT,c TEXT,id TEXT,intent TEXT,command TEXT,
 task TEXT,hash TEXT,status TEXT,request TEXT,result TEXT,
 PRIMARY KEY(t,c,id),UNIQUE(t,c,intent,command));
CREATE TABLE IF NOT EXISTS attempts(t TEXT,c TEXT,action TEXT,attempt TEXT,request TEXT,
 PRIMARY KEY(t,c,action,attempt));
CREATE TABLE IF NOT EXISTS outbox(seq INTEGER PRIMARY KEY AUTOINCREMENT,t TEXT,c TEXT,
 event_type TEXT,aggregate_id TEXT,payload TEXT NOT NULL);
"""
TERMINAL = {"completed", "closed_unfulfilled", "cancelled", "failed"}
SCHEMA_SHA256 = hashlib.sha256(SCHEMA_PATH.read_bytes()).hexdigest()


class Engine:
    def __init__(self, path, identity, facts, clock=None):
        self.path, self.identity, self.facts = str(path), identity, facts
        self.clock = clock or (lambda: datetime.now(timezone.utc).isoformat())
        with sqlite3.connect(self.path, timeout=10) as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript(DDL)

    @contextmanager
    def tx(self):
        db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA busy_timeout=10000")
        try:
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def sc(scope):
        return scope["tenant_id"], scope["company_id"]

    def event(self, db, scope, kind, aggregate, payload):
        db.execute("INSERT INTO outbox(t,c,event_type,aggregate_id,payload) VALUES(?,?,?,?,?)", (*self.sc(scope), kind, aggregate, canonical(payload)))

    def quote(self, db, scope, qid, rev):
        row = db.execute("SELECT * FROM quotes WHERE t=? AND c=? AND id=? AND rev=?", (*self.sc(scope), qid, rev)).fetchone()
        ensure(row is not None, "QUOTE_NOT_FOUND")
        q = json.loads(row["body"])
        ensure((q["status"], q["row_version"], q["business_hash"], q["scope"]) == (row["status"], row["version"], row["hash"], scope), "STORAGE_INCONSISTENT")
        return q

    def task(self, db, scope, tid):
        row = db.execute("SELECT * FROM tasks WHERE t=? AND c=? AND id=?", (*self.sc(scope), tid)).fetchone()
        ensure(row is not None, "TASK_NOT_FOUND")
        return dict(row)

    def add_quote(self, actor, quote):
        scope = quote["scope"]
        with self.tx() as db:
            self.identity.authorize(actor, "quote.create", scope)
            validate_quote(quote, self.facts, self.clock())
            db.execute("INSERT INTO quotes VALUES(?,?,?,?,?,?,?,?,?)", (*self.sc(scope), quote["quote_id"], quote["business_revision"], quote["root_quote_id"], quote["status"], quote["row_version"], quote["business_hash"], canonical(quote)))

    def create_task(self, actor, scope, tid, qid="Q1", rev=1, goal="order_active"):
        ensure(goal in {"quote_ready", "order_active"}, "GOAL_UNSUPPORTED")
        with self.tx() as db:
            self.identity.authorize(actor, "task.create", scope)
            q = self.quote(db, scope, qid, rev)
            bundle = {"application": "0.1.0", "schema_sha256": SCHEMA_SHA256, "canonicalization": "canonical.trade.v1", "industry_config": q["industry_config_ref"], "pricing_policy": q["pricing_policy_ref"], "driver": "local_scripted", "model": None, "eer": None, "bip": None}
            db.execute("INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (*self.sc(scope), tid, goal, qid, rev, q["customer_id"], "created", "ai", 1, 1, None, canonical(bundle)))
            self.event(db, scope, "task.created", tid, {"goal": goal, "quote": qid, "revision": rev})

    def transition(self, actor, scope, tid, event, expected_version):
        transitions = {"start": ({"created"}, "scoping"), "scope_ready": ({"scoping"}, "running"), "need_input": ({"running", "verifying"}, "waiting_input"), "need_approval": ({"running", "verifying"}, "waiting_approval"), "wait_external": ({"running"}, "waiting_external"), "pause": ({"running", "verifying", "waiting_input", "waiting_approval", "waiting_external"}, "paused"), "resume": ({"paused", "waiting_input", "waiting_approval", "waiting_external"}, "running")}
        ensure(event in transitions, "TRANSITION_NOT_ALLOWED")
        with self.tx() as db:
            mode = self.identity.authorize(actor, "task.transition", scope)
            t = self.task(db, scope, tid)
            ensure(t["version"] == expected_version, "VERSION_CONFLICT")
            ensure(mode == t["mode"], "CONTROL_MODE_MISMATCH")
            source, target = transitions[event]
            ensure(t["state"] in source, "TRANSITION_NOT_ALLOWED")
            db.execute("UPDATE tasks SET state=?,version=version+1 WHERE t=? AND c=? AND id=?", (target, *self.sc(scope), tid))
            self.event(db, scope, "task." + event, tid, {"state": target})

    def approve(self, actor, scope, aid, command, target, content_hash, expires):
        ensure(command in {"quote.activate", "order.activate"}, "APPROVAL_COMMAND_UNSUPPORTED")
        ensure(time(expires) > time(self.clock()), "APPROVAL_EXPIRED")
        with self.tx() as db:
            self.identity.authorize(actor, "approve", scope)
            # This trusted local review entry requires a real target and exact content.
            if command == "quote.activate":
                matches = db.execute("SELECT hash FROM quotes WHERE t=? AND c=? AND id=? AND hash=?", (*self.sc(scope), target, content_hash)).fetchall()
                ensure(bool(matches), "APPROVAL_STALE")
            else:
                order = self.order(db, scope, target)
                ensure(order_hash(order) == content_hash, "APPROVAL_STALE")
            db.execute("INSERT INTO approvals VALUES(?,?,?,?,?,?,?,?,1)", (*self.sc(scope), aid, command, target, content_hash, expires, actor))
            self.event(db, scope, "approval.granted", aid, {"command": command, "target": target, "hash": content_hash})

    def check_approval(self, db, scope, refs, command, target, content_hash):
        found = False
        for aid in refs:
            a = db.execute("SELECT * FROM approvals WHERE t=? AND c=? AND id=?", (*self.sc(scope), aid)).fetchone()
            if a and a["active"] and a["command"] == command and a["target"] == target and a["hash"] == content_hash and time(self.clock()) < time(a["expires"]):
                found = True
        ensure(found, "APPROVAL_STALE")

    def register_acceptance(self, actor, acceptance):
        scope = acceptance["scope"]
        with self.tx() as db:
            self.identity.authorize(actor, "acceptance.verify", scope)
            ensure(acceptance["verified_by"] == actor, "VERIFIER_IDENTITY_MISMATCH")
            q = self.quote(db, scope, acceptance["quote_id"], acceptance["quote_business_revision"])
            validate_quote(q, self.facts, self.clock(), active=True)
            validate_acceptance(acceptance, q, self.facts, self.clock())
            existing = db.execute("SELECT body FROM acceptances WHERE t=? AND c=? AND id=?", (*self.sc(scope), acceptance["acceptance_id"])).fetchone()
            if existing:
                ensure(existing["body"] == canonical(acceptance), "ACCEPTANCE_IMMUTABLE")
                return
            # A channel source can be imported repeatedly only as the same evidence.
            records = db.execute("SELECT body FROM acceptances WHERE t=? AND c=?", self.sc(scope)).fetchall()
            def same_confirmation(record):
                value = json.loads(record["body"])
                return value["source_message_id"] == acceptance["source_message_id"] and value["quote_id"] == acceptance["quote_id"] and value["quote_business_revision"] == acceptance["quote_business_revision"]
            ensure(not any(same_confirmation(x) for x in records), "SOURCE_MESSAGE_DUPLICATE")
            db.execute("INSERT INTO acceptances VALUES(?,?,?,?)", (*self.sc(scope), acceptance["acceptance_id"], canonical(acceptance)))
            self.event(db, scope, "acceptance.verified", acceptance["acceptance_id"], {"quote": q["quote_id"], "revision": q["business_revision"]})

    def acceptance(self, db, scope, aid):
        r = db.execute("SELECT body FROM acceptances WHERE t=? AND c=? AND id=?", (*self.sc(scope), aid)).fetchone()
        ensure(r is not None, "ACCEPTANCE_MISSING")
        return json.loads(r["body"])

    def order(self, db, scope, oid):
        r = db.execute("SELECT * FROM orders WHERE t=? AND c=? AND id=?", (*self.sc(scope), oid)).fetchone()
        ensure(r is not None, "ORDER_MISSING")
        o = json.loads(r["body"])
        ensure((o["status"], o["row_version"], o["scope"]) == (r["status"], r["version"], scope), "STORAGE_INCONSISTENT")
        return o

    def admit(self, actor, request):
        validate("ActionRequest", request)
        ensure(request["idempotency_key"] == request["action_id"], "IDEMPOTENCY_KEY_MISMATCH")
        ensure(request["payload_sha256"] == digest(request["payload"]), "PAYLOAD_HASH_MISMATCH")
        scope = request["scope"]
        h = digest({k: request[k] for k in ("scope", "business_intent_id", "command_type", "payload")})
        with self.tx() as db:
            self.identity.authorize(actor, request["command_type"], scope, request["grant_ref"])
            self.task(db, scope, request["task_id"])
            row = db.execute("SELECT * FROM actions WHERE t=? AND c=? AND id=?", (*self.sc(scope), request["action_id"])).fetchone()
            if row:
                ensure(row["hash"] == h and row["task"] == request["task_id"], "IDEMPOTENCY_PAYLOAD_CONFLICT")
                return
            try:
                db.execute("INSERT INTO actions VALUES(?,?,?,?,?,?,?,?,?,?)", (*self.sc(scope), request["action_id"], request["business_intent_id"], request["command_type"], request["task_id"], h, "planned", canonical(request), None))
            except sqlite3.IntegrityError as e:
                raise RuleError("BUSINESS_INTENT_CONFLICT") from e

    @staticmethod
    def expected(request, kind, oid, version):
        versions = [x for x in request["expected_versions"] if x["object_type"] == kind and x["object_id"] == oid]
        ensure(len(versions) == 1 and versions[0]["row_version"] == version, "VERSION_CONFLICT")

    def execute(self, actor, request):
        self.admit(actor, request)  # Durable intent exists before the transaction below.
        scope, p = request["scope"], request["payload"]
        with self.tx() as db:
            mode = self.identity.authorize(actor, request["command_type"], scope, request["grant_ref"])
            action = db.execute("SELECT * FROM actions WHERE t=? AND c=? AND id=?", (*self.sc(scope), request["action_id"])).fetchone()
            if action["status"] == "succeeded":
                return json.loads(action["result"])  # Authorized read of an existing result.
            t = self.task(db, scope, request["task_id"])
            bundle = json.loads(t["bundle"])
            ensure(bundle["schema_sha256"] == SCHEMA_SHA256 and bundle["application"] == "0.1.0" and bundle["canonicalization"] == "canonical.trade.v1", "EXECUTION_BUNDLE_INCOMPATIBLE")
            ensure(t["epoch"] == request["control_epoch"], "CONTROL_EPOCH_STALE")
            ensure(t["mode"] == mode, "CONTROL_MODE_MISMATCH")
            ensure(t["state"] == "running", "TASK_NOT_RUNNING")
            db.execute("INSERT OR IGNORE INTO attempts VALUES(?,?,?,?,?)", (*self.sc(scope), request["action_id"], request["attempt_id"], canonical(request)))
            command = request["command_type"]
            if command == "dispatch.send":
                raise RuleError("TOOL_UNAVAILABLE")
            q = self.quote(db, scope, t["qid"], t["qrev"])
            ensure(bundle["industry_config"] == q["industry_config_ref"] and bundle["pricing_policy"] == q["pricing_policy_ref"], "EXECUTION_BUNDLE_INCOMPATIBLE")
            ensure(q["customer_id"] == t["customer"], "GOAL_CUSTOMER_MISMATCH")
            ensure(p["quote_id"] == q["quote_id"], "GOAL_QUOTE_MISMATCH")
            if command in {"quote.activate", "order.prepare"}:
                ensure(p["business_revision"] == q["business_revision"] and p["business_hash"] == q["business_hash"], "BUSINESS_HASH_MISMATCH")
                self.expected(request, "quote", q["quote_id"], q["row_version"])
            else:
                ensure(p["quote_business_hash"] == q["business_hash"], "BUSINESS_HASH_MISMATCH")
            validate_quote(q, self.facts, self.clock(), active=(command != "quote.activate"))
            if command == "quote.activate":
                self.check_approval(db, scope, request["approval_refs"], command, q["quote_id"], q["business_hash"])
                q.update(status="active", row_version=q["row_version"] + 1, approval_refs=request["approval_refs"])
                db.execute("UPDATE quotes SET status=?,version=?,body=? WHERE t=? AND c=? AND id=? AND rev=?", (q["status"], q["row_version"], canonical(q), *self.sc(scope), q["quote_id"], q["business_revision"]))
                result = {"quote_id": q["quote_id"], "business_revision": q["business_revision"], "row_version": q["row_version"]}
            else:
                self.check_approval(db, scope, q["approval_refs"], "quote.activate", q["quote_id"], q["business_hash"])
                acceptance = self.acceptance(db, scope, p["acceptance_id"])
                validate_acceptance(acceptance, q, self.facts, self.clock())
                if command == "order.prepare":
                    ensure(db.execute("SELECT id FROM orders WHERE t=? AND c=? AND root=? AND slot=?", (*self.sc(scope), q["root_quote_id"], p["conversion_slot"])).fetchone() is None, "CONVERSION_SLOT_CONFLICT")
                    oid = "O." + digest({"scope": scope, "root": q["root_quote_id"], "slot": p["conversion_slot"]})[:24]
                    o = {k: deepcopy(q[k]) for k in ("scope", "customer_id", "currency", "terms", "lines", "total_amount")}
                    o.update(order_id=oid, source_quote_id=q["quote_id"], source_quote_revision=q["business_revision"], source_quote_hash=q["business_hash"], acceptance_id=acceptance["acceptance_id"], status="draft", row_version=1, approval_refs=deepcopy(q["approval_refs"]), conversion_slot=p["conversion_slot"])
                    validate_order(o, q, acceptance)
                    db.execute("INSERT INTO orders VALUES(?,?,?,?,?,?,?,?)", (*self.sc(scope), oid, q["root_quote_id"], p["conversion_slot"], "draft", 1, canonical(o)))
                else:
                    o = self.order(db, scope, p["order_id"])
                    self.expected(request, "order", o["order_id"], o["row_version"])
                    ensure(o["status"] in {"draft", "pending_approval"}, "ORDER_NOT_DRAFT")
                    validate_order(o, q, acceptance)
                    self.check_approval(db, scope, request["approval_refs"], "order.activate", o["order_id"], order_hash(o))
                    o.update(status="active", row_version=o["row_version"] + 1, approval_refs=request["approval_refs"])
                    db.execute("UPDATE orders SET status=?,version=?,body=? WHERE t=? AND c=? AND id=?", (o["status"], o["row_version"], canonical(o), *self.sc(scope), o["order_id"]))
                result = {"order_id": o["order_id"], "status": o["status"], "row_version": o["row_version"]}
            db.execute("UPDATE actions SET status='succeeded',result=? WHERE t=? AND c=? AND id=?", (canonical(result), *self.sc(scope), request["action_id"]))
            self.event(db, scope, command, result.get("order_id", q["quote_id"]), result)
            return result

    def take_control(self, actor, scope, tid, expected_version):
        with self.tx() as db:
            self.identity.authorize(actor, "task.control", scope)
            t = self.task(db, scope, tid)
            ensure(t["version"] == expected_version, "VERSION_CONFLICT")
            ensure(t["state"] not in TERMINAL and t["state"] != "stopping", "TRANSITION_NOT_ALLOWED")
            db.execute("UPDATE tasks SET state='stopping',epoch=epoch+1,version=version+1 WHERE t=? AND c=? AND id=?", (*self.sc(scope), tid))
            self.event(db, scope, "control.requested", tid, {"epoch": t["epoch"] + 1})

    def finish_control(self, actor, scope, tid, target_mode="manual"):
        ensure(target_mode in {"manual", "ai"}, "CONTROL_MODE_UNSUPPORTED")
        with self.tx() as db:
            self.identity.authorize(actor, "task.control", scope)
            t = self.task(db, scope, tid)
            ensure(t["state"] == "stopping", "TRANSITION_NOT_ALLOWED")
            unknown = db.execute("SELECT 1 FROM actions WHERE t=? AND c=? AND task=? AND status IN ('submitted','unknown')", (*self.sc(scope), tid)).fetchone()
            ensure(unknown is None, "EXTERNAL_RESULT_UNKNOWN")
            db.execute("UPDATE tasks SET state='paused',mode=?,version=version+1 WHERE t=? AND c=? AND id=?", (target_mode, *self.sc(scope), tid))
            self.event(db, scope, "control.changed", tid, {"mode": target_mode})

    def verify_and_complete(self, actor, scope, tid):
        with self.tx() as db:
            mode = self.identity.authorize(actor, "task.transition", scope)
            t = self.task(db, scope, tid)
            ensure(mode == t["mode"], "CONTROL_MODE_MISMATCH")
            ensure(t["state"] in {"running", "verifying"}, "TASK_NOT_RUNNING")
            bundle = json.loads(t["bundle"])
            ensure(bundle["schema_sha256"] == SCHEMA_SHA256 and bundle["application"] == "0.1.0" and bundle["canonicalization"] == "canonical.trade.v1", "EXECUTION_BUNDLE_INCOMPATIBLE")
            q = self.quote(db, scope, t["qid"], t["qrev"])
            ensure(bundle["industry_config"] == q["industry_config_ref"] and bundle["pricing_policy"] == q["pricing_policy_ref"], "EXECUTION_BUNDLE_INCOMPATIBLE")
            try:
                ensure(q["customer_id"] == t["customer"], "GOAL_CUSTOMER_MISMATCH")
                validate_quote(q, self.facts, self.clock(), active=True)
                self.check_approval(db, scope, q["approval_refs"], "quote.activate", q["quote_id"], q["business_hash"])
                self.facts.check_document(q)
                pending = db.execute("SELECT 1 FROM actions WHERE t=? AND c=? AND task=? AND status IN ('submitted','unknown')", (*self.sc(scope), tid)).fetchone()
                ensure(pending is None, "EXTERNAL_RESULT_UNKNOWN")
                result = {"goal": t["goal"], "quote_id": q["quote_id"], "total_amount": q["total_amount"], "currency": q["currency"]}
                if t["goal"] == "order_active":
                    r = db.execute("SELECT id FROM orders WHERE t=? AND c=? AND root=? AND slot='full_v1'", (*self.sc(scope), q["root_quote_id"])).fetchone()
                    ensure(r is not None, "ORDER_MISSING")
                    o = self.order(db, scope, r["id"])
                    a = self.acceptance(db, scope, o["acceptance_id"])
                    validate_acceptance(a, q, self.facts, self.clock())
                    validate_order(o, q, a)
                    ensure(o["status"] == "active", "ORDER_NOT_ACTIVE")
                    self.check_approval(db, scope, o["approval_refs"], "order.activate", o["order_id"], order_hash(o))
                    result["order_id"] = o["order_id"]
            except RuleError as e:
                status = "unknown" if e.code in {"REQUIRED_CHECK_UNKNOWN", "EXTERNAL_RESULT_UNKNOWN"} else "unsatisfied"
                result = {"status": status, "reason": e.code, "environment": "synthetic_fixtures"}
                db.execute("UPDATE tasks SET state='verifying',version=version+1 WHERE t=? AND c=? AND id=?", (*self.sc(scope), tid))
                self.event(db, scope, "goal.not_satisfied", tid, result)
                return result
            result.update(status="satisfied", completion_actor="manual" if mode == "manual" else "ai_with_required_review", environment="synthetic_fixtures", model_calls=0)
            db.execute("UPDATE tasks SET state='completed',actor=?,version=version+1 WHERE t=? AND c=? AND id=?", (result["completion_actor"], *self.sc(scope), tid))
            self.event(db, scope, "goal.satisfied", tid, result)
            return result

    def inspect(self, actor, scope, tid):
        with self.tx() as db:
            self.identity.authorize(actor, "read", scope)
            t = self.task(db, scope, tid)
            events = [dict(x) for x in db.execute("SELECT seq,event_type,aggregate_id,payload FROM outbox WHERE t=? AND c=? ORDER BY seq", self.sc(scope))]
            return {"task": t, "events": events, "orders": db.execute("SELECT count(*) FROM orders WHERE t=? AND c=?", self.sc(scope)).fetchone()[0]}
