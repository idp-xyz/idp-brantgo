"""Deterministic predicates for the deliberately bounded P0 fixture profile."""

import hashlib
import json
import unicodedata
from copy import deepcopy
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP, localcontext

from .contracts import validate

D = Decimal


class RuleError(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def ensure(condition, code):
    if not condition:
        raise RuleError(code)


def time(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    ensure(parsed.utcoffset() is not None, "TIMEZONE_REQUIRED")
    return parsed


def canonical(value):
    def norm(x):
        if isinstance(x, str):
            return unicodedata.normalize("NFC", x)
        if isinstance(x, dict):
            return {k: norm(v) for k, v in x.items()}
        if isinstance(x, list):
            return [norm(v) for v in x]
        return x
    return json.dumps(norm(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value):
    return hashlib.sha256(("canonical.trade.v1\n" + canonical(value)).encode("utf-8")).hexdigest()


def quote_hash(quote):
    # Ordered lines remain ordered. Decimal fields alone are normalized, never IDs.
    data = deepcopy(quote)
    for k in ("row_version", "status", "business_hash", "document_refs", "approval_refs"):
        data.pop(k, None)
    decimal_fields = {"quantity", "base_quantity", "unit_net_price", "line_amount", "total_amount", "amount"}
    def normalize(x):
        if isinstance(x, dict):
            for k, v in x.items():
                if k in decimal_fields:
                    x[k] = format(D(v).normalize(), "f")
                else:
                    normalize(v)
        elif isinstance(x, list):
            for v in x:
                normalize(v)
    normalize(data)
    data["source_refs"].sort(key=lambda x: x["evidence_id"])
    return digest(data)


def validate_quote(quote, facts, now, *, active=False):
    validate("Quote", quote)
    ensure(quote["business_hash"] == quote_hash(quote), "BUSINESS_HASH_MISMATCH")
    ensure(time(quote["issued_at"]) < time(quote["expires_at"]), "INVALID_VALIDITY_RANGE")
    ensure(time(quote["issued_at"]) <= time(now) < time(quote["expires_at"]), "QUOTE_EXPIRED")
    ensure(quote["status"] in ({"active"} if active else {"draft", "pending_approval"}), "QUOTE_NOT_EFFECTIVE")
    ensure(len({x["line_id"] for x in quote["lines"]}) == len(quote["lines"]), "DUPLICATE_LINE")
    total = D(0)
    with localcontext() as ctx:
        ctx.prec = 34
        for line in quote["lines"]:
            qty, base, price = (D(line[k]) for k in ("quantity", "base_quantity", "unit_net_price"))
            ensure(0 < qty <= D("1000000") and 0 < base <= D("1000000"), "QUANTITY_OUT_OF_RANGE")
            ensure(0 < price <= D("1000000"), "PRICE_OUT_OF_RANGE")
            factor = facts.units.get(line["conversion_ref"])
            ensure(factor == (line["uom"], line["base_uom"], {"PCS": D(1), "DOZEN": D(12)}[line["uom"]]), "UNIT_REFERENCE_MISMATCH")
            ensure(qty * factor[2] == base, "BASE_QUANTITY_MISMATCH")
            item = facts.skus.get(line["sku_id"])
            ensure(item == (line["sku_revision"], line["color_code"], line["size_code"]), "SKU_REFERENCE_MISMATCH")
            amount = (qty * price).quantize(D("0.01"), rounding=ROUND_HALF_UP)
            ensure(amount == D(line["line_amount"]), "LINE_AMOUNT_MISMATCH")
            total += amount
        all_charges = sum((D(x["amount"]) for x in quote["terms"]["charges"]), D(0))
        extra = sum((D(x["amount"]) for x in quote["terms"]["charges"] if not x["included_in_item_prices"]), D(0))
        actual = D(quote["total_amount"])
        if actual != total + extra and actual == total + all_charges:
            raise RuleError("CHARGE_DOUBLE_COUNT")
        ensure(actual == total + extra and 0 < actual <= D("1000000000000"), "QUOTE_TOTAL_MISMATCH")
        stages = quote["terms"]["payment_stages"]
        ensure(len({x["stage_id"] for x in stages}) == len(stages), "DUPLICATE_PAYMENT_STAGE")
        ensure(sum((D(x["amount"]) for x in stages), D(0)) == actual, "PAYMENT_TOTAL_MISMATCH")
        ensure(quote["terms"]["trade_term_ref"] in facts.trade_terms, "TRADE_TERM_UNKNOWN")
        ensure(quote["terms"]["delivery_kind"] == "committed", "DELIVERY_NOT_CONFIRMED")
        ensure(quote["terms"]["delivery_anchor_ref"] in facts.delivery_evidence, "DELIVERY_EVIDENCE_MISSING")
        fx = facts.fx_snapshots.get(quote["fx_snapshot_ref"])
        ensure(fx is not None and fx[0] == fx[1] == quote["currency"] and fx[2] == D(1), "FX_SNAPSHOT_UNKNOWN")
        ensure(quote["pricing_policy_ref"] in facts.pricing_policies, "PRICING_POLICY_UNKNOWN")
        cost = facts.costs.get(quote["cost_snapshot_ref"])
        ensure(cost is not None, "COST_SNAPSHOT_UNKNOWN")
        ensure(cost[0] == quote["currency"], "COST_CURRENCY_MISMATCH")
        passthrough = sum((D(x["amount"]) for x in quote["terms"]["charges"] if x["kind"] == "tax_pass_through"), D(0))
        net_sales = actual - passthrough
        ensure(net_sales > 0, "NET_SALES_INVALID")
        ensure((net_sales - cost[1]) / net_sales >= facts.minimum_margin, "MARGIN_APPROVAL_REQUIRED")
    ensure(all(facts.source_matches(r, quote["scope"]) for r in quote["source_refs"]), "SOURCE_EVIDENCE_MISMATCH")
    facts.check_industry(quote)


def validate_acceptance(acceptance, quote, facts, now):
    validate("Acceptance", acceptance)
    for key in ("scope", "customer_id", "contact_id", "quote_id"):
        ensure(acceptance[key] == quote[key], "ACCEPTANCE_SCOPE_MISMATCH")
    ensure(acceptance["quote_business_revision"] == quote["business_revision"] and acceptance["quote_business_hash"] == quote["business_hash"], "ACCEPTANCE_SCOPE_MISMATCH")
    ensure(set(acceptance["line_ids"]) == {x["line_id"] for x in quote["lines"]}, "ACCEPTANCE_LINES_MISMATCH")
    ensure(time(acceptance["recorded_at"]) <= time(acceptance["verified_at"]) <= time(now), "ACCEPTANCE_TIME_CONFLICT")
    ensure(time(quote["issued_at"]) <= time(acceptance["verified_at"]), "ACCEPTANCE_TIME_CONFLICT")
    ensure(time(acceptance["verified_at"]) < time(quote["expires_at"]), "QUOTE_EXPIRED")
    ensure(facts.source_matches(acceptance["source_ref"], quote["scope"]), "SOURCE_EVIDENCE_MISMATCH")


def order_hash(order):
    return digest({k: v for k, v in order.items() if k not in {"status", "row_version", "approval_refs"}})


def validate_order(order, quote, acceptance):
    validate("Order", order)
    equal = ("scope", "customer_id", "currency", "terms", "lines", "total_amount")
    ensure(all(order[k] == quote[k] for k in equal), "ORDER_QUOTE_MISMATCH")
    ensure(order["source_quote_id"] == quote["quote_id"] and order["source_quote_revision"] == quote["business_revision"] and order["source_quote_hash"] == quote["business_hash"], "ORDER_QUOTE_MISMATCH")
    ensure(order["acceptance_id"] == acceptance["acceptance_id"], "ORDER_ACCEPTANCE_MISMATCH")
