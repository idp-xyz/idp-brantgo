"""Explicit schema/format checks. No remote schema loading is permitted."""

import json
import re
from datetime import date, datetime
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

SCHEMA_PATH = Path(__file__).parent / "contracts" / "q01.schema.json"
SCHEMA = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
Draft202012Validator.check_schema(SCHEMA)
FORMATS = FormatChecker()


@FORMATS.checks("date-time", raises=(ValueError, TypeError))
def timestamp_format(value):
    if not isinstance(value, str):
        return True
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})", value):
        return False
    return datetime.fromisoformat(value.replace("Z", "+00:00")).utcoffset() is not None


@FORMATS.checks("date", raises=(ValueError, TypeError))
def date_format(value):
    if not isinstance(value, str):
        return True
    return bool(re.fullmatch(r"\d{4}-\d{2}-\d{2}", value)) and date.fromisoformat(value) is not None


def validate(name: str, value: dict) -> None:
    # $defs are bundled locally; runtime values cannot supply new schemas.
    if name not in SCHEMA["$defs"]:
        raise ValueError(f"Unknown contract: {name}")
    contract = {k: v for k, v in SCHEMA.items() if k != "oneOf"}
    contract["$ref"] = f"#/$defs/{name}"
    Draft202012Validator(contract, format_checker=FORMATS).validate(value)
